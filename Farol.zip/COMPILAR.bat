@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

REM =====================================================================
REM  FAROL - COMPILAR O APK
REM =====================================================================
REM  Basta dar dois cliques neste arquivo.
REM  Tudo o que acontecer fica gravado em build_log.txt, na mesma pasta.
REM =====================================================================

set "LOG=%~dp0build_log.txt"

echo ================================================== > "%LOG%"
echo FAROL - compilacao iniciada em %DATE% %TIME%      >> "%LOG%"
echo ================================================== >> "%LOG%"
echo. >> "%LOG%"

echo.
echo  ================================================
echo   FAROL - gerando o APK
echo  ================================================
echo.

REM ---------------------------------------------------------------
REM  PASSO 1 - o Flutter esta instalado?
REM ---------------------------------------------------------------
echo  [1/6] Procurando o Flutter...
echo ----- PASSO 1: onde esta o flutter ----- >> "%LOG%"
where flutter >> "%LOG%" 2>&1
if errorlevel 1 (
    echo.
    echo  *** FLUTTER NAO ENCONTRADO ***
    echo  Instale em https://docs.flutter.dev/get-started/install/windows
    echo. >> "%LOG%"
    echo RESULTADO: FLUTTER_NAO_ENCONTRADO >> "%LOG%"
    goto fim
)
call flutter --version >> "%LOG%" 2>&1

REM ---------------------------------------------------------------
REM  PASSO 2 - guarda o codigo antes de mexer nas pastas
REM ---------------------------------------------------------------
echo  [2/6] Protegendo o codigo-fonte...
echo. >> "%LOG%"
echo ----- PASSO 2: backup do lib/ e do pubspec ----- >> "%LOG%"
if exist "%~dp0_backup" rmdir /s /q "%~dp0_backup"
mkdir "%~dp0_backup" 2>nul
xcopy /e /i /y /q "%~dp0lib" "%~dp0_backup\lib" >> "%LOG%" 2>&1
xcopy /e /i /y /q "%~dp0test" "%~dp0_backup\test" >> "%LOG%" 2>&1
copy /y "%~dp0pubspec.yaml" "%~dp0_backup\pubspec.yaml" >> "%LOG%" 2>&1

REM ---------------------------------------------------------------
REM  PASSO 3 - cria as pastas do Android (android/, gradle etc.)
REM ---------------------------------------------------------------
echo  [3/6] Criando as pastas do Android...
echo. >> "%LOG%"
echo ----- PASSO 3: flutter create ----- >> "%LOG%"
call flutter create . --project-name farol --org br.com.motorista --platforms=android >> "%LOG%" 2>&1

REM  devolve o codigo original (o flutter create sobrescreve o main.dart)
xcopy /e /i /y /q "%~dp0_backup\lib" "%~dp0lib" >> "%LOG%" 2>&1
xcopy /e /i /y /q "%~dp0_backup\test" "%~dp0test" >> "%LOG%" 2>&1
copy /y "%~dp0_backup\pubspec.yaml" "%~dp0pubspec.yaml" >> "%LOG%" 2>&1
rmdir /s /q "%~dp0_backup"

REM ---------------------------------------------------------------
REM  PASSO 4 - permissoes de camera e galeria no AndroidManifest
REM ---------------------------------------------------------------
echo  [4/6] Aplicando as permissoes do app...
echo. >> "%LOG%"
echo ----- PASSO 4: permissoes ----- >> "%LOG%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0patch_manifest.ps1" >> "%LOG%" 2>&1

REM ---------------------------------------------------------------
REM  PASSO 5 - baixa os pacotes
REM ---------------------------------------------------------------
echo  [5/6] Baixando as dependencias...
echo. >> "%LOG%"
echo ----- PASSO 5: flutter pub get ----- >> "%LOG%"
call flutter pub get >> "%LOG%" 2>&1

REM  Gera o icone do app (o farol azul) em todos os tamanhos
echo. >> "%LOG%"
echo ----- PASSO 5b: icone do app ----- >> "%LOG%"
call dart run flutter_launcher_icons >> "%LOG%" 2>&1

REM  Analise estatica: e aqui que aparecem os erros de codigo, se houver
echo. >> "%LOG%"
echo ----- PASSO 5c: flutter analyze ----- >> "%LOG%"
call flutter analyze >> "%LOG%" 2>&1

REM ---------------------------------------------------------------
REM  PASSO 6 - compila o APK
REM ---------------------------------------------------------------
echo  [6/6] Compilando o APK... (a primeira vez demora, e normal)
echo. >> "%LOG%"
echo ----- PASSO 6: flutter build apk ----- >> "%LOG%"
call flutter build apk --release >> "%LOG%" 2>&1

echo. >> "%LOG%"
if exist "%~dp0build\app\outputs\flutter-apk\app-release.apk" (
    echo RESULTADO: APK_GERADO_COM_SUCESSO >> "%LOG%"
    echo CAMINHO: %~dp0build\app\outputs\flutter-apk\app-release.apk >> "%LOG%"
    echo.
    echo  ================================================
    echo   PRONTO! O APK esta em:
    echo   build\app\outputs\flutter-apk\app-release.apk
    echo  ================================================
) else (
    echo RESULTADO: FALHOU >> "%LOG%"
    echo.
    echo  A compilacao falhou. O arquivo build_log.txt tem o motivo.
)

:fim
echo. >> "%LOG%"
echo ===== FIM DO LOG ===== >> "%LOG%"
echo.
echo  O log completo esta em: build_log.txt
echo.
pause
