"""
=======================================================================
 DESLIGA O R8 (otimizador de código) NA COMPILAÇÃO DE RELEASE
=======================================================================
 POR QUE ISSO É NECESSÁRIO:
 O plugin de OCR (google_mlkit_text_recognition) faz referência aos
 reconhecedores de chinês, japonês, coreano e devanágari. O Farol só usa
 o alfabeto latino, então esses módulos não entram no app — e o R8 aborta
 a compilação reclamando de "Missing class ...ChineseTextRecognizerOptions".

 A solução é desligar o R8 no release. O que muda na prática:
   • o APK fica alguns MB maior;
   • o app funciona exatamente igual (o R8 só encolhe/ofusca o código).

 Este script é chamado pelo workflow logo depois do `flutter create`,
 porque é ele que gera o android/app/build.gradle.kts.
=======================================================================
"""

import pathlib
import sys

RAIZ = pathlib.Path('android/app')

# ---------------------------------------------------------------------
# 1) Regras de ProGuard (rede de segurança, caso o R8 rode assim mesmo)
# ---------------------------------------------------------------------
REGRAS = """
# ---- Farol: regras para o OCR do Google ML Kit ----
# O app usa apenas o alfabeto latino. Os reconhecedores de outros
# alfabetos nao entram no APK, entao o R8 nao deve reclamar deles.
-dontwarn com.google.mlkit.vision.text.chinese.**
-dontwarn com.google.mlkit.vision.text.japanese.**
-dontwarn com.google.mlkit.vision.text.korean.**
-dontwarn com.google.mlkit.vision.text.devanagari.**
-dontwarn com.google.mlkit.**
-keep class com.google.mlkit.** { *; }
-keep class com.google_mlkit_text_recognition.** { *; }
"""

proguard = RAIZ / 'proguard-rules.pro'
proguard.parent.mkdir(parents=True, exist_ok=True)
atual = proguard.read_text(encoding='utf-8') if proguard.exists() else ''
if 'mlkit' not in atual:
    proguard.write_text(atual + REGRAS, encoding='utf-8')
    print('OK: proguard-rules.pro gravado')
else:
    print('OK: proguard-rules.pro ja tinha as regras')

# ---------------------------------------------------------------------
# 2) Desliga o minify/shrink no build.gradle
# ---------------------------------------------------------------------
kts = RAIZ / 'build.gradle.kts'
groovy = RAIZ / 'build.gradle'

if kts.exists():
    arquivo, kotlin = kts, True
elif groovy.exists():
    arquivo, kotlin = groovy, False
else:
    print('AVISO: nao achei build.gradle nem build.gradle.kts')
    sys.exit(0)

s = arquivo.read_text(encoding='utf-8')

if 'isMinifyEnabled' in s or 'minifyEnabled' in s:
    print('OK: minify ja estava configurado')
else:
    if kotlin:
        alvo = 'signingConfig = signingConfigs.getByName("debug")'
        novo = (
            alvo
            + '\n            isMinifyEnabled = false'
            + '\n            isShrinkResources = false'
        )
    else:
        alvo = 'signingConfig signingConfigs.debug'
        novo = (
            alvo
            + '\n            minifyEnabled false'
            + '\n            shrinkResources false'
        )

    if alvo in s:
        s = s.replace(alvo, novo, 1)
        arquivo.write_text(s, encoding='utf-8')
        print('OK: R8 desligado no release')
    else:
        # Plano B: injeta um bloco buildTypes inteiro dentro de android { }
        marca = 'android {'
        bloco = (
            'android {\n'
            '    buildTypes {\n'
            '        release {\n'
            + ('            isMinifyEnabled = false\n'
               '            isShrinkResources = false\n' if kotlin else
               '            minifyEnabled false\n'
               '            shrinkResources false\n')
            + '        }\n'
            '    }\n'
        )
        if marca in s:
            s = s.replace(marca, bloco, 1)
            arquivo.write_text(s, encoding='utf-8')
            print('OK: bloco buildTypes injetado')
        else:
            print('AVISO: nao consegui localizar onde desligar o R8')

# ---------------------------------------------------------------------
# 3) Mostra o resultado para conferência no log
# ---------------------------------------------------------------------
print('----- build.gradle final -----')
print(arquivo.read_text(encoding='utf-8'))
