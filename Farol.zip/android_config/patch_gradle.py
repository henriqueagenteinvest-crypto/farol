"""
=======================================================================
 AJUSTES DO ANDROID ANTES DE COMPILAR
=======================================================================
 Este script roda no workflow logo depois do `flutter create`, que é
 quem gera o android/app/build.gradle.kts. Ele faz duas coisas:

 1) DESLIGA O R8 (otimizador de código)
    O R8 remove classes que ele acha que ninguém usa, e vez ou outra
    leva junto algo de que uma biblioteca precisa em tempo de execução
    (o gerador de PDF e o de Excel usam reflexão). Desligado, o APK fica
    alguns MB maior e o app funciona igual — e nunca quebra em produção
    por causa de uma classe removida por engano.

 2) USA UMA CHAVE DE ASSINATURA FIXA
    ESTE É O PONTO MAIS IMPORTANTE PARA O MOTORISTA.
    Sem uma chave fixa, cada compilação gera uma assinatura diferente e
    o Android RECUSA instalar a atualização por cima — obrigando a
    desinstalar o app, o que APAGARIA TODOS OS LANÇAMENTOS (o Farol é
    100% offline, os dados só existem no celular).
    Com a chave fixa, toda versão nova instala por cima e os dados ficam.

    A chave chega pelo workflow em android/app/farol.keystore.
    Se ela não estiver lá, o script mantém a assinatura de depuração
    para não quebrar a compilação — mas avisa no log.
=======================================================================
"""

import pathlib
import re
import sys

APP = pathlib.Path('android/app')
KEYSTORE = APP / 'farol.keystore'
ORIGEM_CHAVE = pathlib.Path('android_config/farol.keystore')
SENHA = 'farolMotorista2026'
ALIAS = 'farol'

# ---------------------------------------------------------------------
# 0) Coloca a chave de assinatura no lugar
# ---------------------------------------------------------------------
# A chave pode chegar de dois jeitos:
#   a) pelo cofre do GitHub (secret KEYSTORE_BASE64), que o workflow
#      grava direto em android/app/farol.keystore  -> preferido
#   b) junto com o projeto, em android_config/farol.keystore -> reserva
# O importante é que seja SEMPRE A MESMA, senao o Android recusa a
# atualizacao por cima e o motorista perde os lancamentos.
APP.mkdir(parents=True, exist_ok=True)
if not KEYSTORE.exists() and ORIGEM_CHAVE.exists():
    KEYSTORE.write_bytes(ORIGEM_CHAVE.read_bytes())
    print('OK: chave de assinatura copiada de android_config/')

# ---------------------------------------------------------------------
# 1) Regras de ProGuard (rede de segurança, caso o R8 rode assim mesmo)
# ---------------------------------------------------------------------
REGRAS = """
# ---- Farol: regras para o OCR do Google ML Kit ----
-dontwarn com.google.mlkit.vision.text.chinese.**
-dontwarn com.google.mlkit.vision.text.japanese.**
-dontwarn com.google.mlkit.vision.text.korean.**
-dontwarn com.google.mlkit.vision.text.devanagari.**
-dontwarn com.google.mlkit.**
-keep class com.google.mlkit.** { *; }
-keep class com.google_mlkit_text_recognition.** { *; }
"""

APP.mkdir(parents=True, exist_ok=True)
proguard = APP / 'proguard-rules.pro'
atual = proguard.read_text(encoding='utf-8') if proguard.exists() else ''
if 'mlkit' not in atual:
    proguard.write_text(atual + REGRAS, encoding='utf-8')
print('OK: proguard-rules.pro pronto')

# ---------------------------------------------------------------------
# 2) Localiza o build.gradle
# ---------------------------------------------------------------------
kts = APP / 'build.gradle.kts'
groovy = APP / 'build.gradle'

if kts.exists():
    arquivo, kotlin = kts, True
elif groovy.exists():
    arquivo, kotlin = groovy, False
else:
    print('AVISO: nao achei build.gradle nem build.gradle.kts')
    sys.exit(0)

s = arquivo.read_text(encoding='utf-8')
tem_chave = KEYSTORE.exists()
print(f'Chave de assinatura presente: {tem_chave}')


def bloco(texto: str, abertura: str) -> tuple:
    """Devolve (inicio, fim) do bloco que comeca em `abertura`, casando chaves."""
    i = texto.find(abertura)
    if i < 0:
        return (-1, -1)
    j = texto.find('{', i)
    prof = 0
    k = j
    while k < len(texto):
        if texto[k] == '{':
            prof += 1
        elif texto[k] == '}':
            prof -= 1
            if prof == 0:
                return (i, k + 1)
        k += 1
    return (-1, -1)


# ---------------------------------------------------------------------
# 3) Injeta o signingConfigs com a chave fixa
# ---------------------------------------------------------------------
if tem_chave and 'farolMotorista' not in s:
    if kotlin:
        assinatura = (
            '\n    signingConfigs {\n'
            '        create("farol") {\n'
            '            storeFile = file("farol.keystore")\n'
            f'            storePassword = "{SENHA}"\n'
            f'            keyAlias = "{ALIAS}"\n'
            f'            keyPassword = "{SENHA}"\n'
            '        }\n'
            '    }\n'
        )
    else:
        assinatura = (
            '\n    signingConfigs {\n'
            '        farol {\n'
            '            storeFile file("farol.keystore")\n'
            f'            storePassword "{SENHA}"\n'
            f'            keyAlias "{ALIAS}"\n'
            f'            keyPassword "{SENHA}"\n'
            '        }\n'
            '    }\n'
        )
    ini, _ = bloco(s, 'android {')
    if ini >= 0:
        corte = s.find('{', ini) + 1
        s = s[:corte] + assinatura + s[corte:]
        print('OK: signingConfigs com a chave fixa injetado')
    else:
        print('AVISO: nao achei o bloco android {')

# ---------------------------------------------------------------------
# 4) Reescreve o buildTypes: sem R8 e com a chave certa
# ---------------------------------------------------------------------
ref_chave = (
    ('signingConfigs.getByName("farol")' if kotlin else 'signingConfigs.farol')
    if tem_chave else
    ('signingConfigs.getByName("debug")' if kotlin else 'signingConfigs.debug')
)

if kotlin:
    novo_buildtypes = (
        'buildTypes {\n'
        '        release {\n'
        f'            signingConfig = {ref_chave}\n'
        '            isMinifyEnabled = false\n'
        '            isShrinkResources = false\n'
        '        }\n'
        '    }'
    )
else:
    novo_buildtypes = (
        'buildTypes {\n'
        '        release {\n'
        f'            signingConfig {ref_chave}\n'
        '            minifyEnabled false\n'
        '            shrinkResources false\n'
        '        }\n'
        '    }'
    )

ini, fim = bloco(s, 'buildTypes {')
if ini >= 0:
    s = s[:ini] + novo_buildtypes + s[fim:]
    print('OK: buildTypes reescrito (R8 desligado, chave fixa)')
else:
    # Nao existia buildTypes: injeta dentro de android { }
    ini_a, _ = bloco(s, 'android {')
    if ini_a >= 0:
        corte = s.find('{', ini_a) + 1
        s = s[:corte] + '\n    ' + novo_buildtypes + '\n' + s[corte:]
        print('OK: buildTypes criado')
    else:
        print('AVISO: nao consegui ajustar o buildTypes')

arquivo.write_text(s, encoding='utf-8')

# ---------------------------------------------------------------------
# 5) Mostra o resultado no log, para conferencia
# ---------------------------------------------------------------------
print('----- build.gradle final -----')
print(arquivo.read_text(encoding='utf-8'))
