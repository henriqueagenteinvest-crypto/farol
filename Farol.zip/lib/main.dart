/// =======================================================================
/// FAROL — PONTO DE ENTRADA DO APLICATIVO
/// =======================================================================
/// Aplicativo de controle financeiro e de jornada para motoristas de app.
///
/// 100% OFFLINE: não existe Firebase, nuvem, servidor nem login externo.
/// Todos os dados ficam no celular do motorista, guardados pelo Hive.
/// =======================================================================
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:provider/provider.dart';

import 'core/app_constants.dart';
import 'core/app_routes.dart';
import 'data/local_database.dart';
import 'presentation/controllers/app_controller.dart';
import 'presentation/controllers/dados_controller.dart';
import 'presentation/controllers/jornada_controller.dart';
import 'presentation/screens/splash_screen.dart';

Future<void> main() async {
  // Garante que o Flutter esteja pronto antes de mexer em arquivos.
  WidgetsFlutterBinding.ensureInitialized();

  // Carrega os nomes de meses e dias em português para as datas.
  await initializeDateFormatting('pt_BR', null);

  // Abre o banco local. Se falhar, o app ainda sobe e avisa na tela.
  await LocalDatabase.iniciar();

  // Se alguma tela quebrar, o motorista vê um recado em português em vez
  // da tela cinza de erro do Flutter — e o app continua de pé.
  ErrorWidget.builder = (detalhes) => const Material(
        color: Color(0xFF0B0E17),
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(28),
            child: Text(
              'Algo não carregou aqui.\n\n'
              'Volte para a tela anterior e tente de novo. '
              'Seus dados continuam salvos no celular.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 15),
            ),
          ),
        ),
      );

  // O app foi desenhado para ser usado em pé, dentro do carro.
  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const AppFarol());
}

class AppFarol extends StatelessWidget {
  const AppFarol({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AppController>(
          create: (_) => AppController()..carregar(),
        ),
        ChangeNotifierProvider<JornadaController>(
          create: (_) => JornadaController()..carregar(),
        ),
        // O DadosController precisa saber as configurações (metas, custos
        // fixos, padrões do carro). Este Proxy mantém os dois em sincronia
        // automaticamente: mudou a configuração, o resumo já sai correto.
        ChangeNotifierProxyProvider<AppController, DadosController>(
          create: (_) => DadosController(),
          update: (_, app, dados) =>
              (dados ?? DadosController())..atualizarConfig(app.config),
        ),
      ],
      child: Consumer<AppController>(
        builder: (context, app, _) {
          return MaterialApp(
            title: AppConstants.nomeApp,
            debugShowCheckedModeBanner: false,

            // ---- Tema escolhido pelo motorista, aplicado na hora ----
            theme: app.visual,

            // ---- Tudo em português do Brasil ----
            locale: const Locale('pt', 'BR'),
            supportedLocales: const <Locale>[Locale('pt', 'BR')],
            localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],

            // ---- Navegação ----
            home: const SplashScreen(),
            onGenerateRoute: AppRoutes.gerar,

            // Trava o tamanho da fonte do sistema num limite saudável:
            // acessibilidade sim, layout quebrado não.
            builder: (context, filho) {
              final escala = MediaQuery.textScalerOf(context)
                  .clamp(minScaleFactor: 0.85, maxScaleFactor: 1.3);
              return MediaQuery(
                data: MediaQuery.of(context).copyWith(textScaler: escala),
                child: filho ?? const SizedBox.shrink(),
              );
            },
          );
        },
      ),
    );
  }
}
