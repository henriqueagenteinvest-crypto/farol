/// Repositório dos gastos (12 categorias fixas).
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../gravacao_segura.dart';
import '../../utils/extensions.dart';
import '../models/gasto.dart';

class GastoRepository {
  Box<Gasto> get _box => Hive.box<Gasto>(HiveBoxes.gastos);

  /// A lista pronta, do mais novo para o mais antigo.
  ///
  /// Fica guardada e só é refeita quando algum dado muda de verdade
  /// (veja `VersaoDados`). Sem isso, cada rolagem de tela reordenava
  /// tudo de novo, dezenas de vezes por segundo.
  List<Gasto>? _guardado;
  int _versaoGuardada = -1;

  List<Gasto> todos() {
    if (_guardado != null && _versaoGuardada == VersaoDados.atual) {
      return _guardado!;
    }
    final lista = _box.values.toList()
      ..sort((a, b) => b.data.compareTo(a.data));
    _guardado = lista;
    _versaoGuardada = VersaoDados.atual;
    return lista;
  }

  List<Gasto> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todos().where((g) => g.data.dentroDe(ini, f)).toList();
  }

  List<Gasto> porCategoria(String categoria) =>
      todos().where((g) => g.categoria == categoria).toList();

  /// Grava sem deixar erro nenhum estourar na tela.
  /// Veja o porquê em `gravacao_segura.dart`.
  Future<ResultadoGravacao> salvar(Gasto item) => gravarComSeguranca(
        gravar: () => _box.put(item.id, item),
        conferir: () => _box.get(item.id) != null,
        descricao: 'Gasto',
      );

  Future<void> apagar(String id) async {
    await _box.delete(id);
    VersaoDados.mudou();
  }

  Gasto? porId(String id) => _box.get(id);
}
