/// Repositório dos gastos (12 categorias fixas).
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../../utils/extensions.dart';
import '../models/gasto.dart';

class GastoRepository {
  Box<Gasto> get _box => Hive.box<Gasto>(HiveBoxes.gastos);

  List<Gasto> todos() {
    final lista = _box.values.toList()
      ..sort((a, b) => b.data.compareTo(a.data));
    return lista;
  }

  List<Gasto> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todos().where((g) => g.data.dentroDe(ini, f)).toList();
  }

  List<Gasto> porCategoria(String categoria) =>
      todos().where((g) => g.categoria == categoria).toList();

  Future<void> salvar(Gasto item) => _box.put(item.id, item);

  Future<void> apagar(String id) => _box.delete(id);

  Gasto? porId(String id) => _box.get(id);
}
