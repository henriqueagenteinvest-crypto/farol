/// Repositório dos lançamentos diários.
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../../utils/extensions.dart';
import '../models/lancamento_diario.dart';

class LancamentoRepository {
  Box<LancamentoDiario> get _box =>
      Hive.box<LancamentoDiario>(HiveBoxes.lancamentos);

  /// Todos os lançamentos, do mais novo para o mais antigo.
  List<LancamentoDiario> todos() {
    final lista = _box.values.toList()
      ..sort((a, b) => b.data.compareTo(a.data));
    return lista;
  }

  /// Lançamentos dentro de um intervalo de datas (inclusivo).
  List<LancamentoDiario> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todos().where((l) => l.data.dentroDe(ini, f)).toList();
  }

  /// Lançamentos de um dia específico.
  List<LancamentoDiario> porDia(DateTime dia) =>
      todos().where((l) => l.data.mesmoDia(dia)).toList();

  /// Lançamentos de hoje.
  List<LancamentoDiario> deHoje() => porDia(DateTime.now());

  Future<void> salvar(LancamentoDiario lancamento) =>
      _box.put(lancamento.id, lancamento);

  Future<void> apagar(String id) => _box.delete(id);

  LancamentoDiario? porId(String id) => _box.get(id);

  /// Data do lançamento mais antigo (usado nos filtros de relatório).
  DateTime? primeiraData() {
    if (_box.isEmpty) return null;
    return _box.values
        .map((l) => l.data)
        .reduce((a, b) => a.isBefore(b) ? a : b);
  }
}
