/// Repositório dos lançamentos diários.
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../gravacao_segura.dart';
import '../../utils/extensions.dart';
import '../models/lancamento_diario.dart';

class LancamentoRepository {
  Box<LancamentoDiario> get _box =>
      Hive.box<LancamentoDiario>(HiveBoxes.lancamentos);

  /// Todos os lançamentos, do mais novo para o mais antigo.
  /// A lista pronta, do mais novo para o mais antigo.
  ///
  /// Fica guardada e só é refeita quando algum dado muda de verdade
  /// (veja `VersaoDados`). Sem isso, cada rolagem de tela reordenava
  /// tudo de novo, dezenas de vezes por segundo.
  List<LancamentoDiario>? _guardado;
  int _versaoGuardada = -1;

  List<LancamentoDiario> todos() {
    if (_guardado != null && _versaoGuardada == VersaoDados.atual) {
      return _guardado!;
    }
    final lista = _box.values.toList()
      ..sort((a, b) => b.data.compareTo(a.data));
    _guardado = lista;
    _versaoGuardada = VersaoDados.atual;
    return lista;
  }

  /// Lançamentos dentro de um intervalo de datas (inclusivo).
  List<LancamentoDiario> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todos().where((l) => l.data.dentroDe(ini, f)).toList();
  }

  /// Lançamentos de um dia específico.
  List<LancamentoDiario> porDia(DateTime dia) =>
      todos().where((l) => l.data.mesmoDia(dia)).toList();

  /// Lançamentos de hoje.
  List<LancamentoDiario> deHoje() => porDia(DateTime.now());

  /// Grava sem deixar erro nenhum estourar na tela.
  /// Veja o porquê em `gravacao_segura.dart`.
  Future<ResultadoGravacao> salvar(LancamentoDiario lancamento) => gravarComSeguranca(
        gravar: () => _box.put(lancamento.id, lancamento),
        conferir: () => _box.get(lancamento.id) != null,
        descricao: 'Lançamento do dia',
      );

  Future<void> apagar(String id) async {
    await _box.delete(id);
    VersaoDados.mudou();
  }

  LancamentoDiario? porId(String id) => _box.get(id);

  /// Data do lançamento mais antigo (usado nos filtros de relatório).
  DateTime? primeiraData() {
    if (_box.isEmpty) return null;
    return _box.values
        .map((l) => l.data)
        .reduce((a, b) => a.isBefore(b) ? a : b);
  }
}
