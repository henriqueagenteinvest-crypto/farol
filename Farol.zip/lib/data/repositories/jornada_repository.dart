/// Repositório das jornadas de trabalho.
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../gravacao_segura.dart';
import '../../utils/extensions.dart';
import '../models/jornada.dart';

class JornadaRepository {
  Box<Jornada> get _box => Hive.box<Jornada>(HiveBoxes.jornadas);

  List<Jornada> todas() {
    final lista = _box.values.toList()
      ..sort((a, b) => b.inicio.compareTo(a.inicio));
    return lista;
  }

  List<Jornada> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todas().where((j) => j.inicio.dentroDe(ini, f)).toList();
  }

  List<Jornada> porDia(DateTime dia) =>
      todas().where((j) => j.inicio.mesmoDia(dia)).toList();

  /// A jornada que está aberta agora (se existir).
  Jornada? emAndamento() {
    for (final j in todas()) {
      if (j.emAndamento) return j;
    }
    return null;
  }

  /// Grava sem deixar erro nenhum estourar na tela.
  /// Veja o porquê em `gravacao_segura.dart`.
  Future<ResultadoGravacao> salvar(Jornada jornada) => gravarComSeguranca(
        gravar: () => _box.put(jornada.id, jornada),
        conferir: () => _box.get(jornada.id) != null,
        descricao: 'Jornada',
      );

  Future<void> apagar(String id) => _box.delete(id);
}
