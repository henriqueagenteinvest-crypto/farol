/// Repositório dos abastecimentos.
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../../utils/extensions.dart';
import '../models/abastecimento.dart';

class AbastecimentoRepository {
  Box<Abastecimento> get _box =>
      Hive.box<Abastecimento>(HiveBoxes.abastecimentos);

  List<Abastecimento> todos() {
    final lista = _box.values.toList()
      ..sort((a, b) => b.data.compareTo(a.data));
    return lista;
  }

  List<Abastecimento> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todos().where((a) => a.data.dentroDe(ini, f)).toList();
  }

  Future<void> salvar(Abastecimento item) => _box.put(item.id, item);

  Future<void> apagar(String id) => _box.delete(id);

  Abastecimento? porId(String id) => _box.get(id);

  /// Último abastecimento registrado — usado para sugerir o preço do litro.
  Abastecimento? ultimo() {
    final lista = todos();
    return lista.isEmpty ? null : lista.first;
  }
}
