/// Repositório dos abastecimentos.
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../gravacao_segura.dart';
import '../../utils/extensions.dart';
import '../models/abastecimento.dart';

class AbastecimentoRepository {
  Box<Abastecimento> get _box =>
      Hive.box<Abastecimento>(HiveBoxes.abastecimentos);

  /// A lista pronta, do mais novo para o mais antigo.
  ///
  /// Fica guardada e só é refeita quando algum dado muda de verdade
  /// (veja `VersaoDados`). Sem isso, cada rolagem de tela reordenava
  /// tudo de novo, dezenas de vezes por segundo.
  List<Abastecimento>? _guardado;
  int _versaoGuardada = -1;

  List<Abastecimento> todos() {
    if (_guardado != null && _versaoGuardada == VersaoDados.atual) {
      return _guardado!;
    }
    final lista = _box.values.toList()
      ..sort((a, b) => b.data.compareTo(a.data));
    _guardado = lista;
    _versaoGuardada = VersaoDados.atual;
    return lista;
  }

  List<Abastecimento> porPeriodo(DateTime inicio, DateTime fim) {
    final ini = inicio.soData;
    final f = DateTime(fim.year, fim.month, fim.day, 23, 59, 59);
    return todos().where((a) => a.data.dentroDe(ini, f)).toList();
  }

  /// Grava sem deixar erro nenhum estourar na tela.
  /// Veja o porquê em `gravacao_segura.dart`.
  Future<ResultadoGravacao> salvar(Abastecimento item) => gravarComSeguranca(
        gravar: () => _box.put(item.id, item),
        conferir: () => _box.get(item.id) != null,
        descricao: 'Abastecimento',
      );

  Future<void> apagar(String id) async {
    await _box.delete(id);
    VersaoDados.mudou();
  }

  Abastecimento? porId(String id) => _box.get(id);

  /// Último abastecimento registrado — usado para sugerir o preço do litro.
  Abastecimento? ultimo() {
    final lista = todos();
    return lista.isEmpty ? null : lista.first;
  }
}
