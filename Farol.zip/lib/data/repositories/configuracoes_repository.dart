/// Repositório das configurações (tema, metas, sons, animações).
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../gravacao_segura.dart';
import '../models/configuracoes.dart';

class ConfiguracoesRepository {
  Box<Configuracoes> get _box =>
      Hive.box<Configuracoes>(HiveBoxes.configuracoes);

  static const String _chave = 'atual';

  /// Sempre devolve um objeto válido: se não existir, cria com os padrões.
  Configuracoes obter() => _box.get(_chave) ?? Configuracoes();

  Future<ResultadoGravacao> salvar(Configuracoes config) => gravarComSeguranca(
        gravar: () => _box.put(_chave, config),
        conferir: () => _box.get(_chave) != null,
        descricao: 'Configurações',
      );
}
