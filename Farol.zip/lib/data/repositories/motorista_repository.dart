/// Repositório do cadastro do motorista (existe só UM registro).
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';
import '../gravacao_segura.dart';
import '../models/motorista.dart';

class MotoristaRepository {
  Box<Motorista> get _box => Hive.box<Motorista>(HiveBoxes.motorista);

  /// Chave fixa: sempre sobrescreve o mesmo registro.
  static const String _chave = 'atual';

  /// Devolve o motorista cadastrado ou null se ainda não fez o cadastro.
  Motorista? obter() => _box.get(_chave);

  /// Existe alguém cadastrado? (usado para decidir se mostra o login)
  bool get temCadastro => _box.get(_chave) != null;

  Future<ResultadoGravacao> salvar(Motorista motorista) => gravarComSeguranca(
        gravar: () => _box.put(_chave, motorista),
        conferir: () => _box.get(_chave) != null,
        descricao: 'Cadastro do motorista',
      );

  Future<void> apagar() => _box.delete(_chave);
}
