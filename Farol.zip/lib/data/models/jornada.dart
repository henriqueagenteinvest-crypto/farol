/// -----------------------------------------------------------------------
/// MODELO: JORNADA (controle de tempo trabalhado)
/// -----------------------------------------------------------------------
/// Uma jornada tem início, fim e uma lista de pausas.
/// REGRA IMPORTANTE: o tempo das pausas NÃO conta como tempo trabalhado.
/// O motorista pode ter várias jornadas no mesmo dia.
/// -----------------------------------------------------------------------
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';

/// Um intervalo de pausa dentro da jornada.
class Pausa {
  DateTime inicio;

  /// Fica nulo enquanto a pausa está acontecendo.
  DateTime? fim;

  String motivo;

  Pausa({required this.inicio, this.fim, this.motivo = 'Outro'});

  bool get emAndamento => fim == null;

  /// Quanto tempo essa pausa durou (ou está durando).
  Duration duracao(DateTime agora) => (fim ?? agora).difference(inicio);
}

class Jornada {
  String id;
  DateTime inicio;

  /// Fica nulo enquanto a jornada está aberta.
  DateTime? fim;

  List<Pausa> pausas;
  String observacao;

  Jornada({
    String? id,
    required this.inicio,
    this.fim,
    List<Pausa>? pausas,
    this.observacao = '',
  })  : id = id ?? _gerarId(),
        pausas = pausas ?? <Pausa>[];

  static String _gerarId() =>
      'J${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}';

  /// A jornada está aberta (ainda não foi encerrada)?
  bool get emAndamento => fim == null;

  /// Existe alguma pausa acontecendo agora?
  bool get pausada => pausas.any((p) => p.emAndamento);

  /// A pausa que está acontecendo agora (ou nulo).
  Pausa? get pausaAtual {
    for (final p in pausas) {
      if (p.emAndamento) return p;
    }
    return null;
  }
}

class PausaAdapter extends TypeAdapter<Pausa> {
  @override
  final int typeId = HiveBoxes.typePausa;

  @override
  Pausa read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return Pausa(
      inicio: campos[0] as DateTime? ?? DateTime.now(),
      fim: campos[1] as DateTime?,
      motivo: campos[2] as String? ?? 'Outro',
    );
  }

  @override
  void write(BinaryWriter writer, Pausa obj) {
    writer
      ..writeByte(3)
      ..writeByte(0)
      ..write(obj.inicio)
      ..writeByte(1)
      ..write(obj.fim)
      ..writeByte(2)
      ..write(obj.motivo);
  }
}

class JornadaAdapter extends TypeAdapter<Jornada> {
  @override
  final int typeId = HiveBoxes.typeJornada;

  @override
  Jornada read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return Jornada(
      id: campos[0] as String?,
      inicio: campos[1] as DateTime? ?? DateTime.now(),
      fim: campos[2] as DateTime?,
      pausas: (campos[3] as List?)?.cast<Pausa>().toList() ?? <Pausa>[],
      observacao: campos[4] as String? ?? '',
    );
  }

  @override
  void write(BinaryWriter writer, Jornada obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.inicio)
      ..writeByte(2)
      ..write(obj.fim)
      ..writeByte(3)
      ..write(obj.pausas)
      ..writeByte(4)
      ..write(obj.observacao);
  }
}
