/// -----------------------------------------------------------------------
/// MODELO: MOTORISTA
/// -----------------------------------------------------------------------
/// Guarda quem é o motorista e qual carro ele usa.
/// Não existe senha nem e-mail: só o nome e os dados do veículo.
/// -----------------------------------------------------------------------
library;

import 'package:hive/hive.dart';
import '../../core/hive_boxes.dart';

class Motorista {
  String nome;
  String modeloCarro;
  String placa;
  int? anoCarro;
  String corCarro;
  DateTime criadoEm;

  Motorista({
    required this.nome,
    this.modeloCarro = '',
    this.placa = '',
    this.anoCarro,
    this.corCarro = '',
    DateTime? criadoEm,
  }) : criadoEm = criadoEm ?? DateTime.now();

  /// Primeiro nome — usado na saudação da tela inicial.
  String get primeiroNome {
    final partes = nome.trim().split(RegExp(r'\s+'));
    return partes.isEmpty ? nome : partes.first;
  }

  /// Descrição curta do carro para mostrar no perfil.
  String get descricaoCarro {
    final partes = <String>[
      if (modeloCarro.trim().isNotEmpty) modeloCarro.trim(),
      if (anoCarro != null) anoCarro.toString(),
      if (corCarro.trim().isNotEmpty) corCarro.trim(),
    ];
    return partes.isEmpty ? 'Carro não informado' : partes.join(' • ');
  }

  Motorista copiarCom({
    String? nome,
    String? modeloCarro,
    String? placa,
    int? anoCarro,
    String? corCarro,
  }) {
    return Motorista(
      nome: nome ?? this.nome,
      modeloCarro: modeloCarro ?? this.modeloCarro,
      placa: placa ?? this.placa,
      anoCarro: anoCarro ?? this.anoCarro,
      corCarro: corCarro ?? this.corCarro,
      criadoEm: criadoEm,
    );
  }
}

/// Adapter escrito à mão (sem build_runner) — mais leve e sem geração.
class MotoristaAdapter extends TypeAdapter<Motorista> {
  @override
  final int typeId = HiveBoxes.typeMotorista;

  @override
  Motorista read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return Motorista(
      nome: campos[0] as String? ?? '',
      modeloCarro: campos[1] as String? ?? '',
      placa: campos[2] as String? ?? '',
      anoCarro: campos[3] as int?,
      corCarro: campos[4] as String? ?? '',
      criadoEm: campos[5] as DateTime? ?? DateTime.now(),
    );
  }

  @override
  void write(BinaryWriter writer, Motorista obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.nome)
      ..writeByte(1)
      ..write(obj.modeloCarro)
      ..writeByte(2)
      ..write(obj.placa)
      ..writeByte(3)
      ..write(obj.anoCarro)
      ..writeByte(4)
      ..write(obj.corCarro)
      ..writeByte(5)
      ..write(obj.criadoEm);
  }
}
