/// -----------------------------------------------------------------------
/// MODELO: CONFIGURAÇÕES DO APP
/// -----------------------------------------------------------------------
/// Guarda as preferências do motorista: tema, metas, custos fixos,
/// animações e sons. Existe apenas UM registro deste tipo no Hive.
/// -----------------------------------------------------------------------
library;

import 'package:hive/hive.dart';
import '../../core/app_constants.dart';
import '../../core/hive_boxes.dart';
import '../../theme/catalogo_temas.dart';

class Configuracoes {
  /// Id do tema escolhido (ver CatalogoTemas).
  String temaId;

  /// Animações ligadas? Desligar ajuda em celulares mais fracos.
  bool animacoesAtivas;

  /// Sons de toque e de notificação ligados?
  bool sonsAtivos;

  /// Metas de LUCRO (não de valor bruto).
  double metaDiaria;
  double metaSemanal;
  double metaMensal;

  /// Custos fixos que o motorista paga todo mês (aluguel do carro,
  /// seguro parcelado, internet etc.). Usado no relatório para mostrar
  /// o lucro REAL depois dos custos fixos.
  double custosFixosMensais;

  /// Valores padrão que já vêm preenchidos nos formulários.
  double kmPorLitroPadrao;
  double precoLitroPadrao;
  String combustivelPadrao;

  /// Margem de lucro mínima desejada (%), usada em "Vale a pena?".
  double margemLucroAlvo;

  /// Fica false depois que o motorista termina o primeiro cadastro.
  bool primeiroUso;

  /// Última vez que a animação de meta batida foi exibida (evita repetir
  /// a comemoração várias vezes no mesmo dia).
  DateTime? ultimaComemoracao;

  Configuracoes({
    this.temaId = CatalogoTemas.idPadrao,
    this.animacoesAtivas = true,
    this.sonsAtivos = true,
    this.metaDiaria = AppConstants.metaDiariaPadrao,
    this.metaSemanal = AppConstants.metaDiariaPadrao * 6,
    this.metaMensal = AppConstants.metaDiariaPadrao * 24,
    this.custosFixosMensais = 0,
    this.kmPorLitroPadrao = AppConstants.kmPorLitroPadrao,
    this.precoLitroPadrao = AppConstants.precoLitroPadrao,
    this.combustivelPadrao = AppConstants.combustivelGasolina,
    this.margemLucroAlvo = AppConstants.margemLucroAlvoPadrao,
    this.primeiroUso = true,
    this.ultimaComemoracao,
  });

  Configuracoes copiarCom({
    String? temaId,
    bool? animacoesAtivas,
    bool? sonsAtivos,
    double? metaDiaria,
    double? metaSemanal,
    double? metaMensal,
    double? custosFixosMensais,
    double? kmPorLitroPadrao,
    double? precoLitroPadrao,
    String? combustivelPadrao,
    double? margemLucroAlvo,
    bool? primeiroUso,
    DateTime? ultimaComemoracao,
  }) {
    return Configuracoes(
      temaId: temaId ?? this.temaId,
      animacoesAtivas: animacoesAtivas ?? this.animacoesAtivas,
      sonsAtivos: sonsAtivos ?? this.sonsAtivos,
      metaDiaria: metaDiaria ?? this.metaDiaria,
      metaSemanal: metaSemanal ?? this.metaSemanal,
      metaMensal: metaMensal ?? this.metaMensal,
      custosFixosMensais: custosFixosMensais ?? this.custosFixosMensais,
      kmPorLitroPadrao: kmPorLitroPadrao ?? this.kmPorLitroPadrao,
      precoLitroPadrao: precoLitroPadrao ?? this.precoLitroPadrao,
      combustivelPadrao: combustivelPadrao ?? this.combustivelPadrao,
      margemLucroAlvo: margemLucroAlvo ?? this.margemLucroAlvo,
      primeiroUso: primeiroUso ?? this.primeiroUso,
      ultimaComemoracao: ultimaComemoracao ?? this.ultimaComemoracao,
    );
  }
}

class ConfiguracoesAdapter extends TypeAdapter<Configuracoes> {
  @override
  final int typeId = HiveBoxes.typeConfiguracoes;

  @override
  Configuracoes read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return Configuracoes(
      temaId: campos[0] as String? ?? CatalogoTemas.idPadrao,
      animacoesAtivas: campos[1] as bool? ?? true,
      sonsAtivos: campos[2] as bool? ?? true,
      metaDiaria:
          (campos[3] as num?)?.toDouble() ?? AppConstants.metaDiariaPadrao,
      metaSemanal: (campos[4] as num?)?.toDouble() ??
          AppConstants.metaDiariaPadrao * 6,
      metaMensal: (campos[5] as num?)?.toDouble() ??
          AppConstants.metaDiariaPadrao * 24,
      custosFixosMensais: (campos[6] as num?)?.toDouble() ?? 0,
      kmPorLitroPadrao: (campos[7] as num?)?.toDouble() ??
          AppConstants.kmPorLitroPadrao,
      precoLitroPadrao: (campos[8] as num?)?.toDouble() ??
          AppConstants.precoLitroPadrao,
      combustivelPadrao:
          campos[9] as String? ?? AppConstants.combustivelGasolina,
      margemLucroAlvo: (campos[10] as num?)?.toDouble() ??
          AppConstants.margemLucroAlvoPadrao,
      primeiroUso: campos[11] as bool? ?? true,
      ultimaComemoracao: campos[12] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, Configuracoes obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.temaId)
      ..writeByte(1)
      ..write(obj.animacoesAtivas)
      ..writeByte(2)
      ..write(obj.sonsAtivos)
      ..writeByte(3)
      ..write(obj.metaDiaria)
      ..writeByte(4)
      ..write(obj.metaSemanal)
      ..writeByte(5)
      ..write(obj.metaMensal)
      ..writeByte(6)
      ..write(obj.custosFixosMensais)
      ..writeByte(7)
      ..write(obj.kmPorLitroPadrao)
      ..writeByte(8)
      ..write(obj.precoLitroPadrao)
      ..writeByte(9)
      ..write(obj.combustivelPadrao)
      ..writeByte(10)
      ..write(obj.margemLucroAlvo)
      ..writeByte(11)
      ..write(obj.primeiroUso)
      ..writeByte(12)
      ..write(obj.ultimaComemoracao);
  }
}
