/// -----------------------------------------------------------------------
/// MODELO: ABASTECIMENTO
/// -----------------------------------------------------------------------
/// Cada vez que o motorista abastece, guarda litros, preço e desconto.
/// O desconto pode ser em R$ OU em % — o cálculo do valor final fica no
/// CalculationsService (nunca aqui).
/// -----------------------------------------------------------------------
library;

import 'package:hive/hive.dart';
import '../../core/app_constants.dart';
import '../../core/hive_boxes.dart';

class Abastecimento {
  String id;
  DateTime data;

  /// Litros colocados no tanque.
  double litros;

  /// Preço de tabela do litro (antes do desconto).
  double precoLitro;

  String tipoCombustivel;
  String formaPagamento;

  /// Desconto em reais (ex.: R$ 5,00 de volta pelo app do posto).
  double descontoReais;

  /// Desconto em porcentagem (ex.: 8%).
  double descontoPercentual;

  /// Nome do posto (opcional).
  String posto;

  /// Odômetro no momento do abastecimento (opcional).
  /// Serve para calcular o consumo REAL do carro entre dois abastecimentos.
  double? odometro;

  DateTime criadoEm;

  Abastecimento({
    String? id,
    required this.data,
    this.litros = 0,
    this.precoLitro = 0,
    this.tipoCombustivel = AppConstants.combustivelGasolina,
    this.formaPagamento = 'Pix',
    this.descontoReais = 0,
    this.descontoPercentual = 0,
    this.posto = '',
    this.odometro,
    DateTime? criadoEm,
  })  : id = id ?? _gerarId(),
        criadoEm = criadoEm ?? DateTime.now();

  static String _gerarId() =>
      'A${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}';

  Abastecimento copiarCom({
    DateTime? data,
    double? litros,
    double? precoLitro,
    String? tipoCombustivel,
    String? formaPagamento,
    double? descontoReais,
    double? descontoPercentual,
    String? posto,
    double? odometro,
  }) {
    return Abastecimento(
      id: id,
      data: data ?? this.data,
      litros: litros ?? this.litros,
      precoLitro: precoLitro ?? this.precoLitro,
      tipoCombustivel: tipoCombustivel ?? this.tipoCombustivel,
      formaPagamento: formaPagamento ?? this.formaPagamento,
      descontoReais: descontoReais ?? this.descontoReais,
      descontoPercentual: descontoPercentual ?? this.descontoPercentual,
      posto: posto ?? this.posto,
      odometro: odometro ?? this.odometro,
      criadoEm: criadoEm,
    );
  }
}

class AbastecimentoAdapter extends TypeAdapter<Abastecimento> {
  @override
  final int typeId = HiveBoxes.typeAbastecimento;

  @override
  Abastecimento read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return Abastecimento(
      id: campos[0] as String?,
      data: campos[1] as DateTime? ?? DateTime.now(),
      litros: (campos[2] as num?)?.toDouble() ?? 0,
      precoLitro: (campos[3] as num?)?.toDouble() ?? 0,
      tipoCombustivel:
          campos[4] as String? ?? AppConstants.combustivelGasolina,
      formaPagamento: campos[5] as String? ?? 'Pix',
      descontoReais: (campos[6] as num?)?.toDouble() ?? 0,
      descontoPercentual: (campos[7] as num?)?.toDouble() ?? 0,
      posto: campos[8] as String? ?? '',
      odometro: (campos[9] as num?)?.toDouble(),
      criadoEm: campos[10] as DateTime? ?? DateTime.now(),
    );
  }

  @override
  void write(BinaryWriter writer, Abastecimento obj) {
    writer
      ..writeByte(11)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.data)
      ..writeByte(2)
      ..write(obj.litros)
      ..writeByte(3)
      ..write(obj.precoLitro)
      ..writeByte(4)
      ..write(obj.tipoCombustivel)
      ..writeByte(5)
      ..write(obj.formaPagamento)
      ..writeByte(6)
      ..write(obj.descontoReais)
      ..writeByte(7)
      ..write(obj.descontoPercentual)
      ..writeByte(8)
      ..write(obj.posto)
      ..writeByte(9)
      ..write(obj.odometro)
      ..writeByte(10)
      ..write(obj.criadoEm);
  }
}
