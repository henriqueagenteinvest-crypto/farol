/// -----------------------------------------------------------------------
/// MODELO: GASTO
/// -----------------------------------------------------------------------
/// Despesa em uma das 12 categorias fixas do app.
/// -----------------------------------------------------------------------
library;

import 'package:hive/hive.dart';
import '../../core/app_constants.dart';
import '../../core/hive_boxes.dart';

class Gasto {
  String id;
  DateTime data;

  /// Deve ser uma das 12 categorias de AppConstants.categoriasGasto.
  String categoria;

  String descricao;
  double valor;
  DateTime criadoEm;

  Gasto({
    String? id,
    required this.data,
    required this.categoria,
    this.descricao = '',
    this.valor = 0,
    DateTime? criadoEm,
  })  : id = id ?? _gerarId(),
        criadoEm = criadoEm ?? DateTime.now();

  static String _gerarId() =>
      'G${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}';

  /// Garante que a categoria salva é sempre uma das 12 válidas.
  String get categoriaValida =>
      AppConstants.categoriasGasto.contains(categoria)
          ? categoria
          : AppConstants.categoriasGasto.first;

  Gasto copiarCom({
    DateTime? data,
    String? categoria,
    String? descricao,
    double? valor,
  }) {
    return Gasto(
      id: id,
      data: data ?? this.data,
      categoria: categoria ?? this.categoria,
      descricao: descricao ?? this.descricao,
      valor: valor ?? this.valor,
      criadoEm: criadoEm,
    );
  }
}

class GastoAdapter extends TypeAdapter<Gasto> {
  @override
  final int typeId = HiveBoxes.typeGasto;

  @override
  Gasto read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return Gasto(
      id: campos[0] as String?,
      data: campos[1] as DateTime? ?? DateTime.now(),
      categoria:
          campos[2] as String? ?? AppConstants.categoriasGasto.first,
      descricao: campos[3] as String? ?? '',
      valor: (campos[4] as num?)?.toDouble() ?? 0,
      criadoEm: campos[5] as DateTime? ?? DateTime.now(),
    );
  }

  @override
  void write(BinaryWriter writer, Gasto obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.data)
      ..writeByte(2)
      ..write(obj.categoria)
      ..writeByte(3)
      ..write(obj.descricao)
      ..writeByte(4)
      ..write(obj.valor)
      ..writeByte(5)
      ..write(obj.criadoEm);
  }
}
