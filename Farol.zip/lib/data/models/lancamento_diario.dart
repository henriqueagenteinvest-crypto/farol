/// -----------------------------------------------------------------------
/// MODELO: LANÇAMENTO DIÁRIO
/// -----------------------------------------------------------------------
/// É o registro de um dia (ou de um período) de trabalho:
/// quanto rodou, quanto ganhou, quantas horas e quantas corridas fez.
///
/// IMPORTANTE: este modelo guarda apenas os DADOS BRUTOS informados pelo
/// motorista. Nenhum cálculo é salvo aqui — todo cálculo é feito na hora
/// pelo CalculationsService. Isso garante que, se o motorista corrigir o
/// preço do combustível, TODOS os números se ajustam sozinhos.
/// -----------------------------------------------------------------------
library;

import 'package:hive/hive.dart';
import '../../core/app_constants.dart';
import '../../core/hive_boxes.dart';

class LancamentoDiario {
  /// Identificador único (também é a chave no Hive).
  String id;
  DateTime data;

  /// Quilômetros rodados no dia.
  double km;

  /// Valor bruto recebido (antes de descontar combustível e gastos).
  double valorBruto;

  /// Horas trabalhadas (em decimal: 8h30 = 8.5).
  double horas;

  /// Quantidade de corridas realizadas.
  int corridas;

  /// Gasolina ou Álcool.
  String tipoCombustivel;

  /// Consumo do carro no período (km por litro).
  double kmPorLitro;

  /// Preço pago no litro.
  double precoLitro;

  /// Anotação livre do motorista.
  String observacao;

  /// Marca se o lançamento veio da leitura de um print (OCR).
  bool veioDeOcr;

  DateTime criadoEm;

  LancamentoDiario({
    String? id,
    required this.data,
    this.km = 0,
    this.valorBruto = 0,
    this.horas = 0,
    this.corridas = 0,
    this.tipoCombustivel = AppConstants.combustivelGasolina,
    this.kmPorLitro = AppConstants.kmPorLitroPadrao,
    this.precoLitro = AppConstants.precoLitroPadrao,
    this.observacao = '',
    this.veioDeOcr = false,
    DateTime? criadoEm,
  })  : id = id ?? _gerarId(),
        criadoEm = criadoEm ?? DateTime.now();

  static String _gerarId() =>
      'L${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}';

  LancamentoDiario copiarCom({
    DateTime? data,
    double? km,
    double? valorBruto,
    double? horas,
    int? corridas,
    String? tipoCombustivel,
    double? kmPorLitro,
    double? precoLitro,
    String? observacao,
    bool? veioDeOcr,
  }) {
    return LancamentoDiario(
      id: id,
      data: data ?? this.data,
      km: km ?? this.km,
      valorBruto: valorBruto ?? this.valorBruto,
      horas: horas ?? this.horas,
      corridas: corridas ?? this.corridas,
      tipoCombustivel: tipoCombustivel ?? this.tipoCombustivel,
      kmPorLitro: kmPorLitro ?? this.kmPorLitro,
      precoLitro: precoLitro ?? this.precoLitro,
      observacao: observacao ?? this.observacao,
      veioDeOcr: veioDeOcr ?? this.veioDeOcr,
      criadoEm: criadoEm,
    );
  }
}

class LancamentoDiarioAdapter extends TypeAdapter<LancamentoDiario> {
  @override
  final int typeId = HiveBoxes.typeLancamento;

  @override
  LancamentoDiario read(BinaryReader reader) {
    final numCampos = reader.readByte();
    final campos = <int, dynamic>{
      for (int i = 0; i < numCampos; i++) reader.readByte(): reader.read(),
    };
    return LancamentoDiario(
      id: campos[0] as String?,
      data: campos[1] as DateTime? ?? DateTime.now(),
      km: (campos[2] as num?)?.toDouble() ?? 0,
      valorBruto: (campos[3] as num?)?.toDouble() ?? 0,
      horas: (campos[4] as num?)?.toDouble() ?? 0,
      corridas: campos[5] as int? ?? 0,
      tipoCombustivel:
          campos[6] as String? ?? AppConstants.combustivelGasolina,
      kmPorLitro:
          (campos[7] as num?)?.toDouble() ?? AppConstants.kmPorLitroPadrao,
      precoLitro:
          (campos[8] as num?)?.toDouble() ?? AppConstants.precoLitroPadrao,
      observacao: campos[9] as String? ?? '',
      veioDeOcr: campos[10] as bool? ?? false,
      criadoEm: campos[11] as DateTime? ?? DateTime.now(),
    );
  }

  @override
  void write(BinaryWriter writer, LancamentoDiario obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.data)
      ..writeByte(2)
      ..write(obj.km)
      ..writeByte(3)
      ..write(obj.valorBruto)
      ..writeByte(4)
      ..write(obj.horas)
      ..writeByte(5)
      ..write(obj.corridas)
      ..writeByte(6)
      ..write(obj.tipoCombustivel)
      ..writeByte(7)
      ..write(obj.kmPorLitro)
      ..writeByte(8)
      ..write(obj.precoLitro)
      ..writeByte(9)
      ..write(obj.observacao)
      ..writeByte(10)
      ..write(obj.veioDeOcr)
      ..writeByte(11)
      ..write(obj.criadoEm);
  }
}
