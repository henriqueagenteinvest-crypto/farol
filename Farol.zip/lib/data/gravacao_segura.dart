/// =======================================================================
/// GRAVAÇÃO SEGURA
/// =======================================================================
/// POR QUE ISTO EXISTE
///
/// Quando o Hive não consegue gravar no disco do celular, ele devolve um
/// erro. Se ninguém trata esse erro, a tela trava em "Salvando..." e o
/// motorista pensa que perdeu o dia de trabalho.
///
/// Só que há um detalhe importante: o Hive guarda o registro NA MEMÓRIA
/// no mesmo instante em que recebe o `put`. O que pode falhar é a
/// gravação no arquivo. Ou seja: mesmo com erro de disco, o número já
/// aparece certinho no aplicativo.
///
/// Então a regra aqui é:
///   1. tenta gravar;
///   2. se falhar, CONFERE se o registro entrou mesmo assim;
///   3. devolve o que realmente aconteceu — nunca estoura para a tela;
///   4. guarda o texto do erro, para a tela de Diagnóstico mostrar.
///
/// Assim o motorista nunca fica no escuro, e eu consigo descobrir a causa
/// real olhando o Diagnóstico em vez de adivinhar.
/// =======================================================================
library;

/// -----------------------------------------------------------------------
/// CONTADOR DE MUDANÇAS
/// -----------------------------------------------------------------------
/// As listas de lançamentos, gastos e abastecimentos são ordenadas toda
/// vez que alguém pede. Como as telas pedem muitas vezes por segundo
/// enquanto se rola, isso vira trabalho repetido à toa.
///
/// Este contador sobe UMA unidade a cada gravação ou exclusão. Os
/// repositórios guardam a lista pronta junto com o número do contador:
/// se o número não mudou, devolvem a lista guardada na hora.
class VersaoDados {
  VersaoDados._();

  static int atual = 0;

  /// Avisa que algum dado mudou — todas as listas guardadas ficam velhas.
  static void mudou() => atual++;
}

/// O que aconteceu numa tentativa de gravar.
class ResultadoGravacao {
  /// Gravou no disco sem erro nenhum.
  final bool gravouNoDisco;

  /// O registro está valendo dentro do aplicativo agora.
  final bool valendoAgora;

  /// Texto do erro, quando houve.
  final String? erro;

  const ResultadoGravacao({
    required this.gravouNoDisco,
    required this.valendoAgora,
    this.erro,
  });

  const ResultadoGravacao.ok()
      : gravouNoDisco = true,
        valendoAgora = true,
        erro = null;

  /// Deu tudo certo?
  bool get perfeito => gravouNoDisco && valendoAgora;

  /// O dado vale agora, mas pode não sobreviver a fechar o aplicativo.
  bool get soNaMemoria => !gravouNoDisco && valendoAgora;

  /// Não entrou de jeito nenhum.
  bool get falhouDeVez => !valendoAgora;
}

/// Caderno de ocorrências: guarda os últimos problemas de gravação para a
/// tela de Diagnóstico. Nada disso vai para lugar nenhum fora do celular.
class DiarioDeErros {
  DiarioDeErros._();

  static final List<String> _linhas = <String>[];

  /// Quantas gravações falharam desde que o aplicativo abriu.
  static int falhas = 0;

  static List<String> get linhas => List<String>.unmodifiable(_linhas);

  static bool get temErro => _linhas.isNotEmpty;

  static void anotar(String oQue, Object erro) {
    falhas++;
    final agora = DateTime.now();
    final hora = '${agora.hour.toString().padLeft(2, '0')}:'
        '${agora.minute.toString().padLeft(2, '0')}:'
        '${agora.second.toString().padLeft(2, '0')}';
    _linhas.insert(0, '[$hora] $oQue → $erro');
    // Guarda só as 20 últimas: é o bastante para entender o problema.
    if (_linhas.length > 20) _linhas.removeRange(20, _linhas.length);
  }

  static void limpar() {
    _linhas.clear();
    falhas = 0;
  }
}

/// Executa uma gravação sem deixar o erro chegar na tela.
///
/// [gravar] é a operação (ex.: `box.put(id, objeto)`).
/// [conferir] responde "o registro está valendo agora?" — normalmente é
/// um `box.get(id) != null`.
Future<ResultadoGravacao> gravarComSeguranca({
  required Future<void> Function() gravar,
  required bool Function() conferir,
  required String descricao,
}) async {
  try {
    await gravar();
    VersaoDados.mudou();
    return const ResultadoGravacao.ok();
  } catch (e) {
    DiarioDeErros.anotar(descricao, e);
    bool entrou;
    try {
      entrou = conferir();
    } catch (_) {
      entrou = false;
    }
    // Mesmo com falha no disco, o registro pode ter entrado na memória:
    // as listas precisam ser refeitas de qualquer jeito.
    VersaoDados.mudou();
    return ResultadoGravacao(
      gravouNoDisco: false,
      valendoAgora: entrou,
      erro: e.toString(),
    );
  }
}
