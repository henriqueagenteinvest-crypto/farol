/// -----------------------------------------------------------------------
/// BANCO DE DADOS LOCAL (HIVE)
/// -----------------------------------------------------------------------
/// Prepara o armazenamento no celular. É chamado uma única vez, no início
/// do app (main.dart), ANTES de qualquer tela aparecer.
///
/// 100% OFFLINE: nada aqui conversa com internet, nuvem ou servidor.
/// Se o motorista desinstalar o app, os dados vão junto — por isso a tela
/// de exportação (Excel/PDF) é a forma de guardar cópia de segurança.
///
/// -----------------------------------------------------------------------
/// ATENÇÃO — A ARMADILHA QUE QUEBROU O APLICATIVO INTEIRO
/// -----------------------------------------------------------------------
/// Antes, o registro era feito por um método assim:
///
///     static void _registrar(int typeId, TypeAdapter<dynamic> adapter)
///
/// Parece inofensivo, mas não é. Como o parâmetro é `TypeAdapter<dynamic>`,
/// o Dart passava `dynamic` como tipo para o `Hive.registerAdapter<T>()`.
/// E o Hive, na hora de GRAVAR, procura o adaptador perguntando
/// "este objeto é do tipo T?". Com T = dynamic, a resposta é SIM para
/// qualquer objeto — então TODO mundo caía no primeiro adaptador da
/// lista, o do Motorista.
///
/// Resultado: gravar um lançamento estourava
///     "type 'LancamentoDiario' is not a subtype of type 'Motorista'"
/// e só o cadastro do motorista salvava (por ser o primeiro da fila).
/// Era isso que fazia o dia não salvar, a jornada não guardar e as
/// preferências de aparência voltarem ao normal ao reabrir o app.
///
/// A correção é o `<T>` no método abaixo: com ele, cada adaptador é
/// registrado com o SEU tipo de verdade.
/// -----------------------------------------------------------------------
library;

import 'package:hive_flutter/hive_flutter.dart';

import '../core/hive_boxes.dart';
import 'gravacao_segura.dart';
import 'models/abastecimento.dart';
import 'models/configuracoes.dart';
import 'models/gasto.dart';
import 'models/jornada.dart';
import 'models/lancamento_diario.dart';
import 'models/motorista.dart';

class LocalDatabase {
  LocalDatabase._();

  static bool _iniciado = false;

  /// Inicia o Hive, registra os modelos e abre todas as caixas.
  static Future<void> iniciar() async {
    if (_iniciado) return;

    await Hive.initFlutter();

    // Cada adaptador com o SEU tipo. Veja a explicação no topo do arquivo.
    _registrar<Motorista>(HiveBoxes.typeMotorista, MotoristaAdapter());
    _registrar<LancamentoDiario>(
        HiveBoxes.typeLancamento, LancamentoDiarioAdapter());
    _registrar<Abastecimento>(
        HiveBoxes.typeAbastecimento, AbastecimentoAdapter());
    _registrar<Gasto>(HiveBoxes.typeGasto, GastoAdapter());
    _registrar<Pausa>(HiveBoxes.typePausa, PausaAdapter());
    _registrar<Jornada>(HiveBoxes.typeJornada, JornadaAdapter());
    _registrar<Configuracoes>(
        HiveBoxes.typeConfiguracoes, ConfiguracoesAdapter());

    // Abre as caixas em paralelo (mais rápido na abertura do app).
    await Future.wait<void>(<Future<void>>[
      Hive.openBox<Motorista>(HiveBoxes.motorista),
      Hive.openBox<LancamentoDiario>(HiveBoxes.lancamentos),
      Hive.openBox<Abastecimento>(HiveBoxes.abastecimentos),
      Hive.openBox<Gasto>(HiveBoxes.gastos),
      Hive.openBox<Jornada>(HiveBoxes.jornadas),
      Hive.openBox<Configuracoes>(HiveBoxes.configuracoes),
    ]);

    _iniciado = true;
  }

  /// O `<T>` aqui é o que conserta tudo: ele carrega o tipo de verdade
  /// do modelo até o registro do Hive.
  static void _registrar<T>(int typeId, TypeAdapter<T> adapter) {
    if (!Hive.isAdapterRegistered(typeId)) {
      Hive.registerAdapter<T>(adapter);
    }
  }

  /// Confere, na prática, se a gravação está funcionando.
  ///
  /// Escreve um registro de teste, lê de volta e apaga. É rápido e roda
  /// na abertura do app: se algo estiver errado com o armazenamento do
  /// aparelho, o motorista descobre ANTES de perder um dia de trabalho.
  static Future<String?> conferirGravacao() async {
    try {
      final caixa = Hive.box<LancamentoDiario>(HiveBoxes.lancamentos);
      const chave = '__teste_de_gravacao__';
      final teste = LancamentoDiario(id: chave, data: DateTime(2000, 1, 1));

      await caixa.put(chave, teste);
      final lido = caixa.get(chave);
      await caixa.delete(chave);

      if (lido == null) return 'O registro de teste não voltou.';
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  /// Garante que tudo que está na memória foi para o arquivo.
  /// Chamado quando o app vai para segundo plano.
  static Future<void> descarregar() async {
    for (final caixa in <BoxBase<dynamic>>[
      Hive.box<Motorista>(HiveBoxes.motorista),
      Hive.box<LancamentoDiario>(HiveBoxes.lancamentos),
      Hive.box<Abastecimento>(HiveBoxes.abastecimentos),
      Hive.box<Gasto>(HiveBoxes.gastos),
      Hive.box<Jornada>(HiveBoxes.jornadas),
      Hive.box<Configuracoes>(HiveBoxes.configuracoes),
    ]) {
      try {
        await caixa.flush();
      } catch (_) {
        // Melhor esforço: se uma caixa falhar, as outras continuam.
      }
    }
  }

  /// Compacta os arquivos, removendo o espaço deixado por registros
  /// apagados. Roda de vez em quando, sem travar nada.
  static Future<void> compactar() async {
    for (final caixa in <BoxBase<dynamic>>[
      Hive.box<LancamentoDiario>(HiveBoxes.lancamentos),
      Hive.box<Abastecimento>(HiveBoxes.abastecimentos),
      Hive.box<Gasto>(HiveBoxes.gastos),
      Hive.box<Jornada>(HiveBoxes.jornadas),
    ]) {
      try {
        await caixa.compact();
      } catch (_) {
        // Compactar é só faxina: falhar aqui não prejudica nada.
      }
    }
  }

  /// Apaga TODOS os lançamentos, abastecimentos, gastos e jornadas.
  /// Mantém o cadastro do motorista e as configurações.
  static Future<void> limparMovimentacoes() async {
    await Hive.box<LancamentoDiario>(HiveBoxes.lancamentos).clear();
    await Hive.box<Abastecimento>(HiveBoxes.abastecimentos).clear();
    await Hive.box<Gasto>(HiveBoxes.gastos).clear();
    await Hive.box<Jornada>(HiveBoxes.jornadas).clear();
    VersaoDados.mudou();
  }

  /// Apaga absolutamente tudo e volta o app ao estado de recém-instalado.
  static Future<void> apagarTudo() async {
    await limparMovimentacoes();
    await Hive.box<Motorista>(HiveBoxes.motorista).clear();
    await Hive.box<Configuracoes>(HiveBoxes.configuracoes).clear();
    VersaoDados.mudou();
  }

  /// Fecha o banco (usado ao encerrar o app).
  static Future<void> fechar() => Hive.close();
}
