/// -----------------------------------------------------------------------
/// BANCO DE DADOS LOCAL (HIVE)
/// -----------------------------------------------------------------------
/// Prepara o armazenamento no celular. É chamado uma única vez, no início
/// do app (main.dart), ANTES de qualquer tela aparecer.
///
/// 100% OFFLINE: nada aqui conversa com internet, nuvem ou servidor.
/// Se o motorista desinstalar o app, os dados vão junto — por isso a tela
/// de exportação (Excel/PDF) é a forma de guardar cópia de segurança.
/// -----------------------------------------------------------------------
library;

import 'package:hive_flutter/hive_flutter.dart';

import '../core/hive_boxes.dart';
import 'models/abastecimento.dart';
import 'models/configuracoes.dart';
import 'models/gasto.dart';
import 'models/jornada.dart';
import 'models/lancamento_diario.dart';
import 'models/motorista.dart';

class LocalDatabase {
  LocalDatabase._();

  static bool _iniciado = false;

  /// Inicia o Hive, registra os modelos e abre todas as caixas.
  static Future<void> iniciar() async {
    if (_iniciado) return;

    await Hive.initFlutter();

    // Registra os adapters (só se ainda não estiverem registrados).
    _registrar(HiveBoxes.typeMotorista, MotoristaAdapter());
    _registrar(HiveBoxes.typeLancamento, LancamentoDiarioAdapter());
    _registrar(HiveBoxes.typeAbastecimento, AbastecimentoAdapter());
    _registrar(HiveBoxes.typeGasto, GastoAdapter());
    _registrar(HiveBoxes.typePausa, PausaAdapter());
    _registrar(HiveBoxes.typeJornada, JornadaAdapter());
    _registrar(HiveBoxes.typeConfiguracoes, ConfiguracoesAdapter());

    // Abre as caixas em paralelo (mais rápido na abertura do app).
    await Future.wait<void>(<Future<void>>[
      Hive.openBox<Motorista>(HiveBoxes.motorista),
      Hive.openBox<LancamentoDiario>(HiveBoxes.lancamentos),
      Hive.openBox<Abastecimento>(HiveBoxes.abastecimentos),
      Hive.openBox<Gasto>(HiveBoxes.gastos),
      Hive.openBox<Jornada>(HiveBoxes.jornadas),
      Hive.openBox<Configuracoes>(HiveBoxes.configuracoes),
    ]);

    _iniciado = true;
  }

  static void _registrar(int typeId, TypeAdapter<dynamic> adapter) {
    if (!Hive.isAdapterRegistered(typeId)) {
      Hive.registerAdapter(adapter);
    }
  }

  /// Apaga TODOS os lançamentos, abastecimentos, gastos e jornadas.
  /// Mantém o cadastro do motorista e as configurações.
  static Future<void> limparMovimentacoes() async {
    await Hive.box<LancamentoDiario>(HiveBoxes.lancamentos).clear();
    await Hive.box<Abastecimento>(HiveBoxes.abastecimentos).clear();
    await Hive.box<Gasto>(HiveBoxes.gastos).clear();
    await Hive.box<Jornada>(HiveBoxes.jornadas).clear();
  }

  /// Apaga absolutamente tudo e volta o app ao estado de recém-instalado.
  static Future<void> apagarTudo() async {
    await limparMovimentacoes();
    await Hive.box<Motorista>(HiveBoxes.motorista).clear();
    await Hive.box<Configuracoes>(HiveBoxes.configuracoes).clear();
  }

  /// Fecha o banco (usado ao encerrar o app).
  static Future<void> fechar() => Hive.close();
}
