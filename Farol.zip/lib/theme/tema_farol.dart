/// -----------------------------------------------------------------------
/// O TEMA DO FAROL
/// -----------------------------------------------------------------------
/// Em vez de uma lista fixa de temas, o visual inteiro é CALCULADO a partir
/// de duas escolhas do motorista: claro/escuro e uma cor principal.
///
/// Isso significa que qualquer cor que ele escolher gera um tema completo e
/// harmônico — fundos, textos, gradientes e sombras saem todos da mesma
/// família de cor, sem risco de combinação feia ou texto ilegível.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

class TemaFarol {
  final Brightness brilho;

  /// Cor de marca: botões, destaques, gráficos.
  final Color primaria;

  /// Cor de apoio, derivada da principal.
  final Color secundaria;

  /// Fundo geral da tela.
  final Color fundo;

  /// Fundo dos cartões.
  final Color superficie;

  /// Fundo de elementos dentro dos cartões (campos, chips).
  final Color superficieAlta;

  /// Cor principal das letras.
  final Color texto;

  /// Cor das letras de apoio.
  final Color textoSuave;

  /// Cores de estado.
  final Color sucesso;
  final Color alerta;
  final Color erro;

  /// Gradiente da marca.
  final List<Color> gradiente;

  /// Raio das bordas arredondadas.
  final double raioBorda;

  /// Multiplicador do tamanho das letras (acessibilidade).
  final double escalaTexto;

  /// Intensidade do brilho nos destaques.
  final double intensidadeBrilho;

  const TemaFarol({
    required this.brilho,
    required this.primaria,
    required this.secundaria,
    required this.fundo,
    required this.superficie,
    required this.superficieAlta,
    required this.texto,
    required this.textoSuave,
    required this.sucesso,
    required this.alerta,
    required this.erro,
    required this.gradiente,
    this.raioBorda = 16,
    this.escalaTexto = 1.0,
    this.intensidadeBrilho = 0.30,
  });

  // =====================================================================
  // GERAÇÃO DO TEMA A PARTIR DE UMA COR
  // =====================================================================

  /// Monta um tema completo a partir do brilho e da cor principal.
  ///
  /// Como funciona: pegamos o MATIZ (a "família") da cor escolhida e
  /// construímos fundos e textos na mesma família, variando só a
  /// luminosidade. É o que faz o app parecer desenhado para aquela cor,
  /// e não apenas pintado por cima.
  factory TemaFarol.gerar({
    required Brightness brilho,
    required Color corPrimaria,
    double escalaTexto = 1.0,
  }) {
    final hsl = HSLColor.fromColor(corPrimaria);
    final matiz = hsl.hue;

    // A cor de apoio fica um passo adiante na roda de cores.
    final matizApoio = (matiz + 32) % 360;

    Color c(double h, double s, double l) =>
        HSLColor.fromAHSL(1, h, s.clamp(0.0, 1.0), l.clamp(0.0, 1.0)).toColor();

    final escuro = brilho == Brightness.dark;

    if (escuro) {
      return TemaFarol(
        brilho: brilho,
        primaria: corPrimaria,
        secundaria: c(matizApoio, (hsl.saturation * 0.85).clamp(0.35, 0.9), 0.62),
        // Nunca preto puro: melhora o contraste e cansa menos a vista.
        fundo: c(matiz, 0.26, 0.058),
        superficie: c(matiz, 0.22, 0.098),
        superficieAlta: c(matiz, 0.20, 0.152),
        texto: c(matiz, 0.22, 0.965),
        textoSuave: c(matiz, 0.14, 0.66),
        sucesso: const Color(0xFF22C55E),
        alerta: const Color(0xFFF5A524),
        erro: const Color(0xFFF4525F),
        gradiente: <Color>[
          corPrimaria,
          c(matiz, (hsl.saturation * 1.05).clamp(0.4, 1.0), 0.34),
        ],
        intensidadeBrilho: 0.38,
        escalaTexto: escalaTexto,
      );
    }

    return TemaFarol(
      brilho: brilho,
      primaria: corPrimaria,
      secundaria: c(matizApoio, (hsl.saturation * 0.9).clamp(0.35, 0.9), 0.42),
      fundo: c(matiz, 0.32, 0.972),
      superficie: Colors.white,
      superficieAlta: c(matiz, 0.34, 0.944),
      texto: c(matiz, 0.30, 0.105),
      textoSuave: c(matiz, 0.12, 0.42),
      sucesso: const Color(0xFF0F9D58),
      alerta: const Color(0xFFB86E00),
      erro: const Color(0xFFD32F3E),
      gradiente: <Color>[
        corPrimaria,
        c(matiz, (hsl.saturation * 1.0).clamp(0.4, 1.0), 0.40),
      ],
      intensidadeBrilho: 0.20,
      escalaTexto: escalaTexto,
    );
  }

  // =====================================================================
  // ATALHOS USADOS PELAS TELAS
  // =====================================================================

  bool get ehEscuro => brilho == Brightness.dark;

  /// Preto ou branco, o que tiver melhor contraste sobre a cor informada.
  static Color contrasteSobre(Color fundo) =>
      fundo.computeLuminance() > 0.5
          ? const Color(0xFF0B0B0B)
          : const Color(0xFFFFFFFF);

  /// Cor de texto para escrever em cima da cor principal.
  Color get textoSobrePrimaria => contrasteSobre(primaria);

  LinearGradient get gradienteLinear => LinearGradient(
        colors: gradiente,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  /// Fundo da tela com um leve degradê, para não ficar chapado.
  LinearGradient get gradienteFundo => LinearGradient(
        colors: <Color>[
          fundo,
          Color.lerp(fundo, primaria, ehEscuro ? 0.055 : 0.030)!,
          fundo,
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );

  /// Sombra suave padrão dos cartões.
  List<BoxShadow> get sombraCartao => <BoxShadow>[
        BoxShadow(
          color: ehEscuro
              ? Colors.black.withValues(alpha: 0.42)
              : primaria.withValues(alpha: 0.07),
          blurRadius: 18,
          offset: const Offset(0, 6),
        ),
      ];

  /// Brilho colorido para elementos em destaque.
  List<BoxShadow> brilhoDe(Color cor) => <BoxShadow>[
        BoxShadow(
          color: cor.withValues(alpha: intensidadeBrilho),
          blurRadius: 24,
          spreadRadius: -4,
          offset: const Offset(0, 8),
        ),
      ];

  /// Linha divisória discreta.
  Color get divisor => textoSuave.withValues(alpha: 0.16);
}
