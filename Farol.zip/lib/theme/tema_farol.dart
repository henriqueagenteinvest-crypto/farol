/// -----------------------------------------------------------------------
/// DEFINIÇÃO DE UM TEMA DO FAROL
/// -----------------------------------------------------------------------
/// Cada tema é uma "receita" de cores + nível de layout. O nível de layout
/// diz QUANTA informação a tela inicial mostra:
///   - simples   -> poucos cartões, letras maiores (para quem quer o básico)
///   - completo  -> todos os indicadores do dia
///   - dashboard -> indicadores + gráficos em destaque (estilo painel)
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

/// Quanta informação a interface mostra.
enum NivelLayout {
  simples('Simples', 'Só o essencial, letras grandes'),
  completo('Completo', 'Todos os indicadores do dia'),
  dashboard('Painel', 'Indicadores + gráficos em destaque');

  final String rotulo;
  final String descricao;
  const NivelLayout(this.rotulo, this.descricao);
}

class TemaFarol {
  /// Identificador salvo no Hive. NUNCA mude depois de publicado.
  final String id;

  /// Nome mostrado na tela de temas.
  final String nome;

  /// Explicação curta para o motorista entender a diferença.
  final String descricao;

  final Brightness brilho;
  final NivelLayout nivel;

  /// Cor de marca (botões, destaques).
  final Color primaria;

  /// Cor de apoio (segundo destaque, gráficos).
  final Color secundaria;

  /// Fundo geral da tela.
  final Color fundo;

  /// Fundo dos cartões.
  final Color superficie;

  /// Fundo de cartões elevados (nível 2).
  final Color superficieAlta;

  /// Cor principal das letras.
  final Color texto;

  /// Cor das letras de apoio (rótulos, legendas).
  final Color textoSuave;

  /// Cores de estado.
  final Color sucesso;
  final Color alerta;
  final Color erro;

  /// Gradiente da marca — usado no cabeçalho, no botão principal e nos
  /// cartões de destaque. Sempre com 2 ou 3 cores.
  final List<Color> gradiente;

  /// Quando true, o fundo da tela também recebe um gradiente suave.
  final bool fundoComGradiente;

  /// Raio das bordas arredondadas dos cartões.
  final double raioBorda;

  /// Multiplicador do tamanho das letras (acessibilidade).
  final double escalaTexto;

  /// Intensidade do brilho (glow) nos destaques — a identidade do "farol".
  final double intensidadeBrilho;

  const TemaFarol({
    required this.id,
    required this.nome,
    required this.descricao,
    required this.brilho,
    required this.nivel,
    required this.primaria,
    required this.secundaria,
    required this.fundo,
    required this.superficie,
    required this.superficieAlta,
    required this.texto,
    required this.textoSuave,
    required this.gradiente,
    this.sucesso = const Color(0xFF20C997),
    this.alerta = const Color(0xFFFFB020),
    this.erro = const Color(0xFFFF5B6E),
    this.fundoComGradiente = false,
    this.raioBorda = 20,
    this.escalaTexto = 1.0,
    this.intensidadeBrilho = 0.35,
  });

  bool get ehEscuro => brilho == Brightness.dark;

  /// Gradiente pronto para usar em BoxDecoration.
  LinearGradient get gradienteLinear => LinearGradient(
        colors: gradiente,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  /// Gradiente do fundo da tela (quando o tema usa fundo degradê).
  LinearGradient get gradienteFundo => LinearGradient(
        colors: fundoComGradiente
            ? <Color>[fundo, Color.lerp(fundo, primaria, 0.10)!, fundo]
            : <Color>[fundo, fundo],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );

  /// Sombra suave padrão dos cartões.
  List<BoxShadow> get sombraCartao => <BoxShadow>[
        BoxShadow(
          color: ehEscuro
              ? Colors.black.withValues(alpha: 0.45)
              : Colors.black.withValues(alpha: 0.07),
          blurRadius: 18,
          offset: const Offset(0, 6),
        ),
      ];

  /// Brilho colorido (efeito farol) para elementos em destaque.
  List<BoxShadow> brilhoDe(Color cor) => <BoxShadow>[
        BoxShadow(
          color: cor.withValues(alpha: intensidadeBrilho),
          blurRadius: 26,
          spreadRadius: -4,
          offset: const Offset(0, 8),
        ),
      ];
}
