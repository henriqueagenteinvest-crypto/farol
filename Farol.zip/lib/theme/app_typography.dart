/// -----------------------------------------------------------------------
/// TIPOGRAFIA DO FAROL
/// -----------------------------------------------------------------------
/// REGRA DE OURO: o app é 100% offline. O pacote google_fonts baixa a fonte
/// da internet na PRIMEIRA vez e guarda em cache. Se o celular estiver sem
/// internet nesse primeiro momento, ele apenas usa a fonte padrão do sistema
/// (Roboto no Android) — o app NUNCA quebra por causa disso.
///
/// Para garantir a Poppins mesmo sem nunca ter internet, veja a seção
/// "Fontes 100% offline" no README.md (é só colocar os arquivos .ttf em
/// assets/fonts/, declarar no pubspec.yaml e trocar `fonteEmbutida` para true).
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTypography {
  AppTypography._();

  /// Troque para `true` depois de colocar os .ttf da Poppins em assets/fonts/
  /// e declará-los no pubspec.yaml. Aí o app deixa de depender de download.
  static const bool fonteEmbutida = false;

  /// Nome da família declarada no pubspec quando `fonteEmbutida` é true.
  static const String familiaEmbutida = 'Poppins';

  /// Devolve um TextStyle na fonte escolhida, com proteção contra falha.
  static TextStyle _estilo(TextStyle base, {bool titulo = false}) {
    if (fonteEmbutida) {
      return base.copyWith(fontFamily: familiaEmbutida);
    }
    try {
      // Títulos em Poppins (mais marcante), textos em Inter (mais legível).
      return titulo
          ? GoogleFonts.poppins(textStyle: base)
          : GoogleFonts.inter(textStyle: base);
    } catch (_) {
      // Sem internet e sem cache: usa a fonte do sistema. App continua ótimo.
      return base;
    }
  }

  /// Monta o conjunto completo de estilos de texto do app.
  /// `corTexto` é a cor principal e `corSecundaria` a dos textos de apoio.
  static TextTheme construir({
    required Color corTexto,
    required Color corSecundaria,
    double escala = 1.0,
  }) {
    double t(double v) => v * escala;

    return TextTheme(
      // Números grandes de destaque (ex.: lucro do dia)
      displayLarge: _estilo(
        TextStyle(
          fontSize: t(40),
          fontWeight: FontWeight.w700,
          color: corTexto,
          height: 1.1,
          letterSpacing: -1.0,
        ),
        titulo: true,
      ),
      displayMedium: _estilo(
        TextStyle(
          fontSize: t(32),
          fontWeight: FontWeight.w700,
          color: corTexto,
          height: 1.15,
          letterSpacing: -0.8,
        ),
        titulo: true,
      ),
      displaySmall: _estilo(
        TextStyle(
          fontSize: t(26),
          fontWeight: FontWeight.w700,
          color: corTexto,
          letterSpacing: -0.5,
        ),
        titulo: true,
      ),
      // Títulos de tela e de card
      headlineMedium: _estilo(
        TextStyle(
          fontSize: t(22),
          fontWeight: FontWeight.w700,
          color: corTexto,
          letterSpacing: -0.3,
        ),
        titulo: true,
      ),
      headlineSmall: _estilo(
        TextStyle(
          fontSize: t(19),
          fontWeight: FontWeight.w600,
          color: corTexto,
        ),
        titulo: true,
      ),
      titleLarge: _estilo(
        TextStyle(
          fontSize: t(17),
          fontWeight: FontWeight.w600,
          color: corTexto,
        ),
        titulo: true,
      ),
      titleMedium: _estilo(
        TextStyle(
          fontSize: t(15.5),
          fontWeight: FontWeight.w600,
          color: corTexto,
        ),
      ),
      // Corpo de texto
      bodyLarge: _estilo(
        TextStyle(fontSize: t(15.5), color: corTexto, height: 1.45),
      ),
      bodyMedium: _estilo(
        TextStyle(fontSize: t(14), color: corTexto, height: 1.45),
      ),
      bodySmall: _estilo(
        TextStyle(fontSize: t(12.5), color: corSecundaria, height: 1.4),
      ),
      // Rótulos (labels de KPI, botões)
      labelLarge: _estilo(
        TextStyle(
          fontSize: t(15),
          fontWeight: FontWeight.w700,
          color: corTexto,
          letterSpacing: 0.2,
        ),
        titulo: true,
      ),
      labelMedium: _estilo(
        TextStyle(
          fontSize: t(12.5),
          fontWeight: FontWeight.w600,
          color: corSecundaria,
          letterSpacing: 0.4,
        ),
      ),
      labelSmall: _estilo(
        TextStyle(
          fontSize: t(11),
          fontWeight: FontWeight.w600,
          color: corSecundaria,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}
