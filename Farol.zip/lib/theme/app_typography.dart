/// -----------------------------------------------------------------------
/// TIPOGRAFIA DO FAROL
/// -----------------------------------------------------------------------
/// O motorista escolhe TRÊS coisas em Aparência, e todas mudam o
/// aplicativo inteiro na hora:
///
///   • CONJUNTO DE FONTES  — Moderna, Clássica ou a fonte do celular
///   • TAMANHO DA LETRA    — Pequena, Média, Grande ou Enorme
///   • NÚMEROS ALINHADOS   — números em fonte de máquina, com as casas
///                           uma embaixo da outra (fica muito mais fácil
///                           de comparar valores um sob o outro)
///
/// REGRA DE OURO: o app é 100% offline. O pacote google_fonts baixa a
/// fonte na PRIMEIRA vez e guarda em cache. Sem internet nesse primeiro
/// momento, ele usa a fonte padrão do sistema — o app NUNCA quebra por
/// causa disso. Quem quiser garantia total é só escolher "Fonte do
/// celular", que não depende de download nenhum.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Os conjuntos de fonte que aparecem em Aparência.
enum ConjuntoFonte {
  moderna(
    'Moderna',
    'Letras enxutas, números alinhados — o visual de painel',
  ),
  classica(
    'Clássica',
    'Letras mais arredondadas e macias',
  ),
  sistema(
    'Do celular',
    'Usa a fonte do próprio aparelho. Nunca depende de internet',
  );

  final String rotulo;
  final String descricao;
  const ConjuntoFonte(this.rotulo, this.descricao);

  static ConjuntoFonte porNome(String? nome) => ConjuntoFonte.values.firstWhere(
        (f) => f.name == nome,
        orElse: () => ConjuntoFonte.moderna,
      );
}

/// Os tamanhos de letra oferecidos.
enum TamanhoTexto {
  pequena('Pequena', 0.90),
  media('Média', 1.00),
  grande('Grande', 1.15),
  enorme('Enorme', 1.30);

  final String rotulo;
  final double escala;
  const TamanhoTexto(this.rotulo, this.escala);

  /// Qual opção corresponde à escala guardada.
  static TamanhoTexto porEscala(double escala) {
    var melhor = TamanhoTexto.media;
    var menorDiferenca = double.infinity;
    for (final t in TamanhoTexto.values) {
      final d = (t.escala - escala).abs();
      if (d < menorDiferenca) {
        menorDiferenca = d;
        melhor = t;
      }
    }
    return melhor;
  }
}

class AppTypography {
  AppTypography._();

  /// Troque para `true` depois de colocar os .ttf em assets/fonts/ e
  /// declará-los no pubspec.yaml. Aí o app deixa de depender de download.
  static const bool fonteEmbutida = false;

  /// Nome da família declarada no pubspec quando `fonteEmbutida` é true.
  static const String familiaEmbutida = 'Poppins';

  // ---------------------------------------------------------------------
  // AS FONTES, UMA A UMA
  // ---------------------------------------------------------------------

  /// Fonte dos textos comuns.
  static TextStyle _corpo(TextStyle base, ConjuntoFonte conjunto,
      {bool titulo = false}) {
    if (fonteEmbutida) return base.copyWith(fontFamily: familiaEmbutida);
    try {
      switch (conjunto) {
        case ConjuntoFonte.moderna:
          return titulo
              ? GoogleFonts.spaceGrotesk(textStyle: base)
              : GoogleFonts.inter(textStyle: base);
        case ConjuntoFonte.classica:
          return titulo
              ? GoogleFonts.poppins(textStyle: base)
              : GoogleFonts.nunitoSans(textStyle: base);
        case ConjuntoFonte.sistema:
          return base;
      }
    } catch (_) {
      // Sem internet e sem cache: fonte do sistema. O app continua ótimo.
      return base;
    }
  }

  /// Fonte dos NÚMEROS. É a que dá o ar de painel: todos os algarismos
  /// ocupam a mesma largura, então R$ 1.999,44 e R$ 2.750,00 ficam
  /// alinhados um embaixo do outro.
  static TextStyle numero(
    TextStyle base, {
    required ConjuntoFonte conjunto,
    required bool mono,
  }) {
    // `tabularFigures` já alinha os algarismos em qualquer fonte — é a
    // rede de segurança para quando o download da fonte não acontece.
    final comTabular = base.copyWith(
      fontFeatures: const <FontFeature>[FontFeature.tabularFigures()],
    );
    if (!mono || fonteEmbutida) return _corpo(comTabular, conjunto);
    try {
      return GoogleFonts.jetBrainsMono(textStyle: comTabular);
    } catch (_) {
      return comTabular;
    }
  }

  // ---------------------------------------------------------------------
  // O CONJUNTO COMPLETO DE ESTILOS
  // ---------------------------------------------------------------------

  static TextTheme construir({
    required Color corTexto,
    required Color corSecundaria,
    double escala = 1.0,
    ConjuntoFonte conjunto = ConjuntoFonte.moderna,
  }) {
    // Limite de segurança: fonte gigante demais quebra o layout.
    final e = escala.clamp(0.85, 1.35);

    TextStyle t(double tamanho, FontWeight peso,
            {Color? cor, double? espacamento, bool titulo = false}) =>
        _corpo(
          TextStyle(
            fontSize: tamanho * e,
            fontWeight: peso,
            color: cor ?? corTexto,
            letterSpacing: espacamento,
            height: 1.25,
            // ALGARISMOS DE LARGURA FIXA EM TODO O APLICATIVO.
            // É o detalhe que faz uma coluna de valores ficar alinhada
            // de verdade: o 1 ocupa o mesmo espaço do 8, então
            // R$ 1.999,44 e R$ 2.750,00 terminam na mesma posição.
            fontFeatures: const <FontFeature>[FontFeature.tabularFigures()],
          ),
          conjunto,
          titulo: titulo,
        );

    return TextTheme(
      displayLarge: t(38, FontWeight.w700, espacamento: -1.2, titulo: true),
      displayMedium: t(32, FontWeight.w700, espacamento: -1, titulo: true),
      displaySmall: t(27, FontWeight.w700, espacamento: -0.6, titulo: true),
      headlineLarge: t(24, FontWeight.w700, espacamento: -0.4, titulo: true),
      headlineMedium: t(21, FontWeight.w700, espacamento: -0.3, titulo: true),
      headlineSmall: t(18.5, FontWeight.w700, titulo: true),
      titleLarge: t(17, FontWeight.w600),
      titleMedium: t(15, FontWeight.w600),
      titleSmall: t(13.5, FontWeight.w600),
      bodyLarge: t(15.5, FontWeight.w400),
      bodyMedium: t(14, FontWeight.w400),
      bodySmall: t(12.5, FontWeight.w400, cor: corSecundaria),
      labelLarge: t(15, FontWeight.w700),
      labelMedium: t(12.5, FontWeight.w600, cor: corSecundaria),
      labelSmall: t(11, FontWeight.w700,
          cor: corSecundaria, espacamento: 1.1),
    );
  }
}
