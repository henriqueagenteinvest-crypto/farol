/// -----------------------------------------------------------------------
/// CATÁLOGO DOS 15 TEMAS DO FAROL
/// -----------------------------------------------------------------------
/// Do mais simples (poucos elementos, letras grandes) ao mais avançado
/// (painel completo com gráficos). O tema 1 é a identidade oficial do app:
/// preto azulado com azul elétrico e o brilho do farol.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'tema_farol.dart';

class CatalogoTemas {
  CatalogoTemas._();

  /// Tema usado quando o motorista ainda não escolheu nenhum.
  static const String idPadrao = 'farol_noturno';

  // =====================================================================
  // 1. FAROL NOTURNO — identidade oficial (referência visual do app)
  // =====================================================================
  static const TemaFarol farolNoturno = TemaFarol(
    id: 'farol_noturno',
    nome: 'Farol Noturno',
    descricao: 'O visual oficial do Farol: preto azulado com azul elétrico',
    brilho: Brightness.dark,
    nivel: NivelLayout.completo,
    primaria: Color(0xFF1F5CFF),
    secundaria: Color(0xFF6BA5FF),
    fundo: Color(0xFF070A12),
    superficie: Color(0xFF101728),
    superficieAlta: Color(0xFF17203A),
    texto: Color(0xFFF2F6FF),
    textoSuave: Color(0xFF8FA0C4),
    gradiente: <Color>[Color(0xFF1F5CFF), Color(0xFF0B2E9E)],
    fundoComGradiente: true,
    intensidadeBrilho: 0.45,
  );

  // =====================================================================
  // 2. FAROL CLARO — mesma identidade, versão dia
  // =====================================================================
  static const TemaFarol farolClaro = TemaFarol(
    id: 'farol_claro',
    nome: 'Farol Claro',
    descricao: 'Fundo branco com azul do Farol — ótimo sob sol forte',
    brilho: Brightness.light,
    nivel: NivelLayout.completo,
    primaria: Color(0xFF1F5CFF),
    secundaria: Color(0xFF4A87FF),
    fundo: Color(0xFFF4F7FC),
    superficie: Color(0xFFFFFFFF),
    superficieAlta: Color(0xFFEDF2FB),
    texto: Color(0xFF0C1526),
    textoSuave: Color(0xFF63708A),
    gradiente: <Color>[Color(0xFF2F6BFF), Color(0xFF1140C8)],
    sucesso: Color(0xFF0FA37F),
    erro: Color(0xFFD93F52),
    intensidadeBrilho: 0.22,
  );

  // =====================================================================
  // 3. AZUL PROFUNDO — degradê azul marinho, elegante
  // =====================================================================
  static const TemaFarol azulProfundo = TemaFarol(
    id: 'azul_profundo',
    nome: 'Azul Profundo',
    descricao: 'Degradê azul marinho com detalhes em ciano',
    brilho: Brightness.dark,
    nivel: NivelLayout.completo,
    primaria: Color(0xFF3D7BFF),
    secundaria: Color(0xFF39D0F5),
    fundo: Color(0xFF060F26),
    superficie: Color(0xFF0E1C3F),
    superficieAlta: Color(0xFF16295A),
    texto: Color(0xFFEAF2FF),
    textoSuave: Color(0xFF87A0CC),
    gradiente: <Color>[Color(0xFF39D0F5), Color(0xFF2E5BFF), Color(0xFF15267A)],
    fundoComGradiente: true,
    intensidadeBrilho: 0.4,
  );

  // =====================================================================
  // 4. VERDE ESTRADA — foco em lucro, tom de dinheiro
  // =====================================================================
  static const TemaFarol verdeEstrada = TemaFarol(
    id: 'verde_estrada',
    nome: 'Verde Estrada',
    descricao: 'Verde esmeralda em fundo escuro — destaque para o lucro',
    brilho: Brightness.dark,
    nivel: NivelLayout.completo,
    primaria: Color(0xFF1DBF73),
    secundaria: Color(0xFF7BE3A8),
    fundo: Color(0xFF06120D),
    superficie: Color(0xFF0F2119),
    superficieAlta: Color(0xFF163024),
    texto: Color(0xFFEFFBF4),
    textoSuave: Color(0xFF86AD9B),
    gradiente: <Color>[Color(0xFF2AE08A), Color(0xFF0E8C57)],
    alerta: Color(0xFFF5C043),
    fundoComGradiente: true,
    intensidadeBrilho: 0.38,
  );

  // =====================================================================
  // 5. VERMELHO TURBO — alto impacto
  // =====================================================================
  static const TemaFarol vermelhoTurbo = TemaFarol(
    id: 'vermelho_turbo',
    nome: 'Vermelho Turbo',
    descricao: 'Preto com vermelho esportivo, bem marcante',
    brilho: Brightness.dark,
    nivel: NivelLayout.completo,
    primaria: Color(0xFFE63946),
    secundaria: Color(0xFFFF8A5C),
    fundo: Color(0xFF120608),
    superficie: Color(0xFF210D11),
    superficieAlta: Color(0xFF2E1319),
    texto: Color(0xFFFFF0F1),
    textoSuave: Color(0xFFC28E93),
    gradiente: <Color>[Color(0xFFFF6B4A), Color(0xFFC1121F)],
    sucesso: Color(0xFF3DDC97),
    erro: Color(0xFFFF9AA5),
    fundoComGradiente: true,
    intensidadeBrilho: 0.42,
  );

  // =====================================================================
  // 6. ROXO NEON — degradê vibrante
  // =====================================================================
  static const TemaFarol roxoNeon = TemaFarol(
    id: 'roxo_neon',
    nome: 'Roxo Neon',
    descricao: 'Degradê roxo e rosa com brilho neon',
    brilho: Brightness.dark,
    nivel: NivelLayout.dashboard,
    primaria: Color(0xFF9B5CFF),
    secundaria: Color(0xFFFF5CC8),
    fundo: Color(0xFF0C0718),
    superficie: Color(0xFF190F2E),
    superficieAlta: Color(0xFF241640),
    texto: Color(0xFFF5EEFF),
    textoSuave: Color(0xFFA394C4),
    gradiente: <Color>[Color(0xFFFF5CC8), Color(0xFF9B5CFF), Color(0xFF4B2ADB)],
    fundoComGradiente: true,
    intensidadeBrilho: 0.55,
  );

  // =====================================================================
  // 7. PÔR DO SOL — degradê laranja e rosa, clima quente
  // =====================================================================
  static const TemaFarol porDoSol = TemaFarol(
    id: 'por_do_sol',
    nome: 'Pôr do Sol',
    descricao: 'Degradê laranja e rosa, visual acolhedor',
    brilho: Brightness.dark,
    nivel: NivelLayout.completo,
    primaria: Color(0xFFFF7A29),
    secundaria: Color(0xFFFF4D8D),
    fundo: Color(0xFF150B08),
    superficie: Color(0xFF25130D),
    superficieAlta: Color(0xFF331B12),
    texto: Color(0xFFFFF3EA),
    textoSuave: Color(0xFFC79E86),
    gradiente: <Color>[Color(0xFFFFB03A), Color(0xFFFF6A3D), Color(0xFFE23A73)],
    fundoComGradiente: true,
    intensidadeBrilho: 0.45,
  );

  // =====================================================================
  // 8. GRAFITE MINIMALISTA — o mais SIMPLES de todos
  // =====================================================================
  static const TemaFarol grafiteMinimalista = TemaFarol(
    id: 'grafite_minimalista',
    nome: 'Grafite Minimalista',
    descricao: 'Visual limpo, poucos elementos e letras maiores',
    brilho: Brightness.light,
    nivel: NivelLayout.simples,
    primaria: Color(0xFF2B3445),
    secundaria: Color(0xFF5C6B85),
    fundo: Color(0xFFF7F8FA),
    superficie: Color(0xFFFFFFFF),
    superficieAlta: Color(0xFFEFF1F5),
    texto: Color(0xFF141A24),
    textoSuave: Color(0xFF6B7688),
    gradiente: <Color>[Color(0xFF3A4457), Color(0xFF1D2531)],
    sucesso: Color(0xFF10916F),
    erro: Color(0xFFC93A4A),
    raioBorda: 16,
    escalaTexto: 1.08,
    intensidadeBrilho: 0.12,
  );

  // =====================================================================
  // 9. PRETO TOTAL — economiza bateria em telas AMOLED
  // =====================================================================
  static const TemaFarol pretoTotal = TemaFarol(
    id: 'preto_total',
    nome: 'Preto Total',
    descricao: 'Preto puro — economiza bateria em telas AMOLED',
    brilho: Brightness.dark,
    nivel: NivelLayout.simples,
    primaria: Color(0xFF4C8DFF),
    secundaria: Color(0xFF9AA6B8),
    fundo: Color(0xFF000000),
    superficie: Color(0xFF0B0B0D),
    superficieAlta: Color(0xFF15161A),
    texto: Color(0xFFFFFFFF),
    textoSuave: Color(0xFF9096A3),
    gradiente: <Color>[Color(0xFF4C8DFF), Color(0xFF1B4FBF)],
    raioBorda: 14,
    escalaTexto: 1.05,
    intensidadeBrilho: 0.3,
  );

  // =====================================================================
  // 10. DOURADO EXECUTIVO — sóbrio e sofisticado
  // =====================================================================
  static const TemaFarol douradoExecutivo = TemaFarol(
    id: 'dourado_executivo',
    nome: 'Dourado Executivo',
    descricao: 'Preto com dourado — visual sofisticado',
    brilho: Brightness.dark,
    nivel: NivelLayout.completo,
    primaria: Color(0xFFD4AF37),
    secundaria: Color(0xFFF2D399),
    fundo: Color(0xFF0D0B07),
    superficie: Color(0xFF1A160E),
    superficieAlta: Color(0xFF261F14),
    texto: Color(0xFFFBF6EA),
    textoSuave: Color(0xFFB3A487),
    gradiente: <Color>[Color(0xFFF0CE85), Color(0xFFB8912F)],
    sucesso: Color(0xFF4FCF9B),
    intensidadeBrilho: 0.35,
  );

  // =====================================================================
  // 11. CIANO ELÉTRICO — tecnológico
  // =====================================================================
  static const TemaFarol cianoEletrico = TemaFarol(
    id: 'ciano_eletrico',
    nome: 'Ciano Elétrico',
    descricao: 'Azul-ciano vibrante com cara de tecnologia',
    brilho: Brightness.dark,
    nivel: NivelLayout.dashboard,
    primaria: Color(0xFF00D1D1),
    secundaria: Color(0xFF4DE8B5),
    fundo: Color(0xFF04121A),
    superficie: Color(0xFF0B2029),
    superficieAlta: Color(0xFF122E39),
    texto: Color(0xFFE6FBFF),
    textoSuave: Color(0xFF7FA8B4),
    gradiente: <Color>[Color(0xFF4DE8B5), Color(0xFF00B4D8), Color(0xFF0353A4)],
    fundoComGradiente: true,
    intensidadeBrilho: 0.5,
  );

  // =====================================================================
  // 12. ROSA AURORA — degradê claro e suave
  // =====================================================================
  static const TemaFarol rosaAurora = TemaFarol(
    id: 'rosa_aurora',
    nome: 'Rosa Aurora',
    descricao: 'Degradê rosa e lilás em fundo claro',
    brilho: Brightness.light,
    nivel: NivelLayout.completo,
    primaria: Color(0xFFD6336C),
    secundaria: Color(0xFF9775FA),
    fundo: Color(0xFFFDF5F9),
    superficie: Color(0xFFFFFFFF),
    superficieAlta: Color(0xFFF7EBF3),
    texto: Color(0xFF2B1024),
    textoSuave: Color(0xFF7C6474),
    gradiente: <Color>[Color(0xFFFF7EB6), Color(0xFFC44BE0), Color(0xFF7B5CFF)],
    sucesso: Color(0xFF0FA37F),
    erro: Color(0xFFD93F52),
    intensidadeBrilho: 0.25,
  );

  // =====================================================================
  // 13. PAPEL SÉPIA — leitura confortável, letras grandes
  // =====================================================================
  static const TemaFarol papelSepia = TemaFarol(
    id: 'papel_sepia',
    nome: 'Papel Sépia',
    descricao: 'Fundo bege e letras grandes — cansa menos a vista',
    brilho: Brightness.light,
    nivel: NivelLayout.simples,
    primaria: Color(0xFF9A5B26),
    secundaria: Color(0xFF2E6B4F),
    fundo: Color(0xFFF6EEE0),
    superficie: Color(0xFFFFFAF2),
    superficieAlta: Color(0xFFEFE3D0),
    texto: Color(0xFF2B2117),
    textoSuave: Color(0xFF6E6151),
    gradiente: <Color>[Color(0xFFC98A45), Color(0xFF8A4E1F)],
    sucesso: Color(0xFF2E6B4F),
    erro: Color(0xFFB03A2E),
    raioBorda: 14,
    escalaTexto: 1.14,
    intensidadeBrilho: 0.1,
  );

  // =====================================================================
  // 14. DASHBOARD PRO — o mais AVANÇADO, estilo painel de BI
  // =====================================================================
  static const TemaFarol dashboardPro = TemaFarol(
    id: 'dashboard_pro',
    nome: 'Dashboard Pro',
    descricao: 'Mostra tudo: indicadores completos e gráficos em destaque',
    brilho: Brightness.dark,
    nivel: NivelLayout.dashboard,
    primaria: Color(0xFF3B82F6),
    secundaria: Color(0xFFA855F7),
    fundo: Color(0xFF0B0F1A),
    superficie: Color(0xFF141B2D),
    superficieAlta: Color(0xFF1C2538),
    texto: Color(0xFFF1F5F9),
    textoSuave: Color(0xFF94A3B8),
    gradiente: <Color>[Color(0xFF3B82F6), Color(0xFFA855F7)],
    sucesso: Color(0xFF22C55E),
    alerta: Color(0xFFF59E0B),
    erro: Color(0xFFEF4444),
    raioBorda: 16,
    escalaTexto: 0.96,
    intensidadeBrilho: 0.3,
  );

  // =====================================================================
  // 15. ALTO CONTRASTE — acessibilidade máxima
  // =====================================================================
  static const TemaFarol altoContraste = TemaFarol(
    id: 'alto_contraste',
    nome: 'Alto Contraste',
    descricao: 'Máxima legibilidade: preto, branco e amarelo forte',
    brilho: Brightness.dark,
    nivel: NivelLayout.simples,
    primaria: Color(0xFFFFD400),
    secundaria: Color(0xFF00E5FF),
    fundo: Color(0xFF000000),
    superficie: Color(0xFF121212),
    superficieAlta: Color(0xFF1F1F1F),
    texto: Color(0xFFFFFFFF),
    textoSuave: Color(0xFFD6D6D6),
    gradiente: <Color>[Color(0xFFFFE44D), Color(0xFFFFB400)],
    sucesso: Color(0xFF3DFF9E),
    alerta: Color(0xFFFFD400),
    erro: Color(0xFFFF5E5E),
    raioBorda: 12,
    escalaTexto: 1.18,
    intensidadeBrilho: 0.2,
  );

  /// Lista completa, na ordem em que aparece na tela de temas.
  static const List<TemaFarol> todos = <TemaFarol>[
    farolNoturno,
    farolClaro,
    azulProfundo,
    verdeEstrada,
    vermelhoTurbo,
    roxoNeon,
    porDoSol,
    grafiteMinimalista,
    pretoTotal,
    douradoExecutivo,
    cianoEletrico,
    rosaAurora,
    papelSepia,
    dashboardPro,
    altoContraste,
  ];

  /// Busca um tema pelo id salvo no Hive. Se não achar, devolve o padrão.
  static TemaFarol porId(String? id) {
    return todos.firstWhere(
      (t) => t.id == id,
      orElse: () => farolNoturno,
    );
  }
}
