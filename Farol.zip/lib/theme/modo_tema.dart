/// -----------------------------------------------------------------------
/// MODOS DE TEMA, CORES E MODOS DE VISUALIZAÇÃO
/// -----------------------------------------------------------------------
/// O visual do Farol é montado a partir de duas escolhas simples:
///   1. o MODO   -> claro, escuro ou automático (segue o celular)
///   2. a COR    -> uma cor principal, escolhida numa paleta ou livre
/// Tudo o mais (fundos, textos, gradientes) é calculado a partir disso.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

/// Como o app decide entre claro e escuro.
enum ModoTema {
  claro('Claro', 'Fundo branco, bom sob sol forte', Icons.light_mode_rounded),
  escuro('Escuro', 'Fundo escuro, cansa menos à noite',
      Icons.dark_mode_rounded),
  automatico('Automático', 'Segue a configuração do celular',
      Icons.brightness_auto_rounded);

  final String rotulo;
  final String descricao;
  final IconData icone;
  const ModoTema(this.rotulo, this.descricao, this.icone);

  /// Descobre o brilho real, consultando o sistema quando for automático.
  Brightness resolver(Brightness doSistema) {
    switch (this) {
      case ModoTema.claro:
        return Brightness.light;
      case ModoTema.escuro:
        return Brightness.dark;
      case ModoTema.automatico:
        return doSistema;
    }
  }

  static ModoTema porNome(String? nome) => ModoTema.values.firstWhere(
        (m) => m.name == nome,
        orElse: () => ModoTema.escuro,
      );
}

/// Como os indicadores aparecem na tela inicial.
enum ModoVisualizacao {
  grade('Grade', 'Cartões lado a lado', Icons.grid_view_rounded),
  lista('Lista', 'Um embaixo do outro, com mais detalhe',
      Icons.view_agenda_rounded),
  graficos('Gráficos', 'Foco nos gráficos', Icons.insert_chart_rounded),
  compacta('Compacta', 'Tudo cabendo numa tela só', Icons.density_small_rounded);

  final String rotulo;
  final String descricao;
  final IconData icone;
  const ModoVisualizacao(this.rotulo, this.descricao, this.icone);

  static ModoVisualizacao porNome(String? nome) =>
      ModoVisualizacao.values.firstWhere(
        (m) => m.name == nome,
        orElse: () => ModoVisualizacao.grade,
      );
}

/// Uma cor da paleta pronta.
class CorPaleta {
  final String nome;
  final Color cor;
  const CorPaleta(this.nome, this.cor);
}

/// As cores que o motorista pode escolher com um toque.
class PaletaCores {
  PaletaCores._();

  /// Azul do Farol — a cor original da marca.
  static const Color padrao = Color(0xFF1F5CFF);

  static const List<CorPaleta> cores = <CorPaleta>[
    CorPaleta('Azul Farol', Color(0xFF1F5CFF)),
    CorPaleta('Turquesa', Color(0xFF00B8C4)),
    CorPaleta('Verde', Color(0xFF16A34A)),
    CorPaleta('Roxo', Color(0xFF7C3AED)),
    CorPaleta('Rosa', Color(0xFFDB2777)),
    CorPaleta('Vermelho', Color(0xFFDC2626)),
    CorPaleta('Laranja', Color(0xFFEA580C)),
    CorPaleta('Dourado', Color(0xFFCA8A04)),
    CorPaleta('Grafite', Color(0xFF475569)),
  ];

  /// Converte a cor guardada (texto hexadecimal) de volta para Color.
  static Color deHex(String? hex) {
    if (hex == null || hex.isEmpty) return padrao;
    var t = hex.replaceAll('#', '').trim();
    if (t.length == 6) t = 'FF$t';
    final v = int.tryParse(t, radix: 16);
    return v == null ? padrao : Color(v);
  }

  /// Guarda a cor como texto hexadecimal.
  static String paraHex(Color cor) {
    // toARGB32 devolve o valor inteiro completo da cor (Flutter 3.27+).
    return '#${cor.toARGB32().toRadixString(16).padLeft(8, '0').toUpperCase()}';
  }
}

/// -----------------------------------------------------------------------
/// CORES DAS CATEGORIAS DO PROGRAMA DE PONTOS
/// -----------------------------------------------------------------------
class CoresCategoria {
  CoresCategoria._();

  static const Color azul = Color(0xFF3B82F6);
  static const Color ouro = Color(0xFFD4A017);
  static const Color platina = Color(0xFF9CA3AF);
  static const Color diamante = Color(0xFF22D3EE);

  /// A cor de cada categoria, pelo nome do enum.
  static Color porNome(String nome) {
    switch (nome) {
      case 'ouro':
        return ouro;
      case 'platina':
        return platina;
      case 'diamante':
        return diamante;
      default:
        return azul;
    }
  }
}
