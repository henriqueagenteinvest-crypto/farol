/// -----------------------------------------------------------------------
/// CONSTRUTOR DE ThemeData A PARTIR DE UM TemaFarol
/// -----------------------------------------------------------------------
/// Transforma a "receita de cores" (TemaFarol) no tema real do Flutter.
/// Assim, trocar de tema muda o app inteiro na hora, sem reiniciar.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_typography.dart';
import 'tema_farol.dart';

class AppThemeBuilder {
  AppThemeBuilder._();

  static ThemeData construir(TemaFarol t) {
    final esquema = ColorScheme(
      brightness: t.brilho,
      primary: t.primaria,
      onPrimary: _contraste(t.primaria),
      secondary: t.secundaria,
      onSecondary: _contraste(t.secundaria),
      error: t.erro,
      onError: _contraste(t.erro),
      surface: t.superficie,
      onSurface: t.texto,
      surfaceContainerHighest: t.superficieAlta,
      outline: t.textoSuave.withValues(alpha: 0.35),
      outlineVariant: t.textoSuave.withValues(alpha: 0.18),
    );

    final textos = AppTypography.construir(
      corTexto: t.texto,
      corSecundaria: t.textoSuave,
      escala: t.escalaTexto,
      conjunto: t.conjuntoFonte,
    );

    final bordaPadrao = OutlineInputBorder(
      borderRadius: BorderRadius.circular(t.raioBorda * 0.7),
      borderSide: BorderSide(color: t.textoSuave.withValues(alpha: 0.25)),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: t.brilho,
      colorScheme: esquema,
      scaffoldBackgroundColor: t.fundo,
      canvasColor: t.fundo,
      textTheme: textos,
      splashFactory: InkSparkle.splashFactory,

      // ---------------- Barra superior ----------------
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        iconTheme: IconThemeData(color: t.texto),
        titleTextStyle: textos.headlineSmall,
        systemOverlayStyle: t.ehEscuro
            ? SystemUiOverlayStyle.light
            : SystemUiOverlayStyle.dark,
      ),

      // ---------------- Cartões ----------------
      cardTheme: CardThemeData(
        color: t.superficie,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(t.raioBorda),
        ),
      ),

      // ---------------- Botão principal (grande, fácil de acertar) -------
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: t.primaria,
          foregroundColor: _contraste(t.primaria),
          minimumSize: const Size.fromHeight(58),
          elevation: 0,
          textStyle: textos.labelLarge?.copyWith(
            color: _contraste(t.primaria),
            fontSize: 16.5,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(t.raioBorda * 0.8),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: t.primaria,
          minimumSize: const Size.fromHeight(54),
          side: BorderSide(color: t.primaria.withValues(alpha: 0.6), width: 1.5),
          textStyle: textos.labelLarge?.copyWith(color: t.primaria),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(t.raioBorda * 0.8),
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: t.primaria,
          textStyle: textos.labelLarge?.copyWith(color: t.primaria),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: t.primaria,
          foregroundColor: _contraste(t.primaria),
          minimumSize: const Size.fromHeight(56),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(t.raioBorda * 0.8),
          ),
        ),
      ),

      // ---------------- Campos de formulário ----------------
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: t.superficieAlta,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        border: bordaPadrao,
        enabledBorder: bordaPadrao,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(t.raioBorda * 0.7),
          borderSide: BorderSide(color: t.primaria, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(t.raioBorda * 0.7),
          borderSide: BorderSide(color: t.erro, width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(t.raioBorda * 0.7),
          borderSide: BorderSide(color: t.erro, width: 2),
        ),
        labelStyle: textos.bodyMedium?.copyWith(color: t.textoSuave),
        hintStyle: textos.bodyMedium?.copyWith(
          color: t.textoSuave.withValues(alpha: 0.7),
        ),
        errorStyle: textos.bodySmall?.copyWith(
          color: t.erro,
          fontWeight: FontWeight.w600,
        ),
        prefixIconColor: t.textoSuave,
        suffixIconColor: t.textoSuave,
      ),

      // ---------------- Diversos ----------------
      dividerTheme: DividerThemeData(
        color: t.textoSuave.withValues(alpha: 0.15),
        thickness: 1,
        space: 1,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: t.superficieAlta,
        selectedColor: t.primaria,
        labelStyle: textos.labelMedium!.copyWith(color: t.texto),
        secondaryLabelStyle:
            textos.labelMedium!.copyWith(color: _contraste(t.primaria)),
        side: BorderSide(color: t.textoSuave.withValues(alpha: 0.2)),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? t.primaria : t.textoSuave,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected)
              ? t.primaria.withValues(alpha: 0.35)
              : t.superficieAlta,
        ),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: t.superficie,
        selectedItemColor: t.primaria,
        unselectedItemColor: t.textoSuave,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: t.superficie,
        indicatorColor: t.primaria.withValues(alpha: 0.18),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        labelTextStyle: WidgetStateProperty.resolveWith(
          (s) => textos.labelSmall!.copyWith(
            color: s.contains(WidgetState.selected) ? t.primaria : t.textoSuave,
            fontWeight: FontWeight.w700,
          ),
        ),
        iconTheme: WidgetStateProperty.resolveWith(
          (s) => IconThemeData(
            color: s.contains(WidgetState.selected) ? t.primaria : t.textoSuave,
            size: 24,
          ),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: t.superficie,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(t.raioBorda),
        ),
        titleTextStyle: textos.headlineSmall,
        contentTextStyle: textos.bodyMedium,
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: t.superficie,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(t.raioBorda + 6),
          ),
        ),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: t.primaria,
        linearTrackColor: t.superficieAlta,
        circularTrackColor: t.superficieAlta,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: t.primaria,
        contentTextStyle: textos.bodyMedium?.copyWith(
          color: _contraste(t.primaria),
          fontWeight: FontWeight.w600,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: t.textoSuave,
        textColor: t.texto,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(t.raioBorda * 0.7),
        ),
      ),
      iconTheme: IconThemeData(color: t.texto),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: t.superficieAlta,
          borderRadius: BorderRadius.circular(10),
        ),
        textStyle: textos.bodySmall?.copyWith(color: t.texto),
      ),
    );
  }

  /// Escolhe preto ou branco para escrever EM CIMA de uma cor,
  /// garantindo contraste adequado (acessibilidade).
  static Color _contraste(Color fundo) {
    // Luminância relativa: acima de 0.5 é uma cor clara -> texto preto.
    return fundo.computeLuminance() > 0.5
        ? const Color(0xFF0B0B0B)
        : const Color(0xFFFFFFFF);
  }

  /// Versão pública do cálculo de contraste (usada por widgets).
  static Color textoSobre(Color fundo) => _contraste(fundo);
}
