/// =======================================================================
/// COMPARTILHAMENTO DE ARQUIVOS
/// =======================================================================
/// Abre a bandeja do Android/iOS para o motorista mandar o relatório por
/// WhatsApp, e-mail, Drive ou salvar no próprio celular.
/// =======================================================================
library;

import 'dart:io';

import 'package:share_plus/share_plus.dart';

class ShareService {
  ShareService._();

  /// Compartilha um arquivo gerado pelo app (Excel ou PDF).
  static Future<void> compartilharArquivo(
    File arquivo, {
    required String assunto,
    String mensagem = '',
  }) async {
    if (!await arquivo.exists()) {
      throw Exception('O arquivo não foi encontrado.');
    }
    await Share.shareXFiles(
      <XFile>[XFile(arquivo.path)],
      subject: assunto,
      text: mensagem.isEmpty
          ? 'Relatório gerado pelo aplicativo Farol.'
          : mensagem,
    );
  }

  /// Compartilha os dois arquivos de uma vez (Excel + PDF).
  static Future<void> compartilharVarios(
    List<File> arquivos, {
    required String assunto,
    String mensagem = '',
  }) async {
    final existentes = <XFile>[];
    for (final f in arquivos) {
      if (await f.exists()) existentes.add(XFile(f.path));
    }
    if (existentes.isEmpty) {
      throw Exception('Nenhum arquivo foi encontrado para compartilhar.');
    }
    await Share.shareXFiles(
      existentes,
      subject: assunto,
      text: mensagem.isEmpty
          ? 'Relatórios gerados pelo aplicativo Farol.'
          : mensagem,
    );
  }
}
