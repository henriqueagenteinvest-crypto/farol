/// =======================================================================
/// PONTOS POR CORRIDA (modelo Uber Pro)
/// =======================================================================
/// Dart puro, sem tela e sem banco — por isso dá para testar à exaustão.
///
/// REGRA DOS PONTOS
///   • 1 ponto por corrida em horário normal
///   • 2 pontos por corrida em HORÁRIO DE PICO
///
/// HORÁRIOS DE PICO (os que o motorista informou):
///   Segunda a quinta ... 07h–10h  e  17h–20h
///   Sexta-feira ........ 07h–10h  e  17h–00h
///   Sábado ............. 00h–03h  e  19h–00h
///   Domingo ............ 00h–03h
///
/// IMPORTANTE — O QUE ESTE SERVIÇO **NÃO** FAZ:
/// o Farol guarda o total de corridas do dia, mas não a hora de cada uma.
/// Por isso o app NÃO inventa quantas corridas caíram no pico: ele conta
/// 1 ponto por corrida e mostra a tabela de horários como referência,
/// avisando quando o momento ATUAL é de pontos em dobro.
/// =======================================================================
library;

/// Uma faixa de horário dentro de um dia da semana.
class FaixaPico {
  /// Hora de início (0 a 23).
  final int inicio;

  /// Hora de término. 24 significa "até a virada do dia".
  final int fim;

  const FaixaPico(this.inicio, this.fim);

  /// A hora informada cai dentro desta faixa?
  /// O início entra, o fim não (ex.: 7–10 pega 7h00 até 9h59).
  bool contem(int hora) => hora >= inicio && hora < fim;

  String get rotulo {
    String h(int v) => v == 24 ? '00h' : '${v.toString().padLeft(2, '0')}h';
    return '${h(inicio)}–${h(fim)}';
  }
}

/// As categorias do programa, da mais baixa para a mais alta.
enum CategoriaMotorista {
  azul('Azul', 0),
  ouro('Ouro', 300),
  platina('Platina', 900),
  diamante('Diamante', 1800);

  /// Nome mostrado na tela.
  final String rotulo;

  /// Pontos necessários para alcançar esta categoria.
  ///
  /// ATENÇÃO: a Uber muda esses números conforme a cidade e o período.
  /// Aqui eles servem de REFERÊNCIA para a barra de progresso — o app
  /// deixa isso claro na tela e não promete que são os seus números.
  final int pontosNecessarios;

  const CategoriaMotorista(this.rotulo, this.pontosNecessarios);

  /// A próxima categoria, ou null se já está no topo.
  CategoriaMotorista? get proxima {
    final i = index + 1;
    return i < CategoriaMotorista.values.length
        ? CategoriaMotorista.values[i]
        : null;
  }

  /// Vantagens de cada nível (informativo).
  List<String> get vantagens {
    switch (this) {
      case CategoriaMotorista.azul:
        return const <String>[
          'Acesso ao programa de pontos',
          'Descontos em parceiros',
        ];
      case CategoriaMotorista.ouro:
        return const <String>[
          'Tudo do Azul',
          'Suporte prioritário',
          'Cashback em combustível',
        ];
      case CategoriaMotorista.platina:
        return const <String>[
          'Tudo do Ouro',
          'Mais informações sobre o destino da corrida',
          'Cashback maior em combustível',
        ];
      case CategoriaMotorista.diamante:
        return const <String>[
          'Tudo do Platina',
          'Suporte premium por telefone',
          'Maior cashback e vantagens exclusivas',
        ];
    }
  }
}

/// Um requisito de qualidade exigido para manter/subir de categoria.
class RequisitoCategoria {
  final String nome;
  final String alvo;
  final String explicacao;

  const RequisitoCategoria(this.nome, this.alvo, this.explicacao);
}

class PontosService {
  PontosService._();

  /// Pontos ganhos por corrida fora do horário de pico.
  static const int pontosNormal = 1;

  /// Pontos ganhos por corrida em horário de pico.
  static const int pontosPico = 2;

  // ---------------------------------------------------------------------
  // TABELA DE HORÁRIOS DE PICO
  // ---------------------------------------------------------------------
  /// Chave = dia da semana do Dart (1 = segunda ... 7 = domingo).
  static const Map<int, List<FaixaPico>> horariosPico = <int, List<FaixaPico>>{
    DateTime.monday: <FaixaPico>[FaixaPico(7, 10), FaixaPico(17, 20)],
    DateTime.tuesday: <FaixaPico>[FaixaPico(7, 10), FaixaPico(17, 20)],
    DateTime.wednesday: <FaixaPico>[FaixaPico(7, 10), FaixaPico(17, 20)],
    DateTime.thursday: <FaixaPico>[FaixaPico(7, 10), FaixaPico(17, 20)],
    DateTime.friday: <FaixaPico>[FaixaPico(7, 10), FaixaPico(17, 24)],
    DateTime.saturday: <FaixaPico>[FaixaPico(0, 3), FaixaPico(19, 24)],
    DateTime.sunday: <FaixaPico>[FaixaPico(0, 3)],
  };

  /// Nome do dia da semana, em português.
  static String nomeDia(int diaSemana) {
    const nomes = <int, String>{
      DateTime.monday: 'Segunda',
      DateTime.tuesday: 'Terça',
      DateTime.wednesday: 'Quarta',
      DateTime.thursday: 'Quinta',
      DateTime.friday: 'Sexta',
      DateTime.saturday: 'Sábado',
      DateTime.sunday: 'Domingo',
    };
    return nomes[diaSemana] ?? '';
  }

  /// O momento informado está em horário de pontos em dobro?
  static bool ehHorarioPico(DateTime momento) {
    final faixas = horariosPico[momento.weekday] ?? const <FaixaPico>[];
    return faixas.any((f) => f.contem(momento.hour));
  }

  /// As faixas de pico do dia da semana informado.
  static List<FaixaPico> faixasDoDia(int diaSemana) =>
      horariosPico[diaSemana] ?? const <FaixaPico>[];

  /// Quanto falta para o próximo horário de pico começar, no mesmo dia.
  /// Devolve null quando não há mais pico hoje.
  static Duration? proximoPicoHoje(DateTime momento) {
    final faixas = faixasDoDia(momento.weekday);
    for (final f in faixas) {
      if (momento.hour < f.inicio) {
        final inicio = DateTime(
          momento.year,
          momento.month,
          momento.day,
          f.inicio,
        );
        return inicio.difference(momento);
      }
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // CÁLCULO DE PONTOS
  // ---------------------------------------------------------------------

  /// Pontos de um conjunto de corridas.
  ///
  /// [corridas] é o total do período.
  /// [corridasEmPico] é quantas delas caíram em horário de pico — quando
  /// não se sabe (o caso normal do app hoje), fica zero e todas contam 1.
  static int calcularPontos({
    required int corridas,
    int corridasEmPico = 0,
  }) {
    final total = corridas < 0 ? 0 : corridas;
    final pico = corridasEmPico.clamp(0, total);
    final normais = total - pico;
    return normais * pontosNormal + pico * pontosPico;
  }

  // ---------------------------------------------------------------------
  // CATEGORIAS
  // ---------------------------------------------------------------------

  /// Qual categoria corresponde a uma quantidade de pontos.
  static CategoriaMotorista categoriaPara(int pontos) {
    var atual = CategoriaMotorista.azul;
    for (final c in CategoriaMotorista.values) {
      if (pontos >= c.pontosNecessarios) atual = c;
    }
    return atual;
  }

  /// Quantos pontos faltam para a próxima categoria (0 se já está no topo).
  static int faltamParaProxima(int pontos) {
    final proxima = categoriaPara(pontos).proxima;
    if (proxima == null) return 0;
    final falta = proxima.pontosNecessarios - pontos;
    return falta < 0 ? 0 : falta;
  }

  /// Progresso de 0.0 a 1.0 dentro da faixa da categoria atual.
  static double progressoParaProxima(int pontos) {
    final atual = categoriaPara(pontos);
    final proxima = atual.proxima;
    if (proxima == null) return 1.0;

    final base = atual.pontosNecessarios;
    final alvo = proxima.pontosNecessarios;
    final intervalo = alvo - base;
    if (intervalo <= 0) return 1.0;

    final p = (pontos - base) / intervalo;
    return p.clamp(0.0, 1.0);
  }

  // ---------------------------------------------------------------------
  // REQUISITOS DE QUALIDADE
  // ---------------------------------------------------------------------
  /// Os critérios que a Uber exige, mostrados como referência.
  ///
  /// O Farol NÃO tem acesso a esses números — eles ficam no aplicativo da
  /// Uber. A tela deixa isso explícito para não passar informação errada.
  static const List<RequisitoCategoria> requisitos = <RequisitoCategoria>[
    RequisitoCategoria(
      'Avaliação média',
      '4,85 ou mais',
      'A nota que os passageiros dão para você',
    ),
    RequisitoCategoria(
      'Taxa de aceitação',
      '60% ou mais',
      'Quantas das corridas oferecidas você aceita',
    ),
    RequisitoCategoria(
      'Taxa de cancelamento',
      '10% ou menos',
      'Quantas corridas aceitas você acaba cancelando',
    ),
  ];
}
