/// =======================================================================
/// PRÉ-PROCESSAMENTO DA IMAGEM PARA O OCR
/// =======================================================================
/// Um print limpo o ML Kit lê de olhos fechados. O problema é a FOTO da
/// tela: reflexo, sombra, ângulo, foco ruim. Esta classe gera versões
/// tratadas da imagem para aumentar a chance de leitura.
///
/// DECISÃO TÉCNICA IMPORTANTE:
/// o ML Kit já tem tratamento interno e muitas vezes lê MELHOR a imagem
/// original do que uma versão binarizada na força bruta. Por isso aqui não
/// se destrói a imagem: geramos VÁRIAS versões (original + tratadas) e o
/// OCRService testa todas, ficando com o melhor resultado. É mais lento
/// por alguns décimos de segundo e MUITO mais confiável.
/// =======================================================================
library;

import 'dart:io';
import 'dart:typed_data';

import 'package:image/image.dart' as img;

class ImagePreprocessor {
  ImagePreprocessor._();

  /// Largura máxima. Imagem gigante deixa o OCR lento sem ganhar precisão.
  static const int _larguraMaxima = 1800;

  /// Largura mínima: print pequeno é ampliado, o que ajuda a leitura.
  static const int _larguraMinima = 900;

  /// Gera as versões da imagem que serão testadas pelo OCR, na ordem de
  /// prioridade. Devolve a lista de arquivos temporários criados.
  ///
  /// Versões geradas:
  ///   1. Original ajustado (tamanho e orientação corrigidos)
  ///   2. Tons de cinza com contraste reforçado
  ///   3. Alto contraste (para foto com sombra/reflexo)
  static Future<List<File>> gerarVersoes(File original) async {
    final saida = <File>[];
    try {
      final bytes = await original.readAsBytes();
      var imagem = img.decodeImage(bytes);
      if (imagem == null) return <File>[original];

      // ---- 1. Corrige a orientação lida do EXIF ----
      // Foto tirada com o celular deitado vem "girada"; isto endireita.
      imagem = img.bakeOrientation(imagem);

      // ---- 2. Ajusta o tamanho ----
      imagem = _ajustarTamanho(imagem);

      final pasta = original.parent.path;
      final marca = DateTime.now().millisecondsSinceEpoch;

      // Versão A: só ajustada (é a que o ML Kit costuma ler melhor).
      saida.add(await _salvar(imagem, '$pasta/farol_ocr_a_$marca.png'));

      // Versão B: cinza + contraste — boa para print com fundo colorido.
      final cinza = img.adjustColor(
        img.grayscale(img.Image.from(imagem)),
        contrast: 1.35,
        brightness: 1.05,
      );
      saida.add(await _salvar(cinza, '$pasta/farol_ocr_b_$marca.png'));

      // Versão C: alto contraste + leve redução de ruído — para FOTO da tela.
      var forte = img.grayscale(img.Image.from(imagem));
      // Suaviza o ruído do sensor antes de forçar o contraste.
      forte = img.gaussianBlur(forte, radius: 1);
      forte = img.adjustColor(forte, contrast: 2.0, brightness: 1.1);
      forte = img.normalize(forte, min: 0, max: 255);
      saida.add(await _salvar(forte, '$pasta/farol_ocr_c_$marca.png'));

      return saida;
    } catch (_) {
      // Qualquer problema no tratamento: usa a imagem original mesmo.
      return <File>[original];
    }
  }

  /// Redimensiona mantendo a proporção, dentro dos limites definidos.
  static img.Image _ajustarTamanho(img.Image imagem) {
    if (imagem.width > _larguraMaxima) {
      return img.copyResize(
        imagem,
        width: _larguraMaxima,
        interpolation: img.Interpolation.cubic,
      );
    }
    if (imagem.width < _larguraMinima) {
      return img.copyResize(
        imagem,
        width: _larguraMinima,
        interpolation: img.Interpolation.cubic,
      );
    }
    return imagem;
  }

  static Future<File> _salvar(img.Image imagem, String caminho) async {
    final arquivo = File(caminho);
    final Uint8List png = img.encodePng(imagem, level: 3);
    await arquivo.writeAsBytes(png);
    return arquivo;
  }

  /// Apaga os arquivos temporários gerados (chamado depois do OCR).
  static Future<void> limparTemporarios(List<File> arquivos, File original) async {
    for (final f in arquivos) {
      if (f.path == original.path) continue; // nunca apaga o original
      try {
        if (await f.exists()) await f.delete();
      } catch (_) {
        // Se não conseguir apagar, tudo bem: o sistema limpa a pasta temp.
      }
    }
  }
}
