/// -----------------------------------------------------------------------
/// O QUE O OCR DEVOLVE
/// -----------------------------------------------------------------------
/// Cada campo lido do print vem embrulhado em [CampoExtraido], que carrega
/// além do valor uma NOTA DE CONFIANÇA e o trecho de texto que o originou.
/// A tela de confirmação usa a confiança para destacar o que o motorista
/// deve conferir com mais atenção.
/// -----------------------------------------------------------------------
library;

/// De onde veio o print.
enum OrigemPrint {
  uber('Uber'),
  noventaENove('99'),
  indrive('InDrive'),
  email('E-mail de resumo'),
  desconhecida('Não identificado');

  final String rotulo;
  const OrigemPrint(this.rotulo);
}

/// O print resume qual intervalo de tempo?
enum TipoResumo {
  diario('Diário', 1),
  semanal('Semanal', 7),
  mensal('Mensal', 30),
  desconhecido('Período não identificado', 1);

  final String rotulo;
  final int diasEstimados;
  const TipoResumo(this.rotulo, this.diasEstimados);
}

/// Um campo lido do print.
class CampoExtraido<T> {
  /// O valor lido. Fica `null` quando o OCR não encontrou nada — nesse caso
  /// a tela de confirmação mostra o campo vazio para preenchimento manual.
  final T? valor;

  /// De 0 a 1. Acima de 0,8 o app considera "leitura confiável".
  final double confianca;

  /// Pedaço do texto de onde o valor saiu (ajuda o motorista a conferir).
  final String? trecho;

  const CampoExtraido({this.valor, this.confianca = 0, this.trecho});

  const CampoExtraido.vazio()
      : valor = null,
        confianca = 0,
        trecho = null;

  bool get encontrado => valor != null;

  /// Leitura considerada segura pelo app.
  bool get confiavel => encontrado && confianca >= 0.8;

  /// Encontrou, mas vale a pena o motorista olhar com atenção.
  bool get duvidoso => encontrado && confianca < 0.8;
}

/// Pacote completo devolvido pela leitura de um print.
class ResultadoOcr {
  /// Todo o texto que o ML Kit conseguiu ler (usado para depurar).
  final String textoBruto;

  final CampoExtraido<double> valorBruto;
  final CampoExtraido<int> corridas;
  final CampoExtraido<double> horas;
  final CampoExtraido<double> km;
  final CampoExtraido<DateTime> data;
  final CampoExtraido<int> diasTrabalhados;

  final TipoResumo tipo;
  final OrigemPrint origem;

  /// Mensagens em português para mostrar ao motorista.
  final List<String> avisos;

  const ResultadoOcr({
    required this.textoBruto,
    this.valorBruto = const CampoExtraido<double>.vazio(),
    this.corridas = const CampoExtraido<int>.vazio(),
    this.horas = const CampoExtraido<double>.vazio(),
    this.km = const CampoExtraido<double>.vazio(),
    this.data = const CampoExtraido<DateTime>.vazio(),
    this.diasTrabalhados = const CampoExtraido<int>.vazio(),
    this.tipo = TipoResumo.desconhecido,
    this.origem = OrigemPrint.desconhecida,
    this.avisos = const <String>[],
  });

  /// Resultado de uma leitura que não deu certo.
  factory ResultadoOcr.falha(String motivo) => ResultadoOcr(
        textoBruto: '',
        avisos: <String>[motivo],
      );

  /// Quantos campos importantes foram encontrados (de 4).
  int get camposEncontrados =>
      (valorBruto.encontrado ? 1 : 0) +
      (corridas.encontrado ? 1 : 0) +
      (horas.encontrado ? 1 : 0) +
      (km.encontrado ? 1 : 0);

  /// Conseguiu ler o mínimo necessário para valer a pena continuar?
  bool get temDadosUteis => valorBruto.encontrado || corridas.encontrado;

  /// Nota geral da leitura, de 0 a 1 — vira a barra de qualidade na tela.
  double get qualidadeGeral {
    final notas = <double>[
      valorBruto.confianca * 2, // o valor é o campo mais importante
      corridas.confianca,
      horas.confianca,
      km.confianca * 0.5,
    ];
    final pesoTotal = 2 + 1 + 1 + 0.5;
    final soma = notas.fold<double>(0, (a, b) => a + b);
    final nota = soma / pesoTotal;
    return nota.clamp(0.0, 1.0);
  }

  /// Frase-resumo mostrada em destaque: "Identificamos: 23 corridas, R$ ...".
  String get frasePreview {
    final partes = <String>[];
    if (corridas.encontrado) partes.add('${corridas.valor} corridas');
    if (valorBruto.encontrado) {
      partes.add('R\$ ${valorBruto.valor!.toStringAsFixed(2).replaceAll('.', ',')}');
    }
    if (horas.encontrado) {
      final totalMin = (horas.valor! * 60).round();
      partes.add('${totalMin ~/ 60}h${(totalMin % 60).toString().padLeft(2, '0')}');
    }
    if (km.encontrado) {
      partes.add('${km.valor!.toStringAsFixed(1).replaceAll('.', ',')} km');
    }
    return partes.isEmpty ? 'Nada foi identificado' : partes.join(', ');
  }
}
