/// =======================================================================
/// OCR PARSER — A INTELIGÊNCIA QUE ENTENDE O PRINT
/// =======================================================================
/// O ML Kit devolve um monte de texto solto. Esta classe transforma esse
/// texto em números organizados (valor, corridas, horas, km, período).
///
/// É DART PURO: não depende de câmera, de plugin nem de tela. Por isso
/// pode ser testada à exaustão em test/ocr_parser_test.dart com dezenas
/// de layouts diferentes de print.
///
/// ESTRATÉGIA (por que funciona mesmo quando a Uber muda o layout):
///   1. Normaliza o texto (tira acento, deixa minúsculo, arruma espaços).
///   2. Trabalha LINHA A LINHA, porque nos apps o rótulo e o número quase
///      sempre estão na mesma linha ou em linhas vizinhas.
///   3. Para cada campo procura por PALAVRA-CHAVE + PROXIMIDADE:
///      mesma linha (confiança alta) > linha seguinte > linha anterior.
///   4. Se não achar por palavra-chave, cai para uma heurística
///      (ex.: o maior valor em R$ da tela costuma ser o total) e marca
///      a confiança como baixa, para o motorista conferir.
///   5. NADA é salvo sem o motorista confirmar na tela seguinte.
/// =======================================================================
library;

import '../utils/formatters.dart';
import 'ocr_resultado.dart';

class OcrParser {
  OcrParser._();

  // =====================================================================
  // PALAVRAS-CHAVE (em minúsculo e SEM acento — o texto é normalizado)
  // =====================================================================

  /// Rótulos que indicam o dinheiro recebido.
  static const List<String> _chavesValor = <String>[
    'ganhos totais', 'total de ganhos', 'ganhos da semana', 'ganhos do dia',
    'seus ganhos', 'total ganho', 'valor total', 'total recebido',
    'faturamento', 'ganhos', 'ganho', 'total', 'receita', 'valor bruto',
    'bruto', 'earnings', 'saldo', 'recebido',
  ];

  /// Rótulos que indicam quantidade de corridas.
  static const List<String> _chavesCorridas = <String>[
    'corridas', 'corrida', 'viagens', 'viagem', 'trips', 'trip',
    'solicitacoes', 'solicitacao', 'atendimentos', 'entregas', 'qtd corridas',
    'numero de corridas', 'total de corridas', 'total de viagens',
  ];

  /// Rótulos que indicam tempo trabalhado.
  static const List<String> _chavesHoras = <String>[
    'tempo online', 'tempo em rota', 'tempo total', 'horas trabalhadas',
    'tempo conectado', 'tempo de direcao', 'horas online', 'tempo dirigindo',
    'tempo', 'horas', 'duracao', 'online',
  ];

  /// Rótulos que indicam distância.
  static const List<String> _chavesKm = <String>[
    'distancia', 'distancia percorrida', 'km rodados', 'quilometragem',
    'km percorridos', 'total de km', 'km',
  ];

  /// Rótulos que indicam dias trabalhados.
  static const List<String> _chavesDias = <String>[
    'dias trabalhados', 'dias online', 'dias ativos', 'dias',
  ];

  /// -------------------------------------------------------------------
  /// JANELA DE BUSCA POR PROXIMIDADE
  /// -------------------------------------------------------------------
  /// Quando o app acha um rótulo ("Ganhos"), o número pode estar na mesma
  /// linha ou em uma linha vizinha. Esta lista define a ORDEM em que as
  /// linhas são testadas e a CONFIANÇA de cada distância.
  ///
  /// Olha até 3 linhas para baixo porque a Uber costuma colocar a data
  /// entre o rótulo e o valor. Para cima olha menos, porque nesse sentido
  /// a chance de pegar o número de outro indicador é maior.
  static const List<_PassoBusca> _janelaBusca = <_PassoBusca>[
    _PassoBusca(0, 0.95),   // mesma linha
    _PassoBusca(1, 0.90),   // logo abaixo
    _PassoBusca(2, 0.85),   // duas abaixo
    _PassoBusca(3, 0.78),   // três abaixo
    _PassoBusca(-1, 0.80),  // logo acima
    _PassoBusca(-2, 0.72),  // duas acima
  ];

  /// Meses abreviados e por extenso, para ler datas como "01 set".
  static const Map<String, int> _meses = <String, int>{
    'jan': 1, 'janeiro': 1,
    'fev': 2, 'fevereiro': 2,
    'mar': 3, 'marco': 3,
    'abr': 4, 'abril': 4,
    'mai': 5, 'maio': 5,
    'jun': 6, 'junho': 6,
    'jul': 7, 'julho': 7,
    'ago': 8, 'agosto': 8,
    'set': 9, 'sep': 9, 'setembro': 9,
    'out': 10, 'oct': 10, 'outubro': 10,
    'nov': 11, 'novembro': 11,
    'dez': 12, 'dec': 12, 'dezembro': 12,
  };

  // =====================================================================
  // MÉTODO PRINCIPAL
  // =====================================================================

  /// Recebe o texto cru do ML Kit e devolve tudo organizado.
  static ResultadoOcr interpretar(String textoBruto) {
    if (textoBruto.trim().isEmpty) {
      return ResultadoOcr.falha(
        'Não consegui ler nenhum texto nesta imagem. '
        'Tente um print mais nítido ou digite os dados na mão.',
      );
    }

    // Linhas originais (para mostrar ao motorista) e normalizadas (para buscar).
    final linhas = textoBruto
        .split(RegExp(r'[\r\n]+'))
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();
    final normalizadas = linhas.map(normalizar).toList();
    final textoNorm = normalizadas.join('\n');

    final avisos = <String>[];

    // ---- 1. De onde veio o print ----
    final origem = _detectarOrigem(textoNorm);

    // ---- 2. Cada campo ----
    final valor = _extrairValor(linhas, normalizadas);
    final corridas = _extrairCorridas(linhas, normalizadas);
    final horas = _extrairHoras(linhas, normalizadas);
    final km = _extrairKm(linhas, normalizadas);
    final dias = _extrairDias(linhas, normalizadas);
    final periodoLido = _extrairPeriodo(linhas, normalizadas);
    final periodo = periodoLido.campo;

    // ---- 3. Tipo do resumo (dia, semana ou mês) ----
    final tipo = _detectarTipo(
      textoNorm,
      periodoLido.intervaloDias,
      dias.valor,
    );

    // ---- 4. Avisos amigáveis ----
    if (!valor.encontrado) {
      avisos.add('Não achei o valor em R\$. Digite você mesmo abaixo.');
    } else if (valor.duvidoso) {
      avisos.add('Confira o valor: tenho dúvida se li certo.');
    }
    if (!corridas.encontrado) {
      avisos.add('Não achei a quantidade de corridas.');
    }
    if (!horas.encontrado) {
      avisos.add('Não achei as horas trabalhadas.');
    }
    if (!km.encontrado) {
      avisos.add('O print não mostra os KM. Preencha para calcular o combustível.');
    }
    if (tipo == TipoResumo.semanal || tipo == TipoResumo.mensal) {
      avisos.add(
        'Parece um resumo ${tipo.rotulo.toLowerCase()}. '
        'Os valores serão lançados de uma vez só nessa data.',
      );
    }

    return ResultadoOcr(
      textoBruto: textoBruto,
      valorBruto: valor,
      corridas: corridas,
      horas: horas,
      km: km,
      data: periodo,
      diasTrabalhados: dias,
      tipo: tipo,
      origem: origem,
      avisos: avisos,
    );
  }

  // =====================================================================
  // NORMALIZAÇÃO
  // =====================================================================

  /// Deixa minúsculo, tira acentos e normaliza espaços.
  /// "Distância Percorrida" -> "distancia percorrida"
  static String normalizar(String texto) {
    var t = texto.toLowerCase();
    const de = 'áàâãäéèêëíìîïóòôõöúùûüçñ';
    const para = 'aaaaaeeeeiiiiooooouuuucn';
    for (var i = 0; i < de.length; i++) {
      t = t.replaceAll(de[i], para[i]);
    }
    // Junta espaços repetidos e troca espaços especiais por espaço comum.
    return t.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  // =====================================================================
  // COMPARAÇÃO POR PALAVRA INTEIRA
  // =====================================================================

  /// Cache das expressões de palavra-chave (montar RegExp é caro).
  static final Map<String, RegExp> _cachePalavras = <String, RegExp>{};

  /// A linha contém a palavra-chave COMO PALAVRA INTEIRA?
  ///
  /// Por que não usar `contains` simples: a palavra "corrida" aparece dentro
  /// de "distância perCORRIDA". Sem esta trava, o app leria "415,8 km" como
  /// "415 corridas" — um erro grave, e silencioso.
  static bool contemPalavra(String linha, String chave) {
    final regex = _cachePalavras.putIfAbsent(
      chave,
      () => RegExp(r'\b' + RegExp.escape(chave) + r'\b'),
    );
    return regex.hasMatch(linha);
  }

  // =====================================================================
  // DETECÇÃO DE ORIGEM
  // =====================================================================

  static OrigemPrint _detectarOrigem(String textoNorm) {
    if (textoNorm.contains('uber')) return OrigemPrint.uber;
    if (RegExp(r'\b99(pop|app|taxi)?\b').hasMatch(textoNorm) ||
        textoNorm.contains('99 corridas') ||
        textoNorm.contains('app 99')) {
      return OrigemPrint.noventaENove;
    }
    if (textoNorm.contains('indrive') || textoNorm.contains('in drive')) {
      return OrigemPrint.indrive;
    }
    if (textoNorm.contains('@') ||
        textoNorm.contains('assunto:') ||
        textoNorm.contains('nao responda')) {
      return OrigemPrint.email;
    }
    return OrigemPrint.desconhecida;
  }

  // =====================================================================
  // EXTRAÇÃO DE VALORES EM DINHEIRO
  // =====================================================================

  /// Encontra todos os valores monetários de uma linha.
  /// Reconhece: "R$ 1.234,56", "R$ 347", "1.847,32", "347,89"
  static List<double> valoresMonetariosDaLinha(String linha) {
    final encontrados = <double>[];

    // Padrão 1 (mais forte): tem o símbolo R$ na frente.
    for (final m in RegExp(r'r\$\s*([0-9][0-9.,]*)').allMatches(linha)) {
      final v = Fmt.paraDouble(m.group(1));
      if (v != null && v > 0) encontrados.add(v);
    }
    if (encontrados.isNotEmpty) return encontrados;

    // Padrão 2: número no formato brasileiro com centavos (1.234,56 ou 347,89).
    for (final m
        in RegExp(r'(?:^|[^\d,.])(\d{1,3}(?:\.\d{3})*,\d{2})(?![\d])')
            .allMatches(linha)) {
      final v = Fmt.paraDouble(m.group(1));
      if (v != null && v > 0) encontrados.add(v);
    }
    if (encontrados.isNotEmpty) return encontrados;

    // Padrão 3: número simples com centavos, sem separador de milhar.
    for (final m in RegExp(r'(?:^|[^\d,.])(\d+,\d{2})(?![\d])').allMatches(linha)) {
      final v = Fmt.paraDouble(m.group(1));
      if (v != null && v > 0) encontrados.add(v);
    }
    return encontrados;
  }

  static CampoExtraido<double> _extrairValor(
    List<String> linhas,
    List<String> norm,
  ) {
    // --- Tentativa 1: linha com palavra-chave de ganhos ---
    // Percorre as chaves da mais específica para a mais genérica.
    for (final chave in _chavesValor) {
      for (var i = 0; i < norm.length; i++) {
        if (!contemPalavra(norm[i], chave)) continue;

        // Procura o valor na mesma linha e nas linhas vizinhas.
        // A ordem da lista define a prioridade; a confiança cai conforme
        // o número se afasta do rótulo.
        //
        // Por que olhar até 3 linhas para baixo: no app da Uber o layout
        // costuma ser  "Seus ganhos" / "23 de ago - 29 de ago" / "R$ ..."  —
        // ou seja, a data fica ENTRE o rótulo e o valor.
        for (final passo in _janelaBusca) {
          final j = i + passo.deslocamento;
          if (j < 0 || j >= norm.length) continue;
          final achados = valoresMonetariosDaLinha(norm[j]);
          if (achados.isEmpty) continue;
          return CampoExtraido<double>(
            valor: achados.reduce((a, b) => a > b ? a : b),
            confianca: passo.confianca,
            trecho: j == i ? linhas[i] : '${linhas[i]} → ${linhas[j]}',
          );
        }
      }
    }

    // --- Tentativa 2: qualquer linha com "R$" -> pega o MAIOR valor ---
    // Nos resumos dos apps o maior número em R$ quase sempre é o total.
    var melhor = 0.0;
    String? trechoMelhor;
    for (var i = 0; i < norm.length; i++) {
      if (!norm[i].contains(r'r$')) continue;
      for (final v in valoresMonetariosDaLinha(norm[i])) {
        if (v > melhor) {
          melhor = v;
          trechoMelhor = linhas[i];
        }
      }
    }
    if (melhor > 0) {
      return CampoExtraido<double>(
        valor: melhor,
        confianca: 0.6,
        trecho: trechoMelhor,
      );
    }

    // --- Tentativa 3: maior número com centavos em qualquer lugar ---
    for (var i = 0; i < norm.length; i++) {
      for (final v in valoresMonetariosDaLinha(norm[i])) {
        if (v > melhor) {
          melhor = v;
          trechoMelhor = linhas[i];
        }
      }
    }
    if (melhor > 0) {
      return CampoExtraido<double>(
        valor: melhor,
        confianca: 0.45,
        trecho: trechoMelhor,
      );
    }

    return const CampoExtraido<double>.vazio();
  }

  // =====================================================================
  // EXTRAÇÃO DE CORRIDAS
  // =====================================================================

  static CampoExtraido<int> _extrairCorridas(
    List<String> linhas,
    List<String> norm,
  ) {
    // --- Padrão direto: "23 corridas" / "82 viagens" ---
    final direto = RegExp(
      r'(\d{1,4})\s*(corridas?|viagens?|trips?|solicitacoes|solicitacao|atendimentos|entregas)\b',
    );
    for (var i = 0; i < norm.length; i++) {
      final m = direto.firstMatch(norm[i]);
      if (m != null) {
        final n = int.tryParse(m.group(1)!);
        if (n != null && n > 0 && n <= 2000) {
          return CampoExtraido<int>(
            valor: n,
            confianca: 0.95,
            trecho: linhas[i],
          );
        }
      }
    }

    // --- Padrão invertido: "Corridas 23" ou "Viagens" / linha seguinte "23" ---
    for (final chave in _chavesCorridas) {
      for (var i = 0; i < norm.length; i++) {
        if (!contemPalavra(norm[i], chave)) continue;

        // Número na mesma linha, depois do rótulo.
        final depois = RegExp(
          r'\b' + RegExp.escape(chave) + r'\s*[:\-]?\s*(\d{1,4})\b',
        ).firstMatch(norm[i]);
        if (depois != null) {
          final n = int.tryParse(depois.group(1)!);
          if (n != null && n > 0 && n <= 2000) {
            return CampoExtraido<int>(
              valor: n,
              confianca: 0.92,
              trecho: linhas[i],
            );
          }
        }

        // Número sozinho numa linha vizinha (rótulo em cima do número).
        for (final passo in _janelaBusca) {
          if (passo.deslocamento == 0) continue; // a mesma linha já foi testada
          final j = i + passo.deslocamento;
          if (j < 0 || j >= norm.length) continue;
          final n = _inteiroSozinho(norm[j]);
          if (n != null && n > 0 && n <= 2000) {
            return CampoExtraido<int>(
              valor: n,
              confianca: passo.confianca - 0.05,
              trecho: '${linhas[i]} → ${linhas[j]}',
            );
          }
        }
      }
    }
    return const CampoExtraido<int>.vazio();
  }

  /// Devolve o número quando a linha tem SÓ um número inteiro.
  static int? _inteiroSozinho(String linha) {
    final m = RegExp(r'^(\d{1,4})$').firstMatch(linha.trim());
    return m == null ? null : int.tryParse(m.group(1)!);
  }

  // =====================================================================
  // EXTRAÇÃO DE HORAS
  // =====================================================================

  /// Lê horas de um texto e devolve em decimal (8h30 -> 8.5).
  /// Devolve null quando não encontra nada.
  static double? horasDaLinha(String linha, {bool permitirDoisPontos = false}) {
    // "8h30", "8 h 30", "32h 15min", "8h30min"
    final hm = RegExp(r'(\d{1,3})\s*h\s*(\d{1,2})\s*(?:min|m)?\b')
        .firstMatch(linha);
    if (hm != null) {
      final h = int.parse(hm.group(1)!);
      final m = int.parse(hm.group(2)!);
      if (m < 60 && h <= 999) return h + m / 60.0;
    }

    // "8,5h" / "8.5 h" (horas com fração decimal)
    final decimal = RegExp(r'(\d{1,3}[,.]\d{1,2})\s*h(?:oras?)?\b')
        .firstMatch(linha);
    if (decimal != null) {
      final v = Fmt.paraDouble(decimal.group(1));
      if (v != null && v >= 0 && v <= 999) return v;
    }

    // "8h" sozinho (sem minutos na sequência)
    final soHora = RegExp(r'(\d{1,3})\s*h(?![a-z0-9])').firstMatch(linha);
    if (soHora != null) {
      final h = int.parse(soHora.group(1)!);
      if (h <= 999) return h.toDouble();
    }

    // "8 horas 30 minutos" / "8 horas"
    final porExtenso = RegExp(r'(\d{1,3})\s*horas?').firstMatch(linha);
    if (porExtenso != null) {
      final h = int.parse(porExtenso.group(1)!);
      final min = RegExp(r'(\d{1,2})\s*(?:min|minutos?)\b').firstMatch(linha);
      final m = min == null ? 0 : int.parse(min.group(1)!);
      if (h <= 999 && m < 60) return h + m / 60.0;
    }

    // "32 min" sozinho
    final soMin = RegExp(r'^(\d{1,3})\s*(?:min|minutos?)$')
        .firstMatch(linha.trim());
    if (soMin != null) {
      final m = int.parse(soMin.group(1)!);
      return m / 60.0;
    }

    // "08:30" — só quando autorizado (perto de um rótulo de tempo),
    // senão confundiria com horário do dia numa lista de corridas.
    if (permitirDoisPontos) {
      final doisPontos = RegExp(r'(\d{1,3}):(\d{2})(?::\d{2})?\b')
          .firstMatch(linha);
      if (doisPontos != null) {
        final h = int.parse(doisPontos.group(1)!);
        final m = int.parse(doisPontos.group(2)!);
        if (m < 60 && h <= 999) return h + m / 60.0;
      }
    }
    return null;
  }

  static CampoExtraido<double> _extrairHoras(
    List<String> linhas,
    List<String> norm,
  ) {
    // --- Tentativa 1: linha com rótulo de tempo (aceita "08:30") ---
    for (final chave in _chavesHoras) {
      for (var i = 0; i < norm.length; i++) {
        if (!contemPalavra(norm[i], chave)) continue;

        for (final passo in _janelaBusca) {
          final j = i + passo.deslocamento;
          if (j < 0 || j >= norm.length) continue;
          final h = horasDaLinha(norm[j], permitirDoisPontos: true);
          if (h == null || h <= 0) continue;
          return CampoExtraido<double>(
            valor: _arredondarHoras(h),
            confianca: passo.confianca,
            trecho: j == i ? linhas[i] : '${linhas[i]} → ${linhas[j]}',
          );
        }
      }
    }

    // --- Tentativa 2: qualquer "8h30" solto na tela (sem "08:30") ---
    for (var i = 0; i < norm.length; i++) {
      final h = horasDaLinha(norm[i]);
      if (h != null && h > 0 && h <= 200) {
        return CampoExtraido<double>(
          valor: _arredondarHoras(h),
          confianca: 0.6,
          trecho: linhas[i],
        );
      }
    }
    return const CampoExtraido<double>.vazio();
  }

  /// Arredonda horas para 4 casas (evita 8.499999999 na tela).
  static double _arredondarHoras(double h) =>
      (h * 10000).round() / 10000;

  // =====================================================================
  // EXTRAÇÃO DE QUILOMETRAGEM
  // =====================================================================

  static CampoExtraido<double> _extrairKm(
    List<String> linhas,
    List<String> norm,
  ) {
    // --- Padrão direto: "612,4 km" / "612.4km" ---
    final direto =
        RegExp(r'(\d{1,3}(?:\.\d{3})*(?:,\d+)?|\d+(?:[.,]\d+)?)\s*(?:km|quilometros?)\b');
    for (var i = 0; i < norm.length; i++) {
      final m = direto.firstMatch(norm[i]);
      if (m != null) {
        final v = Fmt.paraDouble(m.group(1));
        if (v != null && v > 0 && v <= 50000) {
          return CampoExtraido<double>(
            valor: v,
            confianca: 0.95,
            trecho: linhas[i],
          );
        }
      }
    }

    // --- Rótulo de distância com o número na linha vizinha ---
    for (final chave in _chavesKm) {
      for (var i = 0; i < norm.length; i++) {
        if (!contemPalavra(norm[i], chave)) continue;
        for (final j in <int>[i, i + 1, i - 1]) {
          if (j < 0 || j >= norm.length) continue;
          final m = RegExp(r'(\d{1,3}(?:\.\d{3})*(?:,\d+)?|\d+(?:[.,]\d+)?)')
              .firstMatch(norm[j].replaceAll(
                  RegExp(r'\b' + RegExp.escape(chave) + r'\b'), ''));
          if (m == null) continue;
          final v = Fmt.paraDouble(m.group(1));
          if (v != null && v > 0 && v <= 50000) {
            return CampoExtraido<double>(
              valor: v,
              confianca: j == i ? 0.85 : 0.7,
              trecho: linhas[j],
            );
          }
        }
      }
    }
    return const CampoExtraido<double>.vazio();
  }

  // =====================================================================
  // EXTRAÇÃO DE DIAS TRABALHADOS
  // =====================================================================

  static CampoExtraido<int> _extrairDias(
    List<String> linhas,
    List<String> norm,
  ) {
    final direto = RegExp(r'(\d{1,2})\s*dias?\b');
    for (var i = 0; i < norm.length; i++) {
      // Evita casar com datas tipo "7 dias atras" em textos de propaganda.
      if (norm[i].contains('atras') || norm[i].contains('ultimos')) continue;
      final m = direto.firstMatch(norm[i]);
      if (m != null) {
        final n = int.tryParse(m.group(1)!);
        if (n != null && n >= 1 && n <= 31) {
          return CampoExtraido<int>(
            valor: n,
            confianca: 0.9,
            trecho: linhas[i],
          );
        }
      }
    }
    for (final chave in _chavesDias) {
      for (var i = 0; i < norm.length; i++) {
        if (!contemPalavra(norm[i], chave)) continue;
        if (i + 1 < norm.length) {
          final n = _inteiroSozinho(norm[i + 1]);
          if (n != null && n >= 1 && n <= 31) {
            return CampoExtraido<int>(
              valor: n,
              confianca: 0.85,
              trecho: '${linhas[i]} → ${linhas[i + 1]}',
            );
          }
        }
      }
    }
    return const CampoExtraido<int>.vazio();
  }

  // =====================================================================
  // EXTRAÇÃO DE DATA / PERÍODO
  // =====================================================================

  /// Procura a data do resumo. Quando o print mostra um intervalo
  /// ("23 de ago - 29 de ago"), devolve a data FINAL do intervalo.
  static _PeriodoLido _extrairPeriodo(
    List<String> linhas,
    List<String> norm,
  ) {
    final anoAtual = DateTime.now().year;

    // --- Formato 01/09/2026 ou 01/09 ---
    final barra = RegExp(r'\b(\d{1,2})[\/\.](\d{1,2})(?:[\/\.](\d{2,4}))?\b');
    final datasEncontradas = <DateTime>[];
    int? linhaOrigem;

    for (var i = 0; i < norm.length; i++) {
      for (final m in barra.allMatches(norm[i])) {
        final d = int.tryParse(m.group(1)!);
        final mes = int.tryParse(m.group(2)!);
        var ano = m.group(3) == null ? anoAtual : int.parse(m.group(3)!);
        if (ano < 100) ano += 2000; // "26" -> 2026
        if (d == null || mes == null) continue;
        if (d < 1 || d > 31 || mes < 1 || mes > 12) continue;
        if (ano < 2000 || ano > anoAtual + 1) continue;
        datasEncontradas.add(DateTime(ano, mes, d));
        linhaOrigem ??= i;
      }
    }

    // --- Formato "29 de ago" / "seg, 01 set" ---
    final porExtenso =
        RegExp(r'\b(\d{1,2})\s*(?:de\s+)?([a-z]{3,9})\.?\b');
    for (var i = 0; i < norm.length; i++) {
      for (final m in porExtenso.allMatches(norm[i])) {
        final d = int.tryParse(m.group(1)!);
        final nomeMes = m.group(2)!;
        final mes = _meses[nomeMes] ?? _meses[nomeMes.substring(0, 3)];
        if (d == null || mes == null) continue;
        if (d < 1 || d > 31) continue;
        datasEncontradas.add(DateTime(anoAtual, mes, d));
        linhaOrigem ??= i;
      }
    }

    if (datasEncontradas.isEmpty) {
      return const _PeriodoLido(CampoExtraido<DateTime>.vazio(), 0);
    }

    // Quando há mais de uma data, o resumo é de um intervalo:
    // usamos a data FINAL (é quando o motorista está lançando).
    datasEncontradas.sort((a, b) => a.compareTo(b));
    final escolhida = datasEncontradas.last;

    // Tamanho do intervalo: da data mais antiga até a mais nova.
    // "23 de ago - 29 de ago" -> 7 dias -> é um resumo semanal.
    final intervalo =
        datasEncontradas.last.difference(datasEncontradas.first).inDays + 1;

    return _PeriodoLido(
      CampoExtraido<DateTime>(
        valor: escolhida,
        confianca: datasEncontradas.length == 1 ? 0.9 : 0.75,
        trecho: linhaOrigem == null ? null : linhas[linhaOrigem],
      ),
      intervalo,
    );
  }

  /// Descobre se o print resume um dia, uma semana ou um mês.
  static TipoResumo _detectarTipo(
    String textoNorm,
    int intervaloDias,
    int? dias,
  ) {
    // Palavras explícitas mandam mais que qualquer heurística.
    if (textoNorm.contains('mensal') ||
        textoNorm.contains('este mes') ||
        textoNorm.contains('do mes') ||
        textoNorm.contains('no mes')) {
      return TipoResumo.mensal;
    }
    if (textoNorm.contains('semanal') ||
        textoNorm.contains('esta semana') ||
        textoNorm.contains('da semana') ||
        textoNorm.contains('na semana') ||
        textoNorm.contains('ultimos 7 dias')) {
      return TipoResumo.semanal;
    }
    if (textoNorm.contains('hoje') ||
        textoNorm.contains('ontem') ||
        textoNorm.contains('do dia') ||
        textoNorm.contains('diario')) {
      return TipoResumo.diario;
    }

    // Sem palavra explícita: usa a quantidade de dias trabalhados.
    if (dias != null) {
      if (dias == 1) return TipoResumo.diario;
      if (dias <= 8) return TipoResumo.semanal;
      return TipoResumo.mensal;
    }

    // Sem palavra explícita: usa o INTERVALO ENTRE AS DATAS do print.
    // Ex.: "23 de ago - 29 de ago" cobre 7 dias -> semanal.
    if (intervaloDias >= 2) {
      if (intervaloDias <= 10) return TipoResumo.semanal;
      return TipoResumo.mensal;
    }
    if (intervaloDias == 1) return TipoResumo.diario;

    return TipoResumo.desconhecido;
  }
}

/// Um passo da janela de busca: quantas linhas pular e com que confiança.
class _PassoBusca {
  final int deslocamento;
  final double confianca;
  const _PassoBusca(this.deslocamento, this.confianca);
}

/// Resultado da leitura de datas: a data escolhida e o tamanho do intervalo.
class _PeriodoLido {
  final CampoExtraido<DateTime> campo;

  /// Quantos dias o print cobre (1 = um dia só). Zero quando não deu para saber.
  final int intervaloDias;

  const _PeriodoLido(this.campo, this.intervaloDias);
}
