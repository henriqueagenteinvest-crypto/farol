/// =======================================================================
/// EXPORTAÇÃO PARA PDF — RELATÓRIO PROFISSIONAL
/// =======================================================================
/// Monta um PDF com:
///   • Capa com a marca do Farol, o nome do motorista e o período
///   • Cartões de indicadores (KPIs) destacados
///   • Gráfico de barras do lucro dia a dia (desenhado à mão, sem imagem)
///   • Gráfico de barras dos gastos por categoria
///   • Tabelas formatadas com zebra
///   • Rodapé com número da página e data de emissão
///
/// Tudo é gerado no próprio celular, sem internet.
/// =======================================================================
library;

import 'dart:io';

import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../data/models/gasto.dart';
import '../data/models/lancamento_diario.dart';
import '../data/models/motorista.dart';
import '../domain/entities/resumo_periodo.dart';
import '../utils/formatters.dart';
import 'calculations_service.dart';

class ExportPdfService {
  ExportPdfService._();

  // ---------------- Paleta da marca ----------------
  static const PdfColor _azulEscuro = PdfColor.fromInt(0xFF0B2E9E);
  static const PdfColor _azul = PdfColor.fromInt(0xFF1F5CFF);
  static const PdfColor _azulClaro = PdfColor.fromInt(0xFFE8EFFF);
  static const PdfColor _verde = PdfColor.fromInt(0xFF12805C);
  static const PdfColor _verdeClaro = PdfColor.fromInt(0xFFE3F7EF);
  static const PdfColor _vermelho = PdfColor.fromInt(0xFFC0392B);
  static const PdfColor _vermelhoClaro = PdfColor.fromInt(0xFFFDEAE7);
  static const PdfColor _cinza = PdfColor.fromInt(0xFFF2F4F8);
  static const PdfColor _cinzaMedio = PdfColor.fromInt(0xFF8A93A6);
  static const PdfColor _tinta = PdfColor.fromInt(0xFF10233F);
  static const PdfColor _branco = PdfColors.white;

  // =====================================================================
  // MÉTODO PRINCIPAL
  // =====================================================================

  static Future<File> gerar({
    required Motorista? motorista,
    required ResumoPeriodo resumo,
    required List<LancamentoDiario> lancamentos,
    required List<Gasto> gastos,
    /// O período fatiado (semana a semana, ou mês a mês). Vazio quando
    /// não faz sentido fatiar — por exemplo, exportar um dia só.
    List<ResumoPeriodo> fatias = const <ResumoPeriodo>[],
    /// Como cada fatia se chama: "Semana" ou "Mês".
    String nomeDaFatia = 'Semana',
  }) async {
    final doc = pw.Document(
      title: 'Farol — Relatório ${resumo.rotulo}',
      author: motorista?.nome ?? 'Farol',
      creator: 'Farol',
    );

    final emitidoEm =
        DateFormat('dd/MM/yyyy HH:mm', 'pt_BR').format(DateTime.now());

    // ---------------- CAPA ----------------
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (ctx) => _capa(motorista, resumo, emitidoEm),
      ),
    );

    // ---------------- CONTEÚDO ----------------
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(32, 28, 32, 40),
        header: (ctx) => _cabecalhoPagina(resumo),
        footer: (ctx) => _rodape(ctx, emitidoEm),
        build: (ctx) => <pw.Widget>[
          _secao('RESUMO DO PERÍODO'),
          pw.SizedBox(height: 10),
          _gradeKpis(resumo),
          pw.SizedBox(height: 18),

          _secao('INDICADORES DE DESEMPENHO'),
          pw.SizedBox(height: 10),
          _tabelaIndicadores(resumo),
          pw.SizedBox(height: 18),

          // O comparativo vem ANTES dos gráficos: é a informação que o
          // motorista abre o relatório para ver.
          if (fatias.length > 1) ...<pw.Widget>[
            _secao('COMPARATIVO — ${nomeDaFatia.toUpperCase()} A '
                '${nomeDaFatia.toUpperCase()}'),
            pw.SizedBox(height: 10),
            _tabelaComparativo(fatias, nomeDaFatia),
            pw.SizedBox(height: 12),
            _graficoComparativo(fatias),
            pw.SizedBox(height: 18),
          ],

          if (resumo.lucroPorDia.isNotEmpty) ...<pw.Widget>[
            _secao('LUCRO DIA A DIA'),
            pw.SizedBox(height: 10),
            _graficoBarras(resumo.lucroPorDia, _verde),
            pw.SizedBox(height: 18),
          ],

          if (resumo.gastosPorCategoria.isNotEmpty) ...<pw.Widget>[
            _secao('ONDE O DINHEIRO FOI'),
            pw.SizedBox(height: 10),
            _graficoCategorias(resumo),
            pw.SizedBox(height: 18),
          ],

          if (lancamentos.isNotEmpty) ...<pw.Widget>[
            _secao('LANÇAMENTOS DETALHADOS'),
            pw.SizedBox(height: 10),
            _tabelaLancamentos(lancamentos),
            pw.SizedBox(height: 18),
          ],

          if (gastos.isNotEmpty) ...<pw.Widget>[
            _secao('GASTOS DETALHADOS'),
            pw.SizedBox(height: 10),
            _tabelaGastos(gastos),
          ],
        ],
      ),
    );

    // ---------------- Salva ----------------
    final pasta = await getApplicationDocumentsDirectory();
    final carimbo = DateFormat('ddMMyyyy_HHmm').format(DateTime.now());
    final limpo = resumo.rotulo
        .replaceAll(RegExp(r'[^\w\s-]'), '')
        .replaceAll(RegExp(r'\s+'), '_');
    final arquivo = File('${pasta.path}/Farol_${limpo}_$carimbo.pdf');
    await arquivo.writeAsBytes(await doc.save(), flush: true);
    return arquivo;
  }

  // =====================================================================
  // CAPA
  // =====================================================================

  static pw.Widget _capa(
    Motorista? motorista,
    ResumoPeriodo resumo,
    String emitidoEm,
  ) {
    return pw.Container(
      width: double.infinity,
      height: double.infinity,
      color: _azulEscuro,
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: <pw.Widget>[
          pw.Expanded(
            flex: 5,
            child: pw.Container(
              padding: const pw.EdgeInsets.all(44),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: <pw.Widget>[
                  _marcaFarol(),
                  pw.SizedBox(height: 26),
                  pw.Text(
                    'FAROL',
                    style: pw.TextStyle(
                      fontSize: 46,
                      color: _branco,
                      fontWeight: pw.FontWeight.bold,
                      letterSpacing: 4,
                    ),
                  ),
                  pw.SizedBox(height: 6),
                  pw.Text(
                    'Relatório de desempenho do motorista',
                    style: const pw.TextStyle(
                      fontSize: 13,
                      color: PdfColor.fromInt(0xFF9DBBFF),
                    ),
                  ),
                  pw.SizedBox(height: 34),
                  pw.Container(width: 70, height: 3, color: _branco),
                  pw.SizedBox(height: 34),
                  _linhaCapa('MOTORISTA', motorista?.nome ?? '—'),
                  _linhaCapa('VEÍCULO', motorista?.descricaoCarro ?? '—'),
                  if ((motorista?.placa ?? '').isNotEmpty)
                    _linhaCapa('PLACA', motorista!.placa),
                  _linhaCapa('PERÍODO', resumo.rotulo),
                  _linhaCapa(
                    'INTERVALO',
                    '${Fmt.data(resumo.inicio)} a ${Fmt.data(resumo.fim)}',
                  ),
                ],
              ),
            ),
          ),
          // Faixa branca com os 3 números principais
          pw.Expanded(
            flex: 2,
            child: pw.Container(
              color: _branco,
              padding: const pw.EdgeInsets.symmetric(horizontal: 34),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
                children: <pw.Widget>[
                  _numeroCapa('LUCRO', Fmt.moeda(resumo.lucroLiquido), _verde),
                  _divisorVertical(),
                  _numeroCapa('BRUTO', Fmt.moeda(resumo.valorBruto), _azul),
                  _divisorVertical(),
                  _numeroCapa(
                    'GANHO/HORA',
                    Fmt.moeda(resumo.ganhoPorHora),
                    _azulEscuro,
                  ),
                ],
              ),
            ),
          ),
          pw.Container(
            color: _azul,
            padding: const pw.EdgeInsets.symmetric(vertical: 10),
            child: pw.Center(
              child: pw.Text(
                'Emitido em $emitidoEm  •  gerado no celular, sem internet',
                style: const pw.TextStyle(fontSize: 9, color: _branco),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Desenha o símbolo do Farol: um farol de carro aceso, em traços.
  static pw.Widget _marcaFarol() {
    return pw.Container(
      width: 92,
      height: 92,
      decoration: pw.BoxDecoration(
        color: const PdfColor.fromInt(0xFF0A1836),
        borderRadius: pw.BorderRadius.circular(24),
        border: pw.Border.all(color: _azul, width: 2),
      ),
      child: pw.Center(
        child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.center,
          children: <pw.Widget>[
            // Capô / teto do carro
            pw.Container(
              width: 54,
              height: 20,
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: _azul, width: 3),
                borderRadius: const pw.BorderRadius.only(
                  topLeft: pw.Radius.circular(10),
                  topRight: pw.Radius.circular(10),
                ),
              ),
            ),
            pw.SizedBox(height: 4),
            // Os dois faróis acesos
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: <pw.Widget>[
                pw.Container(width: 18, height: 6, color: _branco),
                pw.SizedBox(width: 14),
                pw.Container(width: 18, height: 6, color: _branco),
              ],
            ),
            pw.SizedBox(height: 6),
            // Para-choque
            pw.Container(width: 44, height: 3, color: _azul),
          ],
        ),
      ),
    );
  }

  static pw.Widget _linhaCapa(String rotulo, String valor) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 12),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: <pw.Widget>[
          pw.SizedBox(
            width: 92,
            child: pw.Text(
              rotulo,
              style: const pw.TextStyle(
                fontSize: 9,
                color: PdfColor.fromInt(0xFF7B9BE0),
              ),
            ),
          ),
          pw.Expanded(
            child: pw.Text(
              valor,
              style: pw.TextStyle(
                fontSize: 13,
                color: _branco,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _numeroCapa(String rotulo, String valor, PdfColor cor) {
    return pw.Column(
      mainAxisAlignment: pw.MainAxisAlignment.center,
      children: <pw.Widget>[
        pw.Text(
          rotulo,
          style: const pw.TextStyle(fontSize: 8, color: _cinzaMedio),
        ),
        pw.SizedBox(height: 5),
        pw.Text(
          valor,
          style: pw.TextStyle(
            fontSize: 16,
            color: cor,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
      ],
    );
  }

  static pw.Widget _divisorVertical() =>
      pw.Container(width: 1, height: 40, color: _cinza);

  // =====================================================================
  // CABEÇALHO E RODAPÉ DAS PÁGINAS INTERNAS
  // =====================================================================

  static pw.Widget _cabecalhoPagina(ResumoPeriodo resumo) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 16),
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: _azul, width: 2)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        crossAxisAlignment: pw.CrossAxisAlignment.end,
        children: <pw.Widget>[
          pw.Text(
            'FAROL',
            style: pw.TextStyle(
              fontSize: 15,
              color: _azulEscuro,
              fontWeight: pw.FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          pw.Text(
            resumo.rotulo,
            style: const pw.TextStyle(fontSize: 10, color: _cinzaMedio),
          ),
        ],
      ),
    );
  }

  static pw.Widget _rodape(pw.Context ctx, String emitidoEm) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(top: 12),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: <pw.Widget>[
          pw.Text(
            'Farol • $emitidoEm',
            style: const pw.TextStyle(fontSize: 8, color: _cinzaMedio),
          ),
          pw.Text(
            'Página ${ctx.pageNumber} de ${ctx.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: _cinzaMedio),
          ),
        ],
      ),
    );
  }

  static pw.Widget _secao(String titulo) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      color: _azulEscuro,
      child: pw.Text(
        titulo,
        style: pw.TextStyle(
          fontSize: 10.5,
          color: _branco,
          fontWeight: pw.FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
    );
  }

  // =====================================================================
  // KPIs
  // =====================================================================

  static pw.Widget _gradeKpis(ResumoPeriodo r) {
    final cartoes = <List<dynamic>>[
      <dynamic>['LUCRO LÍQUIDO', Fmt.moeda(r.lucroLiquido), _verde, _verdeClaro],
      <dynamic>['VALOR BRUTO', Fmt.moeda(r.valorBruto), _azul, _azulClaro],
      <dynamic>['COMBUSTÍVEL', Fmt.moeda(r.custoCombustivel), _vermelho, _vermelhoClaro],
      <dynamic>['OUTROS GASTOS', Fmt.moeda(r.outrosGastos), _vermelho, _vermelhoClaro],
      <dynamic>['KM RODADOS', Fmt.km(r.km), _azulEscuro, _cinza],
      <dynamic>['HORAS', Fmt.horasTexto(r.horas), _azulEscuro, _cinza],
      <dynamic>['CORRIDAS', Fmt.inteiro(r.corridas), _azulEscuro, _cinza],
      <dynamic>['DIAS TRABALHADOS', Fmt.inteiro(r.diasTrabalhados), _azulEscuro, _cinza],
    ];

    return pw.Column(
      children: <pw.Widget>[
        for (var i = 0; i < cartoes.length; i += 4)
          pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 8),
            child: pw.Row(
              children: <pw.Widget>[
                for (var j = i; j < i + 4 && j < cartoes.length; j++) ...[
                  pw.Expanded(
                    child: _cartaoKpi(
                      cartoes[j][0] as String,
                      cartoes[j][1] as String,
                      cartoes[j][2] as PdfColor,
                      cartoes[j][3] as PdfColor,
                    ),
                  ),
                  if (j < i + 3 && j < cartoes.length - 1)
                    pw.SizedBox(width: 8),
                ],
              ],
            ),
          ),
      ],
    );
  }

  static pw.Widget _cartaoKpi(
    String rotulo,
    String valor,
    PdfColor cor,
    PdfColor fundo,
  ) {
    return pw.Container(
      height: 54,
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 7),
      decoration: pw.BoxDecoration(
        color: fundo,
        borderRadius: pw.BorderRadius.circular(6),
        border: pw.Border(left: pw.BorderSide(color: cor, width: 3)),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: <pw.Widget>[
          pw.Text(
            rotulo,
            style: const pw.TextStyle(fontSize: 6.5, color: _cinzaMedio),
          ),
          pw.Text(
            valor,
            style: pw.TextStyle(
              fontSize: 12,
              color: cor,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // =====================================================================
  // TABELA DE INDICADORES
  // =====================================================================

  static pw.Widget _tabelaIndicadores(ResumoPeriodo r) {
    final itens = <List<String>>[
      <String>['Ganho por hora', Fmt.moeda(r.ganhoPorHora),
        'Quanto sobra por hora de trabalho'],
      <String>['Custo por KM', Fmt.moeda(r.custoPorKm),
        'Quanto custa cada quilômetro rodado'],
      <String>['Lucro por KM', Fmt.moeda(r.lucroPorKm),
        'Quanto sobra em cada quilômetro'],
      <String>['Ticket médio', Fmt.moeda(r.ticketMedio),
        'Valor médio de cada corrida'],
      <String>['Margem de lucro', Fmt.percentual(r.margemLucro),
        'Percentual do bruto que virou lucro'],
      <String>['Bruto por hora', Fmt.moeda(r.brutoPorHora),
        'Faturamento por hora, antes dos custos'],
      <String>['KM por corrida', Fmt.numero(r.kmPorCorrida, casas: 1),
        'Distância média de cada corrida'],
      <String>['Corridas por hora', Fmt.numero(r.corridasPorHora, casas: 2),
        'Ritmo de atendimento'],
      <String>['Combustível gasto', Fmt.litros(r.litros),
        'Total de litros consumidos'],
      <String>['Lucro médio por dia', Fmt.moeda(r.lucroMedioDia),
        'Média nos dias em que trabalhou'],
      if (r.custosFixosRateados > 0)
        <String>['Custos fixos do período', Fmt.moeda(r.custosFixosRateados),
          'Parte das contas fixas do mês'],
      if (r.custosFixosRateados > 0)
        <String>['Lucro final', Fmt.moeda(r.lucroFinal),
          'Depois de pagar também as contas fixas'],
    ];

    return pw.Table(
      border: pw.TableBorder.all(color: _cinza, width: 0.8),
      columnWidths: const <int, pw.TableColumnWidth>{
        0: pw.FlexColumnWidth(3),
        1: pw.FlexColumnWidth(2),
        2: pw.FlexColumnWidth(4.5),
      },
      children: <pw.TableRow>[
        for (var i = 0; i < itens.length; i++)
          pw.TableRow(
            decoration: pw.BoxDecoration(
              color: i.isEven ? _branco : _cinza,
            ),
            children: <pw.Widget>[
              _celulaTexto(itens[i][0], negrito: true),
              _celulaTexto(itens[i][1],
                  negrito: true, cor: _azulEscuro, alinharDireita: true),
              _celulaTexto(itens[i][2], tamanho: 7.5, cor: _cinzaMedio),
            ],
          ),
      ],
    );
  }

  // =====================================================================
  // GRÁFICOS (desenhados com retângulos — sem imagem, sem dependência)
  // =====================================================================

  /// Gráfico de barras horizontais do lucro por dia.
  static pw.Widget _graficoBarras(Map<DateTime, double> dados, PdfColor cor) {
    if (dados.isEmpty) return pw.SizedBox();

    // O maior valor define 100% da largura da barra.
    final maior = dados.values
        .map((v) => v.abs())
        .reduce((a, b) => a > b ? a : b);
    if (maior <= 0) {
      return _aviso('Ainda não há lucro registrado neste período.');
    }

    // Mostra no máximo 31 dias para o gráfico não ficar ilegível.
    final entradas = dados.entries.toList();
    final lista =
        entradas.length > 31 ? entradas.sublist(entradas.length - 31) : entradas;

    return pw.Column(
      children: <pw.Widget>[
        for (final e in lista)
          pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 3),
            child: pw.Row(
              children: <pw.Widget>[
                pw.SizedBox(
                  width: 52,
                  child: pw.Text(
                    Fmt.dataCurta(e.key),
                    style: const pw.TextStyle(fontSize: 7.5, color: _tinta),
                  ),
                ),
                // A barra é feita com dois pedaços proporcionais lado a
                // lado (preenchido + vazio). Usar `flex` em vez de largura
                // fracionada mantém tudo dentro do que o pacote pdf oferece.
                pw.Expanded(
                  child: _barra(
                    fracao: (e.value.abs() / maior).clamp(0.02, 1.0),
                    cor: e.value >= 0 ? cor : _vermelho,
                    altura: 12,
                  ),
                ),
                pw.SizedBox(width: 8),
                pw.SizedBox(
                  width: 70,
                  child: pw.Text(
                    Fmt.moeda(e.value),
                    textAlign: pw.TextAlign.right,
                    style: pw.TextStyle(
                      fontSize: 7.5,
                      color: e.value >= 0 ? _tinta : _vermelho,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  /// Gráfico de gastos por categoria, com percentual.
  static pw.Widget _graficoCategorias(ResumoPeriodo r) {
    final itens = r.gastosPorCategoria.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    if (itens.isEmpty) return pw.SizedBox();

    final total = r.outrosGastos;

    return pw.Column(
      children: <pw.Widget>[
        for (final e in itens)
          pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 4),
            child: pw.Row(
              children: <pw.Widget>[
                pw.SizedBox(
                  width: 88,
                  child: pw.Text(
                    e.key,
                    style: const pw.TextStyle(fontSize: 8, color: _tinta),
                  ),
                ),
                pw.Expanded(
                  child: _barra(
                    fracao: total <= 0
                        ? 0.02
                        : (e.value / total).clamp(0.02, 1.0),
                    cor: _vermelho,
                    altura: 13,
                  ),
                ),
                pw.SizedBox(width: 8),
                pw.SizedBox(
                  width: 58,
                  child: pw.Text(
                    Fmt.moeda(e.value),
                    textAlign: pw.TextAlign.right,
                    style: pw.TextStyle(
                      fontSize: 8,
                      color: _tinta,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
                pw.SizedBox(
                  width: 42,
                  child: pw.Text(
                    Fmt.percentual(
                      CalculationsService.percentualMeta(
                        realizado: e.value,
                        meta: total,
                      ),
                    ),
                    textAlign: pw.TextAlign.right,
                    style: const pw.TextStyle(fontSize: 7.5, color: _cinzaMedio),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  // =====================================================================
  // TABELAS DETALHADAS
  // =====================================================================

  static pw.Widget _tabelaLancamentos(List<LancamentoDiario> lancamentos) {
    final lista = List<LancamentoDiario>.from(lancamentos)
      ..sort((a, b) => a.data.compareTo(b.data));

    return pw.Table(
      border: pw.TableBorder.all(color: _cinza, width: 0.7),
      columnWidths: const <int, pw.TableColumnWidth>{
        0: pw.FlexColumnWidth(1.6),
        1: pw.FlexColumnWidth(1.2),
        2: pw.FlexColumnWidth(1.8),
        3: pw.FlexColumnWidth(1.1),
        4: pw.FlexColumnWidth(1.1),
        5: pw.FlexColumnWidth(1.7),
        6: pw.FlexColumnWidth(1.7),
      },
      children: <pw.TableRow>[
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: _azulEscuro),
          children: <pw.Widget>[
            _celulaCabecalho('Data'),
            _celulaCabecalho('KM'),
            _celulaCabecalho('Bruto'),
            _celulaCabecalho('Horas'),
            _celulaCabecalho('Corr.'),
            _celulaCabecalho('Combustível'),
            _celulaCabecalho('Lucro'),
          ],
        ),
        for (var i = 0; i < lista.length; i++)
          _linhaLancamento(lista[i], i.isEven),
      ],
    );
  }

  static pw.TableRow _linhaLancamento(LancamentoDiario l, bool clara) {
    // Usa o MESMO serviço de cálculo das telas — zero risco de divergência.
    final custo = CalculationsService.custoCombustivelPorRodagem(
      km: l.km,
      kmPorLitro: l.kmPorLitro,
      precoLitro: l.precoLitro,
    );
    final lucro = CalculationsService.lucroBruto(
      valorBruto: l.valorBruto,
      custoCombustivel: custo,
    );
    return pw.TableRow(
      decoration: pw.BoxDecoration(color: clara ? _branco : _cinza),
      children: <pw.Widget>[
        _celulaTexto(Fmt.data(l.data), tamanho: 7.5),
        _celulaTexto(Fmt.numero(l.km, casas: 1),
            tamanho: 7.5, alinharDireita: true),
        _celulaTexto(Fmt.moeda(l.valorBruto),
            tamanho: 7.5, alinharDireita: true),
        _celulaTexto(Fmt.horasTexto(l.horas),
            tamanho: 7.5, alinharDireita: true),
        _celulaTexto('${l.corridas}', tamanho: 7.5, alinharDireita: true),
        _celulaTexto(Fmt.moeda(custo),
            tamanho: 7.5, alinharDireita: true, cor: _vermelho),
        _celulaTexto(Fmt.moeda(lucro),
            tamanho: 7.5,
            alinharDireita: true,
            negrito: true,
            cor: lucro >= 0 ? _verde : _vermelho),
      ],
    );
  }

  static pw.Widget _tabelaGastos(List<Gasto> gastos) {
    final lista = List<Gasto>.from(gastos)
      ..sort((a, b) => a.data.compareTo(b.data));

    return pw.Table(
      border: pw.TableBorder.all(color: _cinza, width: 0.7),
      columnWidths: const <int, pw.TableColumnWidth>{
        0: pw.FlexColumnWidth(1.5),
        1: pw.FlexColumnWidth(2),
        2: pw.FlexColumnWidth(4),
        3: pw.FlexColumnWidth(1.6),
      },
      children: <pw.TableRow>[
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: _vermelho),
          children: <pw.Widget>[
            _celulaCabecalho('Data'),
            _celulaCabecalho('Categoria'),
            _celulaCabecalho('Descrição'),
            _celulaCabecalho('Valor'),
          ],
        ),
        for (var i = 0; i < lista.length; i++)
          pw.TableRow(
            decoration: pw.BoxDecoration(color: i.isEven ? _branco : _cinza),
            children: <pw.Widget>[
              _celulaTexto(Fmt.data(lista[i].data), tamanho: 7.5),
              _celulaTexto(lista[i].categoriaValida, tamanho: 7.5),
              _celulaTexto(
                lista[i].descricao.isEmpty ? '—' : lista[i].descricao,
                tamanho: 7.5,
              ),
              _celulaTexto(
                Fmt.moeda(lista[i].valor),
                tamanho: 7.5,
                alinharDireita: true,
                negrito: true,
                cor: _vermelho,
              ),
            ],
          ),
      ],
    );
  }

  // =====================================================================
  // PEÇAS PEQUENAS
  // =====================================================================

  /// Desenha uma barra proporcional dentro do espaço disponível.
  ///
  /// O pacote `pdf` não tem largura fracionada como o Flutter, então a barra
  /// é montada com dois pedaços lado a lado usando `flex`: o preenchido e o
  /// vazio. Como `flex` é inteiro, a fração vira uma escala de 0 a 1000 —
  /// precisão de sobra para um gráfico.
  static pw.Widget _barra({
    required double fracao,
    required PdfColor cor,
    required double altura,
  }) {
    final f = fracao.isFinite ? fracao.clamp(0.0, 1.0) : 0.0;
    final preenchido = (f * 1000).round().clamp(1, 1000);
    final vazio = 1000 - preenchido;

    return pw.Row(
      children: <pw.Widget>[
        pw.Expanded(
          flex: preenchido,
          child: pw.Container(
            height: altura,
            decoration: pw.BoxDecoration(
              color: cor,
              borderRadius: pw.BorderRadius.circular(2),
            ),
          ),
        ),
        if (vazio > 0)
          pw.Expanded(
            flex: vazio,
            child: pw.Container(height: altura, color: _cinza),
          ),
      ],
    );
  }

  // =====================================================================
  // COMPARATIVO — SEMANA A SEMANA (ou mês a mês)
  // =====================================================================
  // A tabela que responde o que o total de um mês esconde: qual semana
  // rendeu mais, qual rendeu menos, e quanto cada uma variou em relação
  // à anterior. A variação vem em dinheiro E em porcentagem, porque
  // "caiu R$ 300" e "caiu 22%" dizem coisas diferentes.
  static pw.Widget _tabelaComparativo(
    List<ResumoPeriodo> fatias,
    String nomeDaFatia,
  ) {
    return pw.Table(
      border: pw.TableBorder.symmetric(
        inside: const pw.BorderSide(color: _cinza, width: 0.5),
      ),
      columnWidths: <int, pw.TableColumnWidth>{
        0: const pw.FlexColumnWidth(2.6),
        1: const pw.FlexColumnWidth(1.4),
        2: const pw.FlexColumnWidth(1.4),
        3: const pw.FlexColumnWidth(1.0),
        4: const pw.FlexColumnWidth(1.0),
        5: const pw.FlexColumnWidth(1.6),
      },
      children: <pw.TableRow>[
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: _azulEscuro),
          children: <pw.Widget>[
            _celulaCabecalho(nomeDaFatia),
            _celulaCabecalho('Bruto'),
            _celulaCabecalho('Lucro'),
            _celulaCabecalho('Dias'),
            _celulaCabecalho('Corridas'),
            _celulaCabecalho('Variação do lucro'),
          ],
        ),
        for (var i = 0; i < fatias.length; i++)
          _linhaComparativo(
            fatias[i],
            i == 0 ? null : fatias[i - 1],
            i.isEven,
          ),
      ],
    );
  }

  static pw.TableRow _linhaComparativo(
    ResumoPeriodo atual,
    ResumoPeriodo? anterior,
    bool clara,
  ) {
    final diferenca =
        anterior == null ? 0.0 : atual.lucroLiquido - anterior.lucroLiquido;

    // Divisão protegida: sem lucro anterior não existe porcentagem, e
    // inventar um número aqui seria mentir para o motorista.
    final temBase = anterior != null && anterior.lucroLiquido.abs() > 0.009;
    final percentual =
        temBase ? (diferenca / anterior.lucroLiquido.abs()) * 100 : 0.0;

    final String variacao;
    if (anterior == null) {
      variacao = '—';
    } else if (temBase) {
      final sinal = diferenca >= 0 ? '+' : '-';
      variacao = '$sinal${Fmt.moeda(diferenca.abs())} '
          '($sinal${percentual.abs().toStringAsFixed(0)}%)';
    } else {
      final sinal = diferenca >= 0 ? '+' : '-';
      variacao = '$sinal${Fmt.moeda(diferenca.abs())}';
    }

    final cor = anterior == null
        ? _cinzaMedio
        : (diferenca >= 0 ? _verde : _vermelho);

    return pw.TableRow(
      decoration: pw.BoxDecoration(color: clara ? _branco : _cinza),
      children: <pw.Widget>[
        _celulaTexto(atual.rotulo, tamanho: 8, negrito: true),
        _celulaTexto(Fmt.moeda(atual.valorBruto),
            tamanho: 8, alinharDireita: true),
        _celulaTexto(
          Fmt.moeda(atual.lucroLiquido),
          tamanho: 8,
          alinharDireita: true,
          negrito: true,
          cor: atual.lucroLiquido >= 0 ? _verde : _vermelho,
        ),
        _celulaTexto('${atual.diasTrabalhados}',
            tamanho: 8, alinharDireita: true),
        _celulaTexto('${atual.corridas}', tamanho: 8, alinharDireita: true),
        _celulaTexto(variacao,
            tamanho: 8, alinharDireita: true, cor: cor, negrito: true),
      ],
    );
  }

  /// Uma barra por fatia, para bater o olho e ver o desenho do período.
  /// A régua é a fatia que mais lucrou.
  static pw.Widget _graficoComparativo(List<ResumoPeriodo> fatias) {
    var maior = 0.0;
    for (final f in fatias) {
      final v = f.lucroLiquido.abs();
      if (v > maior) maior = v;
    }
    if (maior <= 0) return pw.SizedBox();

    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: _cinza,
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: <pw.Widget>[
          for (final f in fatias)
            pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 5),
              child: pw.Row(
                children: <pw.Widget>[
                  pw.SizedBox(
                    width: 108,
                    child: pw.Text(
                      f.rotulo,
                      style: const pw.TextStyle(fontSize: 7.5, color: _tinta),
                      maxLines: 1,
                    ),
                  ),
                  pw.Expanded(
                    child: _barra(
                      fracao: (f.lucroLiquido.abs() / maior).clamp(0.0, 1.0),
                      cor: f.lucroLiquido >= 0 ? _verde : _vermelho,
                      altura: 7,
                    ),
                  ),
                  pw.SizedBox(width: 8),
                  pw.SizedBox(
                    width: 62,
                    child: pw.Text(
                      Fmt.moeda(f.lucroLiquido),
                      textAlign: pw.TextAlign.right,
                      style: pw.TextStyle(
                        fontSize: 7.5,
                        color: f.lucroLiquido >= 0 ? _verde : _vermelho,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  static pw.Widget _celulaCabecalho(String texto) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      child: pw.Text(
        texto,
        style: pw.TextStyle(
          fontSize: 7.5,
          color: _branco,
          fontWeight: pw.FontWeight.bold,
        ),
      ),
    );
  }

  static pw.Widget _celulaTexto(
    String texto, {
    double tamanho = 8.5,
    PdfColor cor = _tinta,
    bool negrito = false,
    bool alinharDireita = false,
  }) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 4),
      child: pw.Text(
        texto,
        textAlign: alinharDireita ? pw.TextAlign.right : pw.TextAlign.left,
        style: pw.TextStyle(
          fontSize: tamanho,
          color: cor,
          fontWeight: negrito ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
      ),
    );
  }

  static pw.Widget _aviso(String texto) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      color: _cinza,
      child: pw.Text(
        texto,
        style: const pw.TextStyle(fontSize: 9, color: _cinzaMedio),
      ),
    );
  }
}
