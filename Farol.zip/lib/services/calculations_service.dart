/// =======================================================================
/// CALCULATIONS SERVICE — O CÉREBRO FINANCEIRO DO FAROL
/// =======================================================================
/// REGRA NÚMERO 1 DO PROJETO: **toda** fórmula do aplicativo mora aqui.
/// Nenhuma tela, nenhum widget e nenhum relatório pode fazer conta por
/// conta própria. Se um número aparece na tela, ele saiu de um método
/// desta classe.
///
/// Por que isso importa: se um dia a regra do custo por KM mudar, muda-se
/// em UM lugar só e o app inteiro (telas, Excel e PDF) fica correto junto.
///
/// SEGURANÇA DOS CÁLCULOS:
///   - Toda divisão é protegida contra divisor zero (devolve 0, nunca erro).
///   - Todo resultado passa por [arredondar], que corrige o erro clássico
///     de ponto flutuante (ex.: 0.1 + 0.2 = 0.30000000000000004).
///   - Nenhum método devolve NaN ou Infinity.
///
/// Todos os métodos são estáticos e puros: mesma entrada, mesma saída.
/// Isso permite testá-los sem abrir o app (ver test/).
/// =======================================================================
library;

import 'dart:math' as math;

import '../core/app_constants.dart';
import '../data/models/abastecimento.dart';
import '../data/models/gasto.dart';
import '../data/models/jornada.dart';
import '../data/models/lancamento_diario.dart';
import '../domain/entities/resumo_periodo.dart';
import '../utils/extensions.dart';

class CalculationsService {
  CalculationsService._();

  // =====================================================================
  // BLOCO 0 — FERRAMENTAS BÁSICAS DE SEGURANÇA NUMÉRICA
  // =====================================================================

  /// Arredonda para [casas] casas decimais usando a regra comercial
  /// (0,5 sempre sobe, afastando-se do zero).
  ///
  /// A correção `epsilon` conserta o erro de ponto flutuante: sem ela,
  /// 1.005 vira 100.49999999 ao multiplicar por 100 e arredondaria para
  /// 1,00 em vez de 1,01 — um centavo perdido em cada conta.
  static double arredondar(double valor, [int casas = 2]) {
    if (valor.isNaN || valor.isInfinite) return 0.0;
    final escala = math.pow(10, casas).toDouble();
    final ampliado = valor * escala;
    // Empurra o número um fio na direção do próprio sinal antes de arredondar.
    final epsilon = ampliado.abs() * 1e-9;
    final corrigido = ampliado.isNegative ? ampliado - epsilon : ampliado + epsilon;
    final resultado = corrigido.roundToDouble() / escala;
    // Evita o "-0.0" aparecer na tela.
    return resultado == 0 ? 0.0 : resultado;
  }

  /// Divisão à prova de erro: se o divisor for zero, inválido ou negativo
  /// quando não pode ser, devolve 0 em vez de estourar o app.
  static double dividirSeguro(double dividendo, double divisor,
      {int casas = 2}) {
    if (divisor == 0 || !divisor.isFinite || !dividendo.isFinite) return 0.0;
    return arredondar(dividendo / divisor, casas);
  }

  /// Garante que um número nunca seja negativo (usado em valores finais).
  static double naoNegativo(double valor) =>
      (!valor.isFinite || valor < 0) ? 0.0 : valor;

  // =====================================================================
  // BLOCO 1 — COMBUSTÍVEL
  // =====================================================================

  /// Litros consumidos ao rodar [km] com um carro que faz [kmPorLitro].
  ///
  /// Fórmula: LITROS = KM ÷ (KM/L)
  /// Exemplo: 240 km ÷ 12 km/L = 20 litros
  static double litrosGastos(double km, double kmPorLitro) {
    if (kmPorLitro <= 0 || km <= 0) return 0.0;
    return arredondar(km / kmPorLitro, 3); // 3 casas: litro tem fração fina
  }

  /// Quanto custou o combustível a partir dos litros.
  ///
  /// Fórmula: CUSTO = LITROS × PREÇO DO LITRO
  static double custoCombustivel(double litros, double precoLitro) {
    if (litros <= 0 || precoLitro <= 0) return 0.0;
    return arredondar(litros * precoLitro);
  }

  /// Atalho do dia a dia: quanto de combustível foi gasto rodando [km].
  ///
  /// Fórmula: (KM ÷ KM/L) × PREÇO DO LITRO
  /// Exemplo: (240 ÷ 12) × 6,19 = 20 L × 6,19 = R$ 123,80
  static double custoCombustivelPorRodagem({
    required double km,
    required double kmPorLitro,
    required double precoLitro,
  }) {
    final litros = litrosGastos(km, kmPorLitro);
    return custoCombustivel(litros, precoLitro);
  }

  /// Quanto custa cada quilômetro só de combustível.
  ///
  /// Fórmula: PREÇO DO LITRO ÷ (KM/L)
  /// Exemplo: 6,19 ÷ 12 = R$ 0,5158 por km
  static double custoCombustivelPorKm({
    required double kmPorLitro,
    required double precoLitro,
  }) {
    if (kmPorLitro <= 0) return 0.0;
    return arredondar(precoLitro / kmPorLitro, 4); // 4 casas: precisão fina
  }

  /// Consumo REAL do carro medido entre dois abastecimentos.
  ///
  /// Fórmula: KM RODADOS ÷ LITROS ABASTECIDOS
  static double kmPorLitroReal({
    required double kmRodados,
    required double litrosAbastecidos,
  }) {
    if (litrosAbastecidos <= 0 || kmRodados <= 0) return 0.0;
    return arredondar(kmRodados / litrosAbastecidos, 2);
  }

  // =====================================================================
  // BLOCO 2 — ABASTECIMENTO E DESCONTOS
  // =====================================================================

  /// Valor cheio do abastecimento, antes de qualquer desconto.
  ///
  /// Fórmula: LITROS × PREÇO DO LITRO
  static double valorBrutoAbastecimento({
    required double litros,
    required double precoLitro,
  }) =>
      custoCombustivel(litros, precoLitro);

  /// Aplica desconto em porcentagem E/OU em reais sobre um valor.
  ///
  /// Ordem de aplicação (a mesma dos postos):
  ///   1) tira a porcentagem;
  ///   2) depois abate o valor fixo em reais.
  ///
  /// Fórmula: FINAL = (VALOR × (1 − %/100)) − R$
  /// O resultado nunca fica negativo.
  ///
  /// Exemplo: R$ 200,00 com 10% e mais R$ 5,00
  ///          → 200 × 0,90 = 180,00 → 180 − 5 = R$ 175,00
  static double aplicarDesconto({
    required double valor,
    double descontoPercentual = 0,
    double descontoReais = 0,
  }) {
    if (valor <= 0) return 0.0;
    // Trava a porcentagem entre 0 e 100 para não inverter o sinal.
    final pct = descontoPercentual.clamp(0.0, 100.0);
    final aposPercentual = valor * (1 - pct / 100);
    final aposReais = aposPercentual - naoNegativo(descontoReais);
    return arredondar(naoNegativo(aposReais));
  }

  /// Valor final efetivamente pago em um abastecimento.
  static double valorFinalAbastecimento(Abastecimento a) {
    final bruto = valorBrutoAbastecimento(
      litros: a.litros,
      precoLitro: a.precoLitro,
    );
    return aplicarDesconto(
      valor: bruto,
      descontoPercentual: a.descontoPercentual,
      descontoReais: a.descontoReais,
    );
  }

  /// Quanto o motorista economizou com o desconto.
  static double economiaAbastecimento(Abastecimento a) {
    final bruto = valorBrutoAbastecimento(
      litros: a.litros,
      precoLitro: a.precoLitro,
    );
    return arredondar(naoNegativo(bruto - valorFinalAbastecimento(a)));
  }

  /// Preço que o litro saiu DE VERDADE, já com o desconto.
  ///
  /// Fórmula: VALOR FINAL ÷ LITROS
  /// É esse número que o motorista deve comparar entre postos.
  static double precoEfetivoPorLitro(Abastecimento a) {
    if (a.litros <= 0) return 0.0;
    return arredondar(valorFinalAbastecimento(a) / a.litros, 3);
  }

  // =====================================================================
  // BLOCO 3 — RESULTADO DE UM DIA DE TRABALHO
  // =====================================================================

  /// Lucro bruto: o que sobrou depois de tirar SÓ o combustível.
  ///
  /// Fórmula: LUCRO BRUTO = VALOR BRUTO − COMBUSTÍVEL
  static double lucroBruto({
    required double valorBruto,
    required double custoCombustivel,
  }) =>
      arredondar(valorBruto - custoCombustivel);

  /// Lucro líquido: tira o combustível E os outros gastos do dia.
  ///
  /// Fórmula: LÍQUIDO = VALOR BRUTO − COMBUSTÍVEL − OUTROS GASTOS
  static double lucroLiquido({
    required double valorBruto,
    required double custoCombustivel,
    double outrosGastos = 0,
  }) =>
      arredondar(valorBruto - custoCombustivel - outrosGastos);

  /// Custo por KM: quanto custa cada quilômetro rodado.
  ///
  /// Fórmula: CUSTO TOTAL ÷ KM RODADOS
  /// Use 4 casas porque o valor é pequeno (centavos por km).
  static double custoPorKm({
    required double custoTotal,
    required double km,
  }) =>
      dividirSeguro(custoTotal, km, casas: 4);

  /// Lucro por KM: quanto sobra em cada quilômetro rodado.
  ///
  /// Fórmula: LUCRO ÷ KM RODADOS
  static double lucroPorKm({
    required double lucro,
    required double km,
  }) =>
      dividirSeguro(lucro, km, casas: 4);

  /// Ganho por hora: quanto o motorista tira por hora de trabalho.
  ///
  /// Fórmula: LUCRO ÷ HORAS TRABALHADAS
  /// É o indicador mais importante para comparar dias diferentes.
  static double ganhoPorHora({
    required double lucro,
    required double horas,
  }) =>
      dividirSeguro(lucro, horas);

  /// Valor bruto por hora (antes de descontar custos).
  static double brutoPorHora({
    required double valorBruto,
    required double horas,
  }) =>
      dividirSeguro(valorBruto, horas);

  /// Ticket médio: quanto rende, em média, cada corrida.
  ///
  /// Fórmula: VALOR BRUTO ÷ QUANTIDADE DE CORRIDAS
  static double ticketMedio({
    required double valorBruto,
    required int corridas,
  }) =>
      dividirSeguro(valorBruto, corridas.toDouble());

  /// Margem de lucro em porcentagem.
  ///
  /// Fórmula: (LUCRO ÷ VALOR BRUTO) × 100
  /// Exemplo: lucro 224 sobre bruto 348 = 64,4%
  static double margemLucro({
    required double lucro,
    required double valorBruto,
  }) {
    if (valorBruto <= 0) return 0.0;
    return arredondar(lucro / valorBruto * 100, 2);
  }

  /// Média de quilômetros por corrida.
  static double kmPorCorrida({required double km, required int corridas}) =>
      dividirSeguro(km, corridas.toDouble());

  /// Média de corridas por hora.
  static double corridasPorHora({required int corridas, required double horas}) =>
      dividirSeguro(corridas.toDouble(), horas);

  // =====================================================================
  // BLOCO 4 — METAS
  // =====================================================================

  /// Quanto por cento da meta já foi atingido.
  ///
  /// Fórmula: (REALIZADO ÷ META) × 100
  /// Se a meta for zero, devolve 0 (não faz sentido "bater" meta zero).
  static double percentualMeta({
    required double realizado,
    required double meta,
  }) {
    if (meta <= 0) return 0.0;
    return arredondar(realizado / meta * 100, 1);
  }

  /// Valor da barra de progresso (0.0 a 1.0), já travado no máximo.
  static double progressoMeta({
    required double realizado,
    required double meta,
  }) {
    if (meta <= 0) return 0.0;
    final p = realizado / meta;
    if (!p.isFinite) return 0.0;
    return p.clamp(0.0, 1.0);
  }

  /// Quanto ainda falta para bater a meta (nunca negativo).
  static double faltaParaMeta({
    required double realizado,
    required double meta,
  }) =>
      arredondar(naoNegativo(meta - realizado));

  /// A meta foi batida?
  static bool metaAtingida({
    required double realizado,
    required double meta,
  }) =>
      meta > 0 && realizado >= meta;

  // =====================================================================
  // BLOCO 5 — TEMPO DE JORNADA
  // =====================================================================

  /// Tempo REALMENTE trabalhado em uma jornada.
  ///
  /// Regra: TEMPO ATIVO = (FIM − INÍCIO) − SOMA DAS PAUSAS
  /// Pausas para banheiro, café e almoço NÃO contam como trabalho.
  ///
  /// [agora] permite testar sem depender do relógio real.
  static Duration tempoAtivoJornada(Jornada jornada, {DateTime? agora}) {
    final referencia = agora ?? DateTime.now();
    final fim = jornada.fim ?? referencia;

    // Duração total do começo ao fim (ou até agora, se ainda aberta).
    var total = fim.difference(jornada.inicio);
    if (total.isNegative) return Duration.zero;

    // Desconta cada pausa, respeitando os limites da jornada.
    var pausado = Duration.zero;
    for (final p in jornada.pausas) {
      final ini = p.inicio.isBefore(jornada.inicio) ? jornada.inicio : p.inicio;
      final termino = p.fim ?? referencia;
      final fimPausa = termino.isAfter(fim) ? fim : termino;
      final d = fimPausa.difference(ini);
      if (!d.isNegative) pausado += d;
    }

    final ativo = total - pausado;
    return ativo.isNegative ? Duration.zero : ativo;
  }

  /// Tempo total parado em pausas.
  static Duration tempoPausadoJornada(Jornada jornada, {DateTime? agora}) {
    final referencia = agora ?? DateTime.now();
    final fim = jornada.fim ?? referencia;
    var pausado = Duration.zero;
    for (final p in jornada.pausas) {
      final ini = p.inicio.isBefore(jornada.inicio) ? jornada.inicio : p.inicio;
      final termino = p.fim ?? referencia;
      final fimPausa = termino.isAfter(fim) ? fim : termino;
      final d = fimPausa.difference(ini);
      if (!d.isNegative) pausado += d;
    }
    return pausado;
  }

  /// Converte uma duração em horas decimais (8h30 -> 8.5).
  /// É assim que as horas entram nas fórmulas de ganho por hora.
  static double duracaoParaHoras(Duration d) {
    if (d.isNegative) return 0.0;
    return arredondar(d.inSeconds / 3600.0, 4);
  }

  /// Soma o tempo ativo de várias jornadas e devolve em horas decimais.
  static double horasDeJornadas(List<Jornada> jornadas, {DateTime? agora}) {
    var total = Duration.zero;
    for (final j in jornadas) {
      total += tempoAtivoJornada(j, agora: agora);
    }
    return duracaoParaHoras(total);
  }

  // =====================================================================
  // BLOCO 6 — "VALE A PENA ACEITAR ESTA CORRIDA?"
  // =====================================================================

  /// Avalia uma oferta de corrida comparando o que ela paga com o que
  /// ela custa de combustível, considerando a margem que o motorista quer.
  ///
  /// [kmTotal] deve incluir o deslocamento até o passageiro + a viagem.
  ///
  /// Fórmulas:
  ///   CUSTO      = KM TOTAL × CUSTO POR KM
  ///   LUCRO      = OFERTA − CUSTO
  ///   MARGEM     = (LUCRO ÷ OFERTA) × 100
  ///   VALOR IDEAL= CUSTO ÷ (1 − MARGEM ALVO/100)
  static AvaliacaoCorrida avaliarCorrida({
    required double valorOferta,
    required double kmTotal,
    required double custoPorKmCombustivel,
    double margemAlvo = AppConstants.margemLucroAlvoPadrao,
  }) {
    final km = naoNegativo(kmTotal);
    final oferta = naoNegativo(valorOferta);
    final custo = arredondar(km * naoNegativo(custoPorKmCombustivel));
    final lucro = arredondar(oferta - custo);
    final margem = margemLucro(lucro: lucro, valorBruto: oferta);

    // Trava a margem alvo abaixo de 100% para a divisão não explodir.
    final alvo = margemAlvo.clamp(0.0, 95.0);
    final valorIdeal = arredondar(custo / (1 - alvo / 100));

    final VeredictoCorrida veredicto;
    if (oferta <= 0 || lucro <= 0) {
      veredicto = VeredictoCorrida.recusar;
    } else if (margem < alvo) {
      veredicto = VeredictoCorrida.atencao;
    } else {
      veredicto = VeredictoCorrida.aceitar;
    }

    return AvaliacaoCorrida(
      valorOferta: oferta,
      kmTotal: km,
      custoEstimado: custo,
      lucroEstimado: lucro,
      margem: margem,
      valorMinimoIdeal: valorIdeal,
      veredicto: veredicto,
    );
  }

  // =====================================================================
  // BLOCO 7 — JUROS COMPOSTOS (SIMULADOR DE PATRIMÔNIO)
  // =====================================================================

  /// Converte taxa ANUAL em taxa MENSAL equivalente (juros compostos).
  ///
  /// Fórmula: i_mensal = (1 + i_anual)^(1/12) − 1
  /// ATENÇÃO: não é dividir por 12 — isso daria um número errado.
  /// Ambas as taxas entram e saem em PORCENTAGEM (ex.: 12 = 12%).
  static double taxaAnualParaMensal(double taxaAnualPercentual) {
    if (taxaAnualPercentual <= -100) return 0.0;
    final ia = taxaAnualPercentual / 100;
    final im = math.pow(1 + ia, 1 / 12) - 1;
    return arredondar(im * 100, 6);
  }

  /// Converte taxa MENSAL em ANUAL equivalente.
  ///
  /// Fórmula: i_anual = (1 + i_mensal)^12 − 1
  static double taxaMensalParaAnual(double taxaMensalPercentual) {
    if (taxaMensalPercentual <= -100) return 0.0;
    final im = taxaMensalPercentual / 100;
    final ia = math.pow(1 + im, 12) - 1;
    return arredondar(ia * 100, 4);
  }

  /// Quanto o dinheiro vira depois de [meses], com aportes mensais.
  ///
  /// Fórmula (aportes no FIM de cada mês):
  ///   M = P × (1+i)^n  +  PMT × [ ((1+i)^n − 1) ÷ i ]
  ///
  /// Quando a taxa é zero, a fórmula acima daria divisão por zero,
  /// então usamos o caso simples:  M = P + (PMT × n)
  ///
  /// [taxaMensalPercentual] em porcentagem (ex.: 0.8 = 0,8% ao mês).
  static double montanteJurosCompostos({
    required double valorInicial,
    required double aporteMensal,
    required double taxaMensalPercentual,
    required int meses,
  }) {
    if (meses <= 0) return arredondar(naoNegativo(valorInicial));
    final p = naoNegativo(valorInicial);
    final pmt = naoNegativo(aporteMensal);
    final i = taxaMensalPercentual / 100;

    if (i == 0) {
      return arredondar(p + pmt * meses);
    }

    final fator = math.pow(1 + i, meses).toDouble();
    if (!fator.isFinite) return double.maxFinite;

    final montante = p * fator + pmt * ((fator - 1) / i);
    return arredondar(montante);
  }

  /// Monta a projeção mês a mês para desenhar o gráfico de evolução.
  ///
  /// Cada mês: rende juros sobre o saldo e depois recebe o aporte.
  static List<ProjecaoMes> projecaoPatrimonio({
    required double valorInicial,
    required double aporteMensal,
    required double taxaMensalPercentual,
    required int meses,
  }) {
    final lista = <ProjecaoMes>[];
    final limite = meses.clamp(0, 1200); // no máximo 100 anos
    final i = taxaMensalPercentual / 100;
    final pmt = naoNegativo(aporteMensal);

    var saldo = naoNegativo(valorInicial);
    var aportado = saldo;
    var juros = 0.0;

    // Mês 0 = ponto de partida, antes de qualquer rendimento.
    lista.add(ProjecaoMes(
      mes: 0,
      totalAportado: arredondar(aportado),
      jurosAcumulados: 0,
      saldo: arredondar(saldo),
    ));

    for (var m = 1; m <= limite; m++) {
      final rendimento = saldo * i;
      juros += rendimento;
      saldo = saldo + rendimento + pmt;
      aportado += pmt;

      if (!saldo.isFinite) break; // proteção contra números absurdos

      lista.add(ProjecaoMes(
        mes: m,
        totalAportado: arredondar(aportado),
        jurosAcumulados: arredondar(juros),
        saldo: arredondar(saldo),
      ));
    }
    return lista;
  }

  /// Em quantos MESES o motorista chega na meta.
  /// Devolve -1 quando é impossível (sem aporte e sem juros suficientes).
  ///
  /// Faz a simulação mês a mês — mais confiável que fórmula com logaritmo,
  /// porque nunca dá erro de domínio matemático.
  static int mesesParaMeta({
    required double meta,
    required double valorInicial,
    required double aporteMensal,
    required double taxaMensalPercentual,
    int limiteMeses = 1200,
  }) {
    final alvo = naoNegativo(meta);
    var saldo = naoNegativo(valorInicial);
    if (saldo >= alvo) return 0;

    final i = taxaMensalPercentual / 100;
    final pmt = naoNegativo(aporteMensal);

    // Se não entra dinheiro novo e não rende nada, nunca chega.
    if (pmt <= 0 && i <= 0) return -1;

    for (var m = 1; m <= limiteMeses; m++) {
      saldo = saldo * (1 + i) + pmt;
      if (!saldo.isFinite) return -1;
      if (saldo >= alvo) return m;
    }
    return -1; // não chegou dentro do limite
  }

  /// CÁLCULO REVERSO: "quero X reais em Y meses — quanto guardar por mês?"
  ///
  /// Fórmula: PMT = (META − P×(1+i)^n) × i ÷ ((1+i)^n − 1)
  /// Com taxa zero:  PMT = (META − P) ÷ n
  ///
  /// Se o valor inicial já rende o suficiente sozinho, devolve 0.
  static double aporteNecessario({
    required double meta,
    required double valorInicial,
    required double taxaMensalPercentual,
    required int meses,
  }) {
    if (meses <= 0) return 0.0;
    final alvo = naoNegativo(meta);
    final p = naoNegativo(valorInicial);
    final i = taxaMensalPercentual / 100;

    if (i == 0) {
      return arredondar(naoNegativo((alvo - p) / meses));
    }

    final fator = math.pow(1 + i, meses).toDouble();
    if (!fator.isFinite) return 0.0;

    final divisor = fator - 1;
    if (divisor == 0) return arredondar(naoNegativo((alvo - p) / meses));

    final pmt = (alvo - p * fator) * i / divisor;
    return arredondar(naoNegativo(pmt));
  }

  /// Formata a resposta de tempo em texto amigável: 30 -> "2 anos e 6 meses".
  static String mesesEmTexto(int meses) {
    if (meses < 0) return 'Não é possível com esses valores';
    if (meses == 0) return 'Você já tem o valor';
    final anos = meses ~/ 12;
    final resto = meses % 12;
    final partes = <String>[];
    if (anos > 0) partes.add(anos == 1 ? '1 ano' : '$anos anos');
    if (resto > 0) partes.add(resto == 1 ? '1 mês' : '$resto meses');
    return partes.join(' e ');
  }

  // =====================================================================
  // BLOCO 8 — CUSTOS FIXOS MENSAIS
  // =====================================================================

  /// Divide o custo fixo mensal pelos dias do período analisado.
  ///
  /// Fórmula: (CUSTO FIXO MENSAL ÷ 30) × DIAS DO PERÍODO
  /// Serve para o motorista ver o lucro REAL, já pagando as contas do mês.
  static double ratearCustosFixos({
    required double custoFixoMensal,
    required int diasDoPeriodo,
  }) {
    if (custoFixoMensal <= 0 || diasDoPeriodo <= 0) return 0.0;
    return arredondar(custoFixoMensal / 30.0 * diasDoPeriodo);
  }

  // =====================================================================
  // BLOCO 9 — RESUMO DE UM PERÍODO (usado por telas, Excel e PDF)
  // =====================================================================

  /// Junta lançamentos e gastos de um período e devolve TODOS os números
  /// já calculados. É a única porta de entrada dos relatórios.
  ///
  /// [usarCustoRealAbastecimento]: quando true e existirem abastecimentos
  /// no período, o custo de combustível considerado é o que foi REALMENTE
  /// pago no posto (com desconto), em vez da estimativa por km/L.
  static ResumoPeriodo resumir({
    required List<LancamentoDiario> lancamentos,
    required List<Gasto> gastos,
    List<Abastecimento> abastecimentos = const <Abastecimento>[],
    required DateTime inicio,
    required DateTime fim,
    String rotulo = '',
    double custosFixosMensais = 0,
    bool usarCustoRealAbastecimento = false,
  }) {
    // ---- Somas dos lançamentos ----
    var valorBruto = 0.0;
    var km = 0.0;
    var horas = 0.0;
    var corridas = 0;
    var litros = 0.0;
    var combustivelEstimado = 0.0;

    final lucroPorDia = <DateTime, double>{};
    final brutoPorDia = <DateTime, double>{};
    final diasUnicos = <DateTime>{};

    for (final l in lancamentos) {
      valorBruto += l.valorBruto;
      km += l.km;
      horas += l.horas;
      corridas += l.corridas;

      final litrosDoDia = litrosGastos(l.km, l.kmPorLitro);
      final custoDoDia = custoCombustivel(litrosDoDia, l.precoLitro);
      litros += litrosDoDia;
      combustivelEstimado += custoDoDia;

      final dia = l.data.soData;
      diasUnicos.add(dia);
      brutoPorDia[dia] = (brutoPorDia[dia] ?? 0) + l.valorBruto;
      lucroPorDia[dia] = (lucroPorDia[dia] ?? 0) + (l.valorBruto - custoDoDia);
    }

    // ---- Custo de combustível: estimado ou realmente pago ----
    var custoCombustivelTotal = arredondar(combustivelEstimado);
    if (usarCustoRealAbastecimento && abastecimentos.isNotEmpty) {
      var pago = 0.0;
      for (final a in abastecimentos) {
        pago += valorFinalAbastecimento(a);
      }
      custoCombustivelTotal = arredondar(pago);
    }

    // ---- Gastos das 12 categorias ----
    var outrosGastos = 0.0;
    final porCategoria = <String, double>{};
    for (final g in gastos) {
      outrosGastos += g.valor;
      final cat = g.categoriaValida;
      porCategoria[cat] = arredondar((porCategoria[cat] ?? 0) + g.valor);

      // O gasto também entra no lucro do dia em que aconteceu.
      final dia = g.data.soData;
      lucroPorDia[dia] = (lucroPorDia[dia] ?? 0) - g.valor;
    }

    valorBruto = arredondar(valorBruto);
    km = arredondar(km, 1);
    horas = arredondar(horas, 2);
    litros = arredondar(litros, 3);
    outrosGastos = arredondar(outrosGastos);

    // ---- Resultados ----
    final lBruto = lucroBruto(
      valorBruto: valorBruto,
      custoCombustivel: custoCombustivelTotal,
    );
    final lLiquido = lucroLiquido(
      valorBruto: valorBruto,
      custoCombustivel: custoCombustivelTotal,
      outrosGastos: outrosGastos,
    );

    final diasPeriodo = fim.soData.difference(inicio.soData).inDays + 1;
    final fixos = ratearCustosFixos(
      custoFixoMensal: custosFixosMensais,
      diasDoPeriodo: diasPeriodo,
    );
    final lFinal = arredondar(lLiquido - fixos);

    final custoTotal = arredondar(custoCombustivelTotal + outrosGastos);
    final dias = diasUnicos.length;

    // Ordena as séries por data para os gráficos saírem na ordem certa.
    final lucroOrdenado = _ordenarPorData(
      lucroPorDia.map((k, v) => MapEntry(k, arredondar(v))),
    );
    final brutoOrdenado = _ordenarPorData(
      brutoPorDia.map((k, v) => MapEntry(k, arredondar(v))),
    );

    return ResumoPeriodo(
      inicio: inicio,
      fim: fim,
      rotulo: rotulo,
      valorBruto: valorBruto,
      km: km,
      horas: horas,
      corridas: corridas,
      litros: litros,
      custoCombustivel: custoCombustivelTotal,
      outrosGastos: outrosGastos,
      custosFixosRateados: fixos,
      lucroBruto: lBruto,
      lucroLiquido: lLiquido,
      lucroFinal: lFinal,
      custoPorKm: custoPorKm(custoTotal: custoTotal, km: km),
      lucroPorKm: lucroPorKm(lucro: lLiquido, km: km),
      ganhoPorHora: ganhoPorHora(lucro: lLiquido, horas: horas),
      brutoPorHora: brutoPorHora(valorBruto: valorBruto, horas: horas),
      ticketMedio: ticketMedio(valorBruto: valorBruto, corridas: corridas),
      margemLucro: margemLucro(lucro: lLiquido, valorBruto: valorBruto),
      kmPorCorrida: kmPorCorrida(km: km, corridas: corridas),
      corridasPorHora: corridasPorHora(corridas: corridas, horas: horas),
      diasTrabalhados: dias,
      lucroMedioDia: dividirSeguro(lLiquido, dias.toDouble()),
      lucroPorDia: lucroOrdenado,
      brutoPorDia: brutoOrdenado,
      gastosPorCategoria: porCategoria,
    );
  }

  /// Devolve o mapa ordenado da data mais antiga para a mais nova.
  static Map<DateTime, double> _ordenarPorData(Map<DateTime, double> mapa) {
    final chaves = mapa.keys.toList()..sort((a, b) => a.compareTo(b));
    return <DateTime, double>{for (final k in chaves) k: mapa[k]!};
  }

  // =====================================================================
  // BLOCO 10 — COMPARAÇÃO ENTRE PERÍODOS
  // =====================================================================

  /// Variação percentual entre dois valores (crescimento ou queda).
  ///
  /// Fórmula: ((ATUAL − ANTERIOR) ÷ ANTERIOR) × 100
  /// Se o período anterior foi zero, devolve 100% quando há valor agora
  /// (cresceu do nada) ou 0% quando também é zero.
  static double variacaoPercentual({
    required double atual,
    required double anterior,
  }) {
    if (anterior == 0) return atual > 0 ? 100.0 : 0.0;
    return arredondar((atual - anterior) / anterior.abs() * 100, 1);
  }
}
