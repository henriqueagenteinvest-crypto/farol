/// =======================================================================
/// EXPORTAÇÃO PARA EXCEL (.xlsx) — DUAS ABAS
/// =======================================================================
///   Aba 1 "Painel"  -> dashboard visual estilo Power BI, com KPIs coloridos
///                      e barras feitas com fórmula REPT (barra de verdade,
///                      que se redesenha sozinha se o dado mudar).
///   Aba 2 "Dados"   -> tabela crua com TODAS as colunas e FÓRMULAS REAIS.
///
/// -----------------------------------------------------------------------
/// DETALHE TÉCNICO IMPORTANTE (muita gente erra isto):
/// dentro do ARQUIVO .xlsx as fórmulas são sempre gravadas com os nomes em
/// INGLÊS e vírgula separando os argumentos:  SUM(A1,B1)  /  IF(...)
/// O Excel em português TRADUZ na hora de exibir:  SOMA(A1;B1)  /  SE(...)
/// Por isso o código abaixo escreve SUM/AVERAGE/IF/SUMIF, e o motorista vai
/// ver SOMA/MÉDIA/SE/SOMASE na tela dele. Se gravássemos "SOMA" direto, o
/// Excel abriria a planilha com erro #NOME?.
/// -----------------------------------------------------------------------
/// PONTO SENSÍVEL À VERSÃO DO PACOTE:
/// a formatação de moeda usa `NumFormat` do pacote `excel`. Se a sua versão
/// do pacote reclamar dessa linha, o único lugar a ajustar é o método
/// [_formatoMoeda] — todo o resto do arquivo continua igual.
/// =======================================================================
library;

import 'dart:io';

import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

import '../data/models/abastecimento.dart';
import '../data/models/gasto.dart';
import '../data/models/lancamento_diario.dart';
import '../data/models/motorista.dart';
import '../domain/entities/resumo_periodo.dart';
import 'calculations_service.dart';

class ExportExcelService {
  ExportExcelService._();

  // ---------------------------------------------------------------------
  // PALETA DO RELATÓRIO (a identidade azul do Farol)
  // ---------------------------------------------------------------------
  static final ExcelColor _azulEscuro = ExcelColor.fromHexString('#FF0B2E9E');
  static final ExcelColor _azul = ExcelColor.fromHexString('#FF1F5CFF');
  static final ExcelColor _azulClaro = ExcelColor.fromHexString('#FFE8EFFF');
  static final ExcelColor _verde = ExcelColor.fromHexString('#FF12805C');
  static final ExcelColor _verdeClaro = ExcelColor.fromHexString('#FFE3F7EF');
  static final ExcelColor _vermelho = ExcelColor.fromHexString('#FFC0392B');
  static final ExcelColor _vermelhoClaro = ExcelColor.fromHexString('#FFFDEAE7');
  static final ExcelColor _cinza = ExcelColor.fromHexString('#FFF2F4F8');
  static final ExcelColor _branco = ExcelColor.fromHexString('#FFFFFFFF');
  static final ExcelColor _tinta = ExcelColor.fromHexString('#FF10233F');

  /// ---------------------------------------------------------------------
  /// FORMATOS NUMÉRICOS — ÚNICO PONTO SENSÍVEL À VERSÃO DO PACOTE `excel`
  /// ---------------------------------------------------------------------
  /// Se ao compilar aparecer erro em `NumFormat`, é SÓ este método que muda.
  /// Alternativas conhecidas, conforme a versão do pacote:
  ///
  ///   excel 4.x   ->  NumFormat.custom(formatCode: codigo)     (o atual)
  ///   variação    ->  CustomNumericNumFormat(formatCode: codigo)
  ///   emergência  ->  troque o corpo por `return NumFormat.standard_0;`
  ///                   (perde a formatação bonita, mas os NÚMEROS e as
  ///                    FÓRMULAS continuam 100% corretos)
  ///
  /// Nada mais no arquivo precisa ser tocado.
  static NumFormat _fmt(String codigo) =>
      NumFormat.custom(formatCode: codigo);

  /// R$ 1.234,56
  static NumFormat get _formatoMoeda => _fmt(r'"R$" #,##0.00');

  /// 1.234,56
  static NumFormat get _formatoDecimal => _fmt('#,##0.00');

  /// 1.234
  static NumFormat get _formatoInteiro => _fmt('#,##0');

  /// 64,4%
  static NumFormat get _formatoPercentual => _fmt('0.0%');

  // =====================================================================
  // MÉTODO PRINCIPAL
  // =====================================================================

  /// Gera o arquivo .xlsx e devolve o File pronto para compartilhar.
  static Future<File> gerar({
    required Motorista? motorista,
    required ResumoPeriodo resumo,
    required List<LancamentoDiario> lancamentos,
    required List<Gasto> gastos,
    required List<Abastecimento> abastecimentos,
  }) async {
    final excel = Excel.createExcel();

    // O pacote cria uma aba "Sheet1" que não queremos.
    final abaDados = excel['Dados'];
    final abaPainel = excel['Painel'];
    if (excel.sheets.containsKey('Sheet1')) {
      excel.delete('Sheet1');
    }
    // Deixa o Painel como a aba que abre primeiro.
    excel.setDefaultSheet('Painel');

    // A aba Dados é montada ANTES, porque o Painel aponta suas fórmulas
    // para os intervalos dela.
    final mapa = _montarAbaDados(
      abaDados,
      lancamentos: lancamentos,
      gastos: gastos,
      abastecimentos: abastecimentos,
    );

    _montarAbaPainel(
      abaPainel,
      motorista: motorista,
      resumo: resumo,
      mapa: mapa,
    );

    // ---- Salva na pasta de documentos do app ----
    final bytes = excel.save();
    if (bytes == null) {
      throw Exception('Não foi possível gerar a planilha.');
    }
    final pasta = await getApplicationDocumentsDirectory();
    final nome = 'Farol_${_nomeArquivo(resumo.rotulo)}.xlsx';
    final arquivo = File('${pasta.path}/$nome');
    await arquivo.writeAsBytes(bytes, flush: true);
    return arquivo;
  }

  static String _nomeArquivo(String rotulo) {
    final limpo = rotulo
        .replaceAll(RegExp(r'[^\w\s-]'), '')
        .replaceAll(RegExp(r'\s+'), '_');
    final carimbo = DateFormat('ddMMyyyy_HHmm').format(DateTime.now());
    return limpo.isEmpty ? carimbo : '${limpo}_$carimbo';
  }

  // =====================================================================
  // ABA 2 — DADOS BRUTOS COM FÓRMULAS REAIS
  // =====================================================================

  /// Monta a aba de dados e devolve as posições das tabelas, para o
  /// Painel conseguir montar as fórmulas apontando para os lugares certos.
  static _MapaPlanilha _montarAbaDados(
    Sheet aba, {
    required List<LancamentoDiario> lancamentos,
    required List<Gasto> gastos,
    required List<Abastecimento> abastecimentos,
  }) {
    // Ordena do mais antigo para o mais novo (leitura natural do relatório).
    final linhasLanc = List<LancamentoDiario>.from(lancamentos)
      ..sort((a, b) => a.data.compareTo(b.data));
    final linhasGastos = List<Gasto>.from(gastos)
      ..sort((a, b) => a.data.compareTo(b.data));
    final linhasAbast = List<Abastecimento>.from(abastecimentos)
      ..sort((a, b) => a.data.compareTo(b.data));

    var linha = 0;

    // ---------------- Cabeçalho da tabela de lançamentos ----------------
    _titulo(aba, linha, 'LANÇAMENTOS DIÁRIOS', colunas: 16);
    linha += 1;

    const cabecalhos = <String>[
      'Data',
      'Dia',
      'KM rodados',
      'Valor bruto',
      'Horas',
      'Corridas',
      'Km/L',
      'Preço do litro',
      'Litros',
      'Custo combustível',
      'Lucro',
      'Custo por KM',
      'Lucro por KM',
      'Ganho por hora',
      'Ticket médio',
      'Origem',
    ];
    for (var c = 0; c < cabecalhos.length; c++) {
      _celula(aba, c, linha)
        ..value = TextCellValue(cabecalhos[c])
        ..cellStyle = CellStyle(
          bold: true,
          fontSize: 11,
          fontColorHex: _branco,
          backgroundColorHex: _azulEscuro,
          horizontalAlign: HorizontalAlign.Center,
          verticalAlign: VerticalAlign.Center,
          textWrapping: TextWrapping.WrapText,
        );
    }
    final cabecalhoLanc = linha;
    linha += 1;
    final primeiraLinhaLanc = linha;

    // ---------------- Linhas de lançamento ----------------
    for (final l in linhasLanc) {
      final ex = linha + 1; // número da linha como o Excel enxerga (base 1)
      // Zebra: uma linha sim, outra não, ganha fundo cinza claro.
      final ExcelColor? z =
          (linha - primeiraLinhaLanc) % 2 == 1 ? _cinza : null;

      _texto(aba, 0, linha, DateFormat('dd/MM/yyyy').format(l.data), fundo: z);
      _texto(aba, 1, linha, _diaSemana(l.data), fundo: z);
      _numero(aba, 2, linha, l.km, _formatoDecimal, fundo: z);
      _numero(aba, 3, linha, l.valorBruto, _formatoMoeda, fundo: z);
      _numero(aba, 4, linha, l.horas, _formatoDecimal, fundo: z);
      _inteiro(aba, 5, linha, l.corridas, fundo: z);
      _numero(aba, 6, linha, l.kmPorLitro, _formatoDecimal, fundo: z);
      _numero(aba, 7, linha, l.precoLitro, _formatoMoeda, fundo: z);

      // ---- Colunas calculadas: FÓRMULAS DE VERDADE ----
      // Litros = SE(Km/L = 0; 0; KM ÷ Km/L)
      _formula(aba, 8, linha, 'IF(G$ex=0,0,C$ex/G$ex)', _formatoDecimal, fundo: z);
      // Custo do combustível = Litros × Preço do litro
      _formula(aba, 9, linha, 'I$ex*H$ex', _formatoMoeda, fundo: z);
      // Lucro = Valor bruto − Custo do combustível
      _formula(aba, 10, linha, 'D$ex-J$ex', _formatoMoeda, fundo: z);
      // Custo por KM = SE(KM = 0; 0; Custo ÷ KM)
      _formula(aba, 11, linha, 'IF(C$ex=0,0,J$ex/C$ex)', _formatoMoeda, fundo: z);
      // Lucro por KM
      _formula(aba, 12, linha, 'IF(C$ex=0,0,K$ex/C$ex)', _formatoMoeda, fundo: z);
      // Ganho por hora
      _formula(aba, 13, linha, 'IF(E$ex=0,0,K$ex/E$ex)', _formatoMoeda, fundo: z);
      // Ticket médio
      _formula(aba, 14, linha, 'IF(F$ex=0,0,D$ex/F$ex)', _formatoMoeda, fundo: z);
      _texto(aba, 15, linha, l.veioDeOcr ? 'Print' : 'Manual', fundo: z);

      linha += 1;
    }

    final ultimaLinhaLanc = linha; // primeira linha VAZIA depois da tabela
    final temLancamentos = linhasLanc.isNotEmpty;
    // Intervalo em notação do Excel (base 1).
    final iniL = primeiraLinhaLanc + 1;
    final fimL = temLancamentos ? ultimaLinhaLanc : primeiraLinhaLanc + 1;

    // ---------------- Linha de TOTAIS com SOMA e MÉDIA reais ----------
    _texto(aba, 0, linha, 'TOTAIS', negrito: true);
    _celula(aba, 0, linha).cellStyle = CellStyle(
      bold: true,
      fontColorHex: _branco,
      backgroundColorHex: _azul,
    );
    _celula(aba, 1, linha).cellStyle =
        CellStyle(backgroundColorHex: _azul);

    if (temLancamentos) {
      _formulaTotal(aba, 2, linha, 'SUM(C$iniL:C$fimL)', _formatoDecimal);
      _formulaTotal(aba, 3, linha, 'SUM(D$iniL:D$fimL)', _formatoMoeda);
      _formulaTotal(aba, 4, linha, 'SUM(E$iniL:E$fimL)', _formatoDecimal);
      _formulaTotal(aba, 5, linha, 'SUM(F$iniL:F$fimL)', _formatoInteiro);
      _formulaTotal(aba, 6, linha, 'AVERAGE(G$iniL:G$fimL)', _formatoDecimal);
      _formulaTotal(aba, 7, linha, 'AVERAGE(H$iniL:H$fimL)', _formatoMoeda);
      _formulaTotal(aba, 8, linha, 'SUM(I$iniL:I$fimL)', _formatoDecimal);
      _formulaTotal(aba, 9, linha, 'SUM(J$iniL:J$fimL)', _formatoMoeda);
      _formulaTotal(aba, 10, linha, 'SUM(K$iniL:K$fimL)', _formatoMoeda);
      final lt = linha + 1;
      _formulaTotal(aba, 11, linha, 'IF(C$lt=0,0,J$lt/C$lt)', _formatoMoeda);
      _formulaTotal(aba, 12, linha, 'IF(C$lt=0,0,K$lt/C$lt)', _formatoMoeda);
      _formulaTotal(aba, 13, linha, 'IF(E$lt=0,0,K$lt/E$lt)', _formatoMoeda);
      _formulaTotal(aba, 14, linha, 'IF(F$lt=0,0,D$lt/F$lt)', _formatoMoeda);
    }
    final linhaTotaisLanc = linha + 1; // base 1
    linha += 3; // espaço antes da próxima tabela

    // =================== TABELA DE GASTOS ===================
    _titulo(aba, linha, 'GASTOS POR CATEGORIA', colunas: 4, cor: _vermelho);
    linha += 1;
    for (final (c, t) in <(int, String)>[
      (0, 'Data'),
      (1, 'Categoria'),
      (2, 'Descrição'),
      (3, 'Valor'),
    ]) {
      _celula(aba, c, linha)
        ..value = TextCellValue(t)
        ..cellStyle = CellStyle(
          bold: true,
          fontColorHex: _branco,
          backgroundColorHex: _vermelho,
          horizontalAlign: HorizontalAlign.Center,
        );
    }
    linha += 1;
    final primeiraLinhaGasto = linha;
    for (final g in linhasGastos) {
      _texto(aba, 0, linha, DateFormat('dd/MM/yyyy').format(g.data));
      _texto(aba, 1, linha, g.categoriaValida);
      _texto(aba, 2, linha, g.descricao);
      _numero(aba, 3, linha, g.valor, _formatoMoeda);
      linha += 1;
    }
    final temGastos = linhasGastos.isNotEmpty;
    final iniG = primeiraLinhaGasto + 1;
    final fimG = temGastos ? linha : primeiraLinhaGasto + 1;

    _texto(aba, 0, linha, 'TOTAL', negrito: true);
    _celula(aba, 0, linha).cellStyle = CellStyle(
      bold: true,
      fontColorHex: _branco,
      backgroundColorHex: _vermelho,
    );
    if (temGastos) {
      _formulaTotal(aba, 3, linha, 'SUM(D$iniG:D$fimG)', _formatoMoeda);
    }
    linha += 3;

    // =================== TABELA DE ABASTECIMENTOS ===================
    _titulo(aba, linha, 'ABASTECIMENTOS', colunas: 8, cor: _verde);
    linha += 1;
    for (final (c, t) in <(int, String)>[
      (0, 'Data'),
      (1, 'Posto'),
      (2, 'Combustível'),
      (3, 'Litros'),
      (4, 'Preço do litro'),
      (5, 'Valor cheio'),
      (6, 'Desconto'),
      (7, 'Valor pago'),
    ]) {
      _celula(aba, c, linha)
        ..value = TextCellValue(t)
        ..cellStyle = CellStyle(
          bold: true,
          fontColorHex: _branco,
          backgroundColorHex: _verde,
          horizontalAlign: HorizontalAlign.Center,
          textWrapping: TextWrapping.WrapText,
        );
    }
    linha += 1;
    final primeiraLinhaAbast = linha;
    for (final a in linhasAbast) {
      final ex = linha + 1;
      _texto(aba, 0, linha, DateFormat('dd/MM/yyyy').format(a.data));
      _texto(aba, 1, linha, a.posto.isEmpty ? '—' : a.posto);
      _texto(aba, 2, linha, a.tipoCombustivel);
      _numero(aba, 3, linha, a.litros, _formatoDecimal);
      _numero(aba, 4, linha, a.precoLitro, _formatoMoeda);
      // Valor cheio = Litros × Preço
      _formula(aba, 5, linha, 'D$ex*E$ex', _formatoMoeda);
      // Desconto total (o que foi economizado)
      _numero(
        aba,
        6,
        linha,
        CalculationsService.economiaAbastecimento(a),
        _formatoMoeda,
      );
      // Valor pago = Valor cheio − Desconto
      _formula(aba, 7, linha, 'F$ex-G$ex', _formatoMoeda);
      linha += 1;
    }
    final temAbast = linhasAbast.isNotEmpty;
    final iniA = primeiraLinhaAbast + 1;
    final fimA = temAbast ? linha : primeiraLinhaAbast + 1;

    _texto(aba, 0, linha, 'TOTAL', negrito: true);
    _celula(aba, 0, linha).cellStyle = CellStyle(
      bold: true,
      fontColorHex: _branco,
      backgroundColorHex: _verde,
    );
    if (temAbast) {
      _formulaTotal(aba, 3, linha, 'SUM(D$iniA:D$fimA)', _formatoDecimal);
      _formulaTotal(aba, 6, linha, 'SUM(G$iniA:G$fimA)', _formatoMoeda);
      _formulaTotal(aba, 7, linha, 'SUM(H$iniA:H$fimA)', _formatoMoeda);
    }

    // ---------------- Larguras das colunas ----------------
    const larguras = <double>[
      12, 7, 12, 13, 8, 10, 8, 13, 10, 15, 13, 13, 13, 14, 13, 10,
    ];
    for (var c = 0; c < larguras.length; c++) {
      aba.setColumnWidth(c, larguras[c]);
    }

    return _MapaPlanilha(
      inicioLancamentos: iniL,
      fimLancamentos: fimL,
      linhaTotaisLancamentos: linhaTotaisLanc,
      temLancamentos: temLancamentos,
      inicioGastos: iniG,
      fimGastos: fimG,
      temGastos: temGastos,
      inicioAbastecimentos: iniA,
      fimAbastecimentos: fimA,
      temAbastecimentos: temAbast,
    );
  }

  // =====================================================================
  // ABA 1 — PAINEL (DASHBOARD)
  // =====================================================================

  static void _montarAbaPainel(
    Sheet aba, {
    required Motorista? motorista,
    required ResumoPeriodo resumo,
    required _MapaPlanilha mapa,
  }) {
    var linha = 0;

    // ---------------- Faixa de título ----------------
    aba.merge(
      CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: 0),
      CellIndex.indexByColumnRow(columnIndex: 7, rowIndex: 1),
    );
    _celula(aba, 0, 0)
      ..value = TextCellValue('FAROL  •  RELATÓRIO DE DESEMPENHO')
      ..cellStyle = CellStyle(
        bold: true,
        fontSize: 20,
        fontColorHex: _branco,
        backgroundColorHex: _azulEscuro,
        horizontalAlign: HorizontalAlign.Center,
        verticalAlign: VerticalAlign.Center,
      );
    // Pinta o resto da faixa mesclada.
    for (var c = 1; c <= 7; c++) {
      for (var r = 0; r <= 1; r++) {
        _celula(aba, c, r).cellStyle =
            CellStyle(backgroundColorHex: _azulEscuro);
      }
    }
    linha = 2;

    // ---------------- Identificação ----------------
    aba.merge(
      CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: linha),
      CellIndex.indexByColumnRow(columnIndex: 7, rowIndex: linha),
    );
    final nome = motorista?.nome ?? 'Motorista';
    final carro = motorista?.descricaoCarro ?? '';
    _celula(aba, 0, linha)
      ..value = TextCellValue(
        '$nome   |   $carro   |   Período: ${resumo.rotulo}   |   '
        'Emitido em ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
      )
      ..cellStyle = CellStyle(
        bold: true,
        fontSize: 10,
        fontColorHex: _tinta,
        backgroundColorHex: _azulClaro,
        horizontalAlign: HorizontalAlign.Center,
      );
    for (var c = 1; c <= 7; c++) {
      _celula(aba, c, linha).cellStyle =
          CellStyle(backgroundColorHex: _azulClaro);
    }
    linha += 2;

    // ---------------- KPIs PRINCIPAIS (blocos coloridos) --------------
    // Cada KPI ocupa 2 colunas: rótulo em cima, número grande embaixo.
    // Os valores vêm de FÓRMULA apontando para a aba Dados: se o motorista
    // corrigir um número lá, o painel se atualiza sozinho.
    final t = mapa.linhaTotaisLancamentos;
    final temL = mapa.temLancamentos;
    final somaGastos = mapa.temGastos
        ? "SUM(Dados!D${mapa.inicioGastos}:D${mapa.fimGastos})"
        : '0';

    final kpis = <_Kpi>[
      _Kpi('LUCRO LÍQUIDO', temL ? '=Dados!K$t-$somaGastos' : '=0',
          _verde, _verdeClaro, _formatoMoeda),
      _Kpi('VALOR BRUTO', temL ? '=Dados!D$t' : '=0',
          _azul, _azulClaro, _formatoMoeda),
      _Kpi('COMBUSTÍVEL', temL ? '=Dados!J$t' : '=0',
          _vermelho, _vermelhoClaro, _formatoMoeda),
      _Kpi('OUTROS GASTOS', '=$somaGastos',
          _vermelho, _vermelhoClaro, _formatoMoeda),
    ];
    _linhaDeKpis(aba, linha, kpis);
    linha += 3;

    final kpis2 = <_Kpi>[
      _Kpi('KM RODADOS', temL ? '=Dados!C$t' : '=0',
          _azulEscuro, _cinza, _formatoDecimal),
      _Kpi('HORAS TRABALHADAS', temL ? '=Dados!E$t' : '=0',
          _azulEscuro, _cinza, _formatoDecimal),
      _Kpi('CORRIDAS', temL ? '=Dados!F$t' : '=0',
          _azulEscuro, _cinza, _formatoInteiro),
      _Kpi('DIAS TRABALHADOS', '=${resumo.diasTrabalhados}',
          _azulEscuro, _cinza, _formatoInteiro),
    ];
    _linhaDeKpis(aba, linha, kpis2);
    linha += 3;

    final kpis3 = <_Kpi>[
      _Kpi('GANHO POR HORA',
          temL ? '=IF(Dados!E$t=0,0,(Dados!K$t-$somaGastos)/Dados!E$t)' : '=0',
          _verde, _verdeClaro, _formatoMoeda),
      _Kpi('CUSTO POR KM',
          temL ? '=IF(Dados!C$t=0,0,(Dados!J$t+$somaGastos)/Dados!C$t)' : '=0',
          _vermelho, _vermelhoClaro, _formatoMoeda),
      _Kpi('LUCRO POR KM',
          temL ? '=IF(Dados!C$t=0,0,(Dados!K$t-$somaGastos)/Dados!C$t)' : '=0',
          _verde, _verdeClaro, _formatoMoeda),
      _Kpi('TICKET MÉDIO',
          temL ? '=IF(Dados!F$t=0,0,Dados!D$t/Dados!F$t)' : '=0',
          _azul, _azulClaro, _formatoMoeda),
    ];
    _linhaDeKpis(aba, linha, kpis3);
    linha += 4;

    // ---------------- MARGEM DE LUCRO (com barra visual) --------------
    _titulo(aba, linha, 'MARGEM DE LUCRO', colunas: 8);
    linha += 1;
    _texto(aba, 0, linha, 'Margem sobre o valor bruto', negrito: true);
    if (temL) {
      _formula(
        aba,
        3,
        linha,
        'IF(Dados!D$t=0,0,(Dados!K$t-$somaGastos)/Dados!D$t)',
        _formatoPercentual,
      );
      // Barra visual feita com fórmula REPT: desenha um bloco a cada 5%.
      // É uma barra de verdade — muda sozinha se o dado mudar.
      _celula(aba, 4, linha)
        ..value = FormulaCellValue(
          'REPT("|",ROUND(IF(Dados!D$t=0,0,'
          '(Dados!K$t-$somaGastos)/Dados!D$t)*100/5,0))',
        )
        ..cellStyle = CellStyle(
          bold: true,
          fontColorHex: _verde,
          fontSize: 12,
        );
    }
    linha += 2;

    // ---------------- GASTOS POR CATEGORIA (com SOMASE real) ----------
    _titulo(aba, linha, 'ONDE O DINHEIRO FOI (por categoria)', colunas: 8,
        cor: _vermelho);
    linha += 1;
    for (final (c, txt) in <(int, String)>[
      (0, 'Categoria'),
      (2, 'Valor'),
      (3, 'Participação'),
      (4, 'Gráfico'),
    ]) {
      _celula(aba, c, linha)
        ..value = TextCellValue(txt)
        ..cellStyle = CellStyle(
          bold: true,
          fontColorHex: _tinta,
          backgroundColorHex: _cinza,
        );
    }
    linha += 1;

    // Mostra as categorias que realmente tiveram gasto, da maior para a menor.
    final categorias = resumo.gastosPorCategoria.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    for (final cat in categorias) {
      final ex = linha + 1;
      _texto(aba, 0, linha, cat.key);
      // SOMASE: soma na aba Dados tudo daquela categoria.
      // No Excel em português isto aparece como SOMASE(...).
      if (mapa.temGastos) {
        _formula(
          aba,
          2,
          linha,
          'SUMIF(Dados!B${mapa.inicioGastos}:B${mapa.fimGastos},'
          'A$ex,Dados!D${mapa.inicioGastos}:D${mapa.fimGastos})',
          _formatoMoeda,
        );
        _formula(
          aba,
          3,
          linha,
          'IF($somaGastos=0,0,C$ex/$somaGastos)',
          _formatoPercentual,
        );
        _celula(aba, 4, linha)
          ..value = FormulaCellValue(
            'REPT("|",ROUND(IF($somaGastos=0,0,C$ex/$somaGastos)*40,0))',
          )
          ..cellStyle = CellStyle(fontColorHex: _vermelho, bold: true);
      } else {
        _numero(aba, 2, linha, cat.value, _formatoMoeda);
      }
      linha += 1;
    }
    if (categorias.isEmpty) {
      _texto(aba, 0, linha, 'Nenhum gasto lançado neste período.');
      linha += 1;
    }
    linha += 2;

    // ---------------- RESUMO DIA A DIA ----------------
    _titulo(aba, linha, 'LUCRO DIA A DIA', colunas: 8, cor: _verde);
    linha += 1;
    for (final (c, txt) in <(int, String)>[
      (0, 'Data'),
      (2, 'Lucro do dia'),
      (3, 'Gráfico'),
    ]) {
      _celula(aba, c, linha)
        ..value = TextCellValue(txt)
        ..cellStyle = CellStyle(
          bold: true,
          fontColorHex: _tinta,
          backgroundColorHex: _cinza,
        );
    }
    linha += 1;

    // Maior lucro do período: serve de referência para o tamanho da barra.
    final maiorLucro = resumo.lucroPorDia.values.isEmpty
        ? 0.0
        : resumo.lucroPorDia.values.reduce((a, b) => a > b ? a : b);

    for (final dia in resumo.lucroPorDia.entries) {
      final ex = linha + 1;
      _texto(aba, 0, linha, DateFormat('dd/MM/yyyy').format(dia.key));
      _numero(aba, 2, linha, dia.value, _formatoMoeda);
      if (maiorLucro > 0) {
        _celula(aba, 3, linha)
          ..value = FormulaCellValue(
            'REPT("|",ROUND(MAX(C$ex,0)/$maiorLucro*30,0))',
          )
          ..cellStyle = CellStyle(fontColorHex: _verde, bold: true);
      }
      linha += 1;
    }
    if (resumo.lucroPorDia.isEmpty) {
      _texto(aba, 0, linha, 'Nenhum lançamento neste período.');
      linha += 1;
    }
    linha += 2;

    // ---------------- Rodapé ----------------
    aba.merge(
      CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: linha),
      CellIndex.indexByColumnRow(columnIndex: 7, rowIndex: linha),
    );
    _celula(aba, 0, linha)
      ..value = TextCellValue(
        'Gerado pelo aplicativo Farol  •  os números da aba Painel são '
        'fórmulas ligadas à aba Dados: corrija um valor lá e tudo se '
        'atualiza sozinho aqui.',
      )
      ..cellStyle = CellStyle(
        italic: true,
        fontSize: 9,
        fontColorHex: _tinta,
        backgroundColorHex: _cinza,
        horizontalAlign: HorizontalAlign.Center,
      );

    // ---------------- Larguras ----------------
    const larguras = <double>[22, 4, 16, 14, 30, 4, 16, 16];
    for (var c = 0; c < larguras.length; c++) {
      aba.setColumnWidth(c, larguras[c]);
    }
  }

  /// Desenha uma fileira de 4 KPIs coloridos.
  static void _linhaDeKpis(Sheet aba, int linha, List<_Kpi> kpis) {
    for (var i = 0; i < kpis.length; i++) {
      final k = kpis[i];
      final col = i * 2;
      // Rótulo
      aba.merge(
        CellIndex.indexByColumnRow(columnIndex: col, rowIndex: linha),
        CellIndex.indexByColumnRow(columnIndex: col + 1, rowIndex: linha),
      );
      _celula(aba, col, linha)
        ..value = TextCellValue(k.rotulo)
        ..cellStyle = CellStyle(
          bold: true,
          fontSize: 9,
          fontColorHex: _branco,
          backgroundColorHex: k.corForte,
          horizontalAlign: HorizontalAlign.Center,
        );
      _celula(aba, col + 1, linha).cellStyle =
          CellStyle(backgroundColorHex: k.corForte);

      // Número
      aba.merge(
        CellIndex.indexByColumnRow(columnIndex: col, rowIndex: linha + 1),
        CellIndex.indexByColumnRow(columnIndex: col + 1, rowIndex: linha + 1),
      );
      _celula(aba, col, linha + 1)
        ..value = FormulaCellValue(k.formula.replaceFirst('=', ''))
        ..cellStyle = CellStyle(
          bold: true,
          fontSize: 16,
          fontColorHex: k.corForte,
          backgroundColorHex: k.corSuave,
          horizontalAlign: HorizontalAlign.Center,
          numberFormat: k.formato,
        );
      _celula(aba, col + 1, linha + 1).cellStyle =
          CellStyle(backgroundColorHex: k.corSuave);
    }
  }

  // =====================================================================
  // ATALHOS PARA ESCREVER CÉLULAS
  // =====================================================================

  static Data _celula(Sheet aba, int coluna, int linha) => aba.cell(
        CellIndex.indexByColumnRow(columnIndex: coluna, rowIndex: linha),
      );

  static void _titulo(Sheet aba, int linha, String texto,
      {int colunas = 8, ExcelColor? cor}) {
    aba.merge(
      CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: linha),
      CellIndex.indexByColumnRow(columnIndex: colunas - 1, rowIndex: linha),
    );
    final fundo = cor ?? _azul;
    _celula(aba, 0, linha)
      ..value = TextCellValue(texto)
      ..cellStyle = CellStyle(
        bold: true,
        fontSize: 12,
        fontColorHex: _branco,
        backgroundColorHex: fundo,
        horizontalAlign: HorizontalAlign.Left,
      );
    for (var c = 1; c < colunas; c++) {
      _celula(aba, c, linha).cellStyle = CellStyle(backgroundColorHex: fundo);
    }
  }

  /// [fundo] pinta a célula — usado para o efeito "zebra" nas linhas
  /// alternadas da tabela, que facilita a leitura de listas longas.
  static void _texto(Sheet aba, int c, int l, String valor,
      {bool negrito = false, ExcelColor? fundo}) {
    _celula(aba, c, l)
      ..value = TextCellValue(valor)
      ..cellStyle = fundo == null
          ? CellStyle(bold: negrito, fontColorHex: _tinta)
          : CellStyle(
              bold: negrito,
              fontColorHex: _tinta,
              backgroundColorHex: fundo,
            );
  }

  static void _numero(Sheet aba, int c, int l, double valor, NumFormat fmt,
      {ExcelColor? fundo}) {
    _celula(aba, c, l)
      ..value = DoubleCellValue(valor)
      ..cellStyle = fundo == null
          ? CellStyle(fontColorHex: _tinta, numberFormat: fmt)
          : CellStyle(
              fontColorHex: _tinta,
              numberFormat: fmt,
              backgroundColorHex: fundo,
            );
  }

  static void _inteiro(Sheet aba, int c, int l, int valor,
      {ExcelColor? fundo}) {
    _celula(aba, c, l)
      ..value = IntCellValue(valor)
      ..cellStyle = fundo == null
          ? CellStyle(fontColorHex: _tinta, numberFormat: _formatoInteiro)
          : CellStyle(
              fontColorHex: _tinta,
              numberFormat: _formatoInteiro,
              backgroundColorHex: fundo,
            );
  }

  static void _formula(Sheet aba, int c, int l, String formula, NumFormat fmt,
      {ExcelColor? fundo}) {
    _celula(aba, c, l)
      ..value = FormulaCellValue(formula)
      ..cellStyle = fundo == null
          ? CellStyle(fontColorHex: _tinta, numberFormat: fmt)
          : CellStyle(
              fontColorHex: _tinta,
              numberFormat: fmt,
              backgroundColorHex: fundo,
            );
  }

  static void _formulaTotal(
      Sheet aba, int c, int l, String formula, NumFormat fmt) {
    _celula(aba, c, l)
      ..value = FormulaCellValue(formula)
      ..cellStyle = CellStyle(
        bold: true,
        fontColorHex: _branco,
        backgroundColorHex: _azul,
        numberFormat: fmt,
      );
  }

  static String _diaSemana(DateTime d) {
    const dias = <String>['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
    return dias[d.weekday - 1];
  }
}

/// Guarda onde cada tabela ficou na aba Dados, para o Painel montar
/// fórmulas apontando para os intervalos certos.
class _MapaPlanilha {
  final int inicioLancamentos;
  final int fimLancamentos;
  final int linhaTotaisLancamentos;
  final bool temLancamentos;
  final int inicioGastos;
  final int fimGastos;
  final bool temGastos;
  final int inicioAbastecimentos;
  final int fimAbastecimentos;
  final bool temAbastecimentos;

  const _MapaPlanilha({
    required this.inicioLancamentos,
    required this.fimLancamentos,
    required this.linhaTotaisLancamentos,
    required this.temLancamentos,
    required this.inicioGastos,
    required this.fimGastos,
    required this.temGastos,
    required this.inicioAbastecimentos,
    required this.fimAbastecimentos,
    required this.temAbastecimentos,
  });
}

/// Um cartão de indicador do painel.
class _Kpi {
  final String rotulo;
  final String formula;
  final ExcelColor corForte;
  final ExcelColor corSuave;
  final NumFormat formato;
  const _Kpi(
      this.rotulo, this.formula, this.corForte, this.corSuave, this.formato);
}
