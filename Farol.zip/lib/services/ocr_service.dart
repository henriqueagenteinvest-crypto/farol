/// =======================================================================
/// OCR SERVICE — LEITURA DO PRINT
/// =======================================================================
/// Camada de abstração em cima do Google ML Kit. Se um dia for preciso
/// trocar de motor de OCR (Tesseract, outro SDK), muda-se SÓ esta classe:
/// nenhuma tela conhece o ML Kit diretamente.
///
/// FLUXO:
///   imagem -> pré-processamento (várias versões) -> ML Kit em cada versão
///          -> OcrParser interpreta cada texto -> fica com o melhor
///          -> devolve ResultadoOcr para a TELA DE CONFIRMAÇÃO
///
/// NADA é salvo aqui. O motorista SEMPRE revisa antes.
/// =======================================================================
library;

import 'dart:io';

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

import 'image_preprocessor.dart';
import 'ocr_parser.dart';
import 'ocr_resultado.dart';

/// Interface: permite trocar o motor de OCR sem mexer nas telas.
abstract class MotorOcr {
  Future<String> lerTexto(File imagem);
  Future<void> encerrar();
}

/// Implementação com o Google ML Kit (funciona 100% no aparelho, offline).
class MotorMlKit implements MotorOcr {
  final TextRecognizer _reconhecedor =
      TextRecognizer(script: TextRecognitionScript.latin);

  @override
  Future<String> lerTexto(File imagem) async {
    final entrada = InputImage.fromFile(imagem);
    final resultado = await _reconhecedor.processImage(entrada);
    return resultado.text;
  }

  @override
  Future<void> encerrar() => _reconhecedor.close();
}

class OCRService {
  final MotorOcr _motor;
  final ImagePicker _seletor = ImagePicker();

  /// Por padrão usa o ML Kit; nos testes dá para injetar um motor falso.
  OCRService({MotorOcr? motor}) : _motor = motor ?? MotorMlKit();

  // ---------------------------------------------------------------------
  // SELEÇÃO DA IMAGEM
  // ---------------------------------------------------------------------

  /// Abre a galeria do celular para o motorista escolher o print.
  Future<File?> escolherDaGaleria() async {
    final foto = await _seletor.pickImage(
      source: ImageSource.gallery,
      imageQuality: 100, // qualidade máxima: comprimir atrapalha o OCR
    );
    return foto == null ? null : File(foto.path);
  }

  /// Abre a câmera para fotografar a tela de outro celular.
  Future<File?> tirarFoto() async {
    final foto = await _seletor.pickImage(
      source: ImageSource.camera,
      imageQuality: 100,
      preferredCameraDevice: CameraDevice.rear,
    );
    return foto == null ? null : File(foto.path);
  }

  // ---------------------------------------------------------------------
  // LEITURA
  // ---------------------------------------------------------------------

  /// Lê a imagem e devolve os dados já interpretados.
  ///
  /// Testa várias versões tratadas da imagem e fica com a melhor leitura.
  /// [aoProgredir] recebe uma mensagem a cada etapa, para a tela mostrar
  /// ao motorista o que está acontecendo ("Melhorando a imagem...").
  Future<ResultadoOcr> lerPrint(
    File imagem, {
    void Function(String etapa)? aoProgredir,
  }) async {
    List<File> versoes = <File>[imagem];
    try {
      aoProgredir?.call('Melhorando a imagem...');
      versoes = await ImagePreprocessor.gerarVersoes(imagem);

      ResultadoOcr? melhor;

      for (var i = 0; i < versoes.length; i++) {
        aoProgredir?.call('Lendo o print (${i + 1} de ${versoes.length})...');

        String texto;
        try {
          texto = await _motor.lerTexto(versoes[i]);
        } catch (_) {
          continue; // essa versão falhou; tenta a próxima
        }
        if (texto.trim().isEmpty) continue;

        final resultado = OcrParser.interpretar(texto);

        // Guarda o melhor resultado até agora.
        if (melhor == null ||
            resultado.qualidadeGeral > melhor.qualidadeGeral) {
          melhor = resultado;
        }

        // Leitura excelente e completa: não precisa testar as outras versões.
        if (resultado.qualidadeGeral >= 0.9 &&
            resultado.camposEncontrados >= 3) {
          break;
        }
      }

      if (melhor == null) {
        return ResultadoOcr.falha(
          'Não consegui ler texto nenhum nesta imagem. '
          'Tire o print direto pelo celular (em vez de fotografar a tela) '
          'ou digite os dados na mão.',
        );
      }

      aoProgredir?.call('Pronto!');
      return melhor;
    } catch (e) {
      return ResultadoOcr.falha(
        'Deu um problema ao ler a imagem. Tente novamente ou digite '
        'os dados na mão.',
      );
    } finally {
      // Limpa os arquivos temporários criados no tratamento da imagem.
      await ImagePreprocessor.limparTemporarios(versoes, imagem);
    }
  }

  /// Lê um texto que já foi extraído (usado em testes e depuração).
  ResultadoOcr interpretarTexto(String texto) =>
      OcrParser.interpretar(texto);

  /// Libera os recursos do reconhecedor. Chamar ao sair da tela de OCR.
  Future<void> encerrar() => _motor.encerrar();
}
