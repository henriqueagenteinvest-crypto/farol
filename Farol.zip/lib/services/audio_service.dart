/// =======================================================================
/// SONS E VIBRAÇÃO
/// =======================================================================
/// O app tem três tipos de retorno para o motorista:
///   • toque leve (vibração) em qualquer ação
///   • som curto de clique nos botões
///   • som de comemoração quando bate a meta
///
/// FUNCIONA SEM NENHUM ARQUIVO DE ÁUDIO: os cliques usam o som nativo do
/// sistema e a vibração é do próprio aparelho. Se você quiser um som de
/// comemoração personalizado, basta colocar o arquivo em
/// assets/sounds/comemoracao.mp3 — o app passa a usá-lo sozinho. Se o
/// arquivo não existir, ele simplesmente toca o som padrão e vibra, sem
/// travar nem mostrar erro.
///
/// Tudo respeita o interruptor "Sons" das configurações.
/// =======================================================================
library;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

/// Um som de aviso: o que aparece na tela e qual arquivo toca.
class SomDeAviso {
  final String id;
  final String rotulo;
  final String descricao;
  final String arquivo;
  const SomDeAviso({
    required this.id,
    required this.rotulo,
    required this.descricao,
    required this.arquivo,
  });
}

class AudioService {
  AudioService._();

  /// Ligado/desligado pelas configurações. O controller atualiza este valor.
  static bool sonsAtivos = true;

  /// Ligado/desligado pelas configurações (vibração acompanha as animações).
  static bool vibracaoAtiva = true;

  /// Som de aviso escolhido em Configurações: 'classico', 'suave' ou
  /// 'alerta'. O controller atualiza este valor.
  static String somDeAviso = 'classico';

  /// Os sons disponíveis, com o nome que aparece na tela e o arquivo.
  /// São arquivos .wav curtos que já vêm dentro do aplicativo — tocam
  /// sem internet e sem download nenhum.
  static const Map<String, SomDeAviso> sonsDisponiveis = <String, SomDeAviso>{
    'classico': SomDeAviso(
      id: 'classico',
      rotulo: 'Clássico',
      descricao: 'Dois toques curtos, como um sino',
      arquivo: 'sounds/aviso_classico.wav',
    ),
    'suave': SomDeAviso(
      id: 'suave',
      rotulo: 'Suave',
      descricao: 'Um toque macio, que não assusta',
      arquivo: 'sounds/aviso_suave.wav',
    ),
    'alerta': SomDeAviso(
      id: 'alerta',
      rotulo: 'Alerta',
      descricao: 'Mais firme, para não passar despercebido',
      arquivo: 'sounds/aviso_alerta.wav',
    ),
  };

  /// A lista, na ordem em que aparece na tela de Configurações.
  static List<SomDeAviso> get listaDeSons =>
      const <String>['classico', 'suave', 'alerta']
          .map((id) => sonsDisponiveis[id]!)
          .toList();

  static final AudioPlayer _tocador = AudioPlayer();

  /// Guarda se o arquivo de comemoração existe, para não tentar de novo.
  static bool _comemoracaoIndisponivel = false;

  /// Arquivos de áudio que falharam ao tocar. Não se tenta de novo:
  /// o app cai para o som do sistema e segue em frente.
  static final Set<String> _arquivosRuins = <String>{};

  /// Toca um arquivo de áudio de dentro do app.
  /// Nunca estoura erro: na falha, usa o som nativo do celular.
  static Future<void> _tocarArquivo(String caminho) async {
    if (_arquivosRuins.contains(caminho)) {
      SystemSound.play(SystemSoundType.alert);
      return;
    }
    try {
      await _tocador.stop();
      await _tocador.play(AssetSource(caminho));
    } catch (_) {
      _arquivosRuins.add(caminho);
      SystemSound.play(SystemSoundType.alert);
    }
  }

  /// Toca o som de aviso escolhido pelo motorista.
  /// Passe [som] para ouvir uma amostra de outro som sem trocar o padrão.
  static Future<void> tocarAviso([String? som]) async {
    if (vibracaoAtiva) HapticFeedback.mediumImpact();
    if (!sonsAtivos) return;
    final escolhido = sonsDisponiveis[som ?? somDeAviso] ??
        sonsDisponiveis['classico']!;
    await _tocarArquivo(escolhido.arquivo);
  }

  // ---------------------------------------------------------------------
  // TOQUES DO DIA A DIA
  // ---------------------------------------------------------------------

  /// Toque leve: usado ao trocar de aba, marcar opção, abrir tela.
  static void toqueLeve() {
    if (!vibracaoAtiva) return;
    HapticFeedback.lightImpact();
  }

  /// Toque médio: botão importante (salvar, iniciar jornada).
  static void toqueMedio() {
    if (!vibracaoAtiva) return;
    HapticFeedback.mediumImpact();
  }

  /// Som + vibração de clique de botão.
  static void clique() {
    if (vibracaoAtiva) HapticFeedback.selectionClick();
    if (!sonsAtivos) return;
    // Som nativo do sistema: não precisa de arquivo e funciona offline.
    SystemSound.play(SystemSoundType.click);
  }

  /// Confirmação de algo salvo com sucesso.
  static void sucesso() {
    if (vibracaoAtiva) HapticFeedback.mediumImpact();
    if (!sonsAtivos) return;
    _tocarArquivo('sounds/sucesso.wav');
  }

  /// Aviso de erro de preenchimento.
  static void erro() {
    if (vibracaoAtiva) HapticFeedback.heavyImpact();
    if (!sonsAtivos) return;
    SystemSound.play(SystemSoundType.alert);
  }

  /// Notificação (lembrete, aviso). Usa o som escolhido em Configurações.
  static void notificacao() {
    // Não se espera o áudio: a tela não pode travar por causa de um som.
    tocarAviso();
  }

  // ---------------------------------------------------------------------
  // COMEMORAÇÃO DE META BATIDA
  // ---------------------------------------------------------------------

  /// Toca a comemoração e faz uma sequência de vibrações de festa.
  ///
  /// Tenta o arquivo assets/sounds/comemoracao.mp3. Se não existir,
  /// cai para o som do sistema — o app nunca quebra por falta de áudio.
  static Future<void> comemorar() async {
    // Sequência de vibrações: dá a sensação de "conquista".
    if (vibracaoAtiva) {
      HapticFeedback.heavyImpact();
      await Future<void>.delayed(const Duration(milliseconds: 110));
      HapticFeedback.mediumImpact();
      await Future<void>.delayed(const Duration(milliseconds: 110));
      HapticFeedback.heavyImpact();
    }
    if (!sonsAtivos) return;

    if (_comemoracaoIndisponivel) {
      await _tocarArquivo('sounds/sucesso.wav');
      return;
    }
    try {
      await _tocador.play(AssetSource('sounds/comemoracao.mp3'));
    } catch (_) {
      // Arquivo opcional não existe: usa o som de sucesso que vem no app
      // e nunca mais tenta abrir o mp3 (economiza processamento).
      _comemoracaoIndisponivel = true;
      await _tocarArquivo('sounds/sucesso.wav');
    }
  }

  /// Libera o tocador de áudio (chamado ao encerrar o app).
  static Future<void> encerrar() async {
    try {
      await _tocador.dispose();
    } catch (_) {
      // Sem problema: o sistema libera sozinho.
    }
  }
}
