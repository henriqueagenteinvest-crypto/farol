/// =======================================================================
/// SONS E VIBRAÇÃO
/// =======================================================================
/// O app tem três tipos de retorno para o motorista:
///   • toque leve (vibração) em qualquer ação
///   • som curto de clique nos botões
///   • som de comemoração quando bate a meta
///
/// FUNCIONA SEM NENHUM ARQUIVO DE ÁUDIO: os cliques usam o som nativo do
/// sistema e a vibração é do próprio aparelho. Se você quiser um som de
/// comemoração personalizado, basta colocar o arquivo em
/// assets/sounds/comemoracao.mp3 — o app passa a usá-lo sozinho. Se o
/// arquivo não existir, ele simplesmente toca o som padrão e vibra, sem
/// travar nem mostrar erro.
///
/// Tudo respeita o interruptor "Sons" das configurações.
/// =======================================================================
library;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

class AudioService {
  AudioService._();

  /// Ligado/desligado pelas configurações. O controller atualiza este valor.
  static bool sonsAtivos = true;

  /// Ligado/desligado pelas configurações (vibração acompanha as animações).
  static bool vibracaoAtiva = true;

  static final AudioPlayer _tocador = AudioPlayer();

  /// Guarda se o arquivo de comemoração existe, para não tentar de novo.
  static bool _comemoracaoIndisponivel = false;

  // ---------------------------------------------------------------------
  // TOQUES DO DIA A DIA
  // ---------------------------------------------------------------------

  /// Toque leve: usado ao trocar de aba, marcar opção, abrir tela.
  static void toqueLeve() {
    if (!vibracaoAtiva) return;
    HapticFeedback.lightImpact();
  }

  /// Toque médio: botão importante (salvar, iniciar jornada).
  static void toqueMedio() {
    if (!vibracaoAtiva) return;
    HapticFeedback.mediumImpact();
  }

  /// Som + vibração de clique de botão.
  static void clique() {
    if (vibracaoAtiva) HapticFeedback.selectionClick();
    if (!sonsAtivos) return;
    // Som nativo do sistema: não precisa de arquivo e funciona offline.
    SystemSound.play(SystemSoundType.click);
  }

  /// Confirmação de algo salvo com sucesso.
  static void sucesso() {
    if (vibracaoAtiva) HapticFeedback.mediumImpact();
    if (!sonsAtivos) return;
    SystemSound.play(SystemSoundType.click);
  }

  /// Aviso de erro de preenchimento.
  static void erro() {
    if (vibracaoAtiva) HapticFeedback.heavyImpact();
    if (!sonsAtivos) return;
    SystemSound.play(SystemSoundType.alert);
  }

  /// Notificação (fim de jornada, lembrete).
  static void notificacao() {
    if (vibracaoAtiva) HapticFeedback.mediumImpact();
    if (!sonsAtivos) return;
    SystemSound.play(SystemSoundType.alert);
  }

  // ---------------------------------------------------------------------
  // COMEMORAÇÃO DE META BATIDA
  // ---------------------------------------------------------------------

  /// Toca a comemoração e faz uma sequência de vibrações de festa.
  ///
  /// Tenta o arquivo assets/sounds/comemoracao.mp3. Se não existir,
  /// cai para o som do sistema — o app nunca quebra por falta de áudio.
  static Future<void> comemorar() async {
    // Sequência de vibrações: dá a sensação de "conquista".
    if (vibracaoAtiva) {
      HapticFeedback.heavyImpact();
      await Future<void>.delayed(const Duration(milliseconds: 110));
      HapticFeedback.mediumImpact();
      await Future<void>.delayed(const Duration(milliseconds: 110));
      HapticFeedback.heavyImpact();
    }
    if (!sonsAtivos) return;

    if (_comemoracaoIndisponivel) {
      SystemSound.play(SystemSoundType.alert);
      return;
    }
    try {
      await _tocador.play(AssetSource('sounds/comemoracao.mp3'));
    } catch (_) {
      // Arquivo não existe neste projeto: usa o som do sistema e nunca
      // mais tenta abrir o arquivo (economiza processamento).
      _comemoracaoIndisponivel = true;
      SystemSound.play(SystemSoundType.alert);
    }
  }

  /// Libera o tocador de áudio (chamado ao encerrar o app).
  static Future<void> encerrar() async {
    try {
      await _tocador.dispose();
    } catch (_) {
      // Sem problema: o sistema libera sozinho.
    }
  }
}
