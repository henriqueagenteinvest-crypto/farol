/// -----------------------------------------------------------------------
/// ÍCONES E CORES DE CADA UMA DAS 12 CATEGORIAS DE GASTO
/// -----------------------------------------------------------------------
/// Mantém a identidade visual consistente: a categoria "Pneu" sempre terá
/// o mesmo ícone e a mesma cor em qualquer tela do app.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

class CategoriaVisual {
  final IconData icone;
  final Color cor;
  const CategoriaVisual(this.icone, this.cor);
}

class AppIcons {
  AppIcons._();

  /// Mapa: nome da categoria -> ícone + cor.
  static const Map<String, CategoriaVisual> categorias =
      <String, CategoriaVisual>{
    'Manutenção': CategoriaVisual(Icons.build_rounded, Color(0xFFFF8A3D)),
    'Pneu': CategoriaVisual(Icons.trip_origin_rounded, Color(0xFF8E9AAF)),
    'Seguro': CategoriaVisual(Icons.shield_rounded, Color(0xFF2E9E6B)),
    'IPVA': CategoriaVisual(Icons.account_balance_rounded, Color(0xFFD64550)),
    'Licenciamento':
        CategoriaVisual(Icons.assignment_turned_in_rounded, Color(0xFF6C63FF)),
    'Financiamento': CategoriaVisual(Icons.savings_rounded, Color(0xFFB44FC4)),
    'Pedágio': CategoriaVisual(Icons.toll_rounded, Color(0xFF00A6B8)),
    'Lavagem': CategoriaVisual(Icons.local_car_wash_rounded, Color(0xFF3D9BFF)),
    'Estacionamento':
        CategoriaVisual(Icons.local_parking_rounded, Color(0xFF4C6EF5)),
    'Alimentação': CategoriaVisual(Icons.restaurant_rounded, Color(0xFFE8A33D)),
    'Internet': CategoriaVisual(Icons.wifi_rounded, Color(0xFF17B978)),
    'Acessórios': CategoriaVisual(Icons.headset_rounded, Color(0xFFEC6A9B)),
  };

  /// Busca segura: se a categoria não existir, devolve um visual neutro.
  static CategoriaVisual porCategoria(String nome) {
    return categorias[nome] ??
        const CategoriaVisual(Icons.receipt_long_rounded, Color(0xFF8E9AAF));
  }
}
