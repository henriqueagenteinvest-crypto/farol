/// -----------------------------------------------------------------------
/// CONSTANTES GLOBAIS DO APLICATIVO FAROL
/// -----------------------------------------------------------------------
/// Aqui ficam todos os valores fixos usados em várias partes do app.
/// Centralizar evita "número mágico" espalhado pelo código.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart' show IconData, Icons;

class AppConstants {
  AppConstants._(); // construtor privado: classe só de constantes

  /// Nome exibido do aplicativo
  static const String nomeApp = 'Farol';
  static const String slogan = 'Sua jornada com clareza';
  static const String versao = '1.0.0';

  // ---------------------------------------------------------------------
  // VALORES PADRÃO (podem ser alterados pelo motorista nas configurações)
  // ---------------------------------------------------------------------

  /// Consumo padrão do veículo em quilômetros por litro.
  static const double kmPorLitroPadrao = 12.0;

  /// Preço padrão do litro (só sugestão inicial; o motorista sempre edita).
  static const double precoLitroPadrao = 6.19;

  /// Margem de lucro mínima desejada (30%) usada na avaliação de corridas.
  static const double margemLucroAlvoPadrao = 30.0;

  /// Meta diária de lucro sugerida (o motorista define a dele).
  static const double metaDiariaPadrao = 250.0;

  // ---------------------------------------------------------------------
  // TIPOS DE COMBUSTÍVEL
  // ---------------------------------------------------------------------
  static const String combustivelGasolina = 'Gasolina';
  static const String combustivelAlcool = 'Álcool';
  static const String combustivelGnv = 'GNV';
  static const String combustivelEletrico = 'Elétrico';

  static const List<String> tiposCombustivel = <String>[
    combustivelGasolina,
    combustivelAlcool,
    combustivelGnv,
    combustivelEletrico,
  ];

  /// A unidade em que cada combustível é vendido.
  ///
  /// A CONTA É A MESMA para todos: rendimento (quanto anda com uma
  /// unidade) e preço da unidade. Só muda o NOME da unidade na tela —
  /// litro para gasolina e álcool, metro cúbico para GNV, kWh para
  /// elétrico. Nenhuma fórmula precisou mudar por causa disso.
  static String unidadeDe(String combustivel) {
    switch (combustivel) {
      case combustivelGnv:
        return 'm³';
      case combustivelEletrico:
        return 'kWh';
      default:
        return 'L';
    }
  }

  /// "km/L", "km/m³" ou "km/kWh".
  static String rendimentoDe(String combustivel) =>
      'km/${unidadeDe(combustivel)}';

  /// "Preço do litro", "Preço do m³", "Preço do kWh".
  static String precoDe(String combustivel) {
    switch (combustivel) {
      case combustivelGnv:
        return 'Preço do m³';
      case combustivelEletrico:
        return 'Preço do kWh';
      default:
        return 'Preço do litro';
    }
  }

  /// Como se chama o rendimento do veículo na tela.
  ///
  /// Quem roda a gasolina, álcool ou GNV chama de CONSUMO.
  /// Quem tem carro ou bicicleta elétrica chama de AUTONOMIA — é a
  /// palavra que o motorista de elétrico usa de verdade: quantos
  /// quilômetros ele anda com 1 kWh de carga.
  static String consumoDe(String combustivel) =>
      combustivel == combustivelEletrico ? 'Autonomia' : 'Consumo';

  /// A explicação que aparece embaixo do campo de rendimento.
  static String ajudaConsumoDe(String combustivel) {
    switch (combustivel) {
      case combustivelEletrico:
        return 'Quantos quilômetros o veículo anda com 1 kWh de carga. '
            'Carro elétrico costuma fazer de 5 a 7 km/kWh; '
            'bicicleta elétrica, bem mais.';
      case combustivelGnv:
        return 'Quantos quilômetros o carro anda com 1 m³ de gás. '
            'Se não souber, use 14.';
      default:
        return 'Quantos quilômetros o veículo anda com 1 litro. '
            'Se não souber, use 12.';
    }
  }

  /// O "combustível" é energia elétrica? Muda só ícones e títulos.
  static bool eletrico(String combustivel) =>
      combustivel == combustivelEletrico;

  /// Título da seção na tela de lançamento.
  static String tituloEnergiaDe(String combustivel) {
    switch (combustivel) {
      case combustivelEletrico:
        return 'Recarga e energia';
      case combustivelGnv:
        return 'Gás natural (GNV)';
      default:
        return 'Combustível';
    }
  }

  /// Ícone que combina com cada tipo de veículo.
  static IconData iconeVeiculo(String tipo) {
    switch (tipo) {
      case veiculoMoto:
        return Icons.two_wheeler_rounded;
      case veiculoBicicleta:
        return Icons.pedal_bike_rounded;
      default:
        return Icons.directions_car_rounded;
    }
  }

  // ---------------------------------------------------------------------
  // TIPOS DE VEÍCULO
  // ---------------------------------------------------------------------
  static const String veiculoCarro = 'Carro';
  static const String veiculoMoto = 'Moto';
  static const String veiculoBicicleta = 'Bicicleta elétrica';

  static const List<String> tiposVeiculo = <String>[
    veiculoCarro,
    veiculoMoto,
    veiculoBicicleta,
  ];

  // ---------------------------------------------------------------------
  // FORMAS DE PAGAMENTO DO ABASTECIMENTO
  // ---------------------------------------------------------------------
  static const List<String> formasPagamento = <String>[
    'Pix',
    'App do posto',
    'Dinheiro',
    'Cartão',
  ];

  // ---------------------------------------------------------------------
  // MOTIVOS DE PAUSA DA JORNADA
  // ---------------------------------------------------------------------
  static const List<String> motivosPausa = <String>[
    'Banheiro',
    'Café',
    'Almoço',
    'Descanso',
    'Abastecer',
    'Outro',
  ];

  // ---------------------------------------------------------------------
  // AS 12 CATEGORIAS FIXAS DE GASTO (não podem ser alteradas)
  // ---------------------------------------------------------------------
  /// As categorias que o motorista pode ESCOLHER ao lançar um gasto.
  ///
  /// Manutenção e Pedágio saíram desta lista a pedido dele.
  static const List<String> categoriasGasto = <String>[
    'Pneu',
    'Seguro',
    'IPVA',
    'Licenciamento',
    'Financiamento',
    'Lavagem',
    'Estacionamento',
    'Alimentação',
    'Internet',
    'Acessórios',
  ];

  /// TODAS as categorias que o aplicativo sabe ler, inclusive as que não
  /// aparecem mais para escolher.
  ///
  /// POR QUE ISTO EXISTE: quem já lançou um gasto de Manutenção ou
  /// Pedágio antes continua com esse valor somando certo nos relatórios.
  /// Tirar da lista de escolha é uma coisa; apagar o histórico do
  /// motorista seria outra bem diferente — e nunca é o que se faz.
  static const List<String> categoriasGastoHistoricas = <String>[
    ...categoriasGasto,
    'Manutenção',
    'Pedágio',
  ];

  // ---------------------------------------------------------------------
  // LIMITES DE SEGURANÇA PARA VALIDAÇÃO DE ENTRADA
  // ---------------------------------------------------------------------
  static const double kmMaximoPorDia = 2000.0;
  static const double horasMaximoPorDia = 24.0;
  static const int corridasMaximoPorDia = 500;
  static const double valorMaximoLancamento = 100000.0;
}
