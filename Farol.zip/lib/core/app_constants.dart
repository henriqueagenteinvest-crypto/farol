/// -----------------------------------------------------------------------
/// CONSTANTES GLOBAIS DO APLICATIVO FAROL
/// -----------------------------------------------------------------------
/// Aqui ficam todos os valores fixos usados em várias partes do app.
/// Centralizar evita "número mágico" espalhado pelo código.
/// -----------------------------------------------------------------------
library;

class AppConstants {
  AppConstants._(); // construtor privado: classe só de constantes

  /// Nome exibido do aplicativo
  static const String nomeApp = 'Farol';
  static const String slogan = 'Sua jornada com clareza';
  static const String versao = '1.0.0';

  // ---------------------------------------------------------------------
  // VALORES PADRÃO (podem ser alterados pelo motorista nas configurações)
  // ---------------------------------------------------------------------

  /// Consumo padrão do veículo em quilômetros por litro.
  static const double kmPorLitroPadrao = 12.0;

  /// Preço padrão do litro (só sugestão inicial; o motorista sempre edita).
  static const double precoLitroPadrao = 6.19;

  /// Margem de lucro mínima desejada (30%) usada na avaliação de corridas.
  static const double margemLucroAlvoPadrao = 30.0;

  /// Meta diária de lucro sugerida (o motorista define a dele).
  static const double metaDiariaPadrao = 250.0;

  // ---------------------------------------------------------------------
  // TIPOS DE COMBUSTÍVEL
  // ---------------------------------------------------------------------
  static const String combustivelGasolina = 'Gasolina';
  static const String combustivelAlcool = 'Álcool';
  static const List<String> tiposCombustivel = <String>[
    combustivelGasolina,
    combustivelAlcool,
  ];

  // ---------------------------------------------------------------------
  // FORMAS DE PAGAMENTO DO ABASTECIMENTO
  // ---------------------------------------------------------------------
  static const List<String> formasPagamento = <String>[
    'Pix',
    'App do posto',
    'Dinheiro',
    'Cartão',
  ];

  // ---------------------------------------------------------------------
  // MOTIVOS DE PAUSA DA JORNADA
  // ---------------------------------------------------------------------
  static const List<String> motivosPausa = <String>[
    'Banheiro',
    'Café',
    'Almoço',
    'Descanso',
    'Abastecer',
    'Outro',
  ];

  // ---------------------------------------------------------------------
  // AS 12 CATEGORIAS FIXAS DE GASTO (não podem ser alteradas)
  // ---------------------------------------------------------------------
  static const List<String> categoriasGasto = <String>[
    'Manutenção',
    'Pneu',
    'Seguro',
    'IPVA',
    'Licenciamento',
    'Financiamento',
    'Pedágio',
    'Lavagem',
    'Estacionamento',
    'Alimentação',
    'Internet',
    'Acessórios',
  ];

  // ---------------------------------------------------------------------
  // LIMITES DE SEGURANÇA PARA VALIDAÇÃO DE ENTRADA
  // ---------------------------------------------------------------------
  static const double kmMaximoPorDia = 2000.0;
  static const double horasMaximoPorDia = 24.0;
  static const int corridasMaximoPorDia = 500;
  static const double valorMaximoLancamento = 100000.0;
}
