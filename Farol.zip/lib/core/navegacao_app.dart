/// -----------------------------------------------------------------------
/// NAVEGAÇÃO ENTRE AS ABAS
/// -----------------------------------------------------------------------
/// Permite que qualquer tela peça para trocar de aba sem precisar passar
/// funções de mão em mão pelo app inteiro.
/// Ex.: depois de salvar um lançamento, a tela pede para voltar à Semana.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/foundation.dart';

class NavegacaoApp {
  NavegacaoApp._();

  /// As três abas do aplicativo (o botão do meio abre o lançamento e
  /// não conta como aba).
  static const int abaSemana = 0;
  static const int abaPainel = 1;
  static const int abaMais = 2;

  /// Nomes antigos, mantidos para não quebrar chamadas existentes.
  static const int abaHoje = abaSemana;
  static const int abaInicio = abaSemana;
  static const int abaRelatorios = abaPainel;

  /// A aba que está aberta agora. A estrutura principal fica ouvindo.
  static final ValueNotifier<int> abaAtual = ValueNotifier<int>(abaSemana);

  static void irPara(int aba) => abaAtual.value = aba;
}
