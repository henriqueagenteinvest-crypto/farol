/// -----------------------------------------------------------------------
/// NAVEGAÇÃO ENTRE AS ABAS
/// -----------------------------------------------------------------------
/// Permite que qualquer tela peça para trocar de aba sem precisar passar
/// funções de mão em mão pelo app inteiro.
/// Ex.: o botão "Continuar jornada" da tela inicial leva o motorista
/// direto para a aba Jornada.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/foundation.dart';

class NavegacaoApp {
  NavegacaoApp._();

  static const int abaHoje = 0;
  static const int abaPainel = 1;
  static const int abaJornada = 2;
  static const int abaMais = 3;

  /// Nomes antigos, mantidos para não quebrar chamadas existentes.
  static const int abaInicio = abaHoje;
  static const int abaRelatorios = abaPainel;

  /// A aba que está aberta agora. A estrutura principal fica ouvindo.
  static final ValueNotifier<int> abaAtual = ValueNotifier<int>(abaHoje);

  static void irPara(int aba) => abaAtual.value = aba;
}
