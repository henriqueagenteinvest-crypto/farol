/// -----------------------------------------------------------------------
/// ROTAS DO APLICATIVO
/// -----------------------------------------------------------------------
/// Todas as telas ficam registradas aqui, com transições animadas.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../presentation/screens/abastecimento_screen.dart';
import '../presentation/screens/bem_vindo_screen.dart';
import '../presentation/screens/configuracoes_screen.dart';
import '../presentation/screens/diagnostico_screen.dart';
import '../presentation/screens/exportar_screen.dart';
import '../presentation/screens/gastos_screen.dart';
import '../presentation/screens/lancamento_screen.dart';
import '../presentation/screens/login_screen.dart';
import '../presentation/screens/shell_principal.dart';
import '../presentation/screens/aparencia_screen.dart';
import '../presentation/screens/pontos_screen.dart';

class AppRoutes {
  AppRoutes._();

  static const String login = '/login';
  static const String principal = '/principal';
  static const String lancamento = '/lancamento';
  static const String abastecimento = '/abastecimento';
  static const String gastos = '/gastos';
  static const String exportar = '/exportar';
  static const String configuracoes = '/configuracoes';
  static const String aparencia = '/aparencia';
  static const String pontos = '/pontos';
  static const String diagnostico = '/diagnostico';
  static const String bemVindo = '/bem-vindo';

  static Route<dynamic>? gerar(RouteSettings config) {
    switch (config.name) {
      case login:
        return _transicao(const LoginScreen(), config);
      case principal:
        return _transicao(const ShellPrincipal(), config);
      case lancamento:
        // Pode receber um lançamento existente (edição) ou o dia
        // escolhido no painel da semana.
        return _transicao(
          LancamentoScreen(argumentos: config.arguments as ArgsLancamento?),
          config,
        );
      case abastecimento:
        return _transicao(const AbastecimentoScreen(), config);
      case gastos:
        return _transicao(const GastosScreen(), config);
      case exportar:
        return _transicao(const ExportarScreen(), config);
      case configuracoes:
        return _transicao(const ConfiguracoesScreen(), config);
      case aparencia:
        return _transicao(const AparenciaScreen(), config);
      case pontos:
        return _transicao(const PontosScreen(), config);
      case diagnostico:
        return _transicao(const DiagnosticoScreen(), config);
      case bemVindo:
        return _transicao(const BemVindoScreen(), config);
      default:
        return null;
    }
  }

  /// Transição padrão: a tela entra deslizando de baixo com um leve fade.
  /// É suave e barata em processamento (roda liso em celular simples).
  static PageRouteBuilder<dynamic> _transicao(
    Widget tela,
    RouteSettings config,
  ) {
    return PageRouteBuilder<dynamic>(
      settings: config,
      transitionDuration: const Duration(milliseconds: 280),
      reverseTransitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (_, __, ___) => tela,
      transitionsBuilder: (context, animacao, _, filho) {
        final curva = CurvedAnimation(
          parent: animacao,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return FadeTransition(
          opacity: curva,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.035),
              end: Offset.zero,
            ).animate(curva),
            child: filho,
          ),
        );
      },
    );
  }
}
