/// -----------------------------------------------------------------------
/// NOMES DAS "CAIXAS" (BOXES) DO HIVE
/// -----------------------------------------------------------------------
/// O Hive guarda os dados em caixas. Cada caixa é como uma tabela.
/// Todos os dados ficam SOMENTE no celular do motorista.
/// -----------------------------------------------------------------------
library;

class HiveBoxes {
  HiveBoxes._();

  static const String motorista = 'box_motorista';
  static const String lancamentos = 'box_lancamentos';
  static const String abastecimentos = 'box_abastecimentos';
  static const String gastos = 'box_gastos';
  static const String jornadas = 'box_jornadas';
  static const String configuracoes = 'box_configuracoes';

  /// Identificadores (typeId) de cada modelo registrado no Hive.
  /// NUNCA mude esses números depois de o app estar publicado,
  /// senão os dados já salvos deixam de ser lidos.
  static const int typeMotorista = 1;
  static const int typeLancamento = 2;
  static const int typeAbastecimento = 3;
  static const int typeGasto = 4;
  static const int typeJornada = 5;
  static const int typePausa = 6;
  static const int typeConfiguracoes = 7;
}
