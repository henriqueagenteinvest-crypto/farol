/// =======================================================================
/// APP CONTROLLER — estado geral do aplicativo
/// =======================================================================
/// Cuida do cadastro do motorista e das configurações (tema, metas, sons,
/// animações). Quando algo muda aqui, o app inteiro se redesenha.
/// =======================================================================
library;

import 'package:flutter/material.dart';

import '../../data/local_database.dart';
import '../../data/models/configuracoes.dart';
import '../../data/models/motorista.dart';
import '../../data/repositories/configuracoes_repository.dart';
import '../../data/repositories/motorista_repository.dart';
import '../../services/audio_service.dart';
import '../../theme/catalogo_temas.dart';
import '../../theme/tema_farol.dart';

class AppController extends ChangeNotifier {
  final MotoristaRepository _motoristaRepo = MotoristaRepository();
  final ConfiguracoesRepository _configRepo = ConfiguracoesRepository();

  Motorista? _motorista;
  Configuracoes _config = Configuracoes();

  Motorista? get motorista => _motorista;
  Configuracoes get config => _config;

  /// Já existe motorista cadastrado? Decide entre login e tela inicial.
  bool get temCadastro => _motorista != null;

  /// O tema escolhido, pronto para uso.
  TemaFarol get tema => CatalogoTemas.porId(_config.temaId);

  bool get animacoesAtivas => _config.animacoesAtivas;
  bool get sonsAtivos => _config.sonsAtivos;

  /// Duração de animação que respeita o interruptor das configurações.
  /// Com animações desligadas, tudo acontece instantaneamente.
  Duration duracao(int milissegundos) => _config.animacoesAtivas
      ? Duration(milliseconds: milissegundos)
      : Duration.zero;

  /// Carrega tudo do Hive. Chamado uma vez, na abertura do app.
  Future<void> carregar() async {
    _motorista = _motoristaRepo.obter();
    _config = _configRepo.obter();
    _sincronizarAudio();
    notifyListeners();
  }

  /// Mantém o serviço de som alinhado com as configurações.
  void _sincronizarAudio() {
    AudioService.sonsAtivos = _config.sonsAtivos;
    AudioService.vibracaoAtiva = _config.animacoesAtivas;
  }

  // ---------------------------------------------------------------------
  // MOTORISTA
  // ---------------------------------------------------------------------

  Future<void> salvarMotorista(Motorista m) async {
    await _motoristaRepo.salvar(m);
    _motorista = m;
    // A primeira gravação encerra o "primeiro uso".
    if (_config.primeiroUso) {
      _config = _config.copiarCom(primeiroUso: false);
      await _configRepo.salvar(_config);
    }
    notifyListeners();
  }

  /// Saudação que muda conforme o horário do celular.
  String get saudacao {
    final h = DateTime.now().hour;
    if (h >= 5 && h < 12) return 'Bom dia';
    if (h >= 12 && h < 18) return 'Boa tarde';
    return 'Boa noite';
  }

  /// "Boa tarde, Henrique" — ou só a saudação se não houver cadastro.
  String get saudacaoCompleta {
    final nome = _motorista?.primeiroNome;
    return nome == null || nome.isEmpty ? saudacao : '$saudacao, $nome';
  }

  // ---------------------------------------------------------------------
  // CONFIGURAÇÕES
  // ---------------------------------------------------------------------

  Future<void> salvarConfig(Configuracoes nova) async {
    _config = nova;
    await _configRepo.salvar(_config);
    _sincronizarAudio();
    notifyListeners();
  }

  /// Troca o tema e aplica na hora, sem reiniciar o app.
  Future<void> trocarTema(String temaId) async {
    await salvarConfig(_config.copiarCom(temaId: temaId));
  }

  Future<void> alternarAnimacoes(bool ligado) async {
    await salvarConfig(_config.copiarCom(animacoesAtivas: ligado));
  }

  Future<void> alternarSons(bool ligado) async {
    await salvarConfig(_config.copiarCom(sonsAtivos: ligado));
  }

  Future<void> salvarMetas({
    double? diaria,
    double? semanal,
    double? mensal,
  }) async {
    await salvarConfig(_config.copiarCom(
      metaDiaria: diaria,
      metaSemanal: semanal,
      metaMensal: mensal,
    ));
  }

  Future<void> salvarPadroesVeiculo({
    double? kmPorLitro,
    double? precoLitro,
    String? combustivel,
    double? custosFixos,
    double? margemAlvo,
  }) async {
    await salvarConfig(_config.copiarCom(
      kmPorLitroPadrao: kmPorLitro,
      precoLitroPadrao: precoLitro,
      combustivelPadrao: combustivel,
      custosFixosMensais: custosFixos,
      margemLucroAlvo: margemAlvo,
    ));
  }

  /// Marca que a comemoração de meta já rolou hoje (evita repetir a
  /// animação de confete toda vez que o motorista volta para a tela).
  Future<void> registrarComemoracao() async {
    await salvarConfig(_config.copiarCom(ultimaComemoracao: DateTime.now()));
  }

  /// Já comemorou hoje?
  bool get jaComemorouHoje {
    final u = _config.ultimaComemoracao;
    if (u == null) return false;
    final hoje = DateTime.now();
    return u.year == hoje.year && u.month == hoje.month && u.day == hoje.day;
  }

  // ---------------------------------------------------------------------
  // GERENCIAR DADOS
  // ---------------------------------------------------------------------

  /// Apaga lançamentos, gastos, abastecimentos e jornadas.
  /// Mantém o cadastro e as preferências.
  Future<void> limparMovimentacoes() async {
    await LocalDatabase.limparMovimentacoes();
    notifyListeners();
  }

  /// Apaga absolutamente tudo (volta ao estado de app recém-instalado).
  Future<void> apagarTudo() async {
    await LocalDatabase.apagarTudo();
    _motorista = null;
    _config = Configuracoes();
    _sincronizarAudio();
    notifyListeners();
  }
}
