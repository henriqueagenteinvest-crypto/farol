/// =======================================================================
/// APP CONTROLLER — estado geral do aplicativo
/// =======================================================================
/// Cuida do cadastro do motorista e das configurações (tema, metas, sons,
/// animações). Quando algo muda aqui, o app inteiro se redesenha.
/// =======================================================================
library;

import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';

import '../../data/gravacao_segura.dart';
import '../../data/local_database.dart';
import '../../data/models/configuracoes.dart';
import '../../data/models/motorista.dart';
import '../../data/repositories/configuracoes_repository.dart';
import '../../data/repositories/motorista_repository.dart';
import '../../services/audio_service.dart';
import '../../theme/app_theme_builder.dart';
import '../../theme/app_typography.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';

class AppController extends ChangeNotifier {
  final MotoristaRepository _motoristaRepo = MotoristaRepository();
  final ConfiguracoesRepository _configRepo = ConfiguracoesRepository();

  Motorista? _motorista;
  Configuracoes _config = Configuracoes();

  Motorista? get motorista => _motorista;
  Configuracoes get config => _config;

  /// Já existe motorista cadastrado? Decide entre login e tela inicial.
  bool get temCadastro => _motorista != null;

  /// Brilho atual do sistema operacional (claro ou escuro).
  /// Usado quando o motorista escolhe o modo "Automático".
  Brightness get _brilhoDoSistema =>
      PlatformDispatcher.instance.platformBrightness;

  /// Passa a ouvir quando o celular alterna entre claro e escuro,
  /// para o app acompanhar sozinho no modo Automático.
  void _ouvirBrilhoDoSistema() {
    PlatformDispatcher.instance.onPlatformBrightnessChanged = () {
      if (modoTema == ModoTema.automatico) {
        _esquecerTema();
        notifyListeners();
      }
    };
  }

  /// Modo escolhido: claro, escuro ou automático.
  ModoTema get modoTema => ModoTema.porNome(_config.modoTema);

  /// Cor principal escolhida.
  Color get corPrimaria => PaletaCores.deHex(_config.corPrimariaHex);

  /// Como os indicadores aparecem na tela inicial.
  ModoVisualizacao get modoVisualizacao =>
      ModoVisualizacao.porNome(_config.modoVisualizacao);

  // ------------------- APARÊNCIA (tudo aplica no app inteiro) -------------
  ConjuntoFonte get conjuntoFonte => ConjuntoFonte.porNome(_config.fonteId);
  TamanhoTexto get tamanhoTexto => TamanhoTexto.porEscala(_config.escalaTexto);
  bool get numerosMono => _config.numerosMono;
  bool get compacto => _config.densidade == 'compacto';

  // ------------------- MODO DO PAINEL -------------------------------------
  // 'indicadores' = cartões, barras e ícones (visual de painel).
  // 'texto'       = lista simples de nomes e valores, sem gráfico nenhum.
  // A escolha fica gravada e vale para o app inteiro.
  String get modoPainel => _config.modoPainel;
  bool get modoPainelTexto => _config.modoPainel == 'texto';
  bool get modoPainelIndicadores => !modoPainelTexto;

  /// Som escolhido para os avisos: 'classico', 'suave' ou 'alerta'.
  String get somNotificacao => _config.somNotificacao;

  /// Tipo de veículo que já vem preenchido nos lançamentos.
  String get tipoVeiculoPadrao => _config.tipoVeiculoPadrao;

  // -------------------------------------------------------------------
  // O TEMA FICA GUARDADO (desempenho)
  // -------------------------------------------------------------------
  // Montar o tema envolve contas de cor, e montar o ThemeData do Flutter
  // envolve montar a tipografia inteira. Isso era refeito a cada
  // redesenho de tela — dezenas de vezes por minuto. Agora é feito uma
  // vez e reaproveitado até o motorista trocar o modo ou a cor.
  TemaFarol? _temaGuardado;
  ThemeData? _visualGuardado;
  Brightness? _brilhoGuardado;

  /// Assinatura das escolhas de aparência. Mudou a assinatura, o tema é
  /// remontado; igual, reaproveita o que já está pronto.
  String get _assinaturaAparencia =>
      '${_config.modoTema}|${_config.corPrimariaHex}|${_config.escalaTexto}'
      '|${_config.fonteId}|${_config.numerosMono}|${_config.densidade}';
  String? _assinaturaGuardada;

  /// O tema montado a partir do modo + cor escolhidos.
  TemaFarol get tema {
    final brilho = modoTema.resolver(_brilhoDoSistema);
    final assinatura = _assinaturaAparencia;
    final guardado = _temaGuardado;
    if (guardado != null &&
        _brilhoGuardado == brilho &&
        _assinaturaGuardada == assinatura) {
      return guardado;
    }
    final novo = TemaFarol.gerar(
      brilho: brilho,
      corPrimaria: corPrimaria,
      escalaTexto: _config.escalaTexto,
      conjuntoFonte: conjuntoFonte,
      numerosMono: _config.numerosMono,
      compacto: compacto,
    );
    _temaGuardado = novo;
    _brilhoGuardado = brilho;
    _assinaturaGuardada = assinatura;
    _visualGuardado = null;
    return novo;
  }

  /// O ThemeData que o MaterialApp usa. Montado uma vez por tema.
  ThemeData get visual {
    // Chamar `tema` primeiro: se ele mudou, ele mesmo zera o cache abaixo.
    final t = tema;
    return _visualGuardado ??= AppThemeBuilder.construir(t);
  }

  void _esquecerTema() {
    _temaGuardado = null;
    _visualGuardado = null;
    _brilhoGuardado = null;
    _assinaturaGuardada = null;
  }

  bool get animacoesAtivas => _config.animacoesAtivas;
  bool get sonsAtivos => _config.sonsAtivos;

  /// Duração de animação que respeita o interruptor das configurações.
  /// Com animações desligadas, tudo acontece instantaneamente.
  Duration duracao(int milissegundos) => _config.animacoesAtivas
      ? Duration(milliseconds: milissegundos)
      : Duration.zero;

  /// Carrega tudo do Hive. Chamado uma vez, na abertura do app.
  Future<void> carregar() async {
    _motorista = _motoristaRepo.obter();
    _config = _configRepo.obter();
    _sincronizarAudio();
    _ouvirBrilhoDoSistema();
    notifyListeners();
  }

  /// Mantém o serviço de som alinhado com as configurações.
  void _sincronizarAudio() {
    AudioService.sonsAtivos = _config.sonsAtivos;
    AudioService.vibracaoAtiva = _config.animacoesAtivas;
    AudioService.somDeAviso = _config.somNotificacao;
  }

  // ---------------------------------------------------------------------
  // MOTORISTA
  // ---------------------------------------------------------------------

  Future<ResultadoGravacao> salvarMotorista(Motorista m) async {
    // O cadastro passa a valer na hora; a gravação vem logo atrás e
    // nunca derruba a tela de entrada.
    _motorista = m;
    notifyListeners();

    final r = await _motoristaRepo.salvar(m);

    // A primeira gravação encerra o "primeiro uso".
    if (_config.primeiroUso) {
      _config = _config.copiarCom(primeiroUso: false);
      await _configRepo.salvar(_config);
    }
    notifyListeners();
    return r;
  }

  /// Saudação que muda conforme o horário do celular.
  String get saudacao {
    final h = DateTime.now().hour;
    if (h >= 5 && h < 12) return 'Bom dia';
    if (h >= 12 && h < 18) return 'Boa tarde';
    return 'Boa noite';
  }

  /// "Boa tarde, Henrique" — ou só a saudação se não houver cadastro.
  String get saudacaoCompleta {
    final nome = _motorista?.primeiroNome;
    return nome == null || nome.isEmpty ? saudacao : '$saudacao, $nome';
  }

  // ---------------------------------------------------------------------
  // CONFIGURAÇÕES
  // ---------------------------------------------------------------------

  Future<void> salvarConfig(Configuracoes nova) async {
    _config = nova;
    _esquecerTema();
    _sincronizarAudio();
    // A tela muda NA HORA; a gravação vem logo atrás. Se o disco falhar,
    // o app continua funcionando com a escolha feita.
    notifyListeners();
    // A gravação já vem protegida: nunca estoura erro daqui.
    await _configRepo.salvar(_config);
  }

  /// Troca entre claro, escuro e automático. Aplica na hora.
  Future<void> trocarModoTema(ModoTema modo) async {
    await salvarConfig(_config.copiarCom(modoTema: modo.name));
  }

  /// Troca a cor principal do app. Aplica na hora, em todas as telas.
  Future<void> trocarCor(Color cor) async {
    await salvarConfig(
      _config.copiarCom(corPrimariaHex: PaletaCores.paraHex(cor)),
    );
  }

  /// Troca o modo de visualização dos indicadores.
  Future<void> trocarVisualizacao(ModoVisualizacao modo) async {
    await salvarConfig(_config.copiarCom(modoVisualizacao: modo.name));
  }

  /// Muda o tamanho da letra em TODO o aplicativo.
  Future<void> trocarTamanhoTexto(TamanhoTexto t) async {
    await salvarConfig(_config.copiarCom(escalaTexto: t.escala));
  }

  /// Muda o conjunto de fontes em TODO o aplicativo.
  Future<void> trocarFonte(ConjuntoFonte f) async {
    await salvarConfig(_config.copiarCom(fonteId: f.name));
  }

  /// Liga/desliga os números com casas alinhadas.
  Future<void> alternarNumerosMono(bool ligado) async {
    await salvarConfig(_config.copiarCom(numerosMono: ligado));
  }

  /// Alterna entre espaçamento confortável e compacto.
  Future<void> trocarDensidade(bool compacto) async {
    await salvarConfig(
      _config.copiarCom(densidade: compacto ? 'compacto' : 'confortavel'),
    );
  }

  /// Alterna entre o painel de indicadores e o painel de texto.
  /// Aplica na hora, em todas as telas que mostram números.
  Future<void> trocarModoPainel(bool texto) async {
    await salvarConfig(
      _config.copiarCom(modoPainel: texto ? 'texto' : 'indicadores'),
    );
  }

  /// Troca o som dos avisos e já toca uma amostra para o motorista ouvir.
  Future<void> trocarSomNotificacao(String som) async {
    await salvarConfig(_config.copiarCom(somNotificacao: som));
    await AudioService.tocarAviso(som);
  }

  /// Define o tipo de veículo que vem marcado por padrão nos lançamentos.
  Future<void> trocarTipoVeiculoPadrao(String tipo) async {
    await salvarConfig(_config.copiarCom(tipoVeiculoPadrao: tipo));
  }

  /// Guarda a categoria do programa de pontos escolhida pelo motorista.
  Future<void> trocarCategoriaPontos(String categoria) async {
    await salvarConfig(_config.copiarCom(categoriaPontos: categoria));
  }

  Future<void> alternarAnimacoes(bool ligado) async {
    await salvarConfig(_config.copiarCom(animacoesAtivas: ligado));
  }

  Future<void> alternarSons(bool ligado) async {
    await salvarConfig(_config.copiarCom(sonsAtivos: ligado));
  }

  Future<void> salvarMetas({
    double? diaria,
    double? semanal,
    double? mensal,
  }) async {
    await salvarConfig(_config.copiarCom(
      metaDiaria: diaria,
      metaSemanal: semanal,
      metaMensal: mensal,
    ));
  }

  Future<void> salvarPadroesVeiculo({
    double? kmPorLitro,
    double? precoLitro,
    String? combustivel,
    double? custosFixos,
    double? margemAlvo,
  }) async {
    await salvarConfig(_config.copiarCom(
      kmPorLitroPadrao: kmPorLitro,
      precoLitroPadrao: precoLitro,
      combustivelPadrao: combustivel,
      custosFixosMensais: custosFixos,
      margemLucroAlvo: margemAlvo,
    ));
  }

  /// Marca que a comemoração de meta já rolou hoje (evita repetir a
  /// animação de confete toda vez que o motorista volta para a tela).
  Future<void> registrarComemoracao() async {
    await salvarConfig(_config.copiarCom(ultimaComemoracao: DateTime.now()));
  }

  /// Já comemorou hoje?
  bool get jaComemorouHoje {
    final u = _config.ultimaComemoracao;
    if (u == null) return false;
    final hoje = DateTime.now();
    return u.year == hoje.year && u.month == hoje.month && u.day == hoje.day;
  }

  // ---------------------------------------------------------------------
  // GERENCIAR DADOS
  // ---------------------------------------------------------------------

  /// Apaga lançamentos, gastos, abastecimentos e jornadas.
  /// Mantém o cadastro e as preferências.
  Future<void> limparMovimentacoes() async {
    await LocalDatabase.limparMovimentacoes();
    notifyListeners();
  }

  /// Apaga absolutamente tudo (volta ao estado de app recém-instalado).
  Future<void> apagarTudo() async {
    await LocalDatabase.apagarTudo();
    _motorista = null;
    _config = Configuracoes();
    _sincronizarAudio();
    notifyListeners();
  }
}
