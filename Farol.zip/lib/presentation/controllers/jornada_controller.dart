/// =======================================================================
/// JORNADA CONTROLLER — o cronômetro do trabalho
/// =======================================================================
/// Controla iniciar, pausar, retomar e encerrar a jornada.
/// REGRA DE OURO: o tempo das pausas não conta como trabalho. Quem faz
/// essa conta é o CalculationsService — aqui só se guarda o histórico.
///
/// DUAS DECISÕES IMPORTANTES DESTE ARQUIVO:
///
/// 1) O RELÓGIO NÃO REDESENHA O APLICATIVO INTEIRO.
///    O cronômetro anda de segundo em segundo. Se cada segundo avisasse
///    todas as telas, o aplicativo refaria gráficos e somas 60 vezes por
///    minuto — e é exatamente isso que deixa um celular simples travado.
///    Por isso o tempo vive num ValueNotifier: só o número do cronômetro
///    se redesenha; o resto da tela fica parado.
///
/// 2) A TELA MUDA ANTES DE GRAVAR NO DISCO.
///    Ao apertar "Iniciar", o estado muda e a tela é avisada NA HORA.
///    A gravação acontece logo em seguida. Se ela falhar, o motorista vê
///    um aviso — mas o botão nunca fica "morto" esperando o disco.
/// =======================================================================
library;

import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/models/jornada.dart';
import '../../data/repositories/jornada_repository.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../utils/extensions.dart';

class JornadaController extends ChangeNotifier {
  final JornadaRepository _repo = JornadaRepository();

  Jornada? _atual;
  Timer? _relogio;

  /// Tempo trabalhado agora. Quem mostra o cronômetro escuta ISTO, e não
  /// o controller inteiro — assim só o número pisca a cada segundo.
  final ValueNotifier<Duration> tempoAtivoAgora =
      ValueNotifier<Duration>(Duration.zero);

  /// Tempo parado em pausas na jornada atual.
  final ValueNotifier<Duration> tempoPausadoAgora =
      ValueNotifier<Duration>(Duration.zero);

  /// Guarda o último problema de gravação, para a tela poder avisar.
  String? ultimoErro;

  Jornada? get jornadaAtual => _atual;
  Duration get tempoAtivo => tempoAtivoAgora.value;
  Duration get tempoPausado => tempoPausadoAgora.value;

  bool get temJornadaAberta => _atual != null && _atual!.emAndamento;
  bool get pausada => _atual?.pausada ?? false;
  String? get motivoPausaAtual => _atual?.pausaAtual?.motivo;

  /// Texto do botão principal da tela inicial.
  String get rotuloBotaoPrincipal {
    if (!temJornadaAberta) return 'Iniciar jornada';
    if (pausada) return 'Retomar jornada';
    return 'Continuar jornada';
  }

  List<Jornada> get historico => _repo.todas();

  List<Jornada> historicoDoDia(DateTime dia) => _repo.porDia(dia);

  /// Horas trabalhadas hoje, somando todas as jornadas do dia.
  double get horasHoje =>
      CalculationsService.horasDeJornadas(_repo.porDia(DateTime.now()));

  /// Horas trabalhadas em um intervalo qualquer.
  double horasNoPeriodo(DateTime inicio, DateTime fim) =>
      CalculationsService.horasDeJornadas(_repo.porPeriodo(inicio, fim));

  // ---------------------------------------------------------------------
  // CICLO DE VIDA
  // ---------------------------------------------------------------------

  /// Recupera uma jornada que ficou aberta (o motorista fechou o app
  /// sem encerrar). O tempo continua contando do jeito certo.
  Future<void> carregar() async {
    try {
      _atual = _repo.emAndamento();
    } catch (e) {
      ultimoErro = 'Não foi possível ler a jornada salva.';
      _atual = null;
    }
    if (_atual != null) _ligarRelogio();
    _recalcular();
    notifyListeners();
  }

  void _ligarRelogio() {
    _relogio?.cancel();
    // Só o cronômetro é atualizado aqui. Nada de notifyListeners():
    // avisar o app inteiro a cada segundo é o que trava o celular.
    _relogio = Timer.periodic(const Duration(seconds: 1), (_) => _recalcular());
  }

  void _desligarRelogio() {
    _relogio?.cancel();
    _relogio = null;
  }

  void _recalcular() {
    final j = _atual;
    if (j == null) {
      tempoAtivoAgora.value = Duration.zero;
      tempoPausadoAgora.value = Duration.zero;
      return;
    }
    tempoAtivoAgora.value = CalculationsService.tempoAtivoJornada(j);
    tempoPausadoAgora.value = CalculationsService.tempoPausadoJornada(j);
  }

  @override
  void dispose() {
    _desligarRelogio();
    tempoAtivoAgora.dispose();
    tempoPausadoAgora.dispose();
    super.dispose();
  }

  /// Grava sem deixar a tela travada: se o disco falhar, o motorista
  /// recebe um aviso, mas o aplicativo continua respondendo.
  Future<void> _gravar(Jornada j) async {
    final r = await _repo.salvar(j);
    if (r.perfeito) {
      if (ultimoErro != null) {
        ultimoErro = null;
        notifyListeners();
      }
      return;
    }
    ultimoErro = r.soNaMemoria
        ? 'A jornada está valendo, mas não foi gravada no celular. '
            'Se fechar o aplicativo agora, ela pode se perder.'
        : 'Não foi possível guardar a jornada neste celular.';
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // AÇÕES
  // ---------------------------------------------------------------------

  /// Começa uma nova jornada. Se já houver uma aberta, não faz nada.
  Future<void> iniciar() async {
    if (temJornadaAberta) return;
    AudioService.toqueMedio();

    // Primeiro a tela reage; depois se grava. O motorista vê o cronômetro
    // começar no mesmo instante em que aperta o botão.
    _atual = Jornada(inicio: DateTime.now());
    _ligarRelogio();
    _recalcular();
    notifyListeners();

    await _gravar(_atual!);
  }

  /// Pausa a jornada registrando o motivo (banheiro, café, almoço...).
  Future<void> pausar(String motivo) async {
    final j = _atual;
    if (j == null || !j.emAndamento || j.pausada) return;
    AudioService.toqueLeve();

    j.pausas.add(Pausa(inicio: DateTime.now(), motivo: motivo));
    _recalcular();
    notifyListeners();

    await _gravar(j);
  }

  /// Volta a trabalhar: fecha a pausa que estava aberta.
  Future<void> retomar() async {
    final j = _atual;
    if (j == null) return;
    final pausa = j.pausaAtual;
    if (pausa == null) return;
    AudioService.toqueMedio();

    pausa.fim = DateTime.now();
    _recalcular();
    notifyListeners();

    await _gravar(j);
  }

  /// Encerra a jornada. Devolve quantas horas ficaram registradas,
  /// para a tela já oferecer o lançamento do dia.
  Future<double> encerrar() async {
    final j = _atual;
    if (j == null) return 0;
    AudioService.toqueMedio();

    // Fecha qualquer pausa que tenha ficado aberta.
    final pausa = j.pausaAtual;
    if (pausa != null) pausa.fim = DateTime.now();

    j.fim = DateTime.now();

    final horas = CalculationsService.duracaoParaHoras(
      CalculationsService.tempoAtivoJornada(j),
    );

    _desligarRelogio();
    _atual = null;
    _recalcular();
    notifyListeners();

    await _gravar(j);
    return horas;
  }

  /// Apaga uma jornada do histórico.
  Future<void> apagar(String id) async {
    if (_atual?.id == id) {
      _desligarRelogio();
      _atual = null;
      _recalcular();
    }
    notifyListeners();
    try {
      await _repo.apagar(id);
    } catch (_) {
      ultimoErro = 'A jornada não pôde ser apagada.';
      notifyListeners();
    }
  }

  /// Tempo ativo de uma jornada qualquer do histórico.
  Duration tempoDe(Jornada j) => CalculationsService.tempoAtivoJornada(j);

  /// Jornadas agrupadas por dia, da mais recente para a mais antiga.
  Map<DateTime, List<Jornada>> historicoAgrupado() {
    final mapa = <DateTime, List<Jornada>>{};
    for (final j in historico) {
      final dia = j.inicio.soData;
      mapa.putIfAbsent(dia, () => <Jornada>[]).add(j);
    }
    return mapa;
  }
}
