/// =======================================================================
/// JORNADA CONTROLLER — o cronômetro do trabalho
/// =======================================================================
/// Controla iniciar, pausar, retomar e encerrar a jornada.
/// REGRA DE OURO: o tempo das pausas não conta como trabalho. Quem faz
/// essa conta é o CalculationsService — aqui só se guarda o histórico.
/// =======================================================================
library;

import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/models/jornada.dart';
import '../../data/repositories/jornada_repository.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../utils/extensions.dart';

class JornadaController extends ChangeNotifier {
  final JornadaRepository _repo = JornadaRepository();

  Jornada? _atual;
  Timer? _relogio;

  /// Atualizado a cada segundo enquanto a jornada está rodando.
  Duration _tempoAtivo = Duration.zero;
  Duration _tempoPausado = Duration.zero;

  Jornada? get jornadaAtual => _atual;
  Duration get tempoAtivo => _tempoAtivo;
  Duration get tempoPausado => _tempoPausado;

  bool get temJornadaAberta => _atual != null && _atual!.emAndamento;
  bool get pausada => _atual?.pausada ?? false;
  String? get motivoPausaAtual => _atual?.pausaAtual?.motivo;

  /// Texto do botão principal da tela inicial.
  String get rotuloBotaoPrincipal {
    if (!temJornadaAberta) return 'Iniciar jornada';
    if (pausada) return 'Retomar jornada';
    return 'Continuar jornada';
  }

  List<Jornada> get historico => _repo.todas();

  List<Jornada> historicoDoDia(DateTime dia) => _repo.porDia(dia);

  /// Horas trabalhadas hoje, somando todas as jornadas do dia.
  double get horasHoje =>
      CalculationsService.horasDeJornadas(_repo.porDia(DateTime.now()));

  /// Horas trabalhadas em um intervalo qualquer.
  double horasNoPeriodo(DateTime inicio, DateTime fim) =>
      CalculationsService.horasDeJornadas(_repo.porPeriodo(inicio, fim));

  // ---------------------------------------------------------------------
  // CICLO DE VIDA
  // ---------------------------------------------------------------------

  /// Recupera uma jornada que ficou aberta (o motorista fechou o app
  /// sem encerrar). O tempo continua contando do jeito certo.
  Future<void> carregar() async {
    _atual = _repo.emAndamento();
    if (_atual != null) _ligarRelogio();
    _recalcular();
    notifyListeners();
  }

  void _ligarRelogio() {
    _relogio?.cancel();
    _relogio = Timer.periodic(const Duration(seconds: 1), (_) {
      _recalcular();
      notifyListeners();
    });
  }

  void _desligarRelogio() {
    _relogio?.cancel();
    _relogio = null;
  }

  void _recalcular() {
    final j = _atual;
    if (j == null) {
      _tempoAtivo = Duration.zero;
      _tempoPausado = Duration.zero;
      return;
    }
    _tempoAtivo = CalculationsService.tempoAtivoJornada(j);
    _tempoPausado = CalculationsService.tempoPausadoJornada(j);
  }

  @override
  void dispose() {
    _desligarRelogio();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  // AÇÕES
  // ---------------------------------------------------------------------

  /// Começa uma nova jornada. Se já houver uma aberta, não faz nada.
  Future<void> iniciar() async {
    if (temJornadaAberta) return;
    AudioService.toqueMedio();
    _atual = Jornada(inicio: DateTime.now());
    await _repo.salvar(_atual!);
    _ligarRelogio();
    _recalcular();
    notifyListeners();
  }

  /// Pausa a jornada registrando o motivo (banheiro, café, almoço...).
  Future<void> pausar(String motivo) async {
    final j = _atual;
    if (j == null || !j.emAndamento || j.pausada) return;
    AudioService.toqueLeve();
    j.pausas.add(Pausa(inicio: DateTime.now(), motivo: motivo));
    await _repo.salvar(j);
    _recalcular();
    notifyListeners();
  }

  /// Volta a trabalhar: fecha a pausa que estava aberta.
  Future<void> retomar() async {
    final j = _atual;
    if (j == null) return;
    final pausa = j.pausaAtual;
    if (pausa == null) return;
    AudioService.toqueMedio();
    pausa.fim = DateTime.now();
    await _repo.salvar(j);
    _recalcular();
    notifyListeners();
  }

  /// Encerra a jornada. Devolve quantas horas ficaram registradas,
  /// para a tela já oferecer o lançamento do dia.
  Future<double> encerrar() async {
    final j = _atual;
    if (j == null) return 0;
    AudioService.toqueMedio();

    // Fecha qualquer pausa que tenha ficado aberta.
    final pausa = j.pausaAtual;
    if (pausa != null) pausa.fim = DateTime.now();

    j.fim = DateTime.now();
    await _repo.salvar(j);

    final horas = CalculationsService.duracaoParaHoras(
      CalculationsService.tempoAtivoJornada(j),
    );

    _desligarRelogio();
    _atual = null;
    _recalcular();
    notifyListeners();
    return horas;
  }

  /// Apaga uma jornada do histórico.
  Future<void> apagar(String id) async {
    await _repo.apagar(id);
    if (_atual?.id == id) {
      _desligarRelogio();
      _atual = null;
      _recalcular();
    }
    notifyListeners();
  }

  /// Tempo ativo de uma jornada qualquer do histórico.
  Duration tempoDe(Jornada j) => CalculationsService.tempoAtivoJornada(j);

  /// Jornadas agrupadas por dia, da mais recente para a mais antiga.
  Map<DateTime, List<Jornada>> historicoAgrupado() {
    final mapa = <DateTime, List<Jornada>>{};
    for (final j in historico) {
      final dia = j.inicio.soData;
      mapa.putIfAbsent(dia, () => <Jornada>[]).add(j);
    }
    return mapa;
  }
}
