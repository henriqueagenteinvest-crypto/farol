/// =======================================================================
/// DADOS CONTROLLER — lançamentos, abastecimentos e gastos
/// =======================================================================
/// Concentra o cadastro e a consulta das movimentações. As telas NUNCA
/// mexem no Hive direto e NUNCA fazem conta: pedem tudo aqui, e aqui
/// quem calcula é sempre o CalculationsService.
/// =======================================================================
library;

import 'package:flutter/material.dart';

import '../../data/models/abastecimento.dart';
import '../../data/models/configuracoes.dart';
import '../../data/models/gasto.dart';
import '../../data/models/lancamento_diario.dart';
import '../../data/repositories/abastecimento_repository.dart';
import '../../data/repositories/gasto_repository.dart';
import '../../data/repositories/lancamento_repository.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/calculations_service.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';

/// Os filtros de período disponíveis nos relatórios.
enum FiltroPeriodo {
  dia('Dia'),
  semana('Semana'),
  mes('Mês'),
  ano('Ano'),
  total('Tudo');

  final String rotulo;
  const FiltroPeriodo(this.rotulo);
}

class DadosController extends ChangeNotifier {
  final LancamentoRepository _lancamentos = LancamentoRepository();
  final AbastecimentoRepository _abastecimentos = AbastecimentoRepository();
  final GastoRepository _gastos = GastoRepository();

  /// Configurações vindas do AppController (metas, custos fixos, padrões).
  Configuracoes _config = Configuracoes();

  /// O AppController chama isto sempre que as configurações mudam.
  void atualizarConfig(Configuracoes c) {
    _config = c;
    notifyListeners();
  }

  Configuracoes get config => _config;

  // =====================================================================
  // LISTAS
  // =====================================================================

  List<LancamentoDiario> get lancamentos => _lancamentos.todos();
  List<Abastecimento> get abastecimentos => _abastecimentos.todos();
  List<Gasto> get gastos => _gastos.todos();

  bool get vazio =>
      lancamentos.isEmpty && gastos.isEmpty && abastecimentos.isEmpty;

  // =====================================================================
  // GRAVAÇÃO
  // =====================================================================

  Future<void> salvarLancamento(LancamentoDiario l) async {
    await _lancamentos.salvar(l);
    notifyListeners();
  }

  Future<void> apagarLancamento(String id) async {
    await _lancamentos.apagar(id);
    notifyListeners();
  }

  Future<void> salvarAbastecimento(Abastecimento a) async {
    await _abastecimentos.salvar(a);
    notifyListeners();
  }

  Future<void> apagarAbastecimento(String id) async {
    await _abastecimentos.apagar(id);
    notifyListeners();
  }

  Future<void> salvarGasto(Gasto g) async {
    await _gastos.salvar(g);
    notifyListeners();
  }

  Future<void> apagarGasto(String id) async {
    await _gastos.apagar(id);
    notifyListeners();
  }

  /// Preço do litro sugerido: o do último abastecimento, se houver.
  double get precoLitroSugerido {
    final ultimo = _abastecimentos.ultimo();
    if (ultimo != null && ultimo.precoLitro > 0) {
      return ultimo.precoLitro;
    }
    return _config.precoLitroPadrao;
  }

  // =====================================================================
  // RESUMOS
  // =====================================================================

  /// Monta o intervalo de datas de um filtro, tomando [referencia] como base.
  (DateTime, DateTime, String) intervaloDe(
    FiltroPeriodo filtro, {
    DateTime? referencia,
  }) {
    final base = referencia ?? DateTime.now();
    switch (filtro) {
      case FiltroPeriodo.dia:
        return (base.soData, base.soData, Fmt.data(base));
      case FiltroPeriodo.semana:
        final ini = base.inicioSemana;
        final fim = base.fimSemana;
        return (ini, fim, '${Fmt.dataCurta(ini)} a ${Fmt.data(fim)}');
      case FiltroPeriodo.mes:
        return (base.inicioMes, base.fimMes, Fmt.mesAno(base));
      case FiltroPeriodo.ano:
        return (base.inicioAno, base.fimAno, 'Ano de ${base.year}');
      case FiltroPeriodo.total:
        final primeira = _lancamentos.primeiraData() ?? base;
        return (primeira.soData, base.fimAno, 'Tudo desde o começo');
    }
  }

  /// O resumo completo de um período — é daqui que saem TODAS as telas
  /// de relatório, o Excel e o PDF.
  ResumoPeriodo resumo(
    FiltroPeriodo filtro, {
    DateTime? referencia,
    bool usarCustoRealAbastecimento = false,
  }) {
    final (inicio, fim, rotulo) = intervaloDe(filtro, referencia: referencia);
    return CalculationsService.resumir(
      lancamentos: _lancamentos.porPeriodo(inicio, fim),
      gastos: _gastos.porPeriodo(inicio, fim),
      abastecimentos: _abastecimentos.porPeriodo(inicio, fim),
      inicio: inicio,
      fim: fim,
      rotulo: rotulo,
      custosFixosMensais: _config.custosFixosMensais,
      usarCustoRealAbastecimento: usarCustoRealAbastecimento,
    );
  }

  /// Resumo de um intervalo escolhido à mão.
  ResumoPeriodo resumoPersonalizado({
    required DateTime inicio,
    required DateTime fim,
    String rotulo = 'Período escolhido',
  }) {
    return CalculationsService.resumir(
      lancamentos: _lancamentos.porPeriodo(inicio, fim),
      gastos: _gastos.porPeriodo(inicio, fim),
      abastecimentos: _abastecimentos.porPeriodo(inicio, fim),
      inicio: inicio,
      fim: fim,
      rotulo: rotulo,
      custosFixosMensais: _config.custosFixosMensais,
    );
  }

  /// Resumo de hoje (usado na tela inicial).
  ResumoPeriodo get resumoHoje => resumo(FiltroPeriodo.dia);

  /// Resumo do período ANTERIOR ao filtro — para comparar evolução.
  ResumoPeriodo resumoAnterior(FiltroPeriodo filtro) {
    final agora = DateTime.now();
    final DateTime referencia;
    switch (filtro) {
      case FiltroPeriodo.dia:
        referencia = agora.subtract(const Duration(days: 1));
      case FiltroPeriodo.semana:
        referencia = agora.subtract(const Duration(days: 7));
      case FiltroPeriodo.mes:
        referencia = DateTime(agora.year, agora.month - 1, 1);
      case FiltroPeriodo.ano:
        referencia = DateTime(agora.year - 1, 6, 15);
      case FiltroPeriodo.total:
        return ResumoPeriodo.vazio();
    }
    return resumo(filtro, referencia: referencia);
  }

  /// Lucro de cada um dos últimos [dias] dias (mini gráfico da tela inicial).
  /// Devolve sempre a lista completa, inclusive os dias sem trabalho (zero).
  List<({DateTime dia, double lucro})> ultimosDias([int dias = 7]) {
    final hoje = DateTime.now().soData;
    final inicio = hoje.subtract(Duration(days: dias - 1));
    final r = CalculationsService.resumir(
      lancamentos: _lancamentos.porPeriodo(inicio, hoje),
      gastos: _gastos.porPeriodo(inicio, hoje),
      inicio: inicio,
      fim: hoje,
    );
    return <({DateTime dia, double lucro})>[
      for (var i = 0; i < dias; i++)
        (
          dia: inicio.add(Duration(days: i)),
          lucro: r.lucroPorDia[inicio.add(Duration(days: i))] ?? 0.0,
        ),
    ];
  }

  // =====================================================================
  // METAS
  // =====================================================================

  /// Quanto por cento da meta do dia já foi feito.
  double get percentualMetaHoje => CalculationsService.percentualMeta(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  double get progressoMetaHoje => CalculationsService.progressoMeta(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  bool get metaHojeAtingida => CalculationsService.metaAtingida(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  double get faltaParaMetaHoje => CalculationsService.faltaParaMeta(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  // =====================================================================
  // CUSTO POR KM ATUAL (usado na avaliação de corrida)
  // =====================================================================

  /// Custo de combustível por km com os valores atuais do motorista.
  double get custoPorKmAtual => CalculationsService.custoCombustivelPorKm(
        kmPorLitro: _config.kmPorLitroPadrao,
        precoLitro: precoLitroSugerido,
      );
}
