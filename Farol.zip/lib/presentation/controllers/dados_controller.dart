/// =======================================================================
/// DADOS CONTROLLER — lançamentos, abastecimentos e gastos
/// =======================================================================
/// Concentra o cadastro e a consulta das movimentações. As telas NUNCA
/// mexem no Hive direto e NUNCA fazem conta: pedem tudo aqui, e aqui
/// quem calcula é sempre o CalculationsService.
/// =======================================================================
library;

import 'package:flutter/material.dart';

import '../../data/models/abastecimento.dart';
import '../../data/models/configuracoes.dart';
import '../../data/models/gasto.dart';
import '../../data/models/lancamento_diario.dart';
import '../../data/repositories/abastecimento_repository.dart';
import '../../data/repositories/gasto_repository.dart';
import '../../data/repositories/lancamento_repository.dart';
import '../../domain/entities/periodo_escolhido.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/calculations_service.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';

/// Os filtros de período disponíveis nos relatórios.
enum FiltroPeriodo {
  dia('Dia'),
  semana('Semana'),
  mes('Mês'),
  ano('Ano'),
  total('Tudo');

  final String rotulo;
  const FiltroPeriodo(this.rotulo);
}

class DadosController extends ChangeNotifier {
  final LancamentoRepository _lancamentos = LancamentoRepository();
  final AbastecimentoRepository _abastecimentos = AbastecimentoRepository();
  final GastoRepository _gastos = GastoRepository();

  /// Configurações vindas do AppController (metas, custos fixos, padrões).
  Configuracoes _config = Configuracoes();

  /// -------------------------------------------------------------------
  /// MEMÓRIA DE RESUMOS JÁ CALCULADOS (desempenho)
  /// -------------------------------------------------------------------
  /// Montar um resumo significa varrer todos os lançamentos, gastos e
  /// abastecimentos do período. A tela redesenha várias vezes por segundo
  /// (rolagem, cronômetro, animação) e pediria a mesma conta toda vez.
  ///
  /// Aqui o resultado fica guardado. Assim que QUALQUER dado muda, esta
  /// memória é apagada inteira — então ela nunca devolve número velho.
  final Map<String, ResumoPeriodo> _memoria = <String, ResumoPeriodo>{};

  /// Apaga a memória. Chamado sempre que algo é salvo ou apagado.
  void _esquecerContas() {
    _memoria.clear();
    _anosGuardados = null;
  }

  /// O AppController chama isto sempre que as configurações mudam.
  void atualizarConfig(Configuracoes c) {
    // Sem mudança de verdade, não mexe em nada (evita redesenho à toa).
    if (identical(_config, c)) return;
    _config = c;
    _esquecerContas();

    // IMPORTANTE: este método é chamado ENQUANTO a tela está sendo
    // construída (pelo Provider). Avisar na hora faz o Flutter reclamar
    // de "setState durante o build" e a tela pode parar de atualizar.
    // Por isso o aviso sai só no fim do quadro.
    WidgetsBinding.instance.addPostFrameCallback((_) => notifyListeners());
  }

  Configuracoes get config => _config;

  // =====================================================================
  // LISTAS
  // =====================================================================

  List<LancamentoDiario> get lancamentos => _lancamentos.todos();
  List<Abastecimento> get abastecimentos => _abastecimentos.todos();
  List<Gasto> get gastos => _gastos.todos();

  bool get vazio =>
      lancamentos.isEmpty && gastos.isEmpty && abastecimentos.isEmpty;

  // =====================================================================
  // GRAVAÇÃO
  // =====================================================================

  Future<void> salvarLancamento(LancamentoDiario l) async {
    await _lancamentos.salvar(l);
    _esquecerContas();
    notifyListeners();
  }

  Future<void> apagarLancamento(String id) async {
    await _lancamentos.apagar(id);
    _esquecerContas();
    notifyListeners();
  }

  Future<void> salvarAbastecimento(Abastecimento a) async {
    await _abastecimentos.salvar(a);
    _esquecerContas();
    notifyListeners();
  }

  Future<void> apagarAbastecimento(String id) async {
    await _abastecimentos.apagar(id);
    _esquecerContas();
    notifyListeners();
  }

  Future<void> salvarGasto(Gasto g) async {
    await _gastos.salvar(g);
    _esquecerContas();
    notifyListeners();
  }

  Future<void> apagarGasto(String id) async {
    await _gastos.apagar(id);
    _esquecerContas();
    notifyListeners();
  }

  /// Recarrega tudo do zero (usado depois de apagar dados nas configurações).
  void recarregar() {
    _esquecerContas();
    notifyListeners();
  }

  /// Preço do litro sugerido: o do último abastecimento, se houver.
  double get precoLitroSugerido {
    final ultimo = _abastecimentos.ultimo();
    if (ultimo != null && ultimo.precoLitro > 0) {
      return ultimo.precoLitro;
    }
    return _config.precoLitroPadrao;
  }

  // =====================================================================
  // RESUMOS
  // =====================================================================

  /// Monta o intervalo de datas de um filtro, tomando [referencia] como base.
  (DateTime, DateTime, String) intervaloDe(
    FiltroPeriodo filtro, {
    DateTime? referencia,
  }) {
    final base = referencia ?? DateTime.now();
    switch (filtro) {
      case FiltroPeriodo.dia:
        return (base.soData, base.soData, Fmt.data(base));
      case FiltroPeriodo.semana:
        final ini = base.inicioSemana;
        final fim = base.fimSemana;
        return (ini, fim, '${Fmt.dataCurta(ini)} a ${Fmt.data(fim)}');
      case FiltroPeriodo.mes:
        return (base.inicioMes, base.fimMes, Fmt.mesAno(base));
      case FiltroPeriodo.ano:
        return (base.inicioAno, base.fimAno, 'Ano de ${base.year}');
      case FiltroPeriodo.total:
        final primeira = _lancamentos.primeiraData() ?? base;
        return (primeira.soData, base.fimAno, 'Tudo desde o começo');
    }
  }

  /// O resumo completo de um período — é daqui que saem TODAS as telas
  /// de relatório, o Excel e o PDF.
  ResumoPeriodo resumo(
    FiltroPeriodo filtro, {
    DateTime? referencia,
    bool usarCustoRealAbastecimento = false,
  }) {
    final (inicio, fim, rotulo) = intervaloDe(filtro, referencia: referencia);
    return _resumirComMemoria(
      inicio: inicio,
      fim: fim,
      rotulo: rotulo,
      usarCustoRealAbastecimento: usarCustoRealAbastecimento,
    );
  }

  /// Resumo de um intervalo escolhido à mão.
  ResumoPeriodo resumoPersonalizado({
    required DateTime inicio,
    required DateTime fim,
    String rotulo = 'Período escolhido',
  }) {
    return _resumirComMemoria(inicio: inicio, fim: fim, rotulo: rotulo);
  }

  /// Resumo do período que o motorista selecionou no painel
  /// (ano / mês / semana / dia).
  ResumoPeriodo resumoDe(PeriodoEscolhido periodo) => _resumirComMemoria(
        inicio: periodo.inicio,
        fim: periodo.fim,
        rotulo: periodo.rotulo,
      );

  /// O período IMEDIATAMENTE anterior ao escolhido, para comparar.
  ResumoPeriodo resumoAnteriorDe(PeriodoEscolhido periodo) {
    if (periodo.escopo == EscopoPeriodo.tudo) return ResumoPeriodo.vazio();
    return resumoDe(periodo.anterior);
  }

  /// O coração do desempenho: se este mesmo intervalo já foi calculado
  /// desde a última mudança de dado, devolve o resultado guardado.
  ResumoPeriodo _resumirComMemoria({
    required DateTime inicio,
    required DateTime fim,
    required String rotulo,
    bool usarCustoRealAbastecimento = false,
  }) {
    final chave = '${inicio.millisecondsSinceEpoch}'
        '_${fim.millisecondsSinceEpoch}'
        '_$usarCustoRealAbastecimento'
        '_${_config.custosFixosMensais}';

    final guardado = _memoria[chave];
    if (guardado != null) return guardado;

    final novo = CalculationsService.resumir(
      lancamentos: _lancamentos.porPeriodo(inicio, fim),
      gastos: _gastos.porPeriodo(inicio, fim),
      abastecimentos: _abastecimentos.porPeriodo(inicio, fim),
      inicio: inicio,
      fim: fim,
      rotulo: rotulo,
      custosFixosMensais: _config.custosFixosMensais,
      usarCustoRealAbastecimento: usarCustoRealAbastecimento,
    );

    // Guarda no máximo 40 períodos: o suficiente para o app inteiro e
    // sem risco de encher a memória do celular.
    if (_memoria.length > 40) _memoria.clear();
    _memoria[chave] = novo;
    return novo;
  }

  /// Resumo de hoje (usado na tela inicial).
  ResumoPeriodo get resumoHoje => resumo(FiltroPeriodo.dia);

  /// Os anos que o motorista pode escolher no painel.
  ///
  /// Vai do ano do primeiro lançamento (ou de dois anos atrás, o que for
  /// mais antigo) até dois anos à frente — assim ele já consegue olhar
  /// 2024, 2025, 2026, 2027 e 2028 sem precisar de nada.
  List<int> get anosDisponiveis {
    final guardado = _anosGuardados;
    if (guardado != null) return guardado;

    final atual = DateTime.now().year;
    var menor = atual - 2;
    var maior = atual + 2;

    // As listas já vêm da mais nova para a mais antiga: primeira = recente,
    // última = mais antiga.
    void olhar(List<DateTime> datas) {
      if (datas.isEmpty) return;
      if (datas.first.year > maior) maior = datas.first.year;
      if (datas.last.year < menor) menor = datas.last.year;
    }

    olhar(lancamentos.map((l) => l.data).toList());
    olhar(gastos.map((g) => g.data).toList());
    olhar(abastecimentos.map((a) => a.data).toList());

    final lista = <int>[for (var a = menor; a <= maior; a++) a];
    _anosGuardados = lista;
    return lista;
  }

  List<int>? _anosGuardados;

  /// Resumo do período ANTERIOR ao filtro — para comparar evolução.
  ResumoPeriodo resumoAnterior(FiltroPeriodo filtro) {
    final agora = DateTime.now();
    final DateTime referencia;
    switch (filtro) {
      case FiltroPeriodo.dia:
        referencia = agora.subtract(const Duration(days: 1));
      case FiltroPeriodo.semana:
        referencia = agora.subtract(const Duration(days: 7));
      case FiltroPeriodo.mes:
        referencia = DateTime(agora.year, agora.month - 1, 1);
      case FiltroPeriodo.ano:
        referencia = DateTime(agora.year - 1, 6, 15);
      case FiltroPeriodo.total:
        return ResumoPeriodo.vazio();
    }
    return resumo(filtro, referencia: referencia);
  }

  /// Lucro de cada um dos últimos [dias] dias (mini gráfico da tela inicial).
  /// Devolve sempre a lista completa, inclusive os dias sem trabalho (zero).
  List<({DateTime dia, double lucro})> ultimosDias([int dias = 7]) {
    final hoje = DateTime.now().soData;
    final inicio = DateTime(hoje.year, hoje.month, hoje.day - (dias - 1));
    final r = _resumirComMemoria(
      inicio: inicio,
      fim: DateTime(hoje.year, hoje.month, hoje.day, 23, 59, 59),
      rotulo: 'Últimos $dias dias',
    );
    return <({DateTime dia, double lucro})>[
      for (var i = 0; i < dias; i++)
        (
          dia: inicio.add(Duration(days: i)),
          lucro: r.lucroPorDia[inicio.add(Duration(days: i))] ?? 0.0,
        ),
    ];
  }

  // =====================================================================
  // METAS
  // =====================================================================

  /// Quanto por cento da meta do dia já foi feito.
  double get percentualMetaHoje => CalculationsService.percentualMeta(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  double get progressoMetaHoje => CalculationsService.progressoMeta(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  bool get metaHojeAtingida => CalculationsService.metaAtingida(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  double get faltaParaMetaHoje => CalculationsService.faltaParaMeta(
        realizado: resumoHoje.lucroLiquido,
        meta: _config.metaDiaria,
      );

  // =====================================================================
  // CUSTO POR KM ATUAL (usado na avaliação de corrida)
  // =====================================================================

  /// Custo de combustível por km com os valores atuais do motorista.
  double get custoPorKmAtual => CalculationsService.custoCombustivelPorKm(
        kmPorLitro: _config.kmPorLitroPadrao,
        precoLitro: precoLitroSugerido,
      );
}
