/// -----------------------------------------------------------------------
/// HISTÓRICO DE JORNADAS
/// -----------------------------------------------------------------------
/// Todas as jornadas registradas, agrupadas por dia, com o tempo ativo e
/// as pausas de cada uma.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/jornada.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/jornada_controller.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/estado_vazio.dart';

class HistoricoJornadasScreen extends StatelessWidget {
  const HistoricoJornadasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;
    final controle = context.watch<JornadaController>();
    final agrupado = controle.historicoAgrupado();
    final dias = agrupado.keys.toList()
      ..sort((a, b) => b.compareTo(a));

    return Scaffold(
      appBar: AppBar(title: const Text('Histórico de jornadas')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: dias.isEmpty
            ? EstadoVazio(
                icone: Icons.timer_outlined,
                titulo: 'Nenhuma jornada registrada',
                mensagem: 'Quando você iniciar e encerrar uma jornada, '
                    'ela aparece aqui com o tempo trabalhado.',
                tema: tema,
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 40),
                itemCount: dias.length,
                itemBuilder: (context, i) {
                  final dia = dias[i];
                  final jornadas = agrupado[dia]!;
                  final totalDoDia =
                      CalculationsService.horasDeJornadas(jornadas);

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        // ---- Cabeçalho do dia ----
                        Padding(
                          padding: const EdgeInsets.only(bottom: 9, left: 4),
                          child: Row(
                            children: <Widget>[
                              Text(
                                dia.ehHoje
                                    ? 'Hoje'
                                    : '${Fmt.diaSemana(dia)}, ${Fmt.data(dia)}',
                                style: context.textos.titleMedium,
                              ),
                              const Spacer(),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: tema.primaria.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(99),
                                ),
                                child: Text(
                                  Fmt.horasTexto(totalDoDia),
                                  style: TextStyle(
                                    color: tema.primaria,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        for (final j in jornadas)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: _CartaoJornada(jornada: j, tema: tema),
                          ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}

class _CartaoJornada extends StatelessWidget {
  final Jornada jornada;
  final TemaFarol tema;

  const _CartaoJornada({required this.jornada, required this.tema});

  @override
  Widget build(BuildContext context) {
    final ativo = CalculationsService.tempoAtivoJornada(jornada);
    final pausado = CalculationsService.tempoPausadoJornada(jornada);
    final aberta = jornada.emAndamento;

    return CartaoFarol(
      tema: tema,
      corBorda: aberta ? tema.sucesso : null,
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                aberta ? Icons.play_circle_rounded : Icons.check_circle_rounded,
                size: 19,
                color: aberta ? tema.sucesso : tema.textoSuave,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  '${Fmt.hora(jornada.inicio)} — '
                  '${jornada.fim == null ? "em andamento" : Fmt.hora(jornada.fim!)}',
                  style: context.textos.bodyMedium,
                ),
              ),
              Text(
                Fmt.cronometro(ativo),
                style: context.textos.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: aberta ? tema.sucesso : tema.texto,
                ),
              ),
              const SizedBox(width: 6),
              IconButton(
                visualDensity: VisualDensity.compact,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                icon: Icon(
                  Icons.delete_outline_rounded,
                  size: 19,
                  color: tema.textoSuave,
                ),
                onPressed: () => _apagar(context),
              ),
            ],
          ),
          if (jornada.pausas.isNotEmpty) ...<Widget>[
            const SizedBox(height: 9),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: <Widget>[
                for (final p in jornada.pausas)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: tema.superficieAlta,
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      '${p.motivo} • '
                      '${Fmt.cronometro(p.duracao(DateTime.now()))}',
                      style: TextStyle(
                        color: tema.textoSuave,
                        fontSize: 10.5,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Total parado: ${Fmt.cronometro(pausado)}',
              style: context.textos.bodySmall,
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _apagar(BuildContext context) async {
    AudioService.toqueLeve();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar esta jornada?'),
        content: const Text(
          'O tempo registrado nela será removido do histórico.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: tema.erro),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Apagar'),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    await context.read<JornadaController>().apagar(jornada.id);
    if (context.mounted) context.aviso('Jornada apagada');
  }
}
