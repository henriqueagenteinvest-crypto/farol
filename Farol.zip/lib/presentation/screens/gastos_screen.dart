/// -----------------------------------------------------------------------
/// GASTOS — 12 CATEGORIAS FIXAS
/// -----------------------------------------------------------------------
/// A seleção é visual: o motorista toca no ícone da categoria em vez de
/// abrir uma lista. Cada categoria tem sempre a mesma cor e o mesmo ícone
/// em todo o app.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_icons.dart';
import '../../data/models/gasto.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/estado_vazio.dart';
import '../widgets/painel_widgets.dart';

class GastosScreen extends StatefulWidget {
  const GastosScreen({super.key});

  @override
  State<GastosScreen> createState() => _GastosScreenState();
}

class _GastosScreenState extends State<GastosScreen> {
  /// Categoria usada como filtro da lista. Nulo = mostra todas.
  String? _filtro;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;

    final todos = dados.gastos;
    final lista =
        _filtro == null ? todos : todos.where((g) => g.categoria == _filtro).toList();
    final total = lista.fold<double>(0, (a, g) => a + g.valor);

    // Dois números que ajudam a enxergar o peso das despesas.
    final agora = DateTime.now();
    final gastosDoMes = todos
        .where((g) => g.data.year == agora.year && g.data.month == agora.month)
        .fold<double>(0, (a, g) => a + g.valor);
    final maiorGasto = lista.isEmpty
        ? 0.0
        : lista.map((g) => g.valor).reduce((a, b) => a > b ? a : b);

    return Scaffold(
      appBar: AppBar(title: const Text('Gastos')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: todos.isEmpty
            ? EstadoVazio(
                icone: Icons.receipt_long_rounded,
                titulo: 'Nenhum gasto lançado',
                mensagem: 'Registre manutenção, pedágio, lavagem e as outras '
                    'despesas para saber o lucro de verdade.',
                tema: tema,
                textoBotao: 'Lançar gasto',
                aoTocarBotao: () => _abrirFormulario(context, tema),
              )
            : Column(
                children: <Widget>[
                  // ---------------- Filtro por categoria ----------------
                  SizedBox(
                    height: 46,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      children: <Widget>[
                        _Chip(
                          texto: 'Todas',
                          ativo: _filtro == null,
                          cor: tema.primaria,
                          tema: tema,
                          aoTocar: () => setState(() => _filtro = null),
                        ),
                        for (final c in AppConstants.categoriasGasto)
                          if (todos.any((g) => g.categoria == c))
                            _Chip(
                              texto: c,
                              ativo: _filtro == c,
                              cor: AppIcons.porCategoria(c).cor,
                              tema: tema,
                              aoTocar: () => setState(() => _filtro = c),
                            ),
                      ],
                    ),
                  ),
                  // ---------------- Resumo ----------------
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: Caixa(
                      tema: tema,
                      child: Column(
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      (_filtro == null
                                              ? 'TOTAL DE TODOS OS GASTOS'
                                              : 'TOTAL EM ${_filtro!.toUpperCase()}'),
                                      style: TextStyle(
                                        color: tema.textoSuave,
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.9,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    FittedBox(
                                      fit: BoxFit.scaleDown,
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Fmt.moeda(total),
                                        style: tema.numero(
                                          tamanho: 26,
                                          cor: tema.erro,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.all(11),
                                decoration: BoxDecoration(
                                  color: tema.erro.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  Icons.receipt_long_rounded,
                                  color: tema.erro,
                                  size: 22,
                                ),
                              ),
                            ],
                          ),
                          Divider(height: 20, color: tema.divisor),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: _MiniResumo(
                                  tema: tema,
                                  rotulo: 'Neste mês',
                                  valor: Fmt.moeda(gastosDoMes),
                                ),
                              ),
                              Container(
                                  width: 1, height: 28, color: tema.divisor),
                              Expanded(
                                child: _MiniResumo(
                                  tema: tema,
                                  rotulo: 'Lançamentos',
                                  valor: '${lista.length}',
                                ),
                              ),
                              Container(
                                  width: 1, height: 28, color: tema.divisor),
                              Expanded(
                                child: _MiniResumo(
                                  tema: tema,
                                  rotulo: 'Maior gasto',
                                  valor: Fmt.moeda(maiorGasto),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  // ---------------- Lista ----------------
                  Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(18, 10, 18, 100),
                      itemCount: lista.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, i) => _CartaoGasto(
                        gasto: lista[i],
                        tema: tema,
                        aoTocar: () => _abrirFormulario(
                          context,
                          tema,
                          existente: lista[i],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
      floatingActionButton: todos.isEmpty
          ? null
          : FloatingActionButton.extended(
              onPressed: () => _abrirFormulario(context, tema),
              backgroundColor: tema.primaria,
              foregroundColor: tema.primaria.computeLuminance() > 0.5
                  ? Colors.black
                  : Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Lançar gasto'),
            ),
    );
  }

  void _abrirFormulario(
    BuildContext context,
    TemaFarol tema, {
    Gasto? existente,
  }) {
    AudioService.clique();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: tema.superficie,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(tema.raioBorda + 8),
        ),
      ),
      builder: (_) => _FormularioGasto(existente: existente),
    );
  }
}

// =======================================================================
class _Chip extends StatelessWidget {
  final String texto;
  final bool ativo;
  final Color cor;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _Chip({
    required this.texto,
    required this.ativo,
    required this.cor,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8, top: 6, bottom: 6),
      child: GestureDetector(
        onTap: () {
          AudioService.toqueLeve();
          aoTocar();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
          decoration: BoxDecoration(
            color: ativo ? cor : tema.superficieAlta,
            borderRadius: BorderRadius.circular(99),
          ),
          child: Text(
            texto,
            style: TextStyle(
              color: ativo
                  ? (cor.computeLuminance() > 0.5 ? Colors.black : Colors.white)
                  : tema.texto,
              fontSize: 13,
              fontWeight: ativo ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
class _CartaoGasto extends StatelessWidget {
  final Gasto gasto;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _CartaoGasto({
    required this.gasto,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final visual = AppIcons.porCategoria(gasto.categoriaValida);

    return CartaoFarol(
      tema: tema,
      aoTocar: aoTocar,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      child: Row(
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: visual.cor.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(visual.icone, color: visual.cor, size: 21),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  gasto.categoriaValida,
                  style: context.textos.titleMedium,
                ),
                const SizedBox(height: 2),
                Text(
                  gasto.descricao.isEmpty
                      ? Fmt.data(gasto.data)
                      : '${Fmt.data(gasto.data)} • ${gasto.descricao}',
                  style: context.textos.bodySmall,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            Fmt.moeda(gasto.valor),
            style: context.textos.titleMedium?.copyWith(
              color: tema.erro,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// FORMULÁRIO DE GASTO
// =======================================================================
class _FormularioGasto extends StatefulWidget {
  final Gasto? existente;
  const _FormularioGasto({this.existente});

  @override
  State<_FormularioGasto> createState() => _FormularioGastoState();
}

class _FormularioGastoState extends State<_FormularioGasto> {
  final _formulario = GlobalKey<FormState>();
  final _valor = TextEditingController();
  final _descricao = TextEditingController();

  late DateTime _data;
  late String _categoria;

  bool get _editando => widget.existente != null;

  @override
  void initState() {
    super.initState();
    final g = widget.existente;
    _data = g?.data ?? DateTime.now();
    _categoria = g?.categoriaValida ?? AppConstants.categoriasGasto.first;
    if (g != null) {
      _valor.text = Fmt.numero(g.valor);
      _descricao.text = g.descricao;
    }
  }

  @override
  void dispose() {
    _valor.dispose();
    _descricao.dispose();
    super.dispose();
  }

  Future<void> _salvar() async {
    if (!_formulario.currentState!.validate()) {
      AudioService.erro();
      return;
    }
    final r = await context.read<DadosController>().salvarGasto(
          Gasto(
            id: widget.existente?.id,
            data: _data,
            categoria: _categoria,
            descricao: _descricao.text.trim(),
            valor: Fmt.paraDoubleOuZero(_valor.text),
            criadoEm: widget.existente?.criadoEm,
          ),
        );
    if (!mounted) return;
    if (r.falhouDeVez) {
      AudioService.erro();
      context.aviso('Este celular recusou guardar o gasto. '
          'Veja Mais → Diagnóstico.', erro: true);
      return;
    }
    AudioService.sucesso();
    // O aviso vem ANTES de fechar: depois do pop esta tela já não existe
    // mais e a mensagem se perderia.
    context.aviso(
      r.soNaMemoria ? 'Gasto lançado, mas não gravado no disco.' : 'Gasto salvo!',
      erro: r.soNaMemoria,
    );
    Navigator.of(context).pop();
  }

  Future<void> _apagar() async {
    try {
      await context.read<DadosController>().apagarGasto(widget.existente!.id);
    } catch (e) {
      if (!mounted) return;
      context.aviso('Não deu para apagar o gasto.', erro: true);
      return;
    }
    if (!mounted) return;
    context.aviso('Gasto apagado');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, rolagem) => Form(
          key: _formulario,
          child: ListView(
            controller: rolagem,
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 30),
            children: <Widget>[
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: tema.textoSuave.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      _editando ? 'Editar gasto' : 'Novo gasto',
                      style: context.textos.headlineSmall,
                    ),
                  ),
                  if (_editando)
                    IconButton(
                      icon: Icon(
                        Icons.delete_outline_rounded,
                        color: tema.erro,
                      ),
                      onPressed: _apagar,
                    ),
                ],
              ),
              const SizedBox(height: 22),

              // ---------------- Escolha visual da categoria ----------------
              Text('Categoria', style: context.textos.labelMedium),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.35,
                children: <Widget>[
                  for (final c in AppConstants.categoriasGasto)
                    _BotaoCategoria(
                      categoria: c,
                      selecionada: c == _categoria,
                      tema: tema,
                      aoTocar: () {
                        AudioService.toqueLeve();
                        setState(() => _categoria = c);
                      },
                    ),
                ],
              ),
              const SizedBox(height: 24),

              CampoData(
                data: _data,
                tema: tema,
                aoMudar: (d) => setState(() => _data = d),
              ),
              const SizedBox(height: 16),
              CampoFarol.dinheiro(
                controlador: _valor,
                rotulo: 'Valor do gasto',
                validador: (v) =>
                    Validadores.valorPositivo(v, campo: 'O valor do gasto'),
              ),
              const SizedBox(height: 16),
              CampoFarol(
                controlador: _descricao,
                rotulo: 'Descrição (opcional)',
                dica: 'Ex.: troca de óleo',
                icone: Icons.notes_rounded,
              ),
              const SizedBox(height: 28),
              BotaoGrande(
                texto: 'Salvar gasto',
                icone: Icons.check_circle_rounded,
                tema: tema,
                aoTocar: _salvar,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BotaoCategoria extends StatelessWidget {
  final String categoria;
  final bool selecionada;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _BotaoCategoria({
    required this.categoria,
    required this.selecionada,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final visual = AppIcons.porCategoria(categoria);

    return GestureDetector(
      onTap: aoTocar,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: selecionada
              ? visual.cor.withValues(alpha: 0.2)
              : tema.superficieAlta,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selecionada ? visual.cor : Colors.transparent,
            width: 2,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(visual.icone, color: visual.cor, size: 23),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                categoria,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 10.5,
                  height: 1.15,
                  color: selecionada ? visual.cor : tema.textoSuave,
                  fontWeight:
                      selecionada ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
class _MiniResumo extends StatelessWidget {
  final TemaFarol tema;
  final String rotulo;
  final String valor;

  const _MiniResumo({
    required this.tema,
    required this.rotulo,
    required this.valor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(valor, style: tema.numero(tamanho: 15)),
        ),
        const SizedBox(height: 3),
        Text(
          rotulo.toUpperCase(),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: tema.textoSuave,
            fontSize: 9.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }
}
