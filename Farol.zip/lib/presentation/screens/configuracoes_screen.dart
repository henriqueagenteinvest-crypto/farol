/// -----------------------------------------------------------------------
/// CONFIGURAÇÕES
/// -----------------------------------------------------------------------
/// Perfil, metas, custos fixos, padrões do carro, tema, animações, sons e
/// gerenciamento de dados.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';

class ConfiguracoesScreen extends StatelessWidget {
  const ConfiguracoesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;
    final config = app.config;
    final motorista = app.motorista;

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 40),
          children: <Widget>[
            // ---------------- PERFIL ----------------
            const TituloSecao(texto: 'Perfil', icone: Icons.person_rounded),
            CartaoFarol(
              tema: tema,
              aoTocar: () {
                AudioService.clique();
                Navigator.of(context).pushNamed(AppRoutes.login);
              },
              child: Row(
                children: <Widget>[
                  CircleAvatar(
                    radius: 25,
                    backgroundColor: tema.primaria.withValues(alpha: 0.18),
                    child: Text(
                      (motorista?.primeiroNome.isNotEmpty ?? false)
                          ? motorista!.primeiroNome[0].toUpperCase()
                          : '?',
                      style: TextStyle(
                        color: tema.primaria,
                        fontSize: 21,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          motorista?.nome ?? 'Sem cadastro',
                          style: context.textos.titleLarge,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          motorista?.descricaoCarro ?? '',
                          style: context.textos.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.chevron_right_rounded,
                    color: tema.textoSuave,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ---------------- APARÊNCIA ----------------
            const TituloSecao(
              texto: 'Aparência e conforto',
              icone: Icons.palette_rounded,
            ),
            CartaoFarol(
              tema: tema,
              child: Column(
                children: <Widget>[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.color_lens_rounded,
                        color: tema.primaria),
                    title: const Text('Aparência'),
                    subtitle: Text(
                      '${app.modoTema.rotulo} • ${app.modoVisualizacao.rotulo}',
                      style: context.textos.bodySmall,
                    ),
                    trailing: Icon(
                      Icons.chevron_right_rounded,
                      color: tema.textoSuave,
                    ),
                    onTap: () {
                      AudioService.clique();
                      Navigator.of(context).pushNamed(AppRoutes.aparencia);
                    },
                  ),
                  const Divider(height: 6),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary: Icon(Icons.animation_rounded,
                        color: tema.secundaria),
                    title: const Text('Animações'),
                    subtitle: Text(
                      'Desligue se o seu celular estiver lento',
                      style: context.textos.bodySmall,
                    ),
                    value: config.animacoesAtivas,
                    onChanged: (v) {
                      AudioService.toqueLeve();
                      context.read<AppController>().alternarAnimacoes(v);
                    },
                  ),
                  const Divider(height: 6),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary:
                        Icon(Icons.volume_up_rounded, color: tema.alerta),
                    title: const Text('Sons'),
                    subtitle: Text(
                      'Toques de botão e som ao bater a meta',
                      style: context.textos.bodySmall,
                    ),
                    value: config.sonsAtivos,
                    onChanged: (v) {
                      context.read<AppController>().alternarSons(v);
                      AudioService.clique();
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ---------------- METAS ----------------
            const TituloSecao(
              texto: 'Suas metas de lucro',
              icone: Icons.flag_rounded,
            ),
            CartaoFarol(
              tema: tema,
              child: Column(
                children: <Widget>[
                  _LinhaEditavel(
                    icone: Icons.today_rounded,
                    rotulo: 'Meta por dia',
                    valor: Fmt.moeda(config.metaDiaria),
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: 'Meta de lucro por dia',
                      ajuda: 'Quanto você quer que sobre no bolso por dia '
                          'de trabalho.',
                      atual: config.metaDiaria,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarMetas(diaria: v),
                    ),
                  ),
                  const Divider(height: 20),
                  _LinhaEditavel(
                    icone: Icons.date_range_rounded,
                    rotulo: 'Meta por semana',
                    valor: Fmt.moeda(config.metaSemanal),
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: 'Meta de lucro por semana',
                      atual: config.metaSemanal,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarMetas(semanal: v),
                    ),
                  ),
                  const Divider(height: 20),
                  _LinhaEditavel(
                    icone: Icons.calendar_month_rounded,
                    rotulo: 'Meta por mês',
                    valor: Fmt.moeda(config.metaMensal),
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: 'Meta de lucro por mês',
                      atual: config.metaMensal,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarMetas(mensal: v),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ---------------- CARRO E CUSTOS ----------------
            const TituloSecao(
              texto: 'Seu veículo e seus custos',
              icone: Icons.directions_car_rounded,
            ),
            CartaoFarol(
              tema: tema,
              child: Column(
                children: <Widget>[
                  _LinhaEditavel(
                    icone: Icons.speed_rounded,
                    rotulo: 'Consumo do veículo',
                    // A unidade acompanha o combustível: km/L, km/m³ ou
                    // km/kWh. A conta é a mesma; só o nome muda.
                    valor: '${Fmt.numero(config.kmPorLitroPadrao, casas: 1)} '
                        '${AppConstants.rendimentoDe(config.combustivelPadrao)}',
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: 'Consumo '
                          '(${AppConstants.rendimentoDe(config.combustivelPadrao)})',
                      ajuda: 'Quantos quilômetros o seu veículo faz com '
                          '1 ${AppConstants.unidadeDe(config.combustivelPadrao)}. '
                          'Se não souber, use 12.',
                      atual: config.kmPorLitroPadrao,
                      dinheiro: false,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarPadroesVeiculo(kmPorLitro: v),
                    ),
                  ),
                  const Divider(height: 20),
                  _LinhaEditavel(
                    icone: Icons.local_gas_station_rounded,
                    rotulo: AppConstants.precoDe(config.combustivelPadrao),
                    valor: Fmt.moeda(config.precoLitroPadrao),
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: AppConstants.precoDe(config.combustivelPadrao),
                      ajuda: 'Serve como sugestão nos formulários.',
                      atual: config.precoLitroPadrao,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarPadroesVeiculo(precoLitro: v),
                    ),
                  ),
                  const Divider(height: 20),
                  _LinhaEditavel(
                    icone: Icons.home_work_rounded,
                    rotulo: 'Custos fixos do mês',
                    valor: Fmt.moeda(config.custosFixosMensais),
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: 'Custos fixos mensais',
                      ajuda: 'Some tudo que você paga todo mês por causa do '
                          'trabalho: aluguel do carro, seguro parcelado, '
                          'internet, celular. O app desconta isso no '
                          'relatório para mostrar o lucro de verdade.',
                      atual: config.custosFixosMensais,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarPadroesVeiculo(custosFixos: v),
                    ),
                  ),
                  const Divider(height: 20),
                  _LinhaEditavel(
                    icone: Icons.percent_rounded,
                    rotulo: 'Margem de lucro que você quer',
                    valor:
                        Fmt.percentual(config.margemLucroAlvo, casas: 0),
                    tema: tema,
                    aoTocar: () => _editarValor(
                      context,
                      titulo: 'Margem de lucro desejada (%)',
                      ajuda: 'É a fatia do bruto que você quer que sobre '
                          'como lucro. Serve de referência nos relatórios.',
                      atual: config.margemLucroAlvo,
                      dinheiro: false,
                      aoSalvar: (v) => context
                          .read<AppController>()
                          .salvarPadroesVeiculo(margemAlvo: v),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SeletorOpcoes(
                    rotulo: 'Tipo de veículo',
                    opcoes: AppConstants.tiposVeiculo,
                    selecionada: config.tipoVeiculoPadrao,
                    tema: tema,
                    aoSelecionar: (v) => context
                        .read<AppController>()
                        .trocarTipoVeiculoPadrao(v),
                  ),
                  const SizedBox(height: 16),
                  SeletorOpcoes(
                    rotulo: 'Combustível ou energia que você mais usa',
                    opcoes: AppConstants.tiposCombustivel,
                    selecionada: config.combustivelPadrao,
                    tema: tema,
                    aoSelecionar: (v) => context
                        .read<AppController>()
                        .salvarPadroesVeiculo(combustivel: v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ---------------- DADOS ----------------
            const TituloSecao(
              texto: 'Seus dados',
              icone: Icons.storage_rounded,
            ),
            CartaoFarol(
              tema: tema,
              child: Column(
                children: <Widget>[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading:
                        Icon(Icons.ios_share_rounded, color: tema.sucesso),
                    title: const Text('Exportar cópia de segurança'),
                    subtitle: Text(
                      'Gere o Excel e o PDF e guarde em outro lugar',
                      style: context.textos.bodySmall,
                    ),
                    trailing: Icon(
                      Icons.chevron_right_rounded,
                      color: tema.textoSuave,
                    ),
                    onTap: () {
                      AudioService.clique();
                      Navigator.of(context).pushNamed(AppRoutes.exportar);
                    },
                  ),
                  const Divider(height: 6),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading:
                        Icon(Icons.cleaning_services_rounded,
                            color: tema.alerta),
                    title: const Text('Limpar lançamentos'),
                    subtitle: Text(
                      'Apaga dias, gastos, abastecimentos e jornadas. '
                      'Mantém seu cadastro.',
                      style: context.textos.bodySmall,
                    ),
                    onTap: () => _confirmarLimpeza(context, tema,
                        tudo: false),
                  ),
                  const Divider(height: 6),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading:
                        Icon(Icons.delete_forever_rounded, color: tema.erro),
                    title: Text(
                      'Apagar tudo',
                      style: TextStyle(color: tema.erro),
                    ),
                    subtitle: Text(
                      'Volta o app ao estado de recém-instalado',
                      style: context.textos.bodySmall,
                    ),
                    onTap: () =>
                        _confirmarLimpeza(context, tema, tudo: true),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ---------------- SOBRE ----------------
            Center(
              child: Column(
                children: <Widget>[
                  Text(
                    '${AppConstants.nomeApp} ${AppConstants.versao}',
                    style: context.textos.bodySmall,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        Icons.wifi_off_rounded,
                        size: 13,
                        color: tema.textoSuave,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'Funciona sem internet — nada sai do seu celular',
                        style: context.textos.bodySmall,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // EDIÇÃO DE UM VALOR
  // ---------------------------------------------------------------------
  Future<void> _editarValor(
    BuildContext context, {
    required String titulo,
    required double atual,
    required ValueChanged<double> aoSalvar,
    String? ajuda,
    bool dinheiro = true,
  }) async {
    AudioService.toqueLeve();
    final controlador = TextEditingController(
      text: Fmt.numero(atual, casas: dinheiro ? 2 : 1),
    );
    final tema = context.read<AppController>().tema;

    final novo = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(titulo),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            if (ajuda != null) ...<Widget>[
              Text(ajuda, style: Theme.of(ctx).textTheme.bodySmall),
              const SizedBox(height: 16),
            ],
            if (dinheiro)
              CampoFarol.dinheiro(
                controlador: controlador,
                rotulo: 'Valor',
              )
            else
              CampoFarol.decimal(
                controlador: controlador,
                rotulo: 'Valor',
                icone: Icons.tag_rounded,
              ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: tema.primaria,
              minimumSize: const Size(110, 46),
            ),
            onPressed: () =>
                Navigator.of(ctx).pop(Fmt.paraDouble(controlador.text)),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );

    controlador.dispose();
    if (novo == null) return;
    aoSalvar(novo);
    AudioService.sucesso();
    if (context.mounted) context.aviso('Salvo!');
  }

  // ---------------------------------------------------------------------
  // LIMPEZA DE DADOS
  // ---------------------------------------------------------------------
  Future<void> _confirmarLimpeza(
    BuildContext context,
    TemaFarol tema, {
    required bool tudo,
  }) async {
    AudioService.toqueLeve();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: Icon(Icons.warning_rounded, color: tema.erro, size: 34),
        title: Text(tudo ? 'Apagar TUDO?' : 'Limpar os lançamentos?'),
        content: Text(
          tudo
              ? 'Isso apaga seus lançamentos, gastos, abastecimentos, '
                  'jornadas, cadastro e configurações. Não tem como voltar '
                  'atrás.\n\nSe ainda não exportou uma cópia, cancele e '
                  'exporte antes.'
              : 'Isso apaga os lançamentos, gastos, abastecimentos e '
                  'jornadas. Seu cadastro e suas preferências continuam.\n\n'
                  'Não tem como voltar atrás.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: tema.erro),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(tudo ? 'Apagar tudo' : 'Limpar'),
          ),
        ],
      ),
    );

    if (ok != true || !context.mounted) return;

    final app = context.read<AppController>();
    if (tudo) {
      await app.apagarTudo();
      if (!context.mounted) return;
      Navigator.of(context).pushNamedAndRemoveUntil(
        AppRoutes.login,
        (_) => false,
      );
    } else {
      await app.limparMovimentacoes();
      // Manda o controller de dados jogar fora as contas guardadas e
      // recalcular do zero — senão as telas continuariam mostrando os
      // números antigos.
      if (!context.mounted) return;
      context.read<DadosController>().recarregar();
      context.aviso('Lançamentos apagados');
    }
  }
}

// =======================================================================
class _LinhaEditavel extends StatelessWidget {
  final IconData icone;
  final String rotulo;
  final String valor;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _LinhaEditavel({
    required this.icone,
    required this.rotulo,
    required this.valor,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: aoTocar,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: <Widget>[
            Icon(icone, size: 19, color: tema.textoSuave),
            const SizedBox(width: 12),
            Expanded(
              child: Text(rotulo, style: context.textos.bodyMedium),
            ),
            Text(
              valor,
              style: context.textos.titleMedium?.copyWith(
                color: tema.primaria,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.edit_rounded,
              size: 15,
              color: tema.textoSuave.withValues(alpha: 0.6),
            ),
          ],
        ),
      ),
    );
  }
}
