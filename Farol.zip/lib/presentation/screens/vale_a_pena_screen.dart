/// -----------------------------------------------------------------------
/// "VALE A PENA ACEITAR ESTA CORRIDA?"
/// -----------------------------------------------------------------------
/// O motorista digita o valor que o app ofereceu e a distância total
/// (ida até o passageiro + a viagem) e vê na hora se compensa, com base no
/// custo REAL de combustível do carro dele.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../domain/entities/resumo_periodo.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';

class ValeAPenaScreen extends StatefulWidget {
  const ValeAPenaScreen({super.key});

  @override
  State<ValeAPenaScreen> createState() => _ValeAPenaScreenState();
}

class _ValeAPenaScreenState extends State<ValeAPenaScreen> {
  final _oferta = TextEditingController();
  final _kmAteOPassageiro = TextEditingController();
  final _kmDaViagem = TextEditingController();

  @override
  void dispose() {
    _oferta.dispose();
    _kmAteOPassageiro.dispose();
    _kmDaViagem.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;

    final kmTotal = Fmt.paraDoubleOuZero(_kmAteOPassageiro.text) +
        Fmt.paraDoubleOuZero(_kmDaViagem.text);
    final oferta = Fmt.paraDoubleOuZero(_oferta.text);
    final custoKm = dados.custoPorKmAtual;

    final avaliacao = CalculationsService.avaliarCorrida(
      valorOferta: oferta,
      kmTotal: kmTotal,
      custoPorKmCombustivel: custoKm,
      margemAlvo: app.config.margemLucroAlvo,
    );

    final preencheu = oferta > 0 && kmTotal > 0;

    return Scaffold(
      appBar: AppBar(title: const Text('Vale a pena?')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
          children: <Widget>[
            Text(
              'Digite o valor que o app ofereceu e a distância. Eu comparo '
              'com o custo de combustível do seu carro e digo se compensa.',
              style: context.textos.bodyMedium?.copyWith(
                color: tema.textoSuave,
              ),
            ),
            const SizedBox(height: 24),

            CampoFarol.dinheiro(
              controlador: _oferta,
              rotulo: 'Valor da corrida',
              aoMudar: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(
                  child: CampoFarol.decimal(
                    controlador: _kmAteOPassageiro,
                    rotulo: 'KM até o passageiro',
                    icone: Icons.navigation_rounded,
                    sufixo: 'km',
                    aoMudar: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CampoFarol.decimal(
                    controlador: _kmDaViagem,
                    rotulo: 'KM da viagem',
                    icone: Icons.route_rounded,
                    sufixo: 'km',
                    aoMudar: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            if (!preencheu)
              CartaoFarol(
                tema: tema,
                child: Row(
                  children: <Widget>[
                    Icon(
                      Icons.touch_app_rounded,
                      color: tema.textoSuave,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Preencha o valor e pelo menos uma das distâncias.',
                        style: context.textos.bodyMedium,
                      ),
                    ),
                  ],
                ),
              )
            else
              _Veredicto(tema: tema, avaliacao: avaliacao),

            const SizedBox(height: 22),

            // ---------------- Base do cálculo ----------------
            CartaoFarol(
              tema: tema,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.settings_rounded,
                        size: 17,
                        color: tema.textoSuave,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'De onde vem esse cálculo',
                        style: context.textos.titleMedium,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _Item(
                    'Consumo do seu carro',
                    '${Fmt.numero(app.config.kmPorLitroPadrao, casas: 1)} km/L',
                  ),
                  const SizedBox(height: 8),
                  _Item(
                    'Preço do litro',
                    Fmt.moeda(dados.precoLitroSugerido),
                  ),
                  const SizedBox(height: 8),
                  _Item('Custo por KM', Fmt.moeda(custoKm)),
                  const SizedBox(height: 8),
                  _Item(
                    'Margem que você quer',
                    Fmt.percentual(app.config.margemLucroAlvo, casas: 0),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Dá para mudar esses valores em Configurações.',
                    style: context.textos.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final String rotulo;
  final String valor;
  const _Item(this.rotulo, this.valor);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Text(rotulo, style: context.textos.bodyMedium),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// =======================================================================
// O VEREDICTO
// =======================================================================
class _Veredicto extends StatelessWidget {
  final TemaFarol tema;
  final AvaliacaoCorrida avaliacao;

  const _Veredicto({required this.tema, required this.avaliacao});

  @override
  Widget build(BuildContext context) {
    final Color cor;
    final IconData icone;
    switch (avaliacao.veredicto) {
      case VeredictoCorrida.aceitar:
        cor = tema.sucesso;
        icone = Icons.thumb_up_rounded;
      case VeredictoCorrida.atencao:
        cor = tema.alerta;
        icone = Icons.warning_rounded;
      case VeredictoCorrida.recusar:
        cor = tema.erro;
        icone = Icons.thumb_down_rounded;
    }

    return Column(
      children: <Widget>[
        // ---- Selo grande com a resposta ----
        AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 20),
          decoration: BoxDecoration(
            color: cor.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(tema.raioBorda),
            border: Border.all(color: cor, width: 2),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: cor.withValues(alpha: 0.25),
                blurRadius: 24,
                spreadRadius: -6,
              ),
            ],
          ),
          child: Column(
            children: <Widget>[
              Icon(icone, color: cor, size: 40),
              const SizedBox(height: 12),
              Text(
                avaliacao.veredicto.rotulo.toUpperCase(),
                style: context.textos.headlineMedium?.copyWith(
                  color: cor,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),

              // O número que decide: quanto sobra no bolso. Vem grande
              // porque, no trânsito, o motorista tem dois segundos para
              // olhar e resolver.
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  Fmt.moeda(avaliacao.lucroEstimado),
                  style: tema.numero(tamanho: 38, cor: cor, espacamento: -1.2),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'sobra para você nesta corrida',
                style: context.textos.bodySmall,
              ),
              const SizedBox(height: 10),
              Text(
                avaliacao.veredicto.explicacao,
                textAlign: TextAlign.center,
                style: context.textos.bodySmall,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // ---- A conta aberta ----
        CartaoFarol(
          tema: tema,
          child: Column(
            children: <Widget>[
              _LinhaConta(
                'A corrida paga',
                Fmt.moeda(avaliacao.valorOferta),
                tema.primaria,
              ),
              const Divider(height: 20),
              _LinhaConta(
                'Combustível dos ${Fmt.km(avaliacao.kmTotal)}',
                '− ${Fmt.moeda(avaliacao.custoEstimado)}',
                tema.erro,
              ),
              const Divider(height: 20),
              _LinhaConta(
                'Sobra para você',
                Fmt.moeda(avaliacao.lucroEstimado),
                avaliacao.lucroEstimado >= 0 ? tema.sucesso : tema.erro,
                destaque: true,
              ),
              const Divider(height: 20),
              _LinhaConta(
                'Margem de lucro',
                Fmt.percentual(avaliacao.margem),
                tema.secundaria,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // ---- Quanto deveria pagar ----
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: tema.superficieAlta,
            borderRadius: BorderRadius.circular(tema.raioBorda * 0.8),
          ),
          child: Row(
            children: <Widget>[
              Icon(Icons.flag_rounded, size: 19, color: tema.primaria),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Para bater a margem que você quer, esta corrida '
                  'precisaria pagar pelo menos '
                  '${Fmt.moeda(avaliacao.valorMinimoIdeal)}.',
                  style: context.textos.bodySmall,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Lembre que o combustível não é o único custo: manutenção, pneu '
          'e desgaste também pesam. Use isso como referência rápida.',
          textAlign: TextAlign.center,
          style: context.textos.bodySmall,
        ),
      ],
    );
  }
}

class _LinhaConta extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;
  final bool destaque;

  const _LinhaConta(
    this.rotulo,
    this.valor,
    this.cor, {
    this.destaque = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Text(
            rotulo,
            style: destaque
                ? context.textos.titleMedium
                : context.textos.bodyMedium,
          ),
        ),
        Text(
          valor,
          style: (destaque
                  ? context.textos.headlineSmall
                  : context.textos.titleMedium)
              ?.copyWith(color: cor, fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}
