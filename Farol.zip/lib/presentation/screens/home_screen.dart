/// -----------------------------------------------------------------------
/// HOJE — a tela que o motorista abre no meio do trabalho
/// -----------------------------------------------------------------------
/// Uma pergunta só: COMO ESTÁ O MEU DIA AGORA?
///
///   1. quem é você e qual o carro
///   2. o lucro de hoje, com o anel da meta
///   3. começar/continuar a jornada — com PAUSAR bem à vista
///   4. os quatro números do dia
///   5. as ações rápidas
///   6. os últimos 7 dias
///
/// Nenhuma conta é feita aqui: todo número vem pronto do DadosController,
/// que por sua vez usa o CalculationsService.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../data/gravacao_segura.dart';
import '../../services/audio_service.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../controllers/jornada_controller.dart';
import '../widgets/confete_meta.dart';
import '../widgets/painel_widgets.dart';
import 'lancamento_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final jornada = context.watch<JornadaController>();

    final tema = app.tema;
    final animar = app.animacoesAtivas;
    final hoje = dados.resumoHoje;

    final custoKm = dados.custoPorKmAtual;
    final progresso = dados.progressoMetaHoje;
    final percentual = dados.percentualMetaHoje;
    final bateuMeta = dados.metaHojeAtingida;

    final gastosDeHoje =
        dados.gastos.where((g) => g.data.ehHoje).length;

    return Stack(
      children: <Widget>[
        Column(
          children: <Widget>[
            SafeArea(
              bottom: false,
              child: BarraTopo(
                tema: tema,
                nome: app.motorista?.primeiroNome ?? '',
                carro: app.motorista?.modeloCarro ?? '',
                salvo: !DiarioDeErros.temErro,
                alerta: DiarioDeErros.temErro
                    ? 'Houve problema ao gravar no celular'
                    : null,
                aoTrocarBrilho: () => context
                    .read<AppController>()
                    .trocarModoTema(
                      tema.ehEscuro ? ModoTema.claro : ModoTema.escuro,
                    ),
                aoAbrirPerfil: () {
                  AudioService.toqueLeve();
                  Navigator.of(context).pushNamed(AppRoutes.login);
                },
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.fromLTRB(
                  tema.compacto ? 12 : 16,
                  16,
                  tema.compacto ? 12 : 16,
                  110,
                ),
                children: <Widget>[
                  // ---------- SAUDAÇÃO ----------
                  Text(
                    app.saudacaoCompleta,
                    style: context.textos.headlineMedium,
                  ),
                  const SizedBox(height: 4),
                  _LinhaData(tema: tema, custoKm: custoKm),
                  SizedBox(height: tema.espaco),

                  // ---------- LUCRO DE HOJE ----------
                  CartaoDestaque(
                    tema: tema,
                    rotulo: 'Lucro de hoje',
                    valor: Fmt.moeda(hoje.lucroLiquido),
                    detalhe: '${Fmt.inteiro(hoje.corridas)} corridas · '
                        '${Fmt.km(hoje.km)} · '
                        '${Fmt.horasTexto(hoje.horas)} · '
                        '${Fmt.moeda(hoje.ganhoPorHora)}/h',
                    progressoMeta: progresso,
                    textoAnel: '${Fmt.numero(percentual, casas: 0)}%',
                    animar: animar,
                    negativo: hoje.lucroLiquido < 0,
                  ),
                  SizedBox(height: tema.espaco),

                  // ---------- JORNADA ----------
                  _BlocoJornada(tema: tema, jornada: jornada, animar: animar),
                  SizedBox(height: tema.espaco),

                  // ---------- OS NÚMEROS DO DIA ----------
                  _GradeDoDia(
                    tema: tema,
                    bruto: hoje.valorBruto,
                    combustivel: hoje.custoCombustivel,
                    litros: hoje.litros,
                    gastos: hoje.outrosGastos,
                    quantosGastos: gastosDeHoje,
                    lucroPorKm: hoje.lucroPorKm,
                    km: hoje.km,
                    custoPorKmCarro: custoKm,
                  ),
                  SizedBox(height: tema.espaco + 4),

                  // ---------- AÇÕES RÁPIDAS ----------
                  TituloBloco(tema: tema, texto: 'Ações rápidas'),
                  _Acoes(tema: tema),
                  SizedBox(height: tema.espaco + 4),

                  // ---------- ÚLTIMOS 7 DIAS ----------
                  TituloBloco(
                    tema: tema,
                    texto: 'Últimos 7 dias',
                    acao: _PilhaSemana(
                      tema: tema,
                      feito: dados.ultimosDias(7).fold<double>(
                          0, (a, d) => a + d.lucro),
                      meta: app.config.metaSemanal,
                    ),
                  ),
                  _UltimosDias(
                    tema: tema,
                    dias: dados.ultimosDias(7),
                    animar: animar,
                  ),
                ],
              ),
            ),
          ],
        ),

        // ---------- COMEMORAÇÃO DE META BATIDA ----------
        ConfeteMeta(
          comemorar: bateuMeta && !app.jaComemorouHoje,
          tema: tema,
          animacoesAtivas: animar,
          aoTerminar: () =>
              context.read<AppController>().registrarComemoracao(),
        ),
      ],
    );
  }
}

// =======================================================================
class _LinhaData extends StatelessWidget {
  final TemaFarol tema;
  final double custoKm;

  const _LinhaData({required this.tema, required this.custoKm});

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        style: context.textos.bodySmall,
        children: <InlineSpan>[
          TextSpan(text: Fmt.dataExtenso(DateTime.now())),
          const TextSpan(text: '  ·  custo do seu carro hoje: '),
          TextSpan(
            text: '${Fmt.moeda(custoKm)} por km',
            style: context.textos.bodySmall?.copyWith(
              color: tema.texto,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// BLOCO DA JORNADA — começar, pausar, retomar e encerrar
// =======================================================================
class _BlocoJornada extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;
  final bool animar;

  const _BlocoJornada({
    required this.tema,
    required this.jornada,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    if (!jornada.temJornadaAberta) {
      return Caixa(
        tema: tema,
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'Vai começar agora?',
                    style: context.textos.titleLarge,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Ligue a jornada e o app mede o seu ganho por hora '
                    'em tempo real.',
                    style: context.textos.bodySmall,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            _BotaoCheio(
              tema: tema,
              cor: tema.sucesso,
              icone: Icons.play_arrow_rounded,
              texto: 'Iniciar\njornada',
              aoTocar: () async {
                await context.read<JornadaController>().iniciar();
                if (context.mounted) {
                  context.aviso('Jornada iniciada. Bom trabalho!');
                }
              },
            ),
          ],
        ),
      );
    }

    // ---- Jornada em andamento ----
    final pausada = jornada.pausada;
    final cor = pausada ? tema.alerta : tema.sucesso;

    return Caixa(
      tema: tema,
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  pausada
                      ? 'Pausado — ${jornada.motivoPausaAtual ?? "descanso"}'
                      : 'Trabalhando agora',
                  style: context.textos.titleMedium?.copyWith(color: cor),
                ),
              ),
              // Só o cronômetro se redesenha a cada segundo.
              ValueListenableBuilder<Duration>(
                valueListenable: jornada.tempoAtivoAgora,
                builder: (context, ativo, __) => Text(
                  Fmt.cronometro(ativo),
                  style: tema.numero(tamanho: 22, cor: cor),
                ),
              ),
            ],
          ),
          if (jornada.ultimoErro != null) ...<Widget>[
            const SizedBox(height: 10),
            _AvisoErro(tema: tema, texto: jornada.ultimoErro!),
          ],
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(
                child: BotaoAcao(
                  tema: tema,
                  icone: pausada
                      ? Icons.play_arrow_rounded
                      : Icons.pause_rounded,
                  texto: pausada ? 'Retomar' : 'Pausar',
                  cor: pausada ? tema.sucesso : tema.alerta,
                  aoTocar: () {
                    if (pausada) {
                      context.read<JornadaController>().retomar();
                    } else {
                      _perguntarMotivo(context, tema);
                    }
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: BotaoAcao(
                  tema: tema,
                  icone: Icons.stop_rounded,
                  texto: 'Encerrar',
                  cor: tema.erro,
                  aoTocar: () => _encerrar(context),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Pergunta o motivo da pausa numa folha que sobe de baixo.
  Future<void> _perguntarMotivo(BuildContext context, TemaFarol tema) async {
    const motivos = <(String, IconData)>[
      ('Banheiro', Icons.wc_rounded),
      ('Café', Icons.local_cafe_rounded),
      ('Almoço', Icons.restaurant_rounded),
      ('Descanso', Icons.airline_seat_recline_normal_rounded),
      ('Abastecer', Icons.local_gas_station_rounded),
      ('Outro', Icons.more_horiz_rounded),
    ];

    final escolhido = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: tema.superficie,
      shape: RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(tema.raioBorda + 8)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Por que está parando?',
                  style: Theme.of(ctx).textTheme.headlineSmall),
              const SizedBox(height: 4),
              Text(
                'O tempo parado não conta como trabalho.',
                style: Theme.of(ctx).textTheme.bodySmall,
              ),
              const SizedBox(height: 16),
              for (final m in motivos)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: BotaoAcao(
                    tema: tema,
                    icone: m.$2,
                    texto: m.$1,
                    cor: tema.alerta,
                    aoTocar: () => Navigator.of(ctx).pop(m.$1),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    if (escolhido != null && context.mounted) {
      await context.read<JornadaController>().pausar(escolhido);
    }
  }

  Future<void> _encerrar(BuildContext context) async {
    final confirmou = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Encerrar a jornada?'),
        content: const Text(
          'O tempo trabalhado fica salvo. Em seguida você pode lançar o '
          'dia (valor, KM e corridas).',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Continuar'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Encerrar'),
          ),
        ],
      ),
    );
    if (confirmou != true || !context.mounted) return;

    final horas = await context.read<JornadaController>().encerrar();
    if (!context.mounted) return;
    context.aviso('Jornada encerrada: ${Fmt.horasTexto(horas)} trabalhadas');
    await Navigator.of(context).pushNamed(
      AppRoutes.lancamento,
      arguments: ArgsLancamento(horasSugeridas: horas),
    );
  }
}

// =======================================================================
class _BotaoCheio extends StatelessWidget {
  final TemaFarol tema;
  final Color cor;
  final IconData icone;
  final String texto;
  final VoidCallback aoTocar;

  const _BotaoCheio({
    required this.tema,
    required this.cor,
    required this.icone,
    required this.texto,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final corTexto = TemaFarol.contrasteSobre(cor);
    return Material(
      color: cor,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: () {
          AudioService.clique();
          aoTocar();
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          constraints: const BoxConstraints(minHeight: 58, minWidth: 118),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(icone, color: corTexto, size: 20),
              const SizedBox(width: 7),
              Flexible(
                child: Text(
                  texto,
                  style: TextStyle(
                    color: corTexto,
                    fontSize: 14,
                    height: 1.15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
class _AvisoErro extends StatelessWidget {
  final TemaFarol tema;
  final String texto;

  const _AvisoErro({required this.tema, required this.texto});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: tema.erro.withValues(alpha: 0.13),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: tema.erro.withValues(alpha: 0.45)),
      ),
      child: Row(
        children: <Widget>[
          Icon(Icons.warning_amber_rounded, color: tema.erro, size: 18),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              texto,
              style: context.textos.bodySmall?.copyWith(color: tema.erro),
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// OS QUATRO NÚMEROS DO DIA
// =======================================================================
class _GradeDoDia extends StatelessWidget {
  final TemaFarol tema;
  final double bruto;
  final double combustivel;
  final double litros;
  final double gastos;
  final int quantosGastos;
  final double lucroPorKm;
  final double km;
  final double custoPorKmCarro;

  const _GradeDoDia({
    required this.tema,
    required this.bruto,
    required this.combustivel,
    required this.litros,
    required this.gastos,
    required this.quantosGastos,
    required this.lucroPorKm,
    required this.km,
    required this.custoPorKmCarro,
  });

  @override
  Widget build(BuildContext context) {
    final cartoes = <Widget>[
      CartaoMetrica(
        tema: tema,
        rotulo: 'Bruto do dia',
        valor: Fmt.moeda(bruto),
        detalhe: 'o que os aplicativos mostraram',
      ),
      CartaoMetrica(
        tema: tema,
        rotulo: 'Combustível',
        valor: Fmt.moeda(combustivel),
        detalhe: litros > 0
            ? '${Fmt.litros(litros)} para ${Fmt.km(km)}'
            : 'nada rodado ainda',
        corValor: combustivel > 0 ? tema.erro : null,
      ),
      CartaoMetrica(
        tema: tema,
        rotulo: 'Gastos lançados',
        valor: Fmt.moeda(gastos),
        detalhe: '$quantosGastos lançamento(s) hoje',
        corValor: gastos > 0 ? tema.alerta : null,
      ),
      CartaoMetrica(
        tema: tema,
        rotulo: 'Lucro por km',
        valor: Fmt.moeda(lucroPorKm),
        detalhe: 'seu carro custa ${Fmt.moeda(custoPorKmCarro)}/km',
        corValor: lucroPorKm > 0 ? tema.sucesso : (km > 0 ? tema.erro : null),
        faixa: tema.primaria,
      ),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: tema.compacto ? 1.55 : 1.38,
      children: cartoes,
    );
  }
}

// =======================================================================
// AÇÕES RÁPIDAS
// =======================================================================
class _Acoes extends StatelessWidget {
  final TemaFarol tema;

  const _Acoes({required this.tema});

  @override
  Widget build(BuildContext context) {
    final itens = <(IconData, String, String, Color)>[
      (Icons.add_circle_rounded, 'Lançar o dia', AppRoutes.lancamento,
          tema.primaria),
      (Icons.photo_camera_rounded, 'Ler print', AppRoutes.importarPrint,
          tema.secundaria),
      (Icons.local_gas_station_rounded, 'Abastecer', AppRoutes.abastecimento,
          tema.alerta),
      (Icons.receipt_long_rounded, 'Despesa', AppRoutes.gastos, tema.erro),
      (Icons.calculate_rounded, 'Vale a pena?', AppRoutes.valeAPena,
          tema.sucesso),
      (Icons.workspace_premium_rounded, 'Pontos', AppRoutes.pontos,
          tema.secundaria),
    ];

    return Caixa(
      tema: tema,
      padding: const EdgeInsets.all(12),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 3.1,
        children: <Widget>[
          for (final i in itens)
            BotaoAcao(
              tema: tema,
              icone: i.$1,
              texto: i.$2,
              cor: i.$4,
              aoTocar: () => Navigator.of(context).pushNamed(i.$3),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// PÍLULA DA SEMANA
// =======================================================================
class _PilhaSemana extends StatelessWidget {
  final TemaFarol tema;
  final double feito;
  final double meta;

  const _PilhaSemana({
    required this.tema,
    required this.feito,
    required this.meta,
  });

  @override
  Widget build(BuildContext context) {
    final bateu = meta > 0 && feito >= meta;
    final cor = bateu ? tema.sucesso : tema.primaria;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        meta > 0
            ? '${Fmt.moeda(feito)} de ${Fmt.moeda(meta)}'
            : Fmt.moeda(feito),
        style: TextStyle(
          color: cor,
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// =======================================================================
// ÚLTIMOS DIAS
// =======================================================================
class _UltimosDias extends StatelessWidget {
  final TemaFarol tema;
  final List<({DateTime dia, double lucro})> dias;
  final bool animar;

  const _UltimosDias({
    required this.tema,
    required this.dias,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    // Do mais recente para o mais antigo — é assim que se olha para trás.
    final lista = dias.reversed.toList();

    var maior = 0.0;
    for (final d in lista) {
      final v = d.lucro.abs();
      if (v > maior) maior = v;
    }

    return Caixa(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < lista.length; i++) ...<Widget>[
            if (i > 0) Divider(height: 18, color: tema.divisor),
            _LinhaDia(
              tema: tema,
              dia: lista[i].dia,
              lucro: lista[i].lucro,
              maior: maior,
              animar: animar,
            ),
          ],
        ],
      ),
    );
  }
}

class _LinhaDia extends StatelessWidget {
  final TemaFarol tema;
  final DateTime dia;
  final double lucro;
  final double maior;
  final bool animar;

  const _LinhaDia({
    required this.tema,
    required this.dia,
    required this.lucro,
    required this.maior,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final semLancamento = lucro == 0;
    final cor = semLancamento
        ? tema.textoSuave
        : (lucro > 0 ? tema.sucesso : tema.erro);

    // Divisão protegida: sem dado nenhum, a barra fica vazia.
    final fracao = maior <= 0 ? 0.0 : (lucro.abs() / maior).clamp(0.0, 1.0);

    return Row(
      children: <Widget>[
        SizedBox(
          width: 62,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                Fmt.diaSemana(dia),
                style: context.textos.bodyMedium?.copyWith(
                  fontWeight: dia.ehHoje ? FontWeight.w700 : FontWeight.w500,
                  color: dia.ehHoje ? tema.primaria : tema.texto,
                ),
              ),
              Text(Fmt.dataCurta(dia), style: context.textos.bodySmall),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: fracao),
              duration:
                  animar ? const Duration(milliseconds: 400) : Duration.zero,
              curve: Curves.easeOutCubic,
              builder: (context, f, _) => LinearProgressIndicator(
                value: f,
                minHeight: 8,
                backgroundColor: tema.superficieAlta,
                valueColor: AlwaysStoppedAnimation<Color>(cor),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 84,
          child: Text(
            semLancamento ? '—' : Fmt.moeda(lucro),
            textAlign: TextAlign.right,
            style: tema.numero(tamanho: 13.5, cor: cor, espacamento: 0),
          ),
        ),
      ],
    );
  }
}
