/// -----------------------------------------------------------------------
/// TELA INICIAL (PAINEL DO DIA)
/// -----------------------------------------------------------------------
/// É a primeira coisa que o motorista vê. Mostra como está o dia HOJE e dá
/// acesso rápido ao que ele mais usa.
///
/// A quantidade de informação muda conforme o tema escolhido:
///   • Simples  -> lucro, meta e o botão de jornada
///   • Completo -> tudo acima + os indicadores do dia + mini gráfico
///   • Painel   -> tudo acima + gráficos grandes de evolução e gastos
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../core/navegacao_app.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../controllers/jornada_controller.dart';
import '../widgets/barra_meta.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/confete_meta.dart';
import '../widgets/graficos_farol.dart';
import '../widgets/kpi_card.dart';
import '../widgets/logo_farol.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final jornada = context.watch<JornadaController>();

    final tema = app.tema;
    final resumo = dados.resumoHoje;
    final nivel = tema.nivel;
    final animar = app.animacoesAtivas;

    // A meta considera o lucro do dia. Todos os números vêm prontos
    // do controller, que por sua vez usa o CalculationsService.
    final bateuMeta = dados.metaHojeAtingida;

    return Stack(
      children: <Widget>[
        SafeArea(
          child: RefreshIndicator(
            color: tema.primaria,
            backgroundColor: tema.superficie,
            onRefresh: () async {
              AudioService.toqueLeve();
              await Future<void>.delayed(const Duration(milliseconds: 350));
            },
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
              physics: const AlwaysScrollableScrollPhysics(),
              children: <Widget>[
                _Cabecalho(tema: tema, app: app),
                const SizedBox(height: 20),

                // ---------- LUCRO DO DIA (o número que importa) ----------
                _CartaoLucroDoDia(
                  tema: tema,
                  lucro: resumo.lucroLiquido,
                  bruto: resumo.valorBruto,
                  animar: animar,
                ),
                const SizedBox(height: 16),

                // ---------- META DO DIA ----------
                CartaoFarol(
                  tema: tema,
                  child: BarraMeta(
                    realizado: resumo.lucroLiquido,
                    meta: app.config.metaDiaria,
                    tema: tema,
                    animar: animar,
                  ),
                ),
                const SizedBox(height: 16),

                // ---------- BOTÃO DA JORNADA ----------
                BotaoGrande(
                  texto: jornada.rotuloBotaoPrincipal,
                  icone: jornada.temJornadaAberta
                      ? (jornada.pausada
                          ? Icons.play_arrow_rounded
                          : Icons.timer_rounded)
                      : Icons.play_circle_fill_rounded,
                  tema: tema,
                  cor: jornada.pausada ? tema.alerta : null,
                  aoTocar: () async {
                    if (!jornada.temJornadaAberta) {
                      await context.read<JornadaController>().iniciar();
                      if (context.mounted) {
                        context.aviso('Jornada iniciada. Bom trabalho!');
                      }
                    } else if (jornada.pausada) {
                      await context.read<JornadaController>().retomar();
                    } else {
                      // Já está rodando: leva para a aba Jornada, onde
                      // ficam os botões de pausar e encerrar.
                      NavegacaoApp.irPara(NavegacaoApp.abaJornada);
                    }
                  },
                ),
                if (jornada.temJornadaAberta) ...<Widget>[
                  const SizedBox(height: 10),
                  _FaixaJornadaRodando(tema: tema, jornada: jornada),
                ],
                const SizedBox(height: 16),

                // ---------- ATALHO DO OCR (o destaque do app) ----------
                _AtalhoImportarPrint(tema: tema),
                const SizedBox(height: 22),

                // ---------- INDICADORES DO DIA ----------
                if (nivel != NivelLayout.simples) ...<Widget>[
                  const TituloSecao(
                    texto: 'Seu dia até agora',
                    icone: Icons.today_rounded,
                  ),
                  _GradeIndicadores(tema: tema, dados: dados),
                  const SizedBox(height: 22),
                ],

                // ---------- MINI GRÁFICO DE 7 DIAS ----------
                if (nivel != NivelLayout.simples) ...<Widget>[
                  CartaoFarol(
                    tema: tema,
                    aoTocar: () {
                      AudioService.toqueLeve();
                      Navigator.of(context).pushNamed(AppRoutes.exportar);
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              'Últimos 7 dias',
                              style: context.textos.titleMedium,
                            ),
                            Icon(
                              Icons.chevron_right_rounded,
                              color: tema.textoSuave,
                              size: 20,
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        MiniGrafico7Dias(
                          dados: dados.ultimosDias(),
                          tema: tema,
                          animar: animar,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                ],

                // ---------- GRÁFICOS GRANDES (tema estilo painel) --------
                if (nivel == NivelLayout.dashboard) ...<Widget>[
                  const TituloSecao(
                    texto: 'Evolução do lucro',
                    icone: Icons.show_chart_rounded,
                  ),
                  CartaoFarol(
                    tema: tema,
                    child: GraficoLinhaEvolucao(
                      dados: dados.ultimosDias(14),
                      tema: tema,
                      animar: animar,
                    ),
                  ),
                  const SizedBox(height: 22),
                  const TituloSecao(
                    texto: 'Gastos do mês',
                    icone: Icons.pie_chart_rounded,
                  ),
                  CartaoFarol(
                    tema: tema,
                    child: GraficoPizzaGastos(
                      gastosPorCategoria:
                          dados.resumo(FiltroPeriodo.mes).gastosPorCategoria,
                      tema: tema,
                      animar: animar,
                    ),
                  ),
                  const SizedBox(height: 22),
                ],

                // ---------- ATALHOS RÁPIDOS ----------
                const TituloSecao(
                  texto: 'Atalhos',
                  icone: Icons.bolt_rounded,
                ),
                _Atalhos(tema: tema),
              ],
            ),
          ),
        ),

        // ---------- COMEMORAÇÃO DE META BATIDA ----------
        ConfeteMeta(
          comemorar: bateuMeta && !app.jaComemorouHoje,
          tema: tema,
          animacoesAtivas: animar,
          aoTerminar: () => context.read<AppController>()
              .registrarComemoracao(),
        ),
      ],
    );
  }
}

// =======================================================================
// CABEÇALHO COM SAUDAÇÃO
// =======================================================================
class _Cabecalho extends StatelessWidget {
  final TemaFarol tema;
  final AppController app;

  const _Cabecalho({required this.tema, required this.app});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        LogoFarol(tema: tema, tamanho: 48),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                app.saudacaoCompleta,
                style: context.textos.headlineSmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                Fmt.dataExtenso(DateTime.now()),
                style: context.textos.bodySmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Configurações',
          icon: const Icon(Icons.settings_rounded),
          onPressed: () {
            AudioService.toqueLeve();
            Navigator.of(context).pushNamed(AppRoutes.configuracoes);
          },
        ),
      ],
    );
  }
}

// =======================================================================
// CARTÃO DO LUCRO DO DIA
// =======================================================================
class _CartaoLucroDoDia extends StatelessWidget {
  final TemaFarol tema;
  final double lucro;
  final double bruto;
  final bool animar;

  const _CartaoLucroDoDia({
    required this.tema,
    required this.lucro,
    required this.bruto,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final claro = tema.primaria.computeLuminance() > 0.5;
    final corTexto = claro ? Colors.black87 : Colors.white;

    return CartaoFarol(
      tema: tema,
      comGradiente: true,
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                Icons.savings_rounded,
                color: corTexto.withValues(alpha: 0.85),
                size: 19,
              ),
              const SizedBox(width: 8),
              Text(
                'LUCRO DE HOJE',
                style: TextStyle(
                  color: corTexto.withValues(alpha: 0.85),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // O número sobe de zero até o valor: dá a sensação de "contador".
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: lucro),
            duration:
                animar ? const Duration(milliseconds: 850) : Duration.zero,
            curve: Curves.easeOutCubic,
            builder: (context, valor, _) => FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                Fmt.moeda(valor),
                style: TextStyle(
                  color: corTexto,
                  fontSize: 40,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -1.2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Recebido bruto: ${Fmt.moeda(bruto)}',
            style: TextStyle(
              color: corTexto.withValues(alpha: 0.8),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// FAIXA "JORNADA RODANDO"
// =======================================================================
class _FaixaJornadaRodando extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _FaixaJornadaRodando({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    final pausada = jornada.pausada;
    final cor = pausada ? tema.alerta : tema.sucesso;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(tema.raioBorda * 0.7),
        border: Border.all(color: cor.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: <Widget>[
          Icon(
            pausada ? Icons.pause_circle_rounded : Icons.circle,
            color: cor,
            size: pausada ? 20 : 12,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              pausada
                  ? 'Pausado — ${jornada.motivoPausaAtual ?? "descanso"}'
                  : 'Trabalhando agora',
              style: context.textos.bodyMedium?.copyWith(
                color: cor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            Fmt.cronometro(jornada.tempoAtivo),
            style: context.textos.titleMedium?.copyWith(
              color: cor,
              fontWeight: FontWeight.w700,
              fontFeatures: const <FontFeature>[
                FontFeature.tabularFigures(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// ATALHO PARA IMPORTAR O PRINT (funcionalidade principal)
// =======================================================================
class _AtalhoImportarPrint extends StatelessWidget {
  final TemaFarol tema;

  const _AtalhoImportarPrint({required this.tema});

  @override
  Widget build(BuildContext context) {
    return CartaoFarol(
      tema: tema,
      corBorda: tema.secundaria,
      aoTocar: () {
        AudioService.clique();
        Navigator.of(context).pushNamed(AppRoutes.importarPrint);
      },
      child: Row(
        children: <Widget>[
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: tema.secundaria.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              Icons.photo_camera_rounded,
              color: tema.secundaria,
              size: 25,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Importar print do Uber ou 99',
                  style: context.textos.titleMedium,
                ),
                const SizedBox(height: 3),
                Text(
                  'O app lê a imagem e preenche tudo sozinho',
                  style: context.textos.bodySmall,
                  maxLines: 2,
                ),
              ],
            ),
          ),
          Icon(
            Icons.chevron_right_rounded,
            color: tema.textoSuave,
            size: 22,
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// GRADE DE INDICADORES DO DIA
// =======================================================================
class _GradeIndicadores extends StatelessWidget {
  final TemaFarol tema;
  final DadosController dados;

  const _GradeIndicadores({required this.tema, required this.dados});

  @override
  Widget build(BuildContext context) {
    final r = dados.resumoHoje;

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.45,
      children: <Widget>[
        KpiCard(
          rotulo: 'RECEBIDO BRUTO',
          valor: Fmt.moeda(r.valorBruto),
          icone: Icons.account_balance_wallet_rounded,
          cor: tema.primaria,
          tema: tema,
        ),
        KpiCard(
          rotulo: 'HORAS TRABALHADAS',
          valor: Fmt.horasTexto(r.horas),
          icone: Icons.schedule_rounded,
          cor: tema.secundaria,
          tema: tema,
          complemento: r.horas > 0
              ? '${Fmt.moeda(r.ganhoPorHora)} por hora'
              : null,
        ),
        KpiCard(
          rotulo: 'KM RODADOS',
          valor: Fmt.km(r.km),
          icone: Icons.route_rounded,
          cor: tema.alerta,
          tema: tema,
          complemento: r.km > 0
              ? '${Fmt.moeda(r.custoPorKm)} por km'
              : null,
        ),
        KpiCard(
          rotulo: 'CORRIDAS',
          valor: Fmt.inteiro(r.corridas),
          icone: Icons.local_taxi_rounded,
          cor: tema.sucesso,
          tema: tema,
          complemento: r.corridas > 0
              ? '${Fmt.moeda(r.ticketMedio)} cada'
              : null,
        ),
      ],
    );
  }
}

// =======================================================================
// ATALHOS RÁPIDOS
// =======================================================================
class _Atalhos extends StatelessWidget {
  final TemaFarol tema;

  const _Atalhos({required this.tema});

  @override
  Widget build(BuildContext context) {
    final itens = <(IconData, String, String, Color)>[
      (Icons.local_gas_station_rounded, 'Abastecer', AppRoutes.abastecimento,
          tema.alerta),
      (Icons.receipt_long_rounded, 'Gastos', AppRoutes.gastos, tema.erro),
      (Icons.calculate_rounded, 'Vale a pena?', AppRoutes.valeAPena,
          tema.sucesso),
      (Icons.trending_up_rounded, 'Patrimônio', AppRoutes.simulador,
          tema.secundaria),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 2.5,
      children: <Widget>[
        for (final item in itens)
          CartaoFarol(
            tema: tema,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            aoTocar: () {
              AudioService.clique();
              Navigator.of(context).pushNamed(item.$3);
            },
            child: Row(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: item.$4.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(item.$1, color: item.$4, size: 19),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.$2,
                    style: context.textos.titleMedium,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
