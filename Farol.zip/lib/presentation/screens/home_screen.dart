/// -----------------------------------------------------------------------
/// PAINEL (TELA INICIAL)
/// -----------------------------------------------------------------------
/// A tela é lida de cima para baixo, na ordem que o motorista pediu:
///
///   1. PAINEL ......... escolhe o período: ano, mês, semana ou dia.
///                       Todos os anos, todos os meses, e o dia também
///                       quando ele quiser olhar um dia específico.
///   2. HOJE ........... o lucro de hoje, o bruto recebido e o botão de
///                       iniciar jornada.
///   3. ÚLTIMOS DIAS ... como foram os dias anteriores.
///   4. AÇÕES RÁPIDAS .. começando por ADICIONAR (que abre o lançamento),
///                       depois as outras.
///
/// NADA aqui faz conta. Todo número vem pronto do DadosController, que
/// por sua vez usa o CalculationsService.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../core/navegacao_app.dart';
import '../../domain/entities/periodo_escolhido.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/audio_service.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../controllers/jornada_controller.dart';
import '../widgets/barra_meta.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/confete_meta.dart';
import '../widgets/graficos_farol.dart';
import '../widgets/kpi_card.dart';
import '../widgets/logo_farol.dart';
import '../widgets/seletor_periodo.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  /// O período que o motorista está olhando no painel.
  /// Começa no mês atual — é o recorte mais usado no dia a dia.
  PeriodoEscolhido _periodo = PeriodoEscolhido.hoje();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final jornada = context.watch<JornadaController>();

    final tema = app.tema;
    final animar = app.animacoesAtivas;
    final visual = app.modoVisualizacao;

    final hoje = dados.resumoHoje;
    final periodo = dados.resumoDe(_periodo);

    final bateuMeta = dados.metaHojeAtingida;

    return Stack(
      children: <Widget>[
        SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            physics: const AlwaysScrollableScrollPhysics(),
            children: <Widget>[
              _Cabecalho(tema: tema, app: app),
              const SizedBox(height: 18),

              // ==========================================================
              // 1. PAINEL — escolha do período
              // ==========================================================
              const TituloSecao(
                texto: 'Painel',
                icone: Icons.tune_rounded,
              ),
              SeletorPeriodo(
                periodo: _periodo,
                anos: dados.anosDisponiveis,
                tema: tema,
                aoMudar: (novo) => setState(() => _periodo = novo),
              ),
              const SizedBox(height: 14),

              // Os números do período escolhido, no formato que o
              // motorista definiu em Aparência (grade, lista, etc.).
              _IndicadoresDoPeriodo(
                tema: tema,
                resumo: periodo,
                visual: visual,
              ),
              const SizedBox(height: 16),

              // Gráficos do período — escondidos no modo Compacta, que
              // foi feito justamente para caber tudo numa tela só.
              if (visual != ModoVisualizacao.compacta)
                _GraficosDoPeriodo(
                  tema: tema,
                  resumo: periodo,
                  animar: animar,
                  destaque: visual == ModoVisualizacao.graficos,
                ),
              const SizedBox(height: 12),

              // ==========================================================
              // 2. HOJE
              // ==========================================================
              const TituloSecao(
                texto: 'Hoje',
                icone: Icons.today_rounded,
              ),
              _CartaoLucroDoDia(
                tema: tema,
                lucro: hoje.lucroLiquido,
                bruto: hoje.valorBruto,
                animar: animar,
              ),
              const SizedBox(height: 14),
              CartaoFarol(
                tema: tema,
                child: BarraMeta(
                  realizado: hoje.lucroLiquido,
                  meta: app.config.metaDiaria,
                  tema: tema,
                  animar: animar,
                ),
              ),
              const SizedBox(height: 14),
              BotaoGrande(
                texto: jornada.rotuloBotaoPrincipal,
                icone: jornada.temJornadaAberta
                    ? (jornada.pausada
                        ? Icons.play_arrow_rounded
                        : Icons.timer_rounded)
                    : Icons.play_circle_fill_rounded,
                tema: tema,
                cor: jornada.pausada ? tema.alerta : null,
                aoTocar: () async {
                  if (!jornada.temJornadaAberta) {
                    await context.read<JornadaController>().iniciar();
                    if (context.mounted) {
                      context.aviso('Jornada iniciada. Bom trabalho!');
                    }
                  } else if (jornada.pausada) {
                    await context.read<JornadaController>().retomar();
                  } else {
                    // Já está rodando: leva para a aba Jornada, onde ficam
                    // os botões de pausar e encerrar.
                    NavegacaoApp.irPara(NavegacaoApp.abaJornada);
                  }
                },
              ),
              if (jornada.temJornadaAberta) ...<Widget>[
                const SizedBox(height: 10),
                _FaixaJornadaRodando(tema: tema, jornada: jornada),
              ],
              const SizedBox(height: 22),

              // ==========================================================
              // 3. ÚLTIMOS DIAS
              // ==========================================================
              TituloSecao(
                texto: 'Últimos dias',
                icone: Icons.history_rounded,
                acao: TextButton(
                  onPressed: () {
                    AudioService.toqueLeve();
                    NavegacaoApp.irPara(NavegacaoApp.abaRelatorios);
                  },
                  child: const Text('Ver tudo'),
                ),
              ),
              _UltimosDias(
                tema: tema,
                dias: dados.ultimosDias(7),
                animar: animar,
              ),
              const SizedBox(height: 22),

              // ==========================================================
              // 4. AÇÕES RÁPIDAS
              // ==========================================================
              const TituloSecao(
                texto: 'Ações rápidas',
                icone: Icons.bolt_rounded,
              ),
              _AcoesRapidas(tema: tema),
            ],
          ),
        ),

        // ---------- COMEMORAÇÃO DE META BATIDA ----------
        ConfeteMeta(
          comemorar: bateuMeta && !app.jaComemorouHoje,
          tema: tema,
          animacoesAtivas: animar,
          aoTerminar: () =>
              context.read<AppController>().registrarComemoracao(),
        ),
      ],
    );
  }
}

// =======================================================================
// CABEÇALHO COM SAUDAÇÃO
// =======================================================================
class _Cabecalho extends StatelessWidget {
  final TemaFarol tema;
  final AppController app;

  const _Cabecalho({required this.tema, required this.app});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        LogoFarol(tema: tema, tamanho: 46),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                app.saudacaoCompleta,
                style: context.textos.headlineSmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                Fmt.dataExtenso(DateTime.now()),
                style: context.textos.bodySmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Configurações',
          icon: const Icon(Icons.settings_rounded),
          onPressed: () {
            AudioService.toqueLeve();
            Navigator.of(context).pushNamed(AppRoutes.configuracoes);
          },
        ),
      ],
    );
  }
}

// =======================================================================
// INDICADORES DO PERÍODO ESCOLHIDO
// =======================================================================
/// Os mesmos números, apresentados do jeito que o motorista preferir.
class _IndicadoresDoPeriodo extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;
  final ModoVisualizacao visual;

  const _IndicadoresDoPeriodo({
    required this.tema,
    required this.resumo,
    required this.visual,
  });

  @override
  Widget build(BuildContext context) {
    if (resumo.vazio) {
      return CartaoFarol(
        tema: tema,
        child: Row(
          children: <Widget>[
            Icon(Icons.inbox_rounded, color: tema.textoSuave, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Nada lançado neste período. Escolha outro período acima '
                'ou toque em Adicionar para lançar um dia.',
                style: context.textos.bodySmall,
              ),
            ),
          ],
        ),
      );
    }

    switch (visual) {
      case ModoVisualizacao.lista:
        return _ListaIndicadores(tema: tema, resumo: resumo);
      case ModoVisualizacao.compacta:
        return _CompactoIndicadores(tema: tema, resumo: resumo);
      case ModoVisualizacao.graficos:
      case ModoVisualizacao.grade:
        return _GradeIndicadores(tema: tema, resumo: resumo);
    }
  }
}

/// Os quatro números principais, lado a lado.
class _GradeIndicadores extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;

  const _GradeIndicadores({required this.tema, required this.resumo});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.42,
      children: <Widget>[
        KpiCard(
          rotulo: 'FATURAMENTO',
          valor: Fmt.moeda(resumo.valorBruto),
          icone: Icons.account_balance_wallet_rounded,
          cor: tema.primaria,
          tema: tema,
          complemento: 'o bruto recebido',
        ),
        KpiCard(
          rotulo: 'LUCRO LÍQUIDO',
          valor: Fmt.moeda(resumo.lucroLiquido),
          icone: Icons.savings_rounded,
          cor: resumo.lucroLiquido >= 0 ? tema.sucesso : tema.erro,
          tema: tema,
          complemento: 'o que sobrou pra você',
        ),
        KpiCard(
          rotulo: 'DESPESAS',
          valor: Fmt.moeda(resumo.despesasTotais),
          icone: Icons.receipt_long_rounded,
          cor: tema.erro,
          tema: tema,
          complemento: 'combustível e gastos',
        ),
        KpiCard(
          rotulo: 'LUCRO POR KM',
          valor: Fmt.moeda(resumo.lucroPorKm),
          icone: Icons.route_rounded,
          cor: tema.alerta,
          tema: tema,
          complemento: Fmt.km(resumo.km),
        ),
      ],
    );
  }
}

/// Um embaixo do outro, com explicação de cada número.
class _ListaIndicadores extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;

  const _ListaIndicadores({required this.tema, required this.resumo});

  @override
  Widget build(BuildContext context) {
    final itens = <(String, String, String, IconData, Color)>[
      (
        'Faturamento',
        Fmt.moeda(resumo.valorBruto),
        'o bruto que os aplicativos pagaram',
        Icons.account_balance_wallet_rounded,
        tema.primaria,
      ),
      (
        'Lucro líquido',
        Fmt.moeda(resumo.lucroLiquido),
        'o que sobrou depois de combustível e gastos',
        Icons.savings_rounded,
        resumo.lucroLiquido >= 0 ? tema.sucesso : tema.erro,
      ),
      (
        'Despesas',
        Fmt.moeda(resumo.despesasTotais),
        'combustível mais os outros gastos',
        Icons.receipt_long_rounded,
        tema.erro,
      ),
      (
        'Lucro por KM',
        Fmt.moeda(resumo.lucroPorKm),
        'quanto sobra em cada quilômetro',
        Icons.route_rounded,
        tema.alerta,
      ),
      (
        'Ganho por hora',
        Fmt.moeda(resumo.ganhoPorHora),
        'quanto sobra por hora trabalhada',
        Icons.schedule_rounded,
        tema.secundaria,
      ),
      (
        'Corridas',
        Fmt.inteiro(resumo.corridas),
        '${Fmt.moeda(resumo.ticketMedio)} em média por corrida',
        Icons.local_taxi_rounded,
        tema.primaria,
      ),
    ];

    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < itens.length; i++) ...<Widget>[
            if (i > 0) const Divider(height: 22),
            Row(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: itens[i].$5.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(itens[i].$4, size: 18, color: itens[i].$5),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(itens[i].$1, style: context.textos.bodyMedium),
                      Text(itens[i].$3, style: context.textos.bodySmall),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  itens[i].$2,
                  style: context.textos.titleLarge?.copyWith(
                    color: itens[i].$5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// Tudo numa caixinha só, para quem quer ver rápido.
class _CompactoIndicadores extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;

  const _CompactoIndicadores({required this.tema, required this.resumo});

  @override
  Widget build(BuildContext context) {
    final linhas = <(String, String, Color)>[
      ('Faturamento', Fmt.moeda(resumo.valorBruto), tema.primaria),
      (
        'Lucro líquido',
        Fmt.moeda(resumo.lucroLiquido),
        resumo.lucroLiquido >= 0 ? tema.sucesso : tema.erro,
      ),
      ('Despesas', Fmt.moeda(resumo.despesasTotais), tema.erro),
      ('Lucro por KM', Fmt.moeda(resumo.lucroPorKm), tema.alerta),
      ('KM rodados', Fmt.km(resumo.km), tema.secundaria),
      ('Corridas', Fmt.inteiro(resumo.corridas), tema.primaria),
    ];

    return CartaoFarol(
      tema: tema,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        children: <Widget>[
          for (final l in linhas)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 7,
                    height: 7,
                    decoration:
                        BoxDecoration(color: l.$3, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(l.$1, style: context.textos.bodySmall),
                  ),
                  Text(
                    l.$2,
                    style: context.textos.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: l.$3,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// GRÁFICOS DO PERÍODO
// =======================================================================
class _GraficosDoPeriodo extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;
  final bool animar;

  /// No modo "Gráficos" eles ficam maiores.
  final bool destaque;

  const _GraficosDoPeriodo({
    required this.tema,
    required this.resumo,
    required this.animar,
    required this.destaque,
  });

  @override
  Widget build(BuildContext context) {
    final dias = <({DateTime dia, double lucro})>[
      for (final e in resumo.lucroPorDia.entries) (dia: e.key, lucro: e.value),
    ];

    // Com um dia só não existe evolução para desenhar.
    if (dias.length < 2 && resumo.gastosPorCategoria.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (dias.length > 1) ...<Widget>[
          const TituloSecao(
            texto: 'Evolução do lucro',
            icone: Icons.show_chart_rounded,
          ),
          CartaoFarol(
            tema: tema,
            child: GraficoLinhaEvolucao(
              dados: dias,
              tema: tema,
              animar: animar,
              altura: destaque ? 230 : 180,
            ),
          ),
          const SizedBox(height: 18),
        ],
        if (resumo.gastosPorCategoria.isNotEmpty) ...<Widget>[
          const TituloSecao(
            texto: 'Para onde foi o dinheiro',
            icone: Icons.pie_chart_rounded,
          ),
          CartaoFarol(
            tema: tema,
            child: GraficoPizzaGastos(
              gastosPorCategoria: resumo.gastosPorCategoria,
              tema: tema,
              animar: animar,
            ),
          ),
        ],
      ],
    );
  }
}

// =======================================================================
// CARTÃO DO LUCRO DE HOJE
// =======================================================================
class _CartaoLucroDoDia extends StatelessWidget {
  final TemaFarol tema;
  final double lucro;
  final double bruto;
  final bool animar;

  const _CartaoLucroDoDia({
    required this.tema,
    required this.lucro,
    required this.bruto,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final corTexto = tema.textoSobrePrimaria;

    return CartaoFarol(
      tema: tema,
      comGradiente: true,
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                Icons.savings_rounded,
                color: corTexto.withValues(alpha: 0.85),
                size: 19,
              ),
              const SizedBox(width: 8),
              Text(
                'LUCRO DE HOJE',
                style: TextStyle(
                  color: corTexto.withValues(alpha: 0.85),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // O número sobe de zero até o valor: dá a sensação de "contador".
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: lucro),
            duration:
                animar ? const Duration(milliseconds: 850) : Duration.zero,
            curve: Curves.easeOutCubic,
            builder: (context, valor, _) => FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                Fmt.moeda(valor),
                style: TextStyle(
                  color: corTexto,
                  fontSize: 40,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -1.2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Recebido bruto hoje: ${Fmt.moeda(bruto)}',
            style: TextStyle(
              color: corTexto.withValues(alpha: 0.85),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// FAIXA "JORNADA RODANDO"
// =======================================================================
class _FaixaJornadaRodando extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _FaixaJornadaRodando({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    final pausada = jornada.pausada;
    final cor = pausada ? tema.alerta : tema.sucesso;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(tema.raioBorda * 0.7),
        border: Border.all(color: cor.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: <Widget>[
          Icon(
            pausada ? Icons.pause_circle_rounded : Icons.circle,
            color: cor,
            size: pausada ? 20 : 12,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              pausada
                  ? 'Pausado — ${jornada.motivoPausaAtual ?? "descanso"}'
                  : 'Trabalhando agora',
              style: context.textos.bodyMedium?.copyWith(
                color: cor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          // Só o cronômetro se redesenha a cada segundo.
          ValueListenableBuilder<Duration>(
            valueListenable: jornada.tempoAtivoAgora,
            builder: (context, ativo, __) => Text(
              Fmt.cronometro(ativo),
              style: context.textos.titleMedium?.copyWith(
                color: cor,
                fontWeight: FontWeight.w700,
                fontFeatures: const <FontFeature>[
                  FontFeature.tabularFigures(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// ÚLTIMOS DIAS
// =======================================================================
class _UltimosDias extends StatelessWidget {
  final TemaFarol tema;
  final List<({DateTime dia, double lucro})> dias;
  final bool animar;

  const _UltimosDias({
    required this.tema,
    required this.dias,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    // Do mais recente para o mais antigo — é assim que se olha para trás.
    final lista = dias.reversed.toList();

    // A maior barra serve de régua para as outras.
    var maior = 0.0;
    for (final d in lista) {
      final v = d.lucro.abs();
      if (v > maior) maior = v;
    }

    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < lista.length; i++) ...<Widget>[
            if (i > 0) const Divider(height: 18),
            _LinhaDia(
              tema: tema,
              dia: lista[i].dia,
              lucro: lista[i].lucro,
              maior: maior,
              animar: animar,
            ),
          ],
        ],
      ),
    );
  }
}

class _LinhaDia extends StatelessWidget {
  final TemaFarol tema;
  final DateTime dia;
  final double lucro;
  final double maior;
  final bool animar;

  const _LinhaDia({
    required this.tema,
    required this.dia,
    required this.lucro,
    required this.maior,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final semLancamento = lucro == 0;
    final cor = semLancamento
        ? tema.textoSuave
        : (lucro > 0 ? tema.sucesso : tema.erro);

    // Proporção da barra. Divisão protegida: sem dados, barra vazia.
    final fracao = maior <= 0 ? 0.0 : (lucro.abs() / maior).clamp(0.0, 1.0);

    return Row(
      children: <Widget>[
        SizedBox(
          width: 64,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                Fmt.diaSemana(dia),
                style: context.textos.bodyMedium?.copyWith(
                  fontWeight: dia.ehHoje ? FontWeight.w700 : FontWeight.w500,
                  color: dia.ehHoje ? tema.primaria : tema.texto,
                ),
              ),
              Text(
                Fmt.dataCurta(dia),
                style: context.textos.bodySmall,
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: fracao),
              duration:
                  animar ? const Duration(milliseconds: 400) : Duration.zero,
              curve: Curves.easeOutCubic,
              builder: (context, f, _) => LinearProgressIndicator(
                value: f,
                minHeight: 9,
                backgroundColor: tema.superficieAlta,
                valueColor: AlwaysStoppedAnimation<Color>(cor),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        SizedBox(
          width: 86,
          child: Text(
            semLancamento ? '—' : Fmt.moeda(lucro),
            textAlign: TextAlign.right,
            style: context.textos.bodyMedium?.copyWith(
              color: cor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

// =======================================================================
// AÇÕES RÁPIDAS
// =======================================================================
/// A primeira é ADICIONAR, que abre o lançamento do dia. Depois vêm as
/// outras, na ordem em que o motorista mais usa.
class _AcoesRapidas extends StatelessWidget {
  final TemaFarol tema;

  const _AcoesRapidas({required this.tema});

  @override
  Widget build(BuildContext context) {
    final itens = <(IconData, String, String, Color)>[
      (Icons.add_circle_rounded, 'Adicionar', AppRoutes.lancamento,
          tema.primaria),
      (Icons.photo_camera_rounded, 'Ler print', AppRoutes.importarPrint,
          tema.secundaria),
      (Icons.local_gas_station_rounded, 'Abastecer', AppRoutes.abastecimento,
          tema.alerta),
      (Icons.receipt_long_rounded, 'Gastos', AppRoutes.gastos, tema.erro),
      (Icons.calculate_rounded, 'Vale a pena?', AppRoutes.valeAPena,
          tema.sucesso),
      (Icons.trending_up_rounded, 'Patrimônio', AppRoutes.simulador,
          tema.secundaria),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 2.5,
      children: <Widget>[
        for (final item in itens)
          CartaoFarol(
            tema: tema,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            aoTocar: () {
              AudioService.clique();
              Navigator.of(context).pushNamed(item.$3);
            },
            child: Row(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: item.$4.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(item.$1, color: item.$4, size: 19),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.$2,
                    style: context.textos.titleMedium,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
