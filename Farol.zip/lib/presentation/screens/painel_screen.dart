/// -----------------------------------------------------------------------
/// PAINEL — o retrato do período
/// -----------------------------------------------------------------------
/// O motorista escolhe o período (ano, mês, semana ou dia) e vê tudo
/// medido contra o custo real do carro dele.
///
/// Todo número desta tela vem pronto do DadosController, que usa o
/// CalculationsService. Aqui não se faz conta nenhuma.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../domain/entities/periodo_escolhido.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/graficos_farol.dart';
import '../widgets/painel_widgets.dart';
import '../widgets/seletor_periodo.dart';

class PainelScreen extends StatefulWidget {
  const PainelScreen({super.key});

  @override
  State<PainelScreen> createState() => _PainelScreenState();
}

class _PainelScreenState extends State<PainelScreen> {
  /// Abre no mês atual — o recorte que o motorista mais olha.
  PeriodoEscolhido _periodo = PeriodoEscolhido.hoje();

  /// Os gráficos ficam recolhidos por padrão: a tela abre leve e rápida,
  /// e quem quiser ver abre com um toque.
  bool _mostrarGraficos = false;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final animar = app.animacoesAtivas;

    final r = dados.resumoDe(_periodo);
    final anterior = dados.resumoAnteriorDe(_periodo);

    final meta = dados.metaPara(_periodo.escopo);
    final progresso = CalculationsService.progressoMeta(
      realizado: r.lucroLiquido,
      meta: meta,
    );
    final percentual = CalculationsService.percentualMeta(
      realizado: r.lucroLiquido,
      meta: meta,
    );
    final falta = CalculationsService.faltaParaMeta(
      realizado: r.lucroLiquido,
      meta: meta,
    );

    return SafeArea(
      child: ListView(
        padding: EdgeInsets.fromLTRB(
          tema.compacto ? 12 : 16,
          14,
          tema.compacto ? 12 : 16,
          110,
        ),
        children: <Widget>[
          // ---------------- CABEÇALHO ----------------
          Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Painel', style: context.textos.headlineMedium),
                    const SizedBox(height: 3),
                    Text(
                      'Tudo medido contra o custo real do seu carro: '
                      '${Fmt.moeda(dados.custoPorKmAtual)} por quilômetro.',
                      style: context.textos.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: 'Exportar Excel e PDF',
                onPressed: () {
                  AudioService.clique();
                  Navigator.of(context).pushNamed(AppRoutes.exportar);
                },
                icon: const Icon(Icons.ios_share_rounded),
              ),
            ],
          ),
          SizedBox(height: tema.espaco),

          // ---------------- ESCOLHA DO PERÍODO ----------------
          SeletorPeriodo(
            periodo: _periodo,
            anos: dados.anosDisponiveis,
            tema: tema,
            aoMudar: (novo) => setState(() => _periodo = novo),
          ),
          const SizedBox(height: 10),

          // ---------------- O QUE TEM NO PERÍODO ----------------
          Align(
            alignment: Alignment.centerRight,
            child: _Pilula(
              tema: tema,
              texto: '${Fmt.inteiro(r.corridas)} corridas · '
                  '${r.diasTrabalhados} '
                  '${r.diasTrabalhados == 1 ? "dia" : "dias"}',
              cor: r.vazio ? tema.textoSuave : tema.primaria,
            ),
          ),
          SizedBox(height: tema.espaco),

          if (r.vazio)
            _NadaNoPeriodo(tema: tema, periodo: _periodo)
          else ...<Widget>[
            // ---------------- RESULTADO ----------------
            CartaoDestaque(
              tema: tema,
              rotulo: 'Lucro líquido · ${_periodo.rotulo}',
              valor: Fmt.moeda(r.lucroLiquido),
              detalhe: meta > 0
                  ? 'meta ${Fmt.moeda(meta)} · '
                      '${falta > 0 ? "faltam ${Fmt.moeda(falta)}" : "meta batida!"}'
                  : '${Fmt.moeda(r.valorBruto)} de faturamento bruto',
              progressoMeta: progresso,
              textoAnel: '${Fmt.numero(percentual, casas: 0)}%',
              animar: animar,
              negativo: r.lucroLiquido < 0,
            ),
            SizedBox(height: tema.espaco),

            // ---------------- COMPARAÇÃO ----------------
            if (_periodo.escopo != EscopoPeriodo.tudo && !anterior.vazio) ...[
              _Comparacao(
                tema: tema,
                atual: r,
                anterior: anterior,
                escopo: _periodo.escopo,
              ),
              SizedBox(height: tema.espaco),
            ],

            // ---------------- OS NÚMEROS ----------------
            _GradeNumeros(tema: tema, r: r),
            SizedBox(height: tema.espaco + 4),

            // ---------------- GRÁFICOS (abre quando quiser) ----------------
            TituloBloco(
              tema: tema,
              texto: 'Gráficos',
              acao: TextButton(
                onPressed: () {
                  AudioService.toqueLeve();
                  setState(() => _mostrarGraficos = !_mostrarGraficos);
                },
                child: Text(_mostrarGraficos ? 'Esconder' : 'Mostrar'),
              ),
            ),
            if (_mostrarGraficos)
              _Graficos(tema: tema, r: r, animar: animar)
            else
              Caixa(
                tema: tema,
                child: Row(
                  children: <Widget>[
                    Icon(Icons.insert_chart_outlined_rounded,
                        color: tema.textoSuave, size: 20),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Text(
                        'Os gráficos ficam fechados para a tela abrir mais '
                        'rápido. Toque em Mostrar quando quiser vê-los.',
                        style: context.textos.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }
}

// =======================================================================
class _Pilula extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  final Color cor;

  const _Pilula({required this.tema, required this.texto, required this.cor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        texto,
        style: TextStyle(
          color: cor,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// =======================================================================
class _GradeNumeros extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo r;

  const _GradeNumeros({required this.tema, required this.r});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: tema.compacto ? 1.55 : 1.38,
      children: <Widget>[
        CartaoMetrica(
          tema: tema,
          rotulo: 'Faturamento bruto',
          valor: Fmt.moeda(r.valorBruto),
          detalhe: 'o que os aplicativos mostraram',
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Lucro líquido',
          valor: Fmt.moeda(r.lucroLiquido),
          detalhe: 'já sem combustível e gastos',
          corValor: r.lucroLiquido >= 0 ? tema.sucesso : tema.erro,
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Despesas do período',
          valor: Fmt.moeda(r.despesasTotais),
          detalhe: '${Fmt.moeda(r.custoCombustivel)} de combustível',
          corValor: r.despesasTotais > 0 ? tema.erro : null,
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Custo real por km',
          valor: Fmt.moeda(r.custoPorKm),
          detalhe: 'do que você rodou de verdade',
          faixa: tema.erro,
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Lucro por km',
          valor: Fmt.moeda(r.lucroPorKm),
          detalhe: '${Fmt.km(r.km)} rodados',
          corValor: r.lucroPorKm >= 0 ? tema.sucesso : tema.erro,
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Lucro por hora',
          valor: Fmt.moeda(r.ganhoPorHora),
          detalhe: '${Fmt.horasTexto(r.horas)} trabalhadas',
          corValor: r.ganhoPorHora >= 0 ? tema.sucesso : tema.erro,
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Ticket médio',
          valor: Fmt.moeda(r.ticketMedio),
          detalhe: '${Fmt.numero(r.kmPorCorrida, casas: 1)} km por corrida',
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Margem de lucro',
          valor: Fmt.percentual(r.margemLucro),
          detalhe: 'do bruto que virou lucro',
          corValor: r.margemLucro >= 0 ? tema.sucesso : tema.erro,
        ),
      ],
    );
  }
}

// =======================================================================
class _Comparacao extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo atual;
  final ResumoPeriodo anterior;
  final EscopoPeriodo escopo;

  const _Comparacao({
    required this.tema,
    required this.atual,
    required this.anterior,
    required this.escopo,
  });

  @override
  Widget build(BuildContext context) {
    final variacao = CalculationsService.variacaoPercentual(
      atual: atual.lucroLiquido,
      anterior: anterior.lucroLiquido,
    );
    final subiu = variacao >= 0;
    final cor = subiu ? tema.sucesso : tema.erro;

    final String nome;
    switch (escopo) {
      case EscopoPeriodo.dia:
        nome = 'o dia anterior';
      case EscopoPeriodo.semana:
        nome = 'a semana anterior';
      case EscopoPeriodo.mes:
        nome = 'o mês anterior';
      case EscopoPeriodo.ano:
        nome = 'o ano anterior';
      case EscopoPeriodo.tudo:
        nome = 'o período anterior';
    }

    return Caixa(
      tema: tema,
      child: Row(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: cor.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              subiu ? Icons.trending_up_rounded : Icons.trending_down_rounded,
              color: cor,
              size: 21,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '${subiu ? "Subiu" : "Caiu"} '
                  '${Fmt.percentual(variacao.abs())}',
                  style: tema.numero(tamanho: 17, cor: cor),
                ),
                const SizedBox(height: 2),
                Text(
                  'comparado com $nome '
                  '(${Fmt.moeda(anterior.lucroLiquido)})',
                  style: context.textos.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
class _Graficos extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo r;
  final bool animar;

  const _Graficos({required this.tema, required this.r, required this.animar});

  @override
  Widget build(BuildContext context) {
    final dias = <({DateTime dia, double lucro})>[
      for (final e in r.lucroPorDia.entries) (dia: e.key, lucro: e.value),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (dias.length > 1) ...<Widget>[
          CartaoFarol(
            tema: tema,
            child: Column(
              children: <Widget>[
                Text(
                  'Lucro por dia — toque numa barra para ver o valor',
                  style: context.textos.bodySmall,
                ),
                const SizedBox(height: 12),
                // RepaintBoundary: o desenho do gráfico fica isolado e
                // não é refeito quando outra parte da tela muda.
                RepaintBoundary(
                  child: GraficoBarrasDias(
                    dados: dias,
                    tema: tema,
                    animar: animar,
                    altura: 190,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: tema.espaco),
          CartaoFarol(
            tema: tema,
            child: RepaintBoundary(
              child: GraficoLinhaEvolucao(
                dados: dias,
                tema: tema,
                animar: animar,
              ),
            ),
          ),
          SizedBox(height: tema.espaco),
        ],
        if (r.gastosPorCategoria.isNotEmpty)
          CartaoFarol(
            tema: tema,
            child: Column(
              children: <Widget>[
                Text(
                  'Para onde foi o dinheiro',
                  style: context.textos.bodySmall,
                ),
                const SizedBox(height: 10),
                RepaintBoundary(
                  child: GraficoPizzaGastos(
                    gastosPorCategoria: r.gastosPorCategoria,
                    tema: tema,
                    animar: animar,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

// =======================================================================
class _NadaNoPeriodo extends StatelessWidget {
  final TemaFarol tema;
  final PeriodoEscolhido periodo;

  const _NadaNoPeriodo({required this.tema, required this.periodo});

  @override
  Widget build(BuildContext context) {
    return Caixa(
      tema: tema,
      padding: const EdgeInsets.all(22),
      child: Column(
        children: <Widget>[
          Icon(
            Icons.inbox_rounded,
            size: 42,
            color: tema.textoSuave,
          ),
          const SizedBox(height: 12),
          Text(
            'Nada lançado em ${periodo.rotulo}',
            textAlign: TextAlign.center,
            style: context.textos.titleMedium,
          ),
          const SizedBox(height: 5),
          Text(
            'Escolha outro período acima ou lance um dia de trabalho.',
            textAlign: TextAlign.center,
            style: context.textos.bodySmall,
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () {
              AudioService.clique();
              Navigator.of(context).pushNamed(AppRoutes.lancamento);
            },
            icon: const Icon(Icons.add_rounded),
            label: const Text('Lançar o dia'),
          ),
        ],
      ),
    );
  }
}
