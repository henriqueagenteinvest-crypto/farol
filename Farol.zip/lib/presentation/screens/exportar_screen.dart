/// -----------------------------------------------------------------------
/// EXPORTAÇÃO — EXCEL E PDF
/// -----------------------------------------------------------------------
/// Gera a planilha (2 abas, com fórmulas de verdade) e o relatório em PDF,
/// e abre o compartilhamento do celular para WhatsApp, e-mail ou Drive.
/// -----------------------------------------------------------------------
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../domain/entities/periodo_escolhido.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/audio_service.dart';
import '../../services/export_excel_service.dart';
import '../../services/export_pdf_service.dart';
import '../../services/share_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/painel_widgets.dart';
import '../widgets/seletor_periodo.dart';

class ExportarScreen extends StatefulWidget {
  const ExportarScreen({super.key});

  @override
  State<ExportarScreen> createState() => _ExportarScreenState();
}

class _ExportarScreenState extends State<ExportarScreen> {
  /// O período que o motorista escolheu — dia, semana, mês, ano ou tudo,
  /// e QUAL dia, QUAL semana, QUAL mês. Não é mais "o mês atual": é o
  /// que ele quiser, de 1000 a 3400.
  PeriodoEscolhido _periodo =
      PeriodoEscolhido.hoje(escopo: EscopoPeriodo.mes);

  bool _gerando = false;
  String _etapa = '';

  Future<void> _exportar({required bool excel, required bool pdf}) async {
    final app = context.read<AppController>();
    final dados = context.read<DadosController>();

    final resumo = dados.resumoDe(_periodo);
    if (resumo.vazio) {
      AudioService.erro();
      context.aviso('Não há nada lançado neste período', erro: true);
      return;
    }

    setState(() {
      _gerando = true;
      _etapa = 'Preparando os dados...';
    });
    AudioService.clique();

    try {
      final inicio = _periodo.inicio.soData;
      final fim = DateTime(
        _periodo.fim.year,
        _periodo.fim.month,
        _periodo.fim.day,
        23,
        59,
        59,
      );

      final lancamentos = dados.lancamentos
          .where((l) => l.data.dentroDe(inicio, fim))
          .toList();
      final gastos =
          dados.gastos.where((g) => g.data.dentroDe(inicio, fim)).toList();
      final abastecimentos = dados.abastecimentos
          .where((a) => a.data.dentroDe(inicio, fim))
          .toList();

      // As fatias do período — é o que permite comparar uma semana com a
      // outra em vez de olhar um total só.
      final fatias = dados.quebrarPara(_periodo);
      final nomeDaFatia = dados.nomeDaFatiaPara(_periodo);

      final arquivos = <File>[];

      if (excel) {
        setState(() => _etapa = 'Montando a planilha do Excel...');
        arquivos.add(await ExportExcelService.gerar(
          motorista: app.motorista,
          resumo: resumo,
          lancamentos: lancamentos,
          gastos: gastos,
          abastecimentos: abastecimentos,
          fatias: fatias,
          nomeDaFatia: nomeDaFatia,
        ));
      }

      if (pdf) {
        setState(() => _etapa = 'Montando o relatório em PDF...');
        arquivos.add(await ExportPdfService.gerar(
          motorista: app.motorista,
          resumo: resumo,
          lancamentos: lancamentos,
          gastos: gastos,
          fatias: fatias,
          nomeDaFatia: nomeDaFatia,
        ));
      }

      setState(() => _etapa = 'Abrindo o compartilhamento...');
      await ShareService.compartilharVarios(
        arquivos,
        assunto: 'Farol — Relatório ${resumo.rotulo}',
        mensagem: 'Relatório do período ${resumo.rotulo}.\n'
            'Lucro: ${Fmt.moeda(resumo.lucroLiquido)}  •  '
            'Bruto: ${Fmt.moeda(resumo.valorBruto)}  •  '
            '${resumo.corridas} corridas',
      );

      AudioService.sucesso();
      if (!mounted) return;
      context.aviso('Relatório gerado!');
    } catch (e) {
      AudioService.erro();
      if (!mounted) return;
      context.aviso(
        'Não consegui gerar o arquivo. Tente um período menor.',
        erro: true,
      );
    } finally {
      if (mounted) setState(() => _gerando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final resumo = dados.resumoDe(_periodo);
    final fatias = dados.quebrarPara(_periodo);
    final nomeDaFatia = dados.nomeDaFatiaPara(_periodo);

    return Scaffold(
      appBar: AppBar(title: const Text('Exportar relatório')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: _gerando
            ? _Gerando(tema: tema, etapa: _etapa)
            : ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                children: <Widget>[
                  const TituloSecao(
                    texto: 'Qual período?',
                    icone: Icons.date_range_rounded,
                  ),
                  Text(
                    'Escolha o dia, a semana, o mês ou o ano que você quer — '
                    'e não só o de agora.',
                    style: context.textos.bodySmall,
                  ),
                  const SizedBox(height: 12),

                  // O MESMO seletor do Painel: dia, semana, mês, ano ou
                  // tudo, escolhendo exatamente qual. Reaproveitar aqui
                  // garante que os dois lugares mostrem sempre o mesmo
                  // recorte, com os mesmos nomes.
                  SeletorPeriodo(
                    periodo: _periodo,
                    anos: dados.anosDisponiveis,
                    tema: tema,
                    aoMudar: (novo) => setState(() => _periodo = novo),
                  ),
                  const SizedBox(height: 22),

                  // ---------------- Prévia do que vai sair ----------------
                  CartaoFarol(
                    tema: tema,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(resumo.rotulo, style: context.textos.titleLarge),
                        const SizedBox(height: 4),
                        Text(
                          '${Fmt.data(resumo.inicio)} a ${Fmt.data(resumo.fim)}',
                          style: context.textos.bodySmall,
                        ),
                        const Divider(height: 24),
                        _Linha('Lucro do período',
                            Fmt.moeda(resumo.lucroLiquido), tema.sucesso),
                        const SizedBox(height: 8),
                        _Linha('Recebido bruto',
                            Fmt.moeda(resumo.valorBruto), tema.primaria),
                        const SizedBox(height: 8),
                        _Linha('Dias trabalhados',
                            '${resumo.diasTrabalhados}', tema.textoSuave),
                        const SizedBox(height: 8),
                        _Linha('Corridas', Fmt.inteiro(resumo.corridas),
                            tema.textoSuave),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),

                  // ---------------- Prévia do COMPARATIVO ----------------
                  // Mostra aqui, antes de gerar, exatamente o que vai
                  // sair na planilha e no PDF: uma linha por semana (ou
                  // por mês), com a diferença de uma para a outra.
                  if (fatias.length > 1) ...<Widget>[
                    TituloBloco(
                      tema: tema,
                      texto: '${nomeDaFatia} a ${nomeDaFatia.toLowerCase()}',
                      acao: Text(
                        '${fatias.length} ${nomeDaFatia.toLowerCase()}s',
                        style: context.textos.bodySmall,
                      ),
                    ),
                    _PreviaComparativo(tema: tema, fatias: fatias),
                    const SizedBox(height: 22),
                  ],

                  const TituloSecao(
                    texto: 'O que você quer gerar?',
                    icone: Icons.file_present_rounded,
                  ),
                  _CartaoFormato(
                    tema: tema,
                    icone: Icons.table_chart_rounded,
                    cor: const Color(0xFF1D7044),
                    titulo: 'Planilha do Excel',
                    descricao: 'Três abas: o painel de indicadores, a '
                        'tabela completa com fórmulas de verdade (SOMA, '
                        'MÉDIA, SE) e o COMPARATIVO com uma linha por '
                        'semana ou por mês.',
                  ),
                  const SizedBox(height: 12),
                  _CartaoFormato(
                    tema: tema,
                    icone: Icons.picture_as_pdf_rounded,
                    cor: const Color(0xFFC0392B),
                    titulo: 'Relatório em PDF',
                    descricao: 'Documento pronto para imprimir ou mandar: '
                        'capa, indicadores, o comparativo com a variação '
                        'de uma semana para a outra, gráficos e as tabelas.',
                  ),
                  const SizedBox(height: 26),

                  BotaoGrande(
                    texto: 'Gerar os dois e compartilhar',
                    icone: Icons.ios_share_rounded,
                    tema: tema,
                    altura: 66,
                    aoTocar: () => _exportar(excel: true, pdf: true),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _exportar(excel: true, pdf: false),
                          icon: const Icon(Icons.table_chart_rounded),
                          label: const Text('Só Excel'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _exportar(excel: false, pdf: true),
                          icon: const Icon(Icons.picture_as_pdf_rounded),
                          label: const Text('Só PDF'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: tema.superficieAlta,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.shield_rounded,
                          size: 18,
                          color: tema.primaria,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Exportar de vez em quando é a sua cópia de '
                            'segurança: se trocar de celular, os dados não '
                            'se perdem.',
                            style: context.textos.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;
  const _Linha(this.rotulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Text(rotulo, style: context.textos.bodyMedium),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            color: cor,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _CartaoFormato extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final Color cor;
  final String titulo;
  final String descricao;

  const _CartaoFormato({
    required this.tema,
    required this.icone,
    required this.cor,
    required this.titulo,
    required this.descricao,
  });

  @override
  Widget build(BuildContext context) {
    return CartaoFarol(
      tema: tema,
      corBorda: cor,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: cor.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icone, color: cor, size: 22),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(titulo, style: context.textos.titleMedium),
                const SizedBox(height: 4),
                Text(descricao, style: context.textos.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Gerando extends StatelessWidget {
  final TemaFarol tema;
  final String etapa;

  const _Gerando({required this.tema, required this.etapa});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            width: 46,
            height: 46,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: tema.primaria,
            ),
          ),
          const SizedBox(height: 24),
          Text(etapa, style: context.textos.titleLarge),
          const SizedBox(height: 8),
          Text(
            'Isso acontece tudo dentro do seu celular',
            style: context.textos.bodySmall,
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// PRÉVIA DO COMPARATIVO
// =======================================================================
/// Uma linha por fatia do período, com o lucro e a diferença para a
/// fatia anterior. É exatamente o que sai no Excel e no PDF — ver aqui
/// antes evita gerar o arquivo só para descobrir que não era esse o
/// período que você queria.
class _PreviaComparativo extends StatelessWidget {
  final TemaFarol tema;
  final List<ResumoPeriodo> fatias;

  const _PreviaComparativo({required this.tema, required this.fatias});

  @override
  Widget build(BuildContext context) {
    // A régua das barrinhas é a fatia que mais lucrou.
    var maior = 0.0;
    for (final f in fatias) {
      final v = f.lucroLiquido.abs();
      if (v > maior) maior = v;
    }

    return Caixa(
      tema: tema,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Column(
        children: <Widget>[
          for (var i = 0; i < fatias.length; i++) ...<Widget>[
            if (i > 0) Divider(height: 1, color: tema.divisor),
            _LinhaComparativo(
              tema: tema,
              atual: fatias[i],
              anterior: i == 0 ? null : fatias[i - 1],
              maior: maior,
            ),
          ],
        ],
      ),
    );
  }
}

class _LinhaComparativo extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo atual;
  final ResumoPeriodo? anterior;
  final double maior;

  const _LinhaComparativo({
    required this.tema,
    required this.atual,
    required this.anterior,
    required this.maior,
  });

  @override
  Widget build(BuildContext context) {
    final positivo = atual.lucroLiquido >= 0;
    final ant = anterior;
    final diferenca = ant == null ? 0.0 : atual.lucroLiquido - ant.lucroLiquido;
    final subiu = diferenca >= 0;

    // Divisão protegida: sem lucro na fatia anterior não existe
    // porcentagem, e inventar um número aqui seria mentira.
    final temBase = ant != null && ant.lucroLiquido.abs() > 0.009;
    final percentual =
        temBase ? (diferenca / ant.lucroLiquido.abs()) * 100 : 0.0;

    final fracao = maior <= 0
        ? 0.0
        : (atual.lucroLiquido.abs() / maior).clamp(0.0, 1.0);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  atual.rotulo,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: context.textos.bodyMedium,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                Fmt.moeda(atual.lucroLiquido),
                style: tema.numero(
                  tamanho: 14,
                  cor: positivo ? tema.sucesso : tema.erro,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: <Widget>[
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: LinearProgressIndicator(
                    value: fracao,
                    minHeight: 5,
                    backgroundColor: tema.superficieAlta,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      positivo ? tema.sucesso : tema.erro,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                width: 104,
                child: ant == null
                    ? Text(
                        'referência',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          color: tema.textoSuave,
                          fontSize: 11,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Icon(
                            subiu
                                ? Icons.trending_up_rounded
                                : Icons.trending_down_rounded,
                            size: 14,
                            color: subiu ? tema.sucesso : tema.erro,
                          ),
                          const SizedBox(width: 3),
                          Flexible(
                            child: Text(
                              temBase
                                  ? '${subiu ? "+" : "-"}'
                                      '${percentual.abs().toStringAsFixed(0)}%'
                                  : Fmt.moeda(diferenca.abs()),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                color: subiu ? tema.sucesso : tema.erro,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
