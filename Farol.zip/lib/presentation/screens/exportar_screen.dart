/// -----------------------------------------------------------------------
/// EXPORTAÇÃO — EXCEL E PDF
/// -----------------------------------------------------------------------
/// Gera a planilha (2 abas, com fórmulas de verdade) e o relatório em PDF,
/// e abre o compartilhamento do celular para WhatsApp, e-mail ou Drive.
/// -----------------------------------------------------------------------
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/audio_service.dart';
import '../../services/export_excel_service.dart';
import '../../services/export_pdf_service.dart';
import '../../services/share_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';

class ExportarScreen extends StatefulWidget {
  const ExportarScreen({super.key});

  @override
  State<ExportarScreen> createState() => _ExportarScreenState();
}

class _ExportarScreenState extends State<ExportarScreen> {
  FiltroPeriodo _filtro = FiltroPeriodo.mes;
  bool _gerando = false;
  String _etapa = '';

  Future<void> _exportar({required bool excel, required bool pdf}) async {
    final app = context.read<AppController>();
    final dados = context.read<DadosController>();

    final resumo = dados.resumo(_filtro);
    if (resumo.vazio) {
      AudioService.erro();
      context.aviso('Não há nada lançado neste período', erro: true);
      return;
    }

    setState(() {
      _gerando = true;
      _etapa = 'Preparando os dados...';
    });
    AudioService.clique();

    try {
      final (inicio, fim, _) = dados.intervaloDe(_filtro);
      final lancamentos = dados.lancamentos
          .where((l) => l.data.dentroDe(inicio.soData,
              DateTime(fim.year, fim.month, fim.day, 23, 59, 59)))
          .toList();
      final gastos = dados.gastos
          .where((g) => g.data.dentroDe(inicio.soData,
              DateTime(fim.year, fim.month, fim.day, 23, 59, 59)))
          .toList();
      final abastecimentos = dados.abastecimentos
          .where((a) => a.data.dentroDe(inicio.soData,
              DateTime(fim.year, fim.month, fim.day, 23, 59, 59)))
          .toList();

      final arquivos = <File>[];

      if (excel) {
        setState(() => _etapa = 'Montando a planilha do Excel...');
        arquivos.add(await ExportExcelService.gerar(
          motorista: app.motorista,
          resumo: resumo,
          lancamentos: lancamentos,
          gastos: gastos,
          abastecimentos: abastecimentos,
        ));
      }

      if (pdf) {
        setState(() => _etapa = 'Montando o relatório em PDF...');
        arquivos.add(await ExportPdfService.gerar(
          motorista: app.motorista,
          resumo: resumo,
          lancamentos: lancamentos,
          gastos: gastos,
        ));
      }

      setState(() => _etapa = 'Abrindo o compartilhamento...');
      await ShareService.compartilharVarios(
        arquivos,
        assunto: 'Farol — Relatório ${resumo.rotulo}',
        mensagem: 'Relatório do período ${resumo.rotulo}.\n'
            'Lucro: ${Fmt.moeda(resumo.lucroLiquido)}  •  '
            'Bruto: ${Fmt.moeda(resumo.valorBruto)}  •  '
            '${resumo.corridas} corridas',
      );

      AudioService.sucesso();
      if (!mounted) return;
      context.aviso('Relatório gerado!');
    } catch (e) {
      AudioService.erro();
      if (!mounted) return;
      context.aviso(
        'Não consegui gerar o arquivo. Tente um período menor.',
        erro: true,
      );
    } finally {
      if (mounted) setState(() => _gerando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final resumo = dados.resumo(_filtro);

    return Scaffold(
      appBar: AppBar(title: const Text('Exportar relatório')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: _gerando
            ? _Gerando(tema: tema, etapa: _etapa)
            : ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                children: <Widget>[
                  const TituloSecao(
                    texto: 'Qual período?',
                    icone: Icons.date_range_rounded,
                  ),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: <Widget>[
                      for (final f in FiltroPeriodo.values)
                        GestureDetector(
                          onTap: () {
                            AudioService.toqueLeve();
                            setState(() => _filtro = f);
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 13,
                            ),
                            decoration: BoxDecoration(
                              gradient: _filtro == f
                                  ? tema.gradienteLinear
                                  : null,
                              color: _filtro == f
                                  ? null
                                  : tema.superficieAlta,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              f.rotulo,
                              style: TextStyle(
                                color: _filtro == f
                                    ? Colors.white
                                    : tema.texto,
                                fontWeight: _filtro == f
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                fontSize: 14.5,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 22),

                  // ---------------- Prévia do que vai sair ----------------
                  CartaoFarol(
                    tema: tema,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(resumo.rotulo, style: context.textos.titleLarge),
                        const SizedBox(height: 4),
                        Text(
                          '${Fmt.data(resumo.inicio)} a ${Fmt.data(resumo.fim)}',
                          style: context.textos.bodySmall,
                        ),
                        const Divider(height: 24),
                        _Linha('Lucro do período',
                            Fmt.moeda(resumo.lucroLiquido), tema.sucesso),
                        const SizedBox(height: 8),
                        _Linha('Recebido bruto',
                            Fmt.moeda(resumo.valorBruto), tema.primaria),
                        const SizedBox(height: 8),
                        _Linha('Dias trabalhados',
                            '${resumo.diasTrabalhados}', tema.textoSuave),
                        const SizedBox(height: 8),
                        _Linha('Corridas', Fmt.inteiro(resumo.corridas),
                            tema.textoSuave),
                      ],
                    ),
                  ),
                  const SizedBox(height: 26),

                  const TituloSecao(
                    texto: 'O que você quer gerar?',
                    icone: Icons.file_present_rounded,
                  ),
                  _CartaoFormato(
                    tema: tema,
                    icone: Icons.table_chart_rounded,
                    cor: const Color(0xFF1D7044),
                    titulo: 'Planilha do Excel',
                    descricao: 'Duas abas: um painel visual com os '
                        'indicadores e a tabela completa com fórmulas de '
                        'verdade (SOMA, MÉDIA, SE, SOMASE).',
                  ),
                  const SizedBox(height: 12),
                  _CartaoFormato(
                    tema: tema,
                    icone: Icons.picture_as_pdf_rounded,
                    cor: const Color(0xFFC0392B),
                    titulo: 'Relatório em PDF',
                    descricao: 'Documento pronto para imprimir ou mandar: '
                        'capa, indicadores, gráficos e as tabelas do período.',
                  ),
                  const SizedBox(height: 26),

                  BotaoGrande(
                    texto: 'Gerar os dois e compartilhar',
                    icone: Icons.ios_share_rounded,
                    tema: tema,
                    altura: 66,
                    aoTocar: () => _exportar(excel: true, pdf: true),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _exportar(excel: true, pdf: false),
                          icon: const Icon(Icons.table_chart_rounded),
                          label: const Text('Só Excel'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _exportar(excel: false, pdf: true),
                          icon: const Icon(Icons.picture_as_pdf_rounded),
                          label: const Text('Só PDF'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: tema.superficieAlta,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.shield_rounded,
                          size: 18,
                          color: tema.primaria,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Exportar de vez em quando é a sua cópia de '
                            'segurança: se trocar de celular, os dados não '
                            'se perdem.',
                            style: context.textos.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;
  const _Linha(this.rotulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Text(rotulo, style: context.textos.bodyMedium),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            color: cor,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _CartaoFormato extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final Color cor;
  final String titulo;
  final String descricao;

  const _CartaoFormato({
    required this.tema,
    required this.icone,
    required this.cor,
    required this.titulo,
    required this.descricao,
  });

  @override
  Widget build(BuildContext context) {
    return CartaoFarol(
      tema: tema,
      corBorda: cor,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: cor.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icone, color: cor, size: 22),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(titulo, style: context.textos.titleMedium),
                const SizedBox(height: 4),
                Text(descricao, style: context.textos.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Gerando extends StatelessWidget {
  final TemaFarol tema;
  final String etapa;

  const _Gerando({required this.tema, required this.etapa});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            width: 46,
            height: 46,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: tema.primaria,
            ),
          ),
          const SizedBox(height: 24),
          Text(etapa, style: context.textos.titleLarge),
          const SizedBox(height: 8),
          Text(
            'Isso acontece tudo dentro do seu celular',
            style: context.textos.bodySmall,
          ),
        ],
      ),
    );
  }
}
