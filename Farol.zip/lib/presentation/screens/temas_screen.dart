/// -----------------------------------------------------------------------
/// ESCOLHA DE TEMA — 15 VISUAIS DIFERENTES
/// -----------------------------------------------------------------------
/// Cada tema aparece com uma amostra do visual real. Ao tocar, o app
/// INTEIRO muda de cara na hora, sem precisar reiniciar.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/audio_service.dart';
import '../../theme/catalogo_temas.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../controllers/app_controller.dart';
import '../widgets/logo_farol.dart';

class TemasScreen extends StatelessWidget {
  const TemasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final atual = app.tema;

    return Scaffold(
      appBar: AppBar(title: const Text('Escolha o visual')),
      body: Container(
        decoration: BoxDecoration(gradient: atual.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 40),
          children: <Widget>[
            Text(
              'São 15 visuais diferentes. Os marcados como "Simples" mostram '
              'menos informação e usam letras maiores; os "Painel" mostram '
              'gráficos e indicadores completos.',
              style: context.textos.bodyMedium?.copyWith(
                color: atual.textoSuave,
              ),
            ),
            const SizedBox(height: 20),
            for (final t in CatalogoTemas.todos)
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: _CartaoTema(
                  tema: t,
                  selecionado: t.id == atual.id,
                  aoTocar: () {
                    AudioService.clique();
                    context.read<AppController>().trocarTema(t.id);
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _CartaoTema extends StatelessWidget {
  final TemaFarol tema;
  final bool selecionado;
  final VoidCallback aoTocar;

  const _CartaoTema({
    required this.tema,
    required this.selecionado,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: aoTocar,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          // A amostra usa as cores DO TEMA que ela representa — assim o
          // motorista vê exatamente como o app vai ficar.
          color: tema.fundo,
          borderRadius: BorderRadius.circular(tema.raioBorda),
          border: Border.all(
            color: selecionado
                ? tema.primaria
                : tema.textoSuave.withValues(alpha: 0.18),
            width: selecionado ? 2.5 : 1,
          ),
          boxShadow: selecionado ? tema.brilhoDe(tema.primaria) : null,
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                LogoFarol(tema: tema, tamanho: 44),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        tema.nome,
                        style: TextStyle(
                          color: tema.texto,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tema.descricao,
                        style: TextStyle(
                          color: tema.textoSuave,
                          fontSize: 11.5,
                        ),
                        maxLines: 2,
                      ),
                    ],
                  ),
                ),
                if (selecionado)
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: tema.primaria,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.check_rounded,
                      size: 16,
                      color: tema.primaria.computeLuminance() > 0.5
                          ? Colors.black
                          : Colors.white,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),

            // ---- Amostra do visual: um cartão e um botão ----
            Row(
              children: <Widget>[
                Expanded(
                  flex: 3,
                  child: Container(
                    height: 46,
                    padding: const EdgeInsets.symmetric(horizontal: 11),
                    decoration: BoxDecoration(
                      color: tema.superficie,
                      borderRadius: BorderRadius.circular(
                        tema.raioBorda * 0.55,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'LUCRO DO DIA',
                          style: TextStyle(
                            color: tema.textoSuave,
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'R\$ 224,09',
                          style: TextStyle(
                            color: tema.sucesso,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  flex: 2,
                  child: Container(
                    height: 46,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      gradient: tema.gradienteLinear,
                      borderRadius: BorderRadius.circular(
                        tema.raioBorda * 0.55,
                      ),
                    ),
                    child: Text(
                      'Iniciar',
                      style: TextStyle(
                        color: tema.primaria.computeLuminance() > 0.5
                            ? Colors.black
                            : Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // ---- Etiquetas: nível de informação e claro/escuro ----
            Row(
              children: <Widget>[
                _Etiqueta(
                  texto: tema.nivel.rotulo,
                  cor: tema.primaria,
                  tema: tema,
                ),
                const SizedBox(width: 7),
                _Etiqueta(
                  texto: tema.ehEscuro ? 'Escuro' : 'Claro',
                  cor: tema.secundaria,
                  tema: tema,
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    tema.nivel.descricao,
                    style: TextStyle(color: tema.textoSuave, fontSize: 10),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Etiqueta extends StatelessWidget {
  final String texto;
  final Color cor;
  final TemaFarol tema;

  const _Etiqueta({
    required this.texto,
    required this.cor,
    required this.tema,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        texto,
        style: TextStyle(
          color: cor,
          fontSize: 10,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
