/// -----------------------------------------------------------------------
/// APARÊNCIA
/// -----------------------------------------------------------------------
/// Tudo o que se escolhe aqui muda o APLICATIVO INTEIRO na mesma hora —
/// não só esta tela. A prévia no topo mostra o resultado antes mesmo de
/// sair da página.
///
///   • Claro / Escuro / Automático
///   • A cor do aplicativo
///   • O TAMANHO DA LETRA (vale para todos os textos)
///   • A FONTE (inclusive a do celular, que nunca depende de internet)
///   • Números com as casas alinhadas
///   • Espaçamento confortável ou compacto
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/audio_service.dart';
import '../../theme/app_typography.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../controllers/app_controller.dart';
import '../widgets/painel_widgets.dart';

class AparenciaScreen extends StatelessWidget {
  const AparenciaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;

    return Scaffold(
      appBar: AppBar(title: const Text('Aparência')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
          children: <Widget>[
            // ---------------- PRÉVIA AO VIVO ----------------
            TituloBloco(tema: tema, texto: 'Como vai ficar'),
            _Previa(tema: tema),
            SizedBox(height: tema.espaco + 6),

            // ---------------- CLARO / ESCURO ----------------
            TituloBloco(tema: tema, texto: 'Claro ou escuro'),
            Row(
              children: <Widget>[
                for (final m in ModoTema.values) ...<Widget>[
                  Expanded(
                    child: _CartaoModo(
                      tema: tema,
                      modo: m,
                      selecionado: app.modoTema == m,
                      aoTocar: () {
                        AudioService.clique();
                        context.read<AppController>().trocarModoTema(m);
                      },
                    ),
                  ),
                  if (m != ModoTema.values.last) const SizedBox(width: 9),
                ],
              ],
            ),
            SizedBox(height: tema.espaco + 6),

            // ---------------- COR ----------------
            TituloBloco(tema: tema, texto: 'Cor do aplicativo'),
            Caixa(
              tema: tema,
              child: Wrap(
                spacing: 12,
                runSpacing: 12,
                children: <Widget>[
                  for (final c in PaletaCores.cores)
                    _Amostra(
                      tema: tema,
                      nome: c.nome,
                      cor: c.cor,
                      selecionada:
                          app.corPrimaria.toARGB32() == c.cor.toARGB32(),
                      aoTocar: () {
                        AudioService.clique();
                        context.read<AppController>().trocarCor(c.cor);
                      },
                    ),
                ],
              ),
            ),
            SizedBox(height: tema.espaco + 6),

            // ---------------- TAMANHO DA LETRA ----------------
            TituloBloco(tema: tema, texto: 'Tamanho da letra'),
            Caixa(
              tema: tema,
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      for (final t in TamanhoTexto.values) ...<Widget>[
                        Expanded(
                          child: _Opcao(
                            tema: tema,
                            texto: t.rotulo,
                            tamanhoDemo: 12 * t.escala,
                            selecionado: app.tamanhoTexto == t,
                            aoTocar: () {
                              AudioService.clique();
                              context
                                  .read<AppController>()
                                  .trocarTamanhoTexto(t);
                            },
                          ),
                        ),
                        if (t != TamanhoTexto.values.last)
                          const SizedBox(width: 8),
                      ],
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Vale para os textos de todas as telas.',
                    style: context.textos.bodySmall,
                  ),
                ],
              ),
            ),
            SizedBox(height: tema.espaco + 6),

            // ---------------- FONTE ----------------
            TituloBloco(tema: tema, texto: 'Fonte'),
            Caixa(
              tema: tema,
              child: Column(
                children: <Widget>[
                  for (var i = 0; i < ConjuntoFonte.values.length; i++) ...[
                    if (i > 0) Divider(height: 18, color: tema.divisor),
                    _LinhaEscolha(
                      tema: tema,
                      titulo: ConjuntoFonte.values[i].rotulo,
                      descricao: ConjuntoFonte.values[i].descricao,
                      selecionada: app.conjuntoFonte == ConjuntoFonte.values[i],
                      aoTocar: () {
                        AudioService.clique();
                        context
                            .read<AppController>()
                            .trocarFonte(ConjuntoFonte.values[i]);
                      },
                    ),
                  ],
                ],
              ),
            ),
            SizedBox(height: tema.espaco + 6),

            // ---------------- MODO DO PAINEL ----------------
            // Duas maneiras de ler os mesmos números. É a personalização
            // de layout que o motorista pediu, e ela fica GRAVADA: sai
            // do app, volta, continua do jeito escolhido.
            TituloBloco(tema: tema, texto: 'Como mostrar os números'),
            Row(
              children: <Widget>[
                Expanded(
                  child: _CartaoModoPainel(
                    tema: tema,
                    icone: Icons.bar_chart_rounded,
                    titulo: 'Indicadores',
                    descricao: 'Cartões, barras\ne ícones coloridos',
                    selecionado: app.modoPainelIndicadores,
                    aoTocar: () {
                      AudioService.clique();
                      context.read<AppController>().trocarModoPainel(false);
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _CartaoModoPainel(
                    tema: tema,
                    icone: Icons.format_list_numbered_rounded,
                    titulo: 'Texto',
                    descricao: 'Lista simples\nde nome e valor',
                    selecionado: app.modoPainelTexto,
                    aoTocar: () {
                      AudioService.clique();
                      context.read<AppController>().trocarModoPainel(true);
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: tema.espaco + 6),

            // ---------------- SOM DOS AVISOS ----------------
            TituloBloco(tema: tema, texto: 'Som dos avisos'),
            Caixa(
              tema: tema,
              child: Column(
                children: <Widget>[
                  for (var i = 0; i < AudioService.listaDeSons.length; i++)
                    ...<Widget>[
                    if (i > 0) Divider(height: 18, color: tema.divisor),
                    _LinhaEscolha(
                      tema: tema,
                      titulo: AudioService.listaDeSons[i].rotulo,
                      descricao: AudioService.listaDeSons[i].descricao,
                      selecionada: app.somNotificacao ==
                          AudioService.listaDeSons[i].id,
                      aoTocar: () {
                        // Escolher já TOCA o som: o motorista ouve na hora
                        // o que acabou de escolher.
                        context.read<AppController>().trocarSomNotificacao(
                              AudioService.listaDeSons[i].id,
                            );
                      },
                    ),
                  ],
                  Divider(height: 18, color: tema.divisor),
                  Row(
                    children: <Widget>[
                      Icon(Icons.play_circle_outline_rounded,
                          size: 18, color: tema.textoSuave),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Toque em um som para ouvir. Com "Sons" desligado '
                          'em Detalhes, nada toca.',
                          style: context.textos.bodySmall,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: tema.espaco + 6),

            // ---------------- DETALHES ----------------
            TituloBloco(tema: tema, texto: 'Detalhes'),
            Caixa(
              tema: tema,
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              child: Column(
                children: <Widget>[
                  SwitchListTile(
                    value: app.numerosMono,
                    onChanged: (v) {
                      AudioService.toqueLeve();
                      context.read<AppController>().alternarNumerosMono(v);
                    },
                    secondary: Icon(Icons.pin_rounded, color: tema.primaria),
                    title: const Text('Números alinhados'),
                    subtitle: Text(
                      'As casas ficam uma embaixo da outra, como num painel',
                      style: context.textos.bodySmall,
                    ),
                  ),
                  Divider(height: 4, color: tema.divisor),
                  SwitchListTile(
                    value: app.compacto,
                    onChanged: (v) {
                      AudioService.toqueLeve();
                      context.read<AppController>().trocarDensidade(v);
                    },
                    secondary: Icon(Icons.density_small_rounded,
                        color: tema.secundaria),
                    title: const Text('Modo compacto'),
                    subtitle: Text(
                      'Aperta os espaços e cabe mais coisa na tela',
                      style: context.textos.bodySmall,
                    ),
                  ),
                  Divider(height: 4, color: tema.divisor),
                  SwitchListTile(
                    value: app.animacoesAtivas,
                    onChanged: (v) {
                      AudioService.toqueLeve();
                      context.read<AppController>().alternarAnimacoes(v);
                    },
                    secondary:
                        Icon(Icons.animation_rounded, color: tema.alerta),
                    title: const Text('Animações'),
                    subtitle: Text(
                      'Desligue se o celular estiver lento',
                      style: context.textos.bodySmall,
                    ),
                  ),
                  Divider(height: 4, color: tema.divisor),
                  SwitchListTile(
                    value: app.sonsAtivos,
                    onChanged: (v) {
                      context.read<AppController>().alternarSons(v);
                    },
                    secondary:
                        Icon(Icons.volume_up_rounded, color: tema.sucesso),
                    title: const Text('Sons'),
                    subtitle: Text(
                      'Cliques e avisos sonoros',
                      style: context.textos.bodySmall,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
// PRÉVIA
// =======================================================================
class _Previa extends StatelessWidget {
  final TemaFarol tema;

  const _Previa({required this.tema});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        CartaoDestaque(
          tema: tema,
          rotulo: 'Lucro de hoje',
          valor: 'R\$ 284,90',
          detalhe: '18 corridas · 142,0 km · 7h30 · R\$ 37,99/h',
          progressoMeta: 0.72,
          textoAnel: '72%',
          animar: false,
        ),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            Expanded(
              child: CartaoMetrica(
                tema: tema,
                rotulo: 'Bruto do dia',
                valor: 'R\$ 412,50',
                detalhe: 'o que os aplicativos mostraram',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: CartaoMetrica(
                tema: tema,
                rotulo: 'Lucro por km',
                valor: 'R\$ 2,01',
                detalhe: 'exemplo só para você ver a fonte',
                corValor: tema.sucesso,
                faixa: tema.primaria,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// =======================================================================
class _CartaoModo extends StatelessWidget {
  final TemaFarol tema;
  final ModoTema modo;
  final bool selecionado;
  final VoidCallback aoTocar;

  const _CartaoModo({
    required this.tema,
    required this.modo,
    required this.selecionado,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionado,
      label: modo.rotulo,
      child: Material(
        color: selecionado
            ? tema.primaria.withValues(alpha: 0.15)
            : tema.superficie,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(tema.raioBorda),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(tema.raioBorda),
              border: Border.all(
                color: selecionado ? tema.primaria : tema.divisor,
                width: selecionado ? 1.8 : 1,
              ),
            ),
            child: Column(
              children: <Widget>[
                Icon(
                  modo.icone,
                  size: 24,
                  color: selecionado ? tema.primaria : tema.textoSuave,
                ),
                const SizedBox(height: 7),
                Text(
                  modo.rotulo,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: selecionado ? tema.primaria : tema.texto,
                    fontSize: 13,
                    fontWeight:
                        selecionado ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
class _Amostra extends StatelessWidget {
  final TemaFarol tema;
  final String nome;
  final Color cor;
  final bool selecionada;
  final VoidCallback aoTocar;

  const _Amostra({
    required this.tema,
    required this.nome,
    required this.cor,
    required this.selecionada,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionada,
      label: 'Cor $nome',
      child: GestureDetector(
        onTap: aoTocar,
        // 48x48 no total: dá para acertar com o dedo sem errar de cor.
        child: SizedBox(
          width: 48,
          height: 48,
          child: Center(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: selecionada ? 44 : 38,
              height: selecionada ? 44 : 38,
              decoration: BoxDecoration(
                color: cor,
                shape: BoxShape.circle,
                border: Border.all(
                  color: selecionada ? tema.texto : Colors.transparent,
                  width: 2.5,
                ),
              ),
              child: selecionada
                  ? Icon(
                      Icons.check_rounded,
                      size: 20,
                      color: TemaFarol.contrasteSobre(cor),
                    )
                  : null,
            ),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
class _Opcao extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  final double tamanhoDemo;
  final bool selecionado;
  final VoidCallback aoTocar;

  const _Opcao({
    required this.tema,
    required this.texto,
    required this.tamanhoDemo,
    required this.selecionado,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionado,
      child: Material(
        color: selecionado ? tema.primaria : tema.superficieAlta,
        borderRadius: BorderRadius.circular(11),
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(11),
          child: Container(
            constraints: const BoxConstraints(minHeight: 56),
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Aa',
                  style: TextStyle(
                    fontSize: tamanhoDemo + 6,
                    fontWeight: FontWeight.w700,
                    color: selecionado
                        ? tema.textoSobrePrimaria
                        : tema.texto,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  texto,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600,
                    color: selecionado
                        ? tema.textoSobrePrimaria
                        : tema.textoSuave,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
class _LinhaEscolha extends StatelessWidget {
  final TemaFarol tema;
  final String titulo;
  final String descricao;
  final bool selecionada;
  final VoidCallback aoTocar;

  const _LinhaEscolha({
    required this.tema,
    required this.titulo,
    required this.descricao,
    required this.selecionada,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: aoTocar,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: <Widget>[
            Icon(
              selecionada
                  ? Icons.radio_button_checked_rounded
                  : Icons.radio_button_unchecked_rounded,
              color: selecionada ? tema.primaria : tema.textoSuave,
              size: 22,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(titulo, style: context.textos.titleMedium),
                  const SizedBox(height: 2),
                  Text(descricao, style: context.textos.bodySmall),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
// CARTÃO DE ESCOLHA DO MODO DO PAINEL
// =======================================================================
/// Dois cartões lado a lado, com uma miniatura desenhada de como cada
/// modo fica. O escolhido ganha borda colorida e o "check".
class _CartaoModoPainel extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final String titulo;
  final String descricao;
  final bool selecionado;
  final VoidCallback aoTocar;

  const _CartaoModoPainel({
    required this.tema,
    required this.icone,
    required this.titulo,
    required this.descricao,
    required this.selecionado,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionado,
      child: InkWell(
        onTap: aoTocar,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          decoration: BoxDecoration(
            color: selecionado
                ? tema.primaria.withValues(alpha: 0.12)
                : tema.superficie,
            borderRadius: BorderRadius.circular(tema.raioBorda),
            border: Border.all(
              color: selecionado ? tema.primaria : tema.divisor,
              width: selecionado ? 2 : 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Icon(
                    icone,
                    size: 22,
                    color: selecionado ? tema.primaria : tema.textoSuave,
                  ),
                  const Spacer(),
                  if (selecionado)
                    Icon(Icons.check_circle_rounded,
                        size: 18, color: tema.primaria),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                titulo,
                style: context.textos.titleMedium?.copyWith(
                  color: selecionado ? tema.primaria : tema.texto,
                ),
              ),
              const SizedBox(height: 3),
              Text(descricao, style: context.textos.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}
