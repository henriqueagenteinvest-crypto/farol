/// -----------------------------------------------------------------------
/// APARÊNCIA
/// -----------------------------------------------------------------------
/// Aqui o motorista decide como o app se parece:
///   • Modo: claro, escuro ou automático (segue o celular)
///   • Cor principal: uma paleta pronta, aplicada no app inteiro
///   • Modo de visualização: como os indicadores aparecem na tela inicial
///
/// Tudo muda NA HORA, sem reiniciar, e fica salvo no celular.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/audio_service.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../controllers/app_controller.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/campo_farol.dart';

class AparenciaScreen extends StatelessWidget {
  const AparenciaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;

    return Scaffold(
      appBar: AppBar(title: const Text('Aparência')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          children: <Widget>[
            // ---------------- Prévia ao vivo ----------------
            _Previa(tema: tema),
            const SizedBox(height: 28),

            // ---------------- Modo claro / escuro ----------------
            const TituloSecao(
              texto: 'Modo',
              icone: Icons.contrast_rounded,
            ),
            Row(
              children: <Widget>[
                for (final m in ModoTema.values) ...<Widget>[
                  Expanded(
                    child: _CartaoModo(
                      modo: m,
                      selecionado: app.modoTema == m,
                      tema: tema,
                      aoTocar: () {
                        AudioService.clique();
                        context.read<AppController>().trocarModoTema(m);
                      },
                    ),
                  ),
                  if (m != ModoTema.values.last) const SizedBox(width: 10),
                ],
              ],
            ),
            const SizedBox(height: 28),

            // ---------------- Cor principal ----------------
            const TituloSecao(
              texto: 'Cor principal',
              icone: Icons.palette_rounded,
            ),
            Text(
              'A cor escolhida vale para botões, gráficos, destaques e o '
              'app inteiro.',
              style: context.textos.bodySmall,
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 14,
              runSpacing: 14,
              children: <Widget>[
                for (final c in PaletaCores.cores)
                  _Swatch(
                    corPaleta: c,
                    selecionada:
                        app.corPrimaria.toARGB32() == c.cor.toARGB32(),
                    tema: tema,
                    aoTocar: () {
                      AudioService.clique();
                      context.read<AppController>().trocarCor(c.cor);
                    },
                  ),
              ],
            ),
            const SizedBox(height: 28),

            // ---------------- Modo de visualização ----------------
            const TituloSecao(
              texto: 'Como mostrar os indicadores',
              icone: Icons.dashboard_customize_rounded,
            ),
            for (final v in ModoVisualizacao.values)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _LinhaVisualizacao(
                  modo: v,
                  selecionado: app.modoVisualizacao == v,
                  tema: tema,
                  aoTocar: () {
                    AudioService.clique();
                    context.read<AppController>().trocarVisualizacao(v);
                  },
                ),
              ),
            const SizedBox(height: 22),

            // ---------------- Conforto ----------------
            const TituloSecao(
              texto: 'Conforto',
              icone: Icons.tune_rounded,
            ),
            CartaoFarol(
              tema: tema,
              child: Column(
                children: <Widget>[
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary:
                        Icon(Icons.animation_rounded, color: tema.secundaria),
                    title: const Text('Animações'),
                    subtitle: Text(
                      'Desligue se o celular estiver lento',
                      style: context.textos.bodySmall,
                    ),
                    value: app.animacoesAtivas,
                    onChanged: (v) =>
                        context.read<AppController>().alternarAnimacoes(v),
                  ),
                  Divider(height: 6, color: tema.divisor),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary:
                        Icon(Icons.volume_up_rounded, color: tema.alerta),
                    title: const Text('Sons'),
                    subtitle: Text(
                      'Toques de botão e som ao bater a meta',
                      style: context.textos.bodySmall,
                    ),
                    value: app.sonsAtivos,
                    onChanged: (v) {
                      context.read<AppController>().alternarSons(v);
                      AudioService.clique();
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
// PRÉVIA AO VIVO
// =======================================================================
class _Previa extends StatelessWidget {
  final TemaFarol tema;
  const _Previa({required this.tema});

  @override
  Widget build(BuildContext context) {
    return CartaoFarol(
      tema: tema,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Prévia', style: context.textos.labelMedium),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(
                flex: 3,
                child: Container(
                  height: 74,
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    gradient: tema.gradienteLinear,
                    borderRadius: BorderRadius.circular(tema.raioBorda * 0.8),
                    boxShadow: tema.brilhoDe(tema.primaria),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'LUCRO DE HOJE',
                        style: TextStyle(
                          color: tema.textoSobrePrimaria
                              .withValues(alpha: 0.85),
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'R\$ 224,09',
                        style: TextStyle(
                          color: tema.textoSobrePrimaria,
                          fontSize: 21,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: Container(
                  height: 74,
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: tema.superficieAlta,
                    borderRadius: BorderRadius.circular(tema.raioBorda * 0.8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(Icons.route_rounded,
                          size: 16, color: tema.secundaria),
                      const SizedBox(height: 6),
                      Text(
                        '240,0 km',
                        style: TextStyle(
                          color: tema.texto,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// CARTÃO DE MODO (claro / escuro / automático)
// =======================================================================
class _CartaoModo extends StatelessWidget {
  final ModoTema modo;
  final bool selecionado;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _CartaoModo({
    required this.modo,
    required this.selecionado,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionado,
      label: '${modo.rotulo}. ${modo.descricao}',
      child: GestureDetector(
        onTap: aoTocar,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
          constraints: const BoxConstraints(minHeight: 104),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
          decoration: BoxDecoration(
            color: selecionado
                ? tema.primaria.withValues(alpha: 0.14)
                : tema.superficie,
            borderRadius: BorderRadius.circular(tema.raioBorda),
            border: Border.all(
              color: selecionado ? tema.primaria : tema.divisor,
              width: selecionado ? 2 : 1,
            ),
            boxShadow: selecionado ? tema.brilhoDe(tema.primaria) : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(
                modo.icone,
                size: 26,
                color: selecionado ? tema.primaria : tema.textoSuave,
              ),
              const SizedBox(height: 8),
              Text(
                modo.rotulo,
                textAlign: TextAlign.center,
                style: context.textos.titleMedium?.copyWith(
                  color: selecionado ? tema.primaria : tema.texto,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                modo.descricao,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: context.textos.bodySmall?.copyWith(fontSize: 10.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// BOLINHA DE COR
// =======================================================================
class _Swatch extends StatelessWidget {
  final CorPaleta corPaleta;
  final bool selecionada;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _Swatch({
    required this.corPaleta,
    required this.selecionada,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionada,
      label: 'Cor ${corPaleta.nome}',
      child: GestureDetector(
        onTap: aoTocar,
        // Alvo de toque confortável (mínimo 44x44).
        child: SizedBox(
          width: 62,
          height: 76,
          child: Column(
            children: <Widget>[
              AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutBack,
                width: selecionada ? 50 : 44,
                height: selecionada ? 50 : 44,
                decoration: BoxDecoration(
                  color: corPaleta.cor,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selecionada ? tema.texto : Colors.transparent,
                    width: 3,
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: corPaleta.cor.withValues(alpha: 0.45),
                      blurRadius: selecionada ? 16 : 6,
                      spreadRadius: -2,
                    ),
                  ],
                ),
                child: selecionada
                    ? Icon(
                        Icons.check_rounded,
                        size: 24,
                        color: TemaFarol.contrasteSobre(corPaleta.cor),
                      )
                    : null,
              ),
              const SizedBox(height: 5),
              Text(
                corPaleta.nome,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 9.5,
                  color: selecionada ? tema.texto : tema.textoSuave,
                  fontWeight:
                      selecionada ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// LINHA DE MODO DE VISUALIZAÇÃO
// =======================================================================
class _LinhaVisualizacao extends StatelessWidget {
  final ModoVisualizacao modo;
  final bool selecionado;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _LinhaVisualizacao({
    required this.modo,
    required this.selecionado,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionado,
      child: GestureDetector(
        onTap: aoTocar,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: selecionado
                ? tema.primaria.withValues(alpha: 0.12)
                : tema.superficie,
            borderRadius: BorderRadius.circular(tema.raioBorda),
            border: Border.all(
              color: selecionado ? tema.primaria : tema.divisor,
              width: selecionado ? 2 : 1,
            ),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: (selecionado ? tema.primaria : tema.textoSuave)
                      .withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(
                  modo.icone,
                  size: 21,
                  color: selecionado ? tema.primaria : tema.textoSuave,
                ),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(modo.rotulo, style: context.textos.titleMedium),
                    const SizedBox(height: 2),
                    Text(modo.descricao, style: context.textos.bodySmall),
                  ],
                ),
              ),
              if (selecionado)
                Icon(Icons.check_circle_rounded, color: tema.primaria),
            ],
          ),
        ),
      ),
    );
  }
}
