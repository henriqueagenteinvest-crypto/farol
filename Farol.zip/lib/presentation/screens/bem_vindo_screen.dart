/// -----------------------------------------------------------------------
/// SEJA BEM-VINDO — a festa da primeira vez
/// -----------------------------------------------------------------------
/// Aparece uma única vez, logo depois do primeiro cadastro: fogos saindo
/// dos dois cantos de baixo, o nome do motorista aparecendo e o farol
/// acendendo. Dura poucos segundos e tem um botão para pular.
///
/// Respeita o interruptor de animações: com ele desligado, a tela ainda
/// dá as boas-vindas, só que sem os fogos.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../controllers/app_controller.dart';
import '../widgets/logo_farol.dart';

class BemVindoScreen extends StatefulWidget {
  const BemVindoScreen({super.key});

  @override
  State<BemVindoScreen> createState() => _BemVindoScreenState();
}

class _BemVindoScreenState extends State<BemVindoScreen>
    with TickerProviderStateMixin {
  late final ConfettiController _esquerda;
  late final ConfettiController _direita;
  late final AnimationController _entrada;

  bool _saindo = false;

  @override
  void initState() {
    super.initState();

    _esquerda = ConfettiController(duration: const Duration(seconds: 3));
    _direita = ConfettiController(duration: const Duration(seconds: 3));

    _entrada = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..forward();

    // Deixa a tela montar antes de soltar os fogos.
    WidgetsBinding.instance.addPostFrameCallback((_) => _comecarFesta());
  }

  Future<void> _comecarFesta() async {
    if (!mounted) return;
    final app = context.read<AppController>();

    AudioService.comemorar();

    if (app.animacoesAtivas) {
      _esquerda.play();
      await Future<void>.delayed(const Duration(milliseconds: 400));
      if (!mounted) return;
      _direita.play();
      // Uma segunda salva, para parecer fogos de verdade.
      await Future<void>.delayed(const Duration(milliseconds: 1100));
      if (!mounted) return;
      _esquerda.play();
      _direita.play();
    }

    await Future<void>.delayed(const Duration(milliseconds: 3200));
    _entrar();
  }

  void _entrar() {
    if (_saindo || !mounted) return;
    _saindo = true;
    Navigator.of(context).pushReplacementNamed(AppRoutes.principal);
  }

  @override
  void dispose() {
    _esquerda.dispose();
    _direita.dispose();
    _entrada.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;
    final nome = app.motorista?.primeiroNome ?? '';
    final carro = app.motorista?.modeloCarro ?? '';

    final aparecer = CurvedAnimation(
      parent: _entrada,
      curve: const Interval(0, 0.55, curve: Curves.easeOut),
    );
    final subir = CurvedAnimation(
      parent: _entrada,
      curve: const Interval(0.25, 1, curve: Curves.easeOutCubic),
    );

    return Scaffold(
      backgroundColor: tema.fundo,
      body: Stack(
        children: <Widget>[
          Container(decoration: BoxDecoration(gradient: tema.gradienteFundo)),

          // ---------------- CONTEÚDO ----------------
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  FadeTransition(
                    opacity: aparecer,
                    child: ScaleTransition(
                      scale: Tween<double>(begin: 0.6, end: 1).animate(
                        CurvedAnimation(
                          parent: _entrada,
                          curve: const Interval(0, 0.6,
                              curve: Curves.easeOutBack),
                        ),
                      ),
                      child: LogoFarol(tema: tema, tamanho: 128),
                    ),
                  ),
                  const SizedBox(height: 34),

                  FadeTransition(
                    opacity: subir,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.35),
                        end: Offset.zero,
                      ).animate(subir),
                      child: Column(
                        children: <Widget>[
                          Text(
                            'Seja bem-vindo!',
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .displaySmall
                                ?.copyWith(color: tema.primaria),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            nome.isEmpty ? 'Vamos começar' : nome,
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                          if (carro.isNotEmpty) ...<Widget>[
                            const SizedBox(height: 6),
                            Text(
                              carro,
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ],
                          const SizedBox(height: 22),
                          Text(
                            'A partir de agora, cada corrida vira número. '
                            'Você vai saber exatamente quanto sobra no seu '
                            'bolso no fim do dia.',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ---------------- FOGOS ----------------
          if (app.animacoesAtivas) ...<Widget>[
            Align(
              alignment: Alignment.bottomLeft,
              child: _Fogos(controle: _esquerda, tema: tema, angulo: -math.pi / 3),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child:
                  _Fogos(controle: _direita, tema: tema, angulo: -2 * math.pi / 3),
            ),
          ],

          // ---------------- PULAR ----------------
          Positioned(
            left: 0,
            right: 0,
            bottom: 28,
            child: Center(
              child: TextButton(
                onPressed: _entrar,
                child: const Text('Entrar agora'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Um jorro de fogos saindo de um canto.
class _Fogos extends StatelessWidget {
  final ConfettiController controle;
  final TemaFarol tema;

  /// Para onde o jorro aponta, em radianos.
  final double angulo;

  const _Fogos({
    required this.controle,
    required this.tema,
    required this.angulo,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: ConfettiWidget(
        confettiController: controle,
        blastDirection: angulo,
        emissionFrequency: 0.06,
        numberOfParticles: 22,
        maxBlastForce: 34,
        minBlastForce: 16,
        gravity: 0.28,
        shouldLoop: false,
        colors: <Color>[
          tema.primaria,
          tema.secundaria,
          tema.sucesso,
          tema.alerta,
          const Color(0xFFFFD166),
          Colors.white,
        ],
      ),
    );
  }
}
