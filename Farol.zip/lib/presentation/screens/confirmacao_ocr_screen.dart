/// =======================================================================
/// CONFIRMAÇÃO DA LEITURA DO PRINT
/// =======================================================================
/// ESTA TELA É OBRIGATÓRIA. Nenhum dado lido de imagem entra no app sem
/// passar por aqui. É o que garante a regra "zero erro de cálculo": se o
/// OCR errou, o motorista corrige antes de salvar.
///
/// Os campos que o app leu com pouca confiança aparecem MARCADOS, para o
/// motorista olhar com mais atenção. Os que não foram encontrados ficam
/// vazios, esperando o preenchimento manual.
/// =======================================================================
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../services/ocr_resultado.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import 'lancamento_screen.dart';

class ConfirmacaoOcrScreen extends StatefulWidget {
  final ResultadoOcr resultado;

  const ConfirmacaoOcrScreen({super.key, required this.resultado});

  @override
  State<ConfirmacaoOcrScreen> createState() => _ConfirmacaoOcrScreenState();
}

class _ConfirmacaoOcrScreenState extends State<ConfirmacaoOcrScreen> {
  final _formulario = GlobalKey<FormState>();
  final _valor = TextEditingController();
  final _corridas = TextEditingController();
  final _horas = TextEditingController();
  final _km = TextEditingController();

  late DateTime _data;

  @override
  void initState() {
    super.initState();
    final r = widget.resultado;

    // Campo encontrado -> já vem preenchido.
    // Campo NÃO encontrado -> fica vazio para o motorista digitar.
    if (r.valorBruto.encontrado) {
      _valor.text = Fmt.numero(r.valorBruto.valor!);
    }
    if (r.corridas.encontrado) {
      _corridas.text = r.corridas.valor!.toString();
    }
    if (r.horas.encontrado) {
      _horas.text = Fmt.numero(r.horas.valor!, casas: 2);
    }
    if (r.km.encontrado) {
      _km.text = Fmt.numero(r.km.valor!, casas: 1);
    }
    _data = r.data.valor ?? DateTime.now();
  }

  @override
  void dispose() {
    _valor.dispose();
    _corridas.dispose();
    _horas.dispose();
    _km.dispose();
    super.dispose();
  }

  /// Leva os dados confirmados para a tela de lançamento, onde o motorista
  /// completa o combustível e vê os cálculos antes de salvar de vez.
  Future<void> _confirmar() async {
    if (!_formulario.currentState!.validate()) {
      AudioService.erro();
      context.aviso('Confira os campos marcados', erro: true);
      return;
    }
    AudioService.sucesso();

    await Navigator.of(context).pushReplacementNamed(
      AppRoutes.lancamento,
      arguments: ArgsLancamento(
        valorSugerido: Fmt.paraDouble(_valor.text),
        corridasSugeridas: Fmt.paraInt(_corridas.text),
        horasSugeridas: Fmt.paraDouble(_horas.text),
        kmSugerido: Fmt.paraDouble(_km.text),
        dataSugerida: _data,
        veioDeOcr: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;
    final r = widget.resultado;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Confira o que eu li'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: Form(
          key: _formulario,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
            children: <Widget>[
              // ---------------- O QUE FOI IDENTIFICADO ----------------
              _CartaoLeitura(tema: tema, resultado: r),
              const SizedBox(height: 22),

              // ---------------- AVISOS ----------------
              if (r.avisos.isNotEmpty) ...<Widget>[
                _Avisos(tema: tema, avisos: r.avisos),
                const SizedBox(height: 22),
              ],

              // ---------------- CAMPOS EDITÁVEIS ----------------
              const TituloSecao(
                texto: 'Corrija o que estiver errado',
                icone: Icons.edit_rounded,
              ),
              CampoData(
                data: _data,
                tema: tema,
                rotulo: 'Data do resumo',
                aoMudar: (d) => setState(() => _data = d),
              ),
              const SizedBox(height: 16),

              _CampoComConfianca(
                campo: r.valorBruto,
                tema: tema,
                filho: CampoFarol.dinheiro(
                  controlador: _valor,
                  rotulo: 'Quanto recebeu (bruto)',
                  validador: (v) => Validadores.valorPositivo(
                    v,
                    campo: 'O valor recebido',
                  ),
                ),
              ),
              const SizedBox(height: 16),

              _CampoComConfianca(
                campo: r.corridas,
                tema: tema,
                filho: CampoFarol.inteiro(
                  controlador: _corridas,
                  rotulo: 'Quantidade de corridas',
                  icone: Icons.local_taxi_rounded,
                  validador: (v) =>
                      Validadores.corridas(v, obrigatorioCampo: false),
                ),
              ),
              const SizedBox(height: 16),

              _CampoComConfianca(
                campo: r.horas,
                tema: tema,
                filho: CampoFarol.decimal(
                  controlador: _horas,
                  rotulo: 'Horas trabalhadas',
                  icone: Icons.schedule_rounded,
                  sufixo: 'h',
                  validador: (v) =>
                      Validadores.horas(v, obrigatorioCampo: false),
                  ajuda: 'Use ponto ou vírgula: 8,5 quer dizer 8h30',
                ),
              ),
              const SizedBox(height: 16),

              _CampoComConfianca(
                campo: r.km,
                tema: tema,
                filho: CampoFarol.decimal(
                  controlador: _km,
                  rotulo: 'KM rodados',
                  icone: Icons.route_rounded,
                  sufixo: 'km',
                  validador: (v) =>
                      Validadores.km(v, obrigatorioCampo: false),
                  ajuda: r.km.encontrado
                      ? null
                      : 'O print não mostrava os KM. Sem eles não dá para '
                          'calcular o combustível.',
                ),
              ),
              const SizedBox(height: 30),

              BotaoGrande(
                texto: 'Está correto, continuar',
                icone: Icons.check_circle_rounded,
                tema: tema,
                altura: 66,
                aoTocar: _confirmar,
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () {
                  AudioService.toqueLeve();
                  Navigator.of(context)
                      .pushReplacementNamed(AppRoutes.importarPrint);
                },
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Tentar com outra imagem'),
              ),
              const SizedBox(height: 10),
              Center(
                child: TextButton(
                  onPressed: () {
                    AudioService.toqueLeve();
                    Navigator.of(context).pop();
                  },
                  child: const Text('Cancelar'),
                ),
              ),

              // ---------------- TEXTO LIDO (para conferência) ----------
              const SizedBox(height: 20),
              _TextoLido(tema: tema, texto: r.textoBruto),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// CARTÃO COM O RESUMO DA LEITURA
// =======================================================================
class _CartaoLeitura extends StatelessWidget {
  final TemaFarol tema;
  final ResultadoOcr resultado;

  const _CartaoLeitura({required this.tema, required this.resultado});

  @override
  Widget build(BuildContext context) {
    final qualidade = resultado.qualidadeGeral;
    final Color cor;
    final String nota;
    if (qualidade >= 0.75) {
      cor = tema.sucesso;
      nota = 'Leitura muito boa';
    } else if (qualidade >= 0.45) {
      cor = tema.alerta;
      nota = 'Leitura parcial — confira com atenção';
    } else {
      cor = tema.erro;
      nota = 'Leitura difícil — confira tudo';
    }

    return CartaoFarol(
      tema: tema,
      corBorda: cor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.document_scanner_rounded, color: cor, size: 21),
              const SizedBox(width: 9),
              Expanded(
                child: Text(nota, style: context.textos.titleMedium),
              ),
              if (resultado.origem != OrigemPrint.desconhecida)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: tema.superficieAlta,
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(
                    resultado.origem.rotulo,
                    style: context.textos.labelSmall,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          // Barra de qualidade da leitura.
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: qualidade,
              minHeight: 7,
              backgroundColor: tema.superficieAlta,
              valueColor: AlwaysStoppedAnimation<Color>(cor),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Identifiquei:',
            style: context.textos.labelMedium,
          ),
          const SizedBox(height: 6),
          Text(
            resultado.frasePreview,
            style: context.textos.headlineSmall?.copyWith(color: cor),
          ),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Icon(
                Icons.calendar_month_rounded,
                size: 15,
                color: tema.textoSuave,
              ),
              const SizedBox(width: 7),
              Text(
                'Resumo ${resultado.tipo.rotulo.toLowerCase()}',
                style: context.textos.bodySmall,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// LISTA DE AVISOS
// =======================================================================
class _Avisos extends StatelessWidget {
  final TemaFarol tema;
  final List<String> avisos;

  const _Avisos({required this.tema, required this.avisos});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: tema.alerta.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(tema.raioBorda * 0.8),
        border: Border.all(color: tema.alerta.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.info_rounded, size: 18, color: tema.alerta),
              const SizedBox(width: 8),
              Text('Fique de olho', style: context.textos.titleMedium),
            ],
          ),
          const SizedBox(height: 10),
          for (final a in avisos)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: BoxDecoration(
                        color: tema.alerta,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(a, style: context.textos.bodySmall),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// CAMPO COM SELO DE CONFIANÇA
// =======================================================================
class _CampoComConfianca extends StatelessWidget {
  final CampoExtraido<dynamic> campo;
  final TemaFarol tema;
  final Widget filho;

  const _CampoComConfianca({
    required this.campo,
    required this.tema,
    required this.filho,
  });

  @override
  Widget build(BuildContext context) {
    final (IconData icone, Color cor, String texto) selo;
    if (!campo.encontrado) {
      selo = (Icons.edit_rounded, tema.textoSuave, 'Não encontrei — preencha');
    } else if (campo.confiavel) {
      selo = (Icons.check_circle_rounded, tema.sucesso, 'Li com segurança');
    } else {
      selo = (Icons.help_rounded, tema.alerta, 'Confira este número');
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        filho,
        Padding(
          padding: const EdgeInsets.only(left: 14, top: 6),
          child: Row(
            children: <Widget>[
              Icon(selo.$1, size: 13, color: selo.$2),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  campo.trecho == null
                      ? selo.$3
                      : '${selo.$3} — li de "${campo.trecho}"',
                  style: context.textos.bodySmall?.copyWith(color: selo.$2),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// =======================================================================
// TEXTO BRUTO LIDO (recolhido)
// =======================================================================
class _TextoLido extends StatelessWidget {
  final TemaFarol tema;
  final String texto;

  const _TextoLido({required this.tema, required this.texto});

  @override
  Widget build(BuildContext context) {
    if (texto.trim().isEmpty) return const SizedBox.shrink();

    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        title: Text(
          'Ver todo o texto que eu li na imagem',
          style: context.textos.bodySmall,
        ),
        iconColor: tema.textoSuave,
        collapsedIconColor: tema.textoSuave,
        children: <Widget>[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: tema.superficieAlta,
              borderRadius: BorderRadius.circular(12),
            ),
            child: SelectableText(
              texto,
              style: context.textos.bodySmall?.copyWith(height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}
