/// -----------------------------------------------------------------------
/// SIMULADOR DE PATRIMÔNIO (JUROS COMPOSTOS)
/// -----------------------------------------------------------------------
/// Dois modos:
///   • "Vou guardar X por mês"  -> mostra quanto vira e quando chega na meta
///   • "Quero X em Y anos"      -> mostra quanto precisa guardar por mês
/// Todas as contas ficam no CalculationsService.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../domain/entities/resumo_periodo.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/graficos_farol.dart';

class SimuladorScreen extends StatefulWidget {
  const SimuladorScreen({super.key});

  @override
  State<SimuladorScreen> createState() => _SimuladorScreenState();
}

class _SimuladorScreenState extends State<SimuladorScreen> {
  /// false = simular o futuro | true = descobrir o aporte necessário
  bool _modoReverso = false;

  final _inicial = TextEditingController(text: '0,00');
  final _aporte = TextEditingController(text: '500,00');
  final _taxa = TextEditingController(text: '0,80');
  final _meta = TextEditingController(text: '100.000,00');
  final _anos = TextEditingController(text: '10');

  @override
  void dispose() {
    _inicial.dispose();
    _aporte.dispose();
    _taxa.dispose();
    _meta.dispose();
    _anos.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  double get _valorInicial => Fmt.paraDoubleOuZero(_inicial.text);
  double get _aporteMensal => Fmt.paraDoubleOuZero(_aporte.text);
  double get _taxaMensal => Fmt.paraDoubleOuZero(_taxa.text);
  double get _valorMeta => Fmt.paraDoubleOuZero(_meta.text);
  int get _meses => ((Fmt.paraInt(_anos.text) ?? 0) * 12).clamp(0, 1200);

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;
    final animar = context.watch<AppController>().animacoesAtivas;

    return Scaffold(
      appBar: AppBar(title: const Text('Simulador de patrimônio')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
          children: <Widget>[
            Text(
              'Veja o que acontece se você guardar uma parte do que ganha '
              'todo mês. O dinheiro rende sobre o rendimento — é isso que '
              'chamam de juros compostos.',
              style: context.textos.bodyMedium?.copyWith(
                color: tema.textoSuave,
              ),
            ),
            const SizedBox(height: 22),

            SeletorOpcoes(
              rotulo: 'O que você quer descobrir',
              opcoes: const <String>[
                'Quanto vou ter',
                'Quanto guardar por mês',
              ],
              selecionada: _modoReverso
                  ? 'Quanto guardar por mês'
                  : 'Quanto vou ter',
              tema: tema,
              aoSelecionar: (v) => setState(
                () => _modoReverso = v.contains('guardar'),
              ),
            ),
            const SizedBox(height: 24),

            // ---------------- Campos ----------------
            CampoFarol.dinheiro(
              controlador: _inicial,
              rotulo: 'Quanto você já tem guardado',
              aoMudar: (_) => setState(() {}),
              ajuda: 'Coloque 0 se está começando do zero',
            ),
            const SizedBox(height: 14),

            if (!_modoReverso)
              CampoFarol.dinheiro(
                controlador: _aporte,
                rotulo: 'Quanto vai guardar por mês',
                aoMudar: (_) => setState(() {}),
              )
            else
              CampoFarol.dinheiro(
                controlador: _meta,
                rotulo: 'Quanto você quer ter',
                icone: Icons.flag_rounded,
                aoMudar: (_) => setState(() {}),
              ),
            const SizedBox(height: 14),

            Row(
              children: <Widget>[
                Expanded(
                  child: CampoFarol.decimal(
                    controlador: _taxa,
                    rotulo: 'Rendimento',
                    icone: Icons.trending_up_rounded,
                    sufixo: '% ao mês',
                    validador: Validadores.taxaJuros,
                    aoMudar: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CampoFarol.inteiro(
                    controlador: _anos,
                    rotulo: 'Em quantos anos',
                    icone: Icons.schedule_rounded,
                    aoMudar: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _AtalhosTaxa(tema: tema, aoEscolher: (v) {
              setState(() => _taxa.text = Fmt.numero(v));
            }),
            const SizedBox(height: 26),

            // ---------------- Resultado ----------------
            if (_modoReverso)
              _ResultadoReverso(
                tema: tema,
                meta: _valorMeta,
                inicial: _valorInicial,
                taxa: _taxaMensal,
                meses: _meses,
              )
            else
              _ResultadoDireto(
                tema: tema,
                inicial: _valorInicial,
                aporte: _aporteMensal,
                taxa: _taxaMensal,
                meses: _meses,
                meta: _valorMeta,
                animar: animar,
              ),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
// ATALHOS DE TAXA
// =======================================================================
class _AtalhosTaxa extends StatelessWidget {
  final TemaFarol tema;
  final ValueChanged<double> aoEscolher;

  const _AtalhosTaxa({required this.tema, required this.aoEscolher});

  @override
  Widget build(BuildContext context) {
    // Referências comuns, em % ao mês. São só atalhos — o motorista edita.
    final opcoes = <(String, double)>[
      ('Poupança (~0,5%)', 0.5),
      ('CDI (~0,9%)', 0.9),
      ('Tesouro (~1,0%)', 1.0),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: <Widget>[
        for (final o in opcoes)
          ActionChip(
            label: Text(o.$1, style: const TextStyle(fontSize: 12)),
            onPressed: () {
              AudioService.toqueLeve();
              aoEscolher(o.$2);
            },
          ),
      ],
    );
  }
}

// =======================================================================
// RESULTADO: QUANTO VOU TER
// =======================================================================
class _ResultadoDireto extends StatelessWidget {
  final TemaFarol tema;
  final double inicial;
  final double aporte;
  final double taxa;
  final int meses;
  final double meta;
  final bool animar;

  const _ResultadoDireto({
    required this.tema,
    required this.inicial,
    required this.aporte,
    required this.taxa,
    required this.meses,
    required this.meta,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    if (meses <= 0) {
      return _Aviso(tema: tema, texto: 'Informe em quantos anos você pensa.');
    }

    final montante = CalculationsService.montanteJurosCompostos(
      valorInicial: inicial,
      aporteMensal: aporte,
      taxaMensalPercentual: taxa,
      meses: meses,
    );
    final projecao = CalculationsService.projecaoPatrimonio(
      valorInicial: inicial,
      aporteMensal: aporte,
      taxaMensalPercentual: taxa,
      meses: meses,
    );
    final aportado = projecao.isEmpty ? 0.0 : projecao.last.totalAportado;
    final juros = projecao.isEmpty ? 0.0 : projecao.last.jurosAcumulados;
    final taxaAnual = CalculationsService.taxaMensalParaAnual(taxa);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        CartaoFarol(
          tema: tema,
          comGradiente: true,
          padding: const EdgeInsets.all(22),
          child: Column(
            children: <Widget>[
              Text(
                'VOCÊ VAI TER EM ${meses ~/ 12} ANOS',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.88),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 10),
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: montante),
                duration: animar
                    ? const Duration(milliseconds: 900)
                    : Duration.zero,
                curve: Curves.easeOutCubic,
                builder: (context, v, _) => FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    Fmt.moeda(v),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 36,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -1.2,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // ---- De onde vem esse dinheiro ----
        CartaoFarol(
          tema: tema,
          child: Column(
            children: <Widget>[
              _LinhaValor(
                'Você colocou do bolso',
                Fmt.moeda(aportado),
                tema.primaria,
              ),
              const Divider(height: 20),
              _LinhaValor(
                'Os juros renderam',
                Fmt.moeda(juros),
                tema.sucesso,
              ),
              const Divider(height: 20),
              _LinhaValor(
                'Rendimento equivalente ao ano',
                Fmt.percentual(taxaAnual, casas: 2),
                tema.secundaria,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // ---- Quando chega na meta ----
        if (meta > 0) ...<Widget>[
          Builder(
            builder: (context) {
              final m = CalculationsService.mesesParaMeta(
                meta: meta,
                valorInicial: inicial,
                aporteMensal: aporte,
                taxaMensalPercentual: taxa,
              );
              return CartaoFarol(
                tema: tema,
                corBorda: m < 0 ? tema.erro : tema.sucesso,
                child: Row(
                  children: <Widget>[
                    Icon(
                      m < 0 ? Icons.error_rounded : Icons.flag_rounded,
                      color: m < 0 ? tema.erro : tema.sucesso,
                      size: 22,
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Para juntar ${Fmt.moeda(meta)}',
                            style: context.textos.bodySmall,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            CalculationsService.mesesEmTexto(m),
                            style: context.textos.titleLarge?.copyWith(
                              color: m < 0 ? tema.erro : tema.sucesso,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 16),
        ],

        // ---- Gráfico da evolução ----
        const TituloSecao(
          texto: 'Como o dinheiro cresce',
          icone: Icons.show_chart_rounded,
        ),
        CartaoFarol(
          tema: tema,
          child: GraficoLinhaEvolucao(
            // Reaproveita o gráfico de linha: cada "dia" aqui é um mês.
            dados: _amostrar(projecao),
            tema: tema,
            animar: animar,
            altura: 210,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Cada ponto é um mês. Toque para ver o valor exato.',
          style: context.textos.bodySmall,
        ),
      ],
    );
  }

  /// Reduz a projeção a no máximo 60 pontos para o gráfico ficar leve
  /// e legível mesmo em simulações de 30 anos.
  List<({DateTime dia, double lucro})> _amostrar(List<ProjecaoMes> p) {
    if (p.isEmpty) return const <({DateTime dia, double lucro})>[];
    final passo = (p.length / 60).ceil().clamp(1, 999);
    final hoje = DateTime.now();
    final saida = <({DateTime dia, double lucro})>[];
    for (var i = 0; i < p.length; i += passo) {
      saida.add((
        dia: DateTime(hoje.year, hoje.month + p[i].mes, 1),
        lucro: p[i].saldo,
      ));
    }
    // Garante que o último mês sempre apareça.
    if (saida.isEmpty || saida.last.lucro != p.last.saldo) {
      saida.add((
        dia: DateTime(hoje.year, hoje.month + p.last.mes, 1),
        lucro: p.last.saldo,
      ));
    }
    return saida;
  }
}

// =======================================================================
// RESULTADO: QUANTO GUARDAR POR MÊS
// =======================================================================
class _ResultadoReverso extends StatelessWidget {
  final TemaFarol tema;
  final double meta;
  final double inicial;
  final double taxa;
  final int meses;

  const _ResultadoReverso({
    required this.tema,
    required this.meta,
    required this.inicial,
    required this.taxa,
    required this.meses,
  });

  @override
  Widget build(BuildContext context) {
    if (meses <= 0 || meta <= 0) {
      return _Aviso(
        tema: tema,
        texto: 'Informe quanto você quer ter e em quantos anos.',
      );
    }

    final aporte = CalculationsService.aporteNecessario(
      meta: meta,
      valorInicial: inicial,
      taxaMensalPercentual: taxa,
      meses: meses,
    );
    // Confere: guardando esse valor, chega mesmo na meta?
    final confirmacao = CalculationsService.montanteJurosCompostos(
      valorInicial: inicial,
      aporteMensal: aporte,
      taxaMensalPercentual: taxa,
      meses: meses,
    );
    final porDia = CalculationsService.dividirSeguro(aporte, 30);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        CartaoFarol(
          tema: tema,
          comGradiente: true,
          padding: const EdgeInsets.all(22),
          child: Column(
            children: <Widget>[
              Text(
                'VOCÊ PRECISA GUARDAR POR MÊS',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.88),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 10),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  Fmt.moeda(aporte),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -1.2,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Text(
                  'Isso dá ${Fmt.moeda(porDia)} por dia',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        CartaoFarol(
          tema: tema,
          child: Column(
            children: <Widget>[
              _LinhaValor('Sua meta', Fmt.moeda(meta), tema.primaria),
              const Divider(height: 20),
              _LinhaValor(
                'Prazo',
                CalculationsService.mesesEmTexto(meses),
                tema.secundaria,
              ),
              const Divider(height: 20),
              _LinhaValor(
                'Vai chegar em',
                Fmt.moeda(confirmacao),
                tema.sucesso,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// =======================================================================
class _LinhaValor extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;
  const _LinhaValor(this.rotulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
        ),
        const SizedBox(width: 11),
        Expanded(child: Text(rotulo, style: context.textos.bodyMedium)),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _Aviso extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  const _Aviso({required this.tema, required this.texto});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: tema.superficieAlta,
        borderRadius: BorderRadius.circular(tema.raioBorda * 0.8),
      ),
      child: Row(
        children: <Widget>[
          Icon(Icons.info_rounded, color: tema.textoSuave, size: 19),
          const SizedBox(width: 11),
          Expanded(child: Text(texto, style: context.textos.bodyMedium)),
        ],
      ),
    );
  }
}
