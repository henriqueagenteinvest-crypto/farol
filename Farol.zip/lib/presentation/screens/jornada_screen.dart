/// -----------------------------------------------------------------------
/// CONTROLE DE JORNADA
/// -----------------------------------------------------------------------
/// Cronômetro grande e quatro botões enormes: INICIAR, PAUSAR, RETOMAR e
/// ENCERRAR. Só o tempo ATIVO conta — as pausas ficam de fora.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/jornada_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import 'lancamento_screen.dart';

class JornadaScreen extends StatelessWidget {
  const JornadaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final jornada = context.watch<JornadaController>();
    final tema = app.tema;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  'Controle de jornada',
                  style: context.textos.headlineMedium,
                ),
              ),
              IconButton(
                tooltip: 'Histórico de jornadas',
                icon: const Icon(Icons.history_rounded),
                onPressed: () {
                  AudioService.toqueLeve();
                  Navigator.of(context)
                      .pushNamed(AppRoutes.historicoJornadas);
                },
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'O tempo parado não entra na conta. Pause quando sair do carro.',
            style: context.textos.bodySmall,
          ),
          const SizedBox(height: 24),

          // ---------------- CRONÔMETRO ----------------
          _Cronometro(tema: tema, jornada: jornada),
          const SizedBox(height: 24),

          // ---------------- BOTÕES ----------------
          if (!jornada.temJornadaAberta)
            BotaoGrande(
              texto: 'Iniciar jornada',
              icone: Icons.play_circle_fill_rounded,
              tema: tema,
              altura: 72,
              aoTocar: () async {
                await context.read<JornadaController>().iniciar();
                if (context.mounted) {
                  context.aviso('Jornada iniciada. Bom trabalho!');
                }
              },
            )
          else ...<Widget>[
            if (jornada.pausada)
              BotaoGrande(
                texto: 'Retomar jornada',
                icone: Icons.play_arrow_rounded,
                tema: tema,
                cor: tema.sucesso,
                altura: 72,
                aoTocar: () =>
                    context.read<JornadaController>().retomar(),
              )
            else
              BotaoGrande(
                texto: 'Pausar',
                icone: Icons.pause_rounded,
                tema: tema,
                cor: tema.alerta,
                altura: 72,
                aoTocar: () => _perguntarMotivo(context, tema),
              ),
            const SizedBox(height: 14),
            BotaoGrande(
              texto: 'Encerrar jornada',
              icone: Icons.stop_circle_rounded,
              tema: tema,
              cor: tema.erro,
              altura: 62,
              aoTocar: () => _confirmarEncerrar(context, tema),
            ),
          ],
          const SizedBox(height: 26),

          // ---------------- RESUMO DO DIA ----------------
          const TituloSecao(
            texto: 'Hoje',
            icone: Icons.today_rounded,
          ),
          CartaoFarol(
            tema: tema,
            child: Column(
              children: <Widget>[
                _LinhaResumo(
                  icone: Icons.schedule_rounded,
                  rotulo: 'Tempo trabalhado hoje',
                  valor: Fmt.horasTexto(jornada.horasHoje),
                  cor: tema.primaria,
                ),
                const Divider(height: 22),
                _LinhaResumo(
                  icone: Icons.coffee_rounded,
                  rotulo: 'Tempo em pausa (jornada atual)',
                  valor: Fmt.cronometro(jornada.tempoPausado),
                  cor: tema.alerta,
                ),
                const Divider(height: 22),
                _LinhaResumo(
                  icone: Icons.flag_rounded,
                  rotulo: 'Jornadas registradas hoje',
                  valor: '${jornada.historicoDoDia(DateTime.now()).length}',
                  cor: tema.secundaria,
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          if (jornada.temJornadaAberta && jornada.jornadaAtual!.pausas.isNotEmpty)
            _ListaPausas(tema: tema, jornada: jornada),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // PERGUNTA O MOTIVO DA PAUSA
  // ---------------------------------------------------------------------
  Future<void> _perguntarMotivo(BuildContext context, TemaFarol tema) async {
    AudioService.toqueLeve();
    final motivo = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: tema.superficie,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(tema.raioBorda + 8),
        ),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: tema.textoSuave.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Por que está parando?',
                style: Theme.of(ctx).textTheme.headlineSmall,
              ),
              const SizedBox(height: 6),
              Text(
                'Isso ajuda você a entender para onde vai o seu tempo.',
                style: Theme.of(ctx).textTheme.bodySmall,
              ),
              const SizedBox(height: 20),
              ...AppConstants.motivosPausa.map(
                (m) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => Navigator.of(ctx).pop(m),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 16,
                      ),
                      decoration: BoxDecoration(
                        color: tema.superficieAlta,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        children: <Widget>[
                          Icon(_iconeMotivo(m), color: tema.primaria, size: 21),
                          const SizedBox(width: 14),
                          Text(
                            m,
                            style: Theme.of(ctx).textTheme.titleMedium,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (motivo != null && context.mounted) {
      await context.read<JornadaController>().pausar(motivo);
    }
  }

  static IconData _iconeMotivo(String motivo) {
    switch (motivo) {
      case 'Banheiro':
        return Icons.wc_rounded;
      case 'Café':
        return Icons.local_cafe_rounded;
      case 'Almoço':
        return Icons.restaurant_rounded;
      case 'Descanso':
        return Icons.airline_seat_recline_normal_rounded;
      case 'Abastecer':
        return Icons.local_gas_station_rounded;
      default:
        return Icons.more_horiz_rounded;
    }
  }

  // ---------------------------------------------------------------------
  // CONFIRMA O ENCERRAMENTO
  // ---------------------------------------------------------------------
  Future<void> _confirmarEncerrar(
    BuildContext context,
    TemaFarol tema,
  ) async {
    AudioService.toqueLeve();
    final confirmou = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Encerrar a jornada?'),
        content: const Text(
          'O tempo trabalhado fica salvo no histórico. Em seguida você '
          'pode lançar o dia (valor, KM e corridas).',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Continuar trabalhando'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: tema.erro,
              minimumSize: const Size(120, 46),
            ),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Encerrar'),
          ),
        ],
      ),
    );

    if (confirmou != true || !context.mounted) return;

    final horas = await context.read<JornadaController>().encerrar();
    if (!context.mounted) return;

    context.aviso('Jornada encerrada: ${Fmt.horasTexto(horas)} trabalhadas');

    // Já leva o motorista para lançar o dia, com as horas preenchidas.
    await Navigator.of(context).pushNamed(
      AppRoutes.lancamento,
      arguments: ArgsLancamento(horasSugeridas: horas),
    );
  }
}

// =======================================================================
// CRONÔMETRO GRANDE
// =======================================================================
class _Cronometro extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _Cronometro({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    final rodando = jornada.temJornadaAberta && !jornada.pausada;
    final pausado = jornada.pausada;

    final Color cor;
    final String estado;
    if (!jornada.temJornadaAberta) {
      cor = tema.textoSuave;
      estado = 'Jornada não iniciada';
    } else if (pausado) {
      cor = tema.alerta;
      estado = 'Pausado — ${jornada.motivoPausaAtual ?? "descanso"}';
    } else {
      cor = tema.sucesso;
      estado = 'Trabalhando';
    }

    return CartaoFarol(
      tema: tema,
      padding: const EdgeInsets.symmetric(vertical: 34, horizontal: 20),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              // Ponto que pisca enquanto está trabalhando.
              if (rodando)
                _PontoPiscante(cor: cor)
              else
                Icon(
                  pausado
                      ? Icons.pause_circle_rounded
                      : Icons.hourglass_empty_rounded,
                  color: cor,
                  size: 16,
                ),
              const SizedBox(width: 9),
              Text(
                estado,
                style: context.textos.labelMedium?.copyWith(
                  color: cor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              Fmt.cronometro(jornada.tempoAtivo),
              style: TextStyle(
                fontSize: 56,
                fontWeight: FontWeight.w700,
                color: tema.texto,
                letterSpacing: -1,
                fontFeatures: const <FontFeature>[
                  FontFeature.tabularFigures(),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'tempo trabalhado, sem contar as pausas',
            style: context.textos.bodySmall,
          ),
          if (jornada.temJornadaAberta) ...<Widget>[
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                color: tema.superficieAlta,
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                'Começou às '
                '${Fmt.hora(jornada.jornadaAtual!.inicio)}'
                '   •   ${Fmt.cronometro(jornada.tempoPausado)} em pausa',
                style: context.textos.bodySmall,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Bolinha verde que pisca devagar enquanto a jornada está ativa.
class _PontoPiscante extends StatefulWidget {
  final Color cor;
  const _PontoPiscante({required this.cor});

  @override
  State<_PontoPiscante> createState() => _PontoPiscanteState();
}

class _PontoPiscanteState extends State<_PontoPiscante>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: 0.35, end: 1).animate(_c),
      child: Container(
        width: 11,
        height: 11,
        decoration: BoxDecoration(color: widget.cor, shape: BoxShape.circle),
      ),
    );
  }
}

// =======================================================================
// PEÇAS AUXILIARES
// =======================================================================
class _LinhaResumo extends StatelessWidget {
  final IconData icone;
  final String rotulo;
  final String valor;
  final Color cor;

  const _LinhaResumo({
    required this.icone,
    required this.rotulo,
    required this.valor,
    required this.cor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Icon(icone, size: 19, color: cor),
        const SizedBox(width: 12),
        Expanded(
          child: Text(rotulo, style: context.textos.bodyMedium),
        ),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _ListaPausas extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _ListaPausas({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    final pausas = jornada.jornadaAtual!.pausas;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const TituloSecao(
          texto: 'Pausas desta jornada',
          icone: Icons.coffee_rounded,
        ),
        CartaoFarol(
          tema: tema,
          child: Column(
            children: <Widget>[
              for (var i = 0; i < pausas.length; i++) ...<Widget>[
                if (i > 0) const Divider(height: 20),
                Row(
                  children: <Widget>[
                    Icon(
                      JornadaScreen._iconeMotivo(pausas[i].motivo),
                      size: 18,
                      color: tema.alerta,
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Text(
                        pausas[i].motivo,
                        style: context.textos.bodyMedium,
                      ),
                    ),
                    Text(
                      '${Fmt.hora(pausas[i].inicio)}'
                      '${pausas[i].fim == null ? " — agora" : " às ${Fmt.hora(pausas[i].fim!)}"}',
                      style: context.textos.bodySmall,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      Fmt.cronometro(pausas[i].duracao(DateTime.now())),
                      style: context.textos.bodySmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: tema.alerta,
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}
