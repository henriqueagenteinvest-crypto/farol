/// -----------------------------------------------------------------------
/// JORNADA — o cronômetro do trabalho
/// -----------------------------------------------------------------------
/// Cronômetro enorme, estado sempre visível e dois botões grandes:
/// PAUSAR/RETOMAR e ENCERRAR. Só o tempo ATIVO conta — as pausas ficam
/// de fora, e quem faz essa conta é o CalculationsService.
///
/// DESEMPENHO: o número do relógio anda a cada segundo, mas só ELE se
/// redesenha (ValueListenableBuilder). O resto da tela fica parado.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../controllers/jornada_controller.dart';
import '../widgets/painel_widgets.dart';
import 'lancamento_screen.dart';

class JornadaScreen extends StatelessWidget {
  const JornadaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final jornada = context.watch<JornadaController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;

    final hoje = dados.resumoHoje;

    return SafeArea(
      child: ListView(
        padding: EdgeInsets.fromLTRB(
          tema.compacto ? 12 : 16,
          14,
          tema.compacto ? 12 : 16,
          110,
        ),
        children: <Widget>[
          // ---------------- CABEÇALHO ----------------
          Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Jornada', style: context.textos.headlineMedium),
                    const SizedBox(height: 3),
                    Text(
                      'O tempo parado não entra na conta. Pause quando '
                      'sair do carro.',
                      style: context.textos.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: 'Histórico de jornadas',
                icon: const Icon(Icons.history_rounded),
                onPressed: () {
                  AudioService.toqueLeve();
                  Navigator.of(context).pushNamed(AppRoutes.historicoJornadas);
                },
              ),
            ],
          ),
          SizedBox(height: tema.espaco),

          // ---------------- AVISO DE GRAVAÇÃO ----------------
          if (jornada.ultimoErro != null) ...<Widget>[
            _Aviso(tema: tema, texto: jornada.ultimoErro!),
            SizedBox(height: tema.espaco),
          ],

          // ---------------- CRONÔMETRO ----------------
          _Cronometro(tema: tema, jornada: jornada),
          SizedBox(height: tema.espaco),

          // ---------------- BOTÕES ----------------
          _Botoes(tema: tema, jornada: jornada),
          SizedBox(height: tema.espaco + 4),

          // ---------------- O DIA ATÉ AGORA ----------------
          TituloBloco(tema: tema, texto: 'Hoje'),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: tema.compacto ? 1.7 : 1.5,
            children: <Widget>[
              ValueListenableBuilder<Duration>(
                valueListenable: jornada.tempoAtivoAgora,
                builder: (context, _, __) => CartaoMetrica(
                  tema: tema,
                  rotulo: 'Tempo trabalhado',
                  valor: Fmt.horasTexto(jornada.horasHoje),
                  detalhe: 'somando as jornadas de hoje',
                  faixa: tema.primaria,
                ),
              ),
              ValueListenableBuilder<Duration>(
                valueListenable: jornada.tempoPausadoAgora,
                builder: (context, pausado, __) => CartaoMetrica(
                  tema: tema,
                  rotulo: 'Tempo em pausa',
                  valor: Fmt.cronometro(pausado),
                  detalhe: 'nesta jornada',
                  corValor: pausado > Duration.zero ? tema.alerta : null,
                ),
              ),
              CartaoMetrica(
                tema: tema,
                rotulo: 'Jornadas hoje',
                valor: '${jornada.historicoDoDia(DateTime.now()).length}',
                detalhe: 'registradas no aparelho',
              ),
              CartaoMetrica(
                tema: tema,
                rotulo: 'Ganho por hora',
                valor: Fmt.moeda(hoje.ganhoPorHora),
                detalhe: hoje.horas > 0
                    ? 'com ${Fmt.horasTexto(hoje.horas)} lançadas'
                    : 'lance o dia para ver',
                corValor: hoje.ganhoPorHora > 0 ? tema.sucesso : null,
              ),
            ],
          ),

          // ---------------- PAUSAS DESTA JORNADA ----------------
          if (jornada.temJornadaAberta &&
              jornada.jornadaAtual!.pausas.isNotEmpty) ...<Widget>[
            SizedBox(height: tema.espaco + 4),
            TituloBloco(tema: tema, texto: 'Pausas desta jornada'),
            _ListaPausas(tema: tema, jornada: jornada),
          ],
        ],
      ),
    );
  }
}

// =======================================================================
// CRONÔMETRO
// =======================================================================
class _Cronometro extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _Cronometro({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    final aberta = jornada.temJornadaAberta;
    final pausada = jornada.pausada;

    final Color cor;
    final String estado;
    if (!aberta) {
      cor = tema.textoSuave;
      estado = 'Jornada não iniciada';
    } else if (pausada) {
      cor = tema.alerta;
      estado = 'Pausado — ${jornada.motivoPausaAtual ?? "descanso"}';
    } else {
      cor = tema.sucesso;
      estado = 'Trabalhando agora';
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        vertical: tema.compacto ? 24 : 32,
        horizontal: 18,
      ),
      decoration: BoxDecoration(
        color: tema.superficie,
        borderRadius: BorderRadius.circular(tema.raioBorda + 2),
        border: Border.all(
          color: aberta ? cor.withValues(alpha: 0.45) : tema.divisor,
          width: aberta ? 1.6 : 1,
        ),
      ),
      child: Column(
        children: <Widget>[
          // ---- Estado ----
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: cor.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(99),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                if (aberta && !pausada)
                  _PontoPiscante(cor: cor)
                else
                  Icon(
                    pausada
                        ? Icons.pause_circle_rounded
                        : Icons.hourglass_empty_rounded,
                    color: cor,
                    size: 15,
                  ),
                const SizedBox(width: 8),
                Text(
                  estado,
                  style: TextStyle(
                    color: cor,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // ---- O número (a única coisa que muda a cada segundo) ----
          ValueListenableBuilder<Duration>(
            valueListenable: jornada.tempoAtivoAgora,
            builder: (context, ativo, __) => FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                Fmt.cronometro(ativo),
                style: tema.numero(
                  tamanho: tema.compacto ? 46 : 54,
                  cor: aberta ? tema.texto : tema.textoSuave,
                  espacamento: -1.5,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'tempo trabalhado, sem contar as pausas',
            style: context.textos.bodySmall,
          ),

          if (aberta) ...<Widget>[
            const SizedBox(height: 16),
            ValueListenableBuilder<Duration>(
              valueListenable: jornada.tempoPausadoAgora,
              builder: (context, pausadoAgora, __) => Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: tema.superficieAlta,
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Text(
                  'Começou às ${Fmt.hora(jornada.jornadaAtual!.inicio)}'
                  '   •   ${Fmt.cronometro(pausadoAgora)} em pausa',
                  style: context.textos.bodySmall,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Bolinha que pisca devagar enquanto a jornada está ativa.
class _PontoPiscante extends StatefulWidget {
  final Color cor;
  const _PontoPiscante({required this.cor});

  @override
  State<_PontoPiscante> createState() => _PontoPiscanteState();
}

class _PontoPiscanteState extends State<_PontoPiscante>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: 0.35, end: 1).animate(_c),
      child: Container(
        width: 9,
        height: 9,
        decoration:
            BoxDecoration(color: widget.cor, shape: BoxShape.circle),
      ),
    );
  }
}

// =======================================================================
// BOTÕES
// =======================================================================
class _Botoes extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _Botoes({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    if (!jornada.temJornadaAberta) {
      return _BotaoGrandeV2(
        tema: tema,
        cor: tema.sucesso,
        icone: Icons.play_arrow_rounded,
        texto: 'Iniciar jornada',
        aoTocar: () async {
          await context.read<JornadaController>().iniciar();
          if (context.mounted) {
            context.aviso('Jornada iniciada. Bom trabalho!');
          }
        },
      );
    }

    final pausada = jornada.pausada;

    return Column(
      children: <Widget>[
        _BotaoGrandeV2(
          tema: tema,
          cor: pausada ? tema.sucesso : tema.alerta,
          icone: pausada ? Icons.play_arrow_rounded : Icons.pause_rounded,
          texto: pausada ? 'Retomar jornada' : 'Pausar',
          aoTocar: () {
            if (pausada) {
              context.read<JornadaController>().retomar();
            } else {
              _perguntarMotivo(context, tema);
            }
          },
        ),
        const SizedBox(height: 10),
        _BotaoGrandeV2(
          tema: tema,
          cor: tema.erro,
          icone: Icons.stop_rounded,
          texto: 'Encerrar jornada',
          altura: 56,
          aoTocar: () => _confirmarEncerrar(context),
        ),
      ],
    );
  }

  Future<void> _perguntarMotivo(BuildContext context, TemaFarol tema) async {
    final motivo = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: tema.superficie,
      shape: RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(tema.raioBorda + 8)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Por que está parando?',
                style: Theme.of(ctx).textTheme.headlineSmall,
              ),
              const SizedBox(height: 4),
              Text(
                'Isso ajuda você a entender para onde vai o seu tempo.',
                style: Theme.of(ctx).textTheme.bodySmall,
              ),
              const SizedBox(height: 16),
              for (final m in AppConstants.motivosPausa)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: BotaoAcao(
                    tema: tema,
                    icone: iconeMotivo(m),
                    texto: m,
                    cor: tema.alerta,
                    aoTocar: () => Navigator.of(ctx).pop(m),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    if (motivo != null && context.mounted) {
      await context.read<JornadaController>().pausar(motivo);
    }
  }

  static IconData iconeMotivo(String motivo) {
    switch (motivo) {
      case 'Banheiro':
        return Icons.wc_rounded;
      case 'Café':
        return Icons.local_cafe_rounded;
      case 'Almoço':
        return Icons.restaurant_rounded;
      case 'Descanso':
        return Icons.airline_seat_recline_normal_rounded;
      case 'Abastecer':
        return Icons.local_gas_station_rounded;
      default:
        return Icons.more_horiz_rounded;
    }
  }

  Future<void> _confirmarEncerrar(BuildContext context) async {
    AudioService.toqueLeve();
    final confirmou = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Encerrar a jornada?'),
        content: const Text(
          'O tempo trabalhado fica salvo no histórico. Em seguida você '
          'pode lançar o dia (valor, KM e corridas).',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Continuar trabalhando'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: tema.erro),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Encerrar'),
          ),
        ],
      ),
    );
    if (confirmou != true || !context.mounted) return;

    final horas = await context.read<JornadaController>().encerrar();
    if (!context.mounted) return;

    context.aviso('Jornada encerrada: ${Fmt.horasTexto(horas)} trabalhadas');

    // Já leva o motorista para lançar o dia, com as horas preenchidas.
    await Navigator.of(context).pushNamed(
      AppRoutes.lancamento,
      arguments: ArgsLancamento(horasSugeridas: horas),
    );
  }
}

class _BotaoGrandeV2 extends StatelessWidget {
  final TemaFarol tema;
  final Color cor;
  final IconData icone;
  final String texto;
  final double altura;
  final VoidCallback aoTocar;

  const _BotaoGrandeV2({
    required this.tema,
    required this.cor,
    required this.icone,
    required this.texto,
    required this.aoTocar,
    this.altura = 66,
  });

  @override
  Widget build(BuildContext context) {
    final corTexto = TemaFarol.contrasteSobre(cor);
    return Material(
      color: cor,
      borderRadius: BorderRadius.circular(tema.raioBorda),
      child: InkWell(
        onTap: () {
          AudioService.clique();
          aoTocar();
        },
        borderRadius: BorderRadius.circular(tema.raioBorda),
        child: SizedBox(
          height: altura,
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icone, color: corTexto, size: 24),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  texto,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: corTexto,
                    fontSize: 16.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
class _Aviso extends StatelessWidget {
  final TemaFarol tema;
  final String texto;

  const _Aviso({required this.tema, required this.texto});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: tema.erro.withValues(alpha: 0.13),
        borderRadius: BorderRadius.circular(tema.raioBorda),
        border: Border.all(color: tema.erro.withValues(alpha: 0.45)),
      ),
      child: Row(
        children: <Widget>[
          Icon(Icons.warning_amber_rounded, color: tema.erro, size: 19),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              texto,
              style: context.textos.bodySmall?.copyWith(color: tema.erro),
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
class _ListaPausas extends StatelessWidget {
  final TemaFarol tema;
  final JornadaController jornada;

  const _ListaPausas({required this.tema, required this.jornada});

  @override
  Widget build(BuildContext context) {
    final pausas = jornada.jornadaAtual!.pausas;

    return Caixa(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < pausas.length; i++) ...<Widget>[
            if (i > 0) Divider(height: 18, color: tema.divisor),
            Row(
              children: <Widget>[
                Icon(
                  _Botoes.iconeMotivo(pausas[i].motivo),
                  size: 18,
                  color: tema.alerta,
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        pausas[i].motivo,
                        style: context.textos.bodyMedium,
                      ),
                      Text(
                        '${Fmt.hora(pausas[i].inicio)}'
                        '${pausas[i].fim == null ? " — agora" : " às ${Fmt.hora(pausas[i].fim!)}"}',
                        style: context.textos.bodySmall,
                      ),
                    ],
                  ),
                ),
                // A pausa aberta continua contando.
                ValueListenableBuilder<Duration>(
                  valueListenable: jornada.tempoPausadoAgora,
                  builder: (context, _, __) => Text(
                    Fmt.cronometro(pausas[i].duracao(DateTime.now())),
                    style: tema.numero(
                      tamanho: 13,
                      cor: tema.alerta,
                      espacamento: 0,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
