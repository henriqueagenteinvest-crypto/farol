/// -----------------------------------------------------------------------
/// PAINEL DA SEMANA
/// -----------------------------------------------------------------------
/// A tela principal do aplicativo. Responde a pergunta que o motorista
/// realmente faz: COMO FOI A MINHA SEMANA, DIA A DIA?
///
///   • total faturado e lucro da semana, com o anel da meta
///   • os sete dias, de segunda a domingo, cada um com seu gráfico
///   • o dia que mais faturou fica marcado com uma coroa
///   • tocar em qualquer dia abre o lançamento daquele dia para EDITAR —
///     inclusive dias já passados
///
/// Tem dois modos, escolhidos em Aparência:
///   INDICADORES — cartões, barras e ícones (padrão)
///   TEXTO       — uma tabela enxuta de nomes e números, sem gráfico
///
/// Nenhuma conta é feita aqui: tudo vem pronto do DadosController.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../data/gravacao_segura.dart';
import '../../data/models/lancamento_diario.dart';
import '../../domain/entities/dia_da_semana.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/confete_meta.dart';
import '../widgets/entrada_suave.dart';
import '../widgets/painel_widgets.dart';
import 'lancamento_screen.dart';

class SemanaScreen extends StatefulWidget {
  const SemanaScreen({super.key});

  @override
  State<SemanaScreen> createState() => _SemanaScreenState();
}

class _SemanaScreenState extends State<SemanaScreen> {
  /// Qual semana está sendo olhada. Começa na semana de hoje.
  DateTime _referencia = DateTime.now();

  bool get _ehSemanaAtual =>
      _referencia.inicioSemana == DateTime.now().inicioSemana;

  void _andar(int semanas) {
    AudioService.toqueLeve();
    setState(() {
      _referencia = DateTime(
        _referencia.year,
        _referencia.month,
        _referencia.day + (semanas * 7),
      );
    });
  }

  void _voltarParaHoje() {
    AudioService.toqueLeve();
    setState(() => _referencia = DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();

    final tema = app.tema;
    final animar = app.animacoesAtivas;
    final modoTexto = app.modoPainelTexto;

    final semana = dados.semanaDe(_referencia);
    final meta = app.config.metaSemanal;

    final progresso = CalculationsService.progressoMeta(
      realizado: semana.lucro,
      meta: meta,
    );
    final percentual = CalculationsService.percentualMeta(
      realizado: semana.lucro,
      meta: meta,
    );
    final falta = CalculationsService.faltaParaMeta(
      realizado: semana.lucro,
      meta: meta,
    );

    final bateuMetaHoje = dados.metaHojeAtingida;

    return Stack(
      children: <Widget>[
        Column(
          children: <Widget>[
            SafeArea(
              bottom: false,
              child: BarraTopo(
                tema: tema,
                nome: app.motorista?.primeiroNome ?? '',
                carro: app.motorista?.modeloCarro ?? '',
                salvo: !DiarioDeErros.temErro,
                alerta: DiarioDeErros.temErro
                    ? 'Houve problema ao gravar no celular'
                    : null,
                aoTrocarBrilho: () =>
                    context.read<AppController>().trocarModoTema(
                          tema.ehEscuro ? ModoTema.claro : ModoTema.escuro,
                        ),
                aoAbrirPerfil: () {
                  AudioService.toqueLeve();
                  Navigator.of(context).pushNamed(AppRoutes.login);
                },
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.fromLTRB(
                  tema.compacto ? 12 : 16,
                  14,
                  tema.compacto ? 12 : 16,
                  110,
                ),
                children: <Widget>[
                  // ---------- ESCOLHA DA SEMANA ----------
                  _BarraDaSemana(
                    tema: tema,
                    semana: semana,
                    ehAtual: _ehSemanaAtual,
                    aoAnterior: () => _andar(-1),
                    aoProxima: () => _andar(1),
                    aoHoje: _voltarParaHoje,
                  ),
                  SizedBox(height: tema.espaco),

                  // ---------- TOTAL DA SEMANA ----------
                  CartaoDestaque(
                    tema: tema,
                    rotulo: 'Faturamento da semana',
                    valor: Fmt.moeda(semana.faturado),
                    detalhe: meta > 0
                        ? 'lucro ${Fmt.moeda(semana.lucro)} · '
                            '${falta > 0 ? "faltam ${Fmt.moeda(falta)} para a meta" : "meta batida!"}'
                        : 'lucro de ${Fmt.moeda(semana.lucro)} na semana',
                    progressoMeta: progresso,
                    textoAnel: '${Fmt.numero(percentual, casas: 0)}%',
                    animar: animar,
                    negativo: semana.lucro < 0,
                  ),
                  SizedBox(height: tema.espaco),

                  // ---------- OS NÚMEROS DA SEMANA ----------
                  if (!modoTexto) ...<Widget>[
                    _ResumoSemana(tema: tema, semana: semana),
                    SizedBox(height: tema.espaco + 4),
                  ],

                  // ---------- OS SETE DIAS ----------
                  TituloBloco(
                    tema: tema,
                    texto: 'Dia a dia',
                    acao: Text(
                      '${semana.diasTrabalhados} de 7 dias',
                      style: context.textos.bodySmall,
                    ),
                  ),
                  if (modoTexto)
                    _TabelaDeDias(
                      tema: tema,
                      semana: semana,
                      aoTocarDia: (d) => _abrirDia(context, d),
                    )
                  else
                    _CartoesDeDias(
                      tema: tema,
                      semana: semana,
                      animar: animar,
                      aoTocarDia: (d) => _abrirDia(context, d),
                    ),
                  SizedBox(height: tema.espaco + 4),

                  // ---------- AÇÕES RÁPIDAS ----------
                  TituloBloco(tema: tema, texto: 'Ações rápidas'),
                  _Acoes(tema: tema),
                ],
              ),
            ),
          ],
        ),

        ConfeteMeta(
          comemorar: bateuMetaHoje && !app.jaComemorouHoje,
          tema: tema,
          animacoesAtivas: animar,
          aoTerminar: () =>
              context.read<AppController>().registrarComemoracao(),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------
  // ABRIR UM DIA PARA LANÇAR OU CORRIGIR
  // ---------------------------------------------------------------------
  /// É por aqui que se corrige um dia já passado: toca no dia, abre o
  /// lançamento dele. Se o dia tiver mais de um lançamento, o motorista
  /// escolhe qual quer mexer.
  Future<void> _abrirDia(BuildContext context, DiaDaSemana dia) async {
    AudioService.clique();
    final dados = context.read<DadosController>();
    final tema = context.read<AppController>().tema;
    final lista = dados.lancamentosDoDia(dia.dia);

    if (lista.isEmpty) {
      // Dia sem registro: abre um lançamento novo já com a data certa.
      await Navigator.of(context).pushNamed(
        AppRoutes.lancamento,
        arguments: ArgsLancamento(dataSugerida: dia.dia),
      );
      return;
    }

    if (lista.length == 1) {
      await Navigator.of(context).pushNamed(
        AppRoutes.lancamento,
        arguments: ArgsLancamento(existente: lista.first),
      );
      return;
    }

    if (!context.mounted) return;
    final escolhido = await showModalBottomSheet<LancamentoDiario>(
      context: context,
      backgroundColor: tema.superficie,
      shape: RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(tema.raioBorda + 8)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                '${dia.nomeLongo}, ${Fmt.data(dia.dia)}',
                style: Theme.of(ctx).textTheme.headlineSmall,
              ),
              const SizedBox(height: 4),
              Text(
                'Este dia tem ${lista.length} lançamentos. '
                'Qual você quer corrigir?',
                style: Theme.of(ctx).textTheme.bodySmall,
              ),
              const SizedBox(height: 16),
              for (final l in lista)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: BotaoAcao(
                    tema: tema,
                    icone: Icons.edit_rounded,
                    texto: '${Fmt.moeda(l.valorBruto)} · '
                        '${l.corridas} corridas · ${Fmt.km(l.km)}',
                    cor: tema.primaria,
                    aoTocar: () => Navigator.of(ctx).pop(l),
                  ),
                ),
              const SizedBox(height: 4),
              BotaoAcao(
                tema: tema,
                icone: Icons.add_rounded,
                texto: 'Lançar mais um neste dia',
                cor: tema.sucesso,
                aoTocar: () => Navigator.of(ctx).pop(),
              ),
            ],
          ),
        ),
      ),
    );

    if (!context.mounted) return;
    await Navigator.of(context).pushNamed(
      AppRoutes.lancamento,
      arguments: escolhido == null
          ? ArgsLancamento(dataSugerida: dia.dia)
          : ArgsLancamento(existente: escolhido),
    );
  }
}

// =======================================================================
// BARRA DE ESCOLHA DA SEMANA
// =======================================================================
class _BarraDaSemana extends StatelessWidget {
  final TemaFarol tema;
  final SemanaDeTrabalho semana;
  final bool ehAtual;
  final VoidCallback aoAnterior;
  final VoidCallback aoProxima;
  final VoidCallback aoHoje;

  const _BarraDaSemana({
    required this.tema,
    required this.semana,
    required this.ehAtual,
    required this.aoAnterior,
    required this.aoProxima,
    required this.aoHoje,
  });

  @override
  Widget build(BuildContext context) {
    return Caixa(
      tema: tema,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
      child: Row(
        children: <Widget>[
          _Seta(
            tema: tema,
            icone: Icons.chevron_left_rounded,
            dica: 'Semana anterior',
            aoTocar: aoAnterior,
          ),
          Expanded(
            child: Column(
              children: <Widget>[
                Text(
                  ehAtual ? 'Esta semana' : 'Semana',
                  style: TextStyle(
                    color: tema.textoSuave,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${Fmt.dataCurta(semana.inicio)} a '
                  '${Fmt.dataCurta(semana.fim)}',
                  style: tema.numero(tamanho: 15, espacamento: 0),
                ),
              ],
            ),
          ),
          _Seta(
            tema: tema,
            icone: Icons.chevron_right_rounded,
            dica: 'Próxima semana',
            aoTocar: aoProxima,
          ),
          if (!ehAtual)
            Padding(
              padding: const EdgeInsets.only(left: 2, right: 4),
              child: TextButton(
                onPressed: aoHoje,
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  minimumSize: const Size(0, 40),
                ),
                child: const Text('Hoje'),
              ),
            ),
        ],
      ),
    );
  }
}

class _Seta extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final String dica;
  final VoidCallback aoTocar;

  const _Seta({
    required this.tema,
    required this.icone,
    required this.dica,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: dica,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(99),
          child: SizedBox(
            width: 44,
            height: 44,
            child: Icon(icone, size: 24, color: tema.texto),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// OS QUATRO NÚMEROS DA SEMANA
// =======================================================================
class _ResumoSemana extends StatelessWidget {
  final TemaFarol tema;
  final SemanaDeTrabalho semana;

  const _ResumoSemana({required this.tema, required this.semana});

  @override
  Widget build(BuildContext context) {
    final porHora = CalculationsService.ganhoPorHora(
      lucro: semana.lucro,
      horas: semana.horas,
    );

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: tema.compacto ? 1.7 : 1.5,
      children: <Widget>[
        CartaoMetrica(
          tema: tema,
          rotulo: 'Lucro da semana',
          valor: Fmt.moeda(semana.lucro),
          detalhe: 'já sem combustível e gastos',
          corValor: semana.lucro >= 0 ? tema.sucesso : tema.erro,
          faixa: tema.primaria,
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Horas trabalhadas',
          valor: Fmt.horasTexto(semana.horas),
          detalhe: '${Fmt.moeda(porHora)} por hora',
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Corridas',
          valor: Fmt.inteiro(semana.corridas),
          detalhe: '${Fmt.km(semana.km)} rodados',
        ),
        CartaoMetrica(
          tema: tema,
          rotulo: 'Média por dia',
          valor: Fmt.moeda(
            CalculationsService.dividirSeguro(
              semana.faturado,
              semana.diasTrabalhados.toDouble(),
            ),
          ),
          detalhe: semana.diasTrabalhados == 0
              ? 'nenhum dia lançado'
              : 'nos ${semana.diasTrabalhados} dias trabalhados',
        ),
      ],
    );
  }
}

// =======================================================================
// OS SETE DIAS — MODO INDICADORES
// =======================================================================
class _CartoesDeDias extends StatelessWidget {
  final TemaFarol tema;
  final SemanaDeTrabalho semana;
  final bool animar;
  final ValueChanged<DiaDaSemana> aoTocarDia;

  const _CartoesDeDias({
    required this.tema,
    required this.semana,
    required this.animar,
    required this.aoTocarDia,
  });

  @override
  Widget build(BuildContext context) {
    final melhor = semana.melhorDia;

    return Column(
      children: <Widget>[
        for (var i = 0; i < semana.dias.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            // Efeito escada: segunda entra primeiro, domingo por último.
            child: EntradaSuave(
              animar: animar,
              ordem: i,
              child: _CartaoDia(
                tema: tema,
                dia: semana.dias[i],
                semana: semana,
                melhor: melhor != null && melhor.dia == semana.dias[i].dia,
                animar: animar,
                aoTocar: () => aoTocarDia(semana.dias[i]),
              ),
            ),
          ),
      ],
    );
  }
}

class _CartaoDia extends StatelessWidget {
  final TemaFarol tema;
  final DiaDaSemana dia;
  final SemanaDeTrabalho semana;
  final bool melhor;
  final bool animar;
  final VoidCallback aoTocar;

  const _CartaoDia({
    required this.tema,
    required this.dia,
    required this.semana,
    required this.melhor,
    required this.animar,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final ehHoje = dia.dia.ehHoje;
    final cor = dia.vazio
        ? tema.textoSuave
        : (dia.lucro >= 0 ? tema.sucesso : tema.erro);

    // A régua de cada barra é o maior valor da semana. Divisão protegida:
    // semana zerada devolve barra vazia em vez de estourar.
    double fracao(double valor, double maior) =>
        maior <= 0 ? 0.0 : (valor / maior).clamp(0.0, 1.0);

    return ToqueQueAfunda(
      animar: animar,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(tema.raioBorda),
          child: Container(
            padding: EdgeInsets.all(tema.compacto ? 12 : 14),
            decoration: BoxDecoration(
              color: tema.superficie,
              borderRadius: BorderRadius.circular(tema.raioBorda),
              border: Border.all(
                color: melhor
                    ? tema.sucesso
                    : (ehHoje ? tema.primaria : tema.divisor),
                width: melhor || ehHoje ? 1.6 : 1,
              ),
            ),
            child: Column(
              children: <Widget>[
                // ---- Linha de cima: dia, coroa e valor ----
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 46,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            dia.nomeCurto,
                            style: TextStyle(
                              color: ehHoje ? tema.primaria : tema.texto,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            Fmt.dataCurta(dia.dia),
                            style: TextStyle(
                              color: tema.textoSuave,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (melhor)
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: Icon(
                          Icons.emoji_events_rounded,
                          size: 17,
                          color: tema.sucesso,
                        ),
                      ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            dia.vazio ? '—' : Fmt.moeda(dia.faturado),
                            style: tema.numero(
                              tamanho: 19,
                              cor: dia.vazio ? tema.textoSuave : tema.texto,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Icon(
                      Icons.chevron_right_rounded,
                      size: 18,
                      color: tema.textoSuave,
                    ),
                  ],
                ),

                if (!dia.vazio) ...<Widget>[
                  const SizedBox(height: 10),

                  // ---- Barra do faturamento (a régua é a semana) ----
                  _Barra(
                    tema: tema,
                    fracao: fracao(dia.faturado, semana.maiorFaturamento),
                    cor: melhor ? tema.sucesso : tema.primaria,
                    altura: 7,
                    animar: animar,
                  ),
                  const SizedBox(height: 10),

                  // ---- Os três indicadores do dia ----
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: _Indicador(
                          tema: tema,
                          icone: Icons.schedule_rounded,
                          rotulo: 'Tempo',
                          valor: Fmt.horasTexto(dia.horas),
                          fracao: fracao(dia.horas, semana.maiorHoras),
                          cor: tema.secundaria,
                          animar: animar,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _Indicador(
                          tema: tema,
                          icone: Icons.savings_rounded,
                          rotulo: 'Lucro',
                          valor: Fmt.moeda(dia.lucro),
                          fracao: fracao(
                            dia.lucro.abs(),
                            semana.maiorFaturamento,
                          ),
                          cor: cor,
                          animar: animar,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _Indicador(
                          tema: tema,
                          icone: Icons.local_taxi_rounded,
                          rotulo: 'Corridas',
                          valor: '${dia.corridas}',
                          fracao: semana.maiorCorridas == 0
                              ? 0
                              : dia.corridas / semana.maiorCorridas,
                          cor: tema.alerta,
                          animar: animar,
                        ),
                      ),
                    ],
                  ),
                ] else ...<Widget>[
                  const SizedBox(height: 6),
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.add_circle_outline_rounded,
                        size: 15,
                        color: tema.textoSuave,
                      ),
                      const SizedBox(width: 7),
                      Text(
                        'Sem lançamento — toque para lançar este dia',
                        style: context.textos.bodySmall,
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Uma barra horizontal simples, com animação de crescimento.
class _Barra extends StatelessWidget {
  final TemaFarol tema;
  final double fracao;
  final Color cor;
  final double altura;
  final bool animar;

  const _Barra({
    required this.tema,
    required this.fracao,
    required this.cor,
    required this.altura,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final f = fracao.isFinite ? fracao.clamp(0.0, 1.0) : 0.0;
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: f),
        duration: animar ? const Duration(milliseconds: 450) : Duration.zero,
        curve: Curves.easeOutCubic,
        builder: (context, v, _) => LinearProgressIndicator(
          value: v,
          minHeight: altura,
          backgroundColor: tema.superficieAlta,
          valueColor: AlwaysStoppedAnimation<Color>(cor),
        ),
      ),
    );
  }
}

/// Um dos três indicadores dentro do cartão do dia.
class _Indicador extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final String rotulo;
  final String valor;
  final double fracao;
  final Color cor;
  final bool animar;

  const _Indicador({
    required this.tema,
    required this.icone,
    required this.rotulo,
    required this.valor,
    required this.fracao,
    required this.cor,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Icon(icone, size: 12, color: cor),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                rotulo.toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: tema.textoSuave,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.6,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 3),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(
            valor,
            style: tema.numero(tamanho: 13, cor: cor, espacamento: 0),
          ),
        ),
        const SizedBox(height: 4),
        _Barra(
          tema: tema,
          fracao: fracao,
          cor: cor,
          altura: 4,
          animar: animar,
        ),
      ],
    );
  }
}

// =======================================================================
// OS SETE DIAS — MODO TEXTO
// =======================================================================
/// Para quem prefere ler número em vez de olhar gráfico.
class _TabelaDeDias extends StatelessWidget {
  final TemaFarol tema;
  final SemanaDeTrabalho semana;
  final ValueChanged<DiaDaSemana> aoTocarDia;

  const _TabelaDeDias({
    required this.tema,
    required this.semana,
    required this.aoTocarDia,
  });

  @override
  Widget build(BuildContext context) {
    final melhor = semana.melhorDia;

    return Caixa(
      tema: tema,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Column(
        children: <Widget>[
          // ---- Cabeçalho da tabela ----
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: <Widget>[
                SizedBox(width: 54, child: _Cabecalho(tema: tema, texto: 'Dia')),
                Expanded(
                  flex: 3,
                  child: _Cabecalho(
                      tema: tema, texto: 'Faturado', direita: true),
                ),
                Expanded(
                  flex: 2,
                  child:
                      _Cabecalho(tema: tema, texto: 'Tempo', direita: true),
                ),
                SizedBox(
                  width: 42,
                  child: _Cabecalho(tema: tema, texto: 'Corr.', direita: true),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: tema.divisor),

          for (final d in semana.dias)
            InkWell(
              onTap: () => aoTocarDia(d),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 11),
                child: Row(
                  children: <Widget>[
                    SizedBox(
                      width: 54,
                      child: Row(
                        children: <Widget>[
                          Text(
                            d.nomeCurto,
                            style: TextStyle(
                              color: d.dia.ehHoje ? tema.primaria : tema.texto,
                              fontSize: 13.5,
                              fontWeight: d.dia.ehHoje
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                            ),
                          ),
                          if (melhor != null && melhor.dia == d.dia) ...[
                            const SizedBox(width: 4),
                            Icon(
                              Icons.star_rounded,
                              size: 13,
                              color: tema.sucesso,
                            ),
                          ],
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: _Celula(
                        tema: tema,
                        texto: d.vazio ? '—' : Fmt.moeda(d.faturado),
                        cor: d.vazio ? tema.textoSuave : tema.texto,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: _Celula(
                        tema: tema,
                        texto: d.vazio ? '—' : Fmt.horasTexto(d.horas),
                        cor: tema.textoSuave,
                      ),
                    ),
                    SizedBox(
                      width: 42,
                      child: _Celula(
                        tema: tema,
                        texto: d.vazio ? '—' : '${d.corridas}',
                        cor: tema.textoSuave,
                      ),
                    ),
                  ],
                ),
              ),
            ),

          Divider(height: 1, color: tema.divisor),
          Padding(
            padding: const EdgeInsets.only(top: 11, bottom: 4),
            child: Row(
              children: <Widget>[
                const SizedBox(
                  width: 54,
                  child: Text(
                    'TOTAL',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: _Celula(
                    tema: tema,
                    texto: Fmt.moeda(semana.faturado),
                    cor: tema.primaria,
                    forte: true,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _Celula(
                    tema: tema,
                    texto: Fmt.horasTexto(semana.horas),
                    cor: tema.texto,
                    forte: true,
                  ),
                ),
                SizedBox(
                  width: 42,
                  child: _Celula(
                    tema: tema,
                    texto: '${semana.corridas}',
                    cor: tema.texto,
                    forte: true,
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 14, color: tema.divisor),
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  'Lucro líquido da semana',
                  style: context.textos.bodyMedium,
                ),
              ),
              Text(
                Fmt.moeda(semana.lucro),
                style: tema.numero(
                  tamanho: 16,
                  cor: semana.lucro >= 0 ? tema.sucesso : tema.erro,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Cabecalho extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  final bool direita;

  const _Cabecalho({
    required this.tema,
    required this.texto,
    this.direita = false,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      texto.toUpperCase(),
      textAlign: direita ? TextAlign.right : TextAlign.left,
      style: TextStyle(
        color: tema.textoSuave,
        fontSize: 9.5,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.8,
      ),
    );
  }
}

class _Celula extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  final Color cor;
  final bool forte;

  const _Celula({
    required this.tema,
    required this.texto,
    required this.cor,
    this.forte = false,
  });

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerRight,
      child: Text(
        texto,
        style: tema.numero(
          tamanho: forte ? 14 : 13,
          cor: cor,
          peso: forte ? FontWeight.w700 : FontWeight.w500,
          espacamento: 0,
        ),
      ),
    );
  }
}

// =======================================================================
// AÇÕES RÁPIDAS
// =======================================================================
class _Acoes extends StatelessWidget {
  final TemaFarol tema;

  const _Acoes({required this.tema});

  @override
  Widget build(BuildContext context) {
    final itens = <(IconData, String, String, Color)>[
      (Icons.add_circle_rounded, 'Lançar o dia', AppRoutes.lancamento,
          tema.primaria),
      (Icons.local_gas_station_rounded, 'Abastecer', AppRoutes.abastecimento,
          tema.alerta),
      (Icons.receipt_long_rounded, 'Despesa', AppRoutes.gastos, tema.erro),
      (Icons.workspace_premium_rounded, 'Pontos', AppRoutes.pontos,
          tema.secundaria),
    ];

    return Caixa(
      tema: tema,
      padding: const EdgeInsets.all(12),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 3.1,
        children: <Widget>[
          for (final i in itens)
            BotaoAcao(
              tema: tema,
              icone: i.$1,
              texto: i.$2,
              cor: i.$4,
              aoTocar: () => Navigator.of(context).pushNamed(i.$3),
            ),
        ],
      ),
    );
  }
}
