/// -----------------------------------------------------------------------
/// TELA DE ABERTURA — O CARRO QUE ACENDE O FAROL
/// -----------------------------------------------------------------------
/// Enquanto o app lê os dados do celular, o motorista vê o carro do Farol
/// acender os faróis no escuro. Depois a tela decide para onde ir:
/// cadastro (primeira vez) ou a Semana.
///
/// A animação inteira dura 1,6 segundo, mas ela NÃO SEGURA O APLICATIVO:
/// os dados são carregados ao mesmo tempo. Quando os dois terminam, a
/// tela passa. Se o motorista desligou as animações nas configurações,
/// a abertura fica praticamente instantânea.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_routes.dart';
import '../controllers/app_controller.dart';
import '../widgets/animacao_farol.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animacao;

  @override
  void initState() {
    super.initState();
    _animacao = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..forward();
    _decidirDestino();
  }

  Future<void> _decidirDestino() async {
    final app = context.read<AppController>();

    // Os dois acontecem JUNTOS: carregar o banco e rodar a animação.
    // O app só espera o que for mais demorado dos dois.
    await app.carregar();
    if (!mounted) return;

    // Sem animações, a abertura é só o tempo de ler o banco.
    final espera = app.animacoesAtivas
        ? const Duration(milliseconds: 1500)
        : const Duration(milliseconds: 120);

    // Desconta o tempo que o banco já levou.
    final decorrido = _animacao.lastElapsedDuration ?? Duration.zero;
    final restante = espera - decorrido;
    if (restante > Duration.zero) {
      await Future<void>.delayed(restante);
    }
    if (!mounted) return;

    Navigator.of(context).pushReplacementNamed(
      app.temCadastro ? AppRoutes.principal : AppRoutes.login,
    );
  }

  @override
  void dispose() {
    _animacao.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;
    final largura = MediaQuery.sizeOf(context).width;

    return Scaffold(
      backgroundColor: tema.fundo,
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              // ---- O CARRO ACENDENDO O FAROL ----
              AnimacaoFarolLigando(
                animacao: _animacao,
                tema: tema,
                // Ocupa 60% da largura, com teto para não ficar gigante
                // em tablet.
                tamanho: (largura * 0.60).clamp(180.0, 280.0),
              ),
              const SizedBox(height: 18),

              // ---- O NOME, surgindo dentro da luz ----
              AnimatedBuilder(
                animation: _animacao,
                builder: (context, filho) {
                  final t = _animacao.value;
                  // Entra do instante 0.60 em diante.
                  final f =
                      Curves.easeOut.transform(((t - 0.60) / 0.40).clamp(0.0, 1.0));
                  return Opacity(
                    opacity: f,
                    child: Transform.translate(
                      offset: Offset(0, 12 * (1 - f)),
                      child: filho,
                    ),
                  );
                },
                child: Column(
                  children: <Widget>[
                    Text(
                      AppConstants.nomeApp.toUpperCase(),
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                            letterSpacing: 9,
                            fontWeight: FontWeight.w700,
                            shadows: <Shadow>[
                              Shadow(
                                color: tema.primaria.withValues(alpha: 0.55),
                                blurRadius: 22,
                              ),
                            ],
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      AppConstants.slogan,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: tema.textoSuave,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 42),

              // ---- A LINHA DE CARREGAMENTO ----
              // Uma barra fina que anda com a própria animação: mais
              // discreta do que a rodinha girando.
              AnimatedBuilder(
                animation: _animacao,
                builder: (context, _) {
                  return SizedBox(
                    width: 120,
                    height: 3,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(3),
                      child: LinearProgressIndicator(
                        value: _animacao.value.clamp(0.05, 1.0),
                        backgroundColor:
                            tema.textoSuave.withValues(alpha: 0.20),
                        valueColor:
                            AlwaysStoppedAnimation<Color>(tema.primaria),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
