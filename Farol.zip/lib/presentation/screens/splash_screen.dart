/// -----------------------------------------------------------------------
/// TELA DE ABERTURA
/// -----------------------------------------------------------------------
/// Mostra a marca por um instante enquanto carrega os dados do celular e
/// decide para onde ir: cadastro (primeira vez) ou tela inicial.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_routes.dart';
import '../controllers/app_controller.dart';
import '../widgets/logo_farol.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animacao;

  @override
  void initState() {
    super.initState();
    _animacao = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();
    _decidirDestino();
  }

  Future<void> _decidirDestino() async {
    final app = context.read<AppController>();
    await app.carregar();

    // Um respiro curto para a marca aparecer — e só isso. Tempo de
    // abertura é tempo parado: o motorista quer o app na mão, rápido.
    await Future<void>.delayed(const Duration(milliseconds: 650));
    if (!mounted) return;

    Navigator.of(context).pushReplacementNamed(
      app.temCadastro ? AppRoutes.principal : AppRoutes.login,
    );
  }

  @override
  void dispose() {
    _animacao.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              // A marca entra crescendo e clareando.
              FadeTransition(
                opacity: CurvedAnimation(
                  parent: _animacao,
                  curve: const Interval(0, 0.6, curve: Curves.easeOut),
                ),
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.7, end: 1).animate(
                    CurvedAnimation(
                      parent: _animacao,
                      curve: const Interval(0, 0.7, curve: Curves.easeOutBack),
                    ),
                  ),
                  child: LogoFarol(tema: tema, tamanho: 132),
                ),
              ),
              const SizedBox(height: 28),
              FadeTransition(
                opacity: CurvedAnimation(
                  parent: _animacao,
                  curve: const Interval(0.35, 1, curve: Curves.easeOut),
                ),
                child: Column(
                  children: <Widget>[
                    Text(
                      AppConstants.nomeApp.toUpperCase(),
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                            letterSpacing: 9,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      AppConstants.slogan,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: tema.textoSuave,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 52),
              SizedBox(
                width: 26,
                height: 26,
                child: CircularProgressIndicator(
                  strokeWidth: 2.4,
                  color: tema.primaria,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
