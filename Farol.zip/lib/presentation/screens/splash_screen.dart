/// -----------------------------------------------------------------------
/// TELA DE ABERTURA — A AVENIDA OCUPA A TELA INTEIRA
/// -----------------------------------------------------------------------
/// Sem moldura, sem borda, sem cartão: a cena vai de canto a canto do
/// aparelho, inclusive por baixo da barra de status e da barra de
/// navegação do Android. É a primeira coisa que o motorista vê.
///
/// Por cima da cena ficam só duas coisas, no alto: o nome FAROL e uma
/// linha fina de carregamento. O resto é a avenida.
///
/// E O CARRO BUZINA no instante em que acende o farol — duas buzinadas,
/// com duas batidinhas de vibração junto. Quem desligar "Sons" em
/// Aparência não ouve nada; quem desligar "Animações" nem chega aqui.
///
/// A animação dura 2,6 segundos, mas NÃO SEGURA O APLICATIVO: os dados
/// do celular são lidos ao mesmo tempo em que ela roda. Quando os dois
/// terminam, a tela passa.
///
/// Quem desligou as animações em Aparência entra praticamente na hora —
/// a abertura vira só o tempo de ler o banco.
///
/// NADA AQUI MEXE NOS DADOS. Esta tela só lê o que já está gravado no
/// celular; o histórico do motorista continua exatamente onde estava.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../controllers/app_controller.dart';
import '../widgets/animacao_farol.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animacao;

  /// Quanto tempo a abertura fica na tela, com as animações ligadas.
  static const Duration _duracao = Duration(milliseconds: 2600);

  /// Já buzinou nesta abertura? A buzina toca UMA vez só.
  bool _jaBuzinou = false;

  @override
  void initState() {
    super.initState();
    _animacao = AnimationController(vsync: this, duration: _duracao)
      ..addListener(_talvezBuzinar)
      ..forward();

    // A cena vai até as bordas do aparelho: as barras do sistema ficam
    // transparentes, com os ícones claros (o fundo é escuro).
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.edgeToEdge,
      overlays: SystemUiOverlay.values,
    );
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Colors.transparent,
      ),
    );

    _decidirDestino();
  }

  /// A BUZINA, no instante exato em que o farol acende.
  ///
  /// Fica pendurada na própria animação: quando ela passa do ponto em
  /// que o farol firma (logo depois dos dois lampejos), o carro buzina.
  /// Assim o som e a luz acontecem juntos, sem cronômetro separado que
  /// pudesse sair do compasso.
  void _talvezBuzinar() {
    if (_jaBuzinou) return;
    if (_animacao.value < 0.70) return;
    _jaBuzinou = true;
    // Sem animações, a tela passa antes da buzina fazer sentido.
    if (!mounted) return;
    if (!context.read<AppController>().animacoesAtivas) return;
    AudioService.buzinar();
  }

  Future<void> _decidirDestino() async {
    final app = context.read<AppController>();

    // Os dois acontecem JUNTOS: carregar o banco e rodar a animação.
    await app.carregar();
    if (!mounted) return;

    final espera = app.animacoesAtivas
        ? _duracao - const Duration(milliseconds: 60)
        : const Duration(milliseconds: 120);

    // Desconta o tempo que a leitura do banco já levou.
    final decorrido = _animacao.lastElapsedDuration ?? Duration.zero;
    final restante = espera - decorrido;
    if (restante > Duration.zero) {
      await Future<void>.delayed(restante);
    }
    if (!mounted) return;

    Navigator.of(context).pushReplacementNamed(
      app.temCadastro ? AppRoutes.principal : AppRoutes.login,
    );
  }

  @override
  void dispose() {
    _animacao
      ..removeListener(_talvezBuzinar)
      ..dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;

    return Scaffold(
      backgroundColor: tema.fundo,
      // Sem AppBar e com o Stack preenchendo tudo: é isso que faz a cena
      // encostar nas quatro bordas do aparelho.
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          // ---- A CENA, DE CANTO A CANTO ----
          AnimacaoFarolLigando(animacao: _animacao, tema: tema),

          // ---- O NOME, NO ALTO ----
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 26),
                child: AnimatedBuilder(
                  animation: _animacao,
                  builder: (context, filho) {
                    final t = _animacao.value;
                    // Entra do instante 0.78 em diante — depois que o
                    // carro fez a curva e o farol acendeu.
                    final f = Curves.easeOut
                        .transform(((t - 0.78) / 0.22).clamp(0.0, 1.0));
                    return Opacity(
                      opacity: f,
                      child: Transform.translate(
                        offset: Offset(0, -10 * (1 - f)),
                        child: filho,
                      ),
                    );
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        AppConstants.nomeApp.toUpperCase(),
                        style: Theme.of(context)
                            .textTheme
                            .displayMedium
                            ?.copyWith(
                              letterSpacing: 11,
                              fontWeight: FontWeight.w700,
                              shadows: <Shadow>[
                                Shadow(
                                  color:
                                      tema.primaria.withValues(alpha: 0.75),
                                  blurRadius: 26,
                                ),
                              ],
                            ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        AppConstants.slogan,
                        style:
                            Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: tema.textoSuave,
                                  letterSpacing: 0.6,
                                ),
                      ),
                      const SizedBox(height: 18),
                      // A linha fina de carregamento, andando junto com
                      // a própria animação.
                      AnimatedBuilder(
                        animation: _animacao,
                        builder: (context, _) => SizedBox(
                          width: 110,
                          height: 2.5,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: _animacao.value.clamp(0.05, 1.0),
                              backgroundColor:
                                  tema.textoSuave.withValues(alpha: 0.20),
                              valueColor: AlwaysStoppedAnimation<Color>(
                                tema.primaria,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
