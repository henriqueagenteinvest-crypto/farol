/// -----------------------------------------------------------------------
/// ABASTECIMENTO
/// -----------------------------------------------------------------------
/// Registra cada ida ao posto. O desconto (em R$ ou em %) é aplicado na
/// hora, e o app mostra quanto o litro saiu DE VERDADE — que é o número
/// que serve para comparar postos.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../data/models/abastecimento.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/estado_vazio.dart';

class AbastecimentoScreen extends StatelessWidget {
  const AbastecimentoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final lista = dados.abastecimentos;

    return Scaffold(
      appBar: AppBar(title: const Text('Abastecimentos')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: lista.isEmpty
            ? EstadoVazio(
                icone: Icons.local_gas_station_rounded,
                titulo: 'Nenhum abastecimento',
                mensagem: 'Registre quando encher o tanque para acompanhar '
                    'quanto o litro está saindo de verdade.',
                tema: tema,
                textoBotao: 'Registrar abastecimento',
                iconeBotao: Icons.add_rounded,
                aoTocarBotao: () => _abrirFormulario(context, tema),
              )
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 100),
                itemCount: lista.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) => _CartaoAbastecimento(
                  item: lista[i],
                  tema: tema,
                  aoTocar: () =>
                      _abrirFormulario(context, tema, existente: lista[i]),
                ),
              ),
      ),
      floatingActionButton: lista.isEmpty
          ? null
          : FloatingActionButton.extended(
              onPressed: () => _abrirFormulario(context, tema),
              backgroundColor: tema.primaria,
              foregroundColor: tema.primaria.computeLuminance() > 0.5
                  ? Colors.black
                  : Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Abastecer'),
            ),
    );
  }

  void _abrirFormulario(
    BuildContext context,
    TemaFarol tema, {
    Abastecimento? existente,
  }) {
    AudioService.clique();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: tema.superficie,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(tema.raioBorda + 8),
        ),
      ),
      builder: (_) => _FormularioAbastecimento(existente: existente),
    );
  }
}

// =======================================================================
// CARTÃO DE UM ABASTECIMENTO
// =======================================================================
class _CartaoAbastecimento extends StatelessWidget {
  final Abastecimento item;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _CartaoAbastecimento({
    required this.item,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    // Números prontos, vindos do serviço de cálculo.
    final valorFinal = CalculationsService.valorFinalAbastecimento(item);
    final economia = CalculationsService.economiaAbastecimento(item);
    final precoEfetivo = CalculationsService.precoEfetivoPorLitro(item);

    return CartaoFarol(
      tema: tema,
      aoTocar: aoTocar,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: tema.alerta.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(
                  Icons.local_gas_station_rounded,
                  color: tema.alerta,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '${Fmt.quantidade(item.litros, AppConstants.unidadeDe(item.tipoCombustivel))}'
                      ' de ${item.tipoCombustivel}',
                      style: context.textos.titleMedium,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${Fmt.data(item.data)}'
                      '${item.posto.isEmpty ? "" : " • ${item.posto}"}'
                      ' • ${item.formaPagamento}',
                      style: context.textos.bodySmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Text(
                Fmt.moeda(valorFinal),
                style: context.textos.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: tema.superficieAlta,
              borderRadius: BorderRadius.circular(11),
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: _MiniInfo(
                    rotulo: 'Litro na bomba',
                    valor: Fmt.moeda(item.precoLitro),
                    cor: tema.textoSuave,
                  ),
                ),
                Expanded(
                  child: _MiniInfo(
                    rotulo: 'Saiu por',
                    valor: Fmt.moeda(precoEfetivo),
                    cor: tema.sucesso,
                  ),
                ),
                if (economia > 0)
                  Expanded(
                    child: _MiniInfo(
                      rotulo: 'Você economizou',
                      valor: Fmt.moeda(economia),
                      cor: tema.primaria,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniInfo extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;

  const _MiniInfo({
    required this.rotulo,
    required this.valor,
    required this.cor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          rotulo,
          style: context.textos.labelSmall,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 3),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            color: cor,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// =======================================================================
// FORMULÁRIO
// =======================================================================
class _FormularioAbastecimento extends StatefulWidget {
  final Abastecimento? existente;
  const _FormularioAbastecimento({this.existente});

  @override
  State<_FormularioAbastecimento> createState() =>
      _FormularioAbastecimentoState();
}

class _FormularioAbastecimentoState extends State<_FormularioAbastecimento> {
  final _formulario = GlobalKey<FormState>();
  final _litros = TextEditingController();
  final _precoLitro = TextEditingController();
  final _descontoReais = TextEditingController();
  final _descontoPct = TextEditingController();
  final _posto = TextEditingController();

  late DateTime _data;
  late String _combustivel;
  late String _pagamento;

  /// O motorista escolhe se o desconto é em R$ ou em %.
  bool _descontoEmPorcentagem = false;

  bool get _editando => widget.existente != null;

  @override
  void initState() {
    super.initState();
    final a = widget.existente;
    final config = context.read<AppController>().config;

    _data = a?.data ?? DateTime.now();
    _combustivel = a?.tipoCombustivel ?? config.combustivelPadrao;
    _pagamento = a?.formaPagamento ?? AppConstants.formasPagamento.first;

    if (a != null) {
      _litros.text = Fmt.numero(a.litros);
      _precoLitro.text = Fmt.numero(a.precoLitro);
      _posto.text = a.posto;
      if (a.descontoPercentual > 0) {
        _descontoEmPorcentagem = true;
        _descontoPct.text = Fmt.numero(a.descontoPercentual, casas: 1);
      } else if (a.descontoReais > 0) {
        _descontoReais.text = Fmt.numero(a.descontoReais);
      }
    } else {
      _precoLitro.text =
          Fmt.numero(context.read<DadosController>().precoLitroSugerido);
    }
  }

  @override
  void dispose() {
    _litros.dispose();
    _precoLitro.dispose();
    _descontoReais.dispose();
    _descontoPct.dispose();
    _posto.dispose();
    super.dispose();
  }

  /// Monta o objeto com o que está na tela agora (para a prévia e o salvar).
  Abastecimento _montar() => Abastecimento(
        id: widget.existente?.id,
        data: _data,
        litros: Fmt.paraDoubleOuZero(_litros.text),
        precoLitro: Fmt.paraDoubleOuZero(_precoLitro.text),
        tipoCombustivel: _combustivel,
        formaPagamento: _pagamento,
        descontoReais: _descontoEmPorcentagem
            ? 0
            : Fmt.paraDoubleOuZero(_descontoReais.text),
        descontoPercentual: _descontoEmPorcentagem
            ? Fmt.paraDoubleOuZero(_descontoPct.text)
            : 0,
        posto: _posto.text.trim(),
        criadoEm: widget.existente?.criadoEm,
      );

  Future<void> _salvar() async {
    if (!_formulario.currentState!.validate()) {
      AudioService.erro();
      return;
    }
    final r = await context.read<DadosController>().salvarAbastecimento(_montar());
    if (!mounted) return;
    if (r.falhouDeVez) {
      AudioService.erro();
      context.aviso('Este celular recusou guardar o abastecimento. '
          'Veja Mais → Diagnóstico.', erro: true);
      return;
    }
    AudioService.sucesso();
    // O aviso vem ANTES de fechar: depois do pop esta tela já não existe
    // mais e a mensagem se perderia.
    context.aviso(
      r.soNaMemoria
          ? 'Abastecimento lançado, mas não gravado no disco.'
          : 'Abastecimento salvo!',
      erro: r.soNaMemoria,
    );
    Navigator.of(context).pop();
  }

  Future<void> _apagar() async {
    try {
      await context
          .read<DadosController>()
          .apagarAbastecimento(widget.existente!.id);
    } catch (e) {
      if (!mounted) return;
      context.aviso('Não deu para apagar o abastecimento.', erro: true);
      return;
    }
    if (!mounted) return;
    context.aviso('Abastecimento apagado');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;
    final previa = _montar();
    final valorCheio = CalculationsService.valorBrutoAbastecimento(
      litros: previa.litros,
      precoLitro: previa.precoLitro,
    );
    final valorFinal = CalculationsService.valorFinalAbastecimento(previa);
    final precoEfetivo = CalculationsService.precoEfetivoPorLitro(previa);
    final economia = CalculationsService.economiaAbastecimento(previa);

    return Padding(
      // Sobe junto com o teclado, para o campo nunca ficar escondido.
      padding: EdgeInsets.only(
        bottom: MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: DraggableScrollableSheet(
        initialChildSize: 0.92,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, rolagem) => Form(
          key: _formulario,
          onChanged: () => setState(() {}),
          child: ListView(
            controller: rolagem,
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 30),
            children: <Widget>[
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: tema.textoSuave.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      _editando ? 'Editar abastecimento' : 'Novo abastecimento',
                      style: context.textos.headlineSmall,
                    ),
                  ),
                  if (_editando)
                    IconButton(
                      icon: Icon(
                        Icons.delete_outline_rounded,
                        color: tema.erro,
                      ),
                      onPressed: _apagar,
                    ),
                ],
              ),
              const SizedBox(height: 20),

              CampoData(
                data: _data,
                tema: tema,
                aoMudar: (d) => setState(() => _data = d),
              ),
              const SizedBox(height: 16),
              // O tipo vem PRIMEIRO porque ele decide os rótulos abaixo:
              // litro para gasolina e álcool, m³ para GNV, kWh para
              // elétrico. A conta é a mesma nos três casos.
              SeletorOpcoes(
                rotulo: 'Combustível ou energia',
                opcoes: AppConstants.tiposCombustivel,
                selecionada: _combustivel,
                tema: tema,
                aoSelecionar: (v) => setState(() => _combustivel = v),
              ),
              const SizedBox(height: 18),
              Row(
                children: <Widget>[
                  Expanded(
                    child: CampoFarol.decimal(
                      controlador: _litros,
                      rotulo: AppConstants.eletrico(_combustivel)
                          ? 'kWh'
                          : (_combustivel == AppConstants.combustivelGnv
                              ? 'Metros cúbicos'
                              : 'Litros'),
                      icone: AppConstants.eletrico(_combustivel)
                          ? Icons.bolt_rounded
                          : Icons.water_drop_rounded,
                      sufixo: AppConstants.unidadeDe(_combustivel),
                      validador: Validadores.litros,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CampoFarol.dinheiro(
                      controlador: _precoLitro,
                      rotulo: AppConstants.precoDe(_combustivel),
                      icone: Icons.sell_rounded,
                      validador: (v) => Validadores.valorPositivo(
                        v,
                        campo: AppConstants.precoDe(_combustivel),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              SeletorOpcoes(
                rotulo: 'Como pagou',
                opcoes: AppConstants.formasPagamento,
                selecionada: _pagamento,
                tema: tema,
                aoSelecionar: (v) => setState(() => _pagamento = v),
              ),
              const SizedBox(height: 22),

              // ---------------- DESCONTO ----------------
              const TituloSecao(
                texto: 'Desconto',
                icone: Icons.discount_rounded,
              ),
              SeletorOpcoes(
                rotulo: 'O desconto foi em',
                opcoes: const <String>['Reais (R\$)', 'Porcentagem (%)'],
                selecionada: _descontoEmPorcentagem
                    ? 'Porcentagem (%)'
                    : 'Reais (R\$)',
                tema: tema,
                aoSelecionar: (v) => setState(
                  () => _descontoEmPorcentagem = v.contains('%'),
                ),
              ),
              const SizedBox(height: 14),
              if (_descontoEmPorcentagem)
                CampoFarol.decimal(
                  controlador: _descontoPct,
                  rotulo: 'Desconto',
                  icone: Icons.percent_rounded,
                  sufixo: '%',
                  validador: Validadores.percentual,
                  ajuda: 'Deixe vazio se não teve desconto',
                )
              else
                CampoFarol.dinheiro(
                  controlador: _descontoReais,
                  rotulo: 'Desconto',
                  icone: Icons.money_off_rounded,
                  validador: (v) =>
                      Validadores.valorNaoNegativo(v, campo: 'O desconto'),
                  ajuda: 'Deixe vazio se não teve desconto',
                ),
              const SizedBox(height: 16),
              CampoFarol(
                controlador: _posto,
                rotulo: 'Posto (opcional)',
                dica: 'Ex.: Posto Ipiranga da Anhanguera',
                icone: Icons.store_rounded,
                capitalizacao: TextCapitalization.words,
              ),
              const SizedBox(height: 24),

              // ---------------- RESULTADO ----------------
              CartaoFarol(
                tema: tema,
                comGradiente: true,
                child: Column(
                  children: <Widget>[
                    Text(
                      'VOCÊ VAI PAGAR',
                      style: context.textos.labelSmall?.copyWith(
                        color: Colors.white.withValues(alpha: 0.85),
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.1,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      Fmt.moeda(valorFinal),
                      style: context.textos.displaySmall
                          ?.copyWith(color: Colors.white),
                    ),
                    if (economia > 0) ...<Widget>[
                      const SizedBox(height: 8),
                      Text(
                        'De ${Fmt.moeda(valorCheio)} — '
                        'você economizou ${Fmt.moeda(economia)}',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Text(
                        'O litro saiu por ${Fmt.moeda(precoEfetivo)}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              BotaoGrande(
                texto: 'Salvar abastecimento',
                icone: Icons.check_circle_rounded,
                tema: tema,
                aoTocar: _salvar,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
