/// -----------------------------------------------------------------------
/// DIAGNÓSTICO
/// -----------------------------------------------------------------------
/// Quando alguma gravação falha, o motorista vê aqui exatamente o que o
/// celular respondeu. Basta tirar um print desta tela para o problema
/// ser resolvido de vez, em vez de ficar no chute.
///
/// Nada daqui sai do aparelho: é só uma lista guardada na memória.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../data/gravacao_segura.dart';
import '../../utils/extensions.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/painel_widgets.dart';

class DiagnosticoScreen extends StatefulWidget {
  const DiagnosticoScreen({super.key});

  @override
  State<DiagnosticoScreen> createState() => _DiagnosticoScreenState();
}

class _DiagnosticoScreenState extends State<DiagnosticoScreen> {
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final linhas = DiarioDeErros.linhas;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnóstico'),
        actions: <Widget>[
          if (linhas.isNotEmpty)
            IconButton(
              tooltip: 'Copiar',
              icon: const Icon(Icons.copy_rounded),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: linhas.join('\n')));
                context.aviso('Copiado. Pode colar na conversa.');
              },
            ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
          children: <Widget>[
            // ---------------- ESTADO ----------------
            Caixa(
              tema: tema,
              child: Row(
                children: <Widget>[
                  Icon(
                    DiarioDeErros.temErro
                        ? Icons.warning_amber_rounded
                        : Icons.check_circle_rounded,
                    color: DiarioDeErros.temErro ? tema.erro : tema.sucesso,
                    size: 30,
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          DiarioDeErros.temErro
                              ? 'Houve falha ao gravar'
                              : 'Tudo gravando normalmente',
                          style: context.textos.titleLarge,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          DiarioDeErros.temErro
                              ? '${DiarioDeErros.falhas} falha(s) desde que '
                                  'o aplicativo abriu. Copie o texto abaixo '
                                  'e me mande.'
                              : 'Nenhuma falha desde que o aplicativo abriu.',
                          style: context.textos.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: tema.espaco + 4),

            // ---------------- O QUE ESTÁ GUARDADO ----------------
            TituloBloco(tema: tema, texto: 'O que está guardado'),
            Caixa(
              tema: tema,
              child: Column(
                children: <Widget>[
                  _Linha(
                    rotulo: 'Lançamentos de dias',
                    valor: '${dados.lancamentos.length}',
                  ),
                  Divider(height: 18, color: tema.divisor),
                  _Linha(
                    rotulo: 'Abastecimentos',
                    valor: '${dados.abastecimentos.length}',
                  ),
                  Divider(height: 18, color: tema.divisor),
                  _Linha(
                    rotulo: 'Gastos',
                    valor: '${dados.gastos.length}',
                  ),
                  Divider(height: 18, color: tema.divisor),
                  _Linha(
                    rotulo: 'Cadastro do motorista',
                    valor: app.temCadastro ? 'ok' : 'não encontrado',
                  ),
                ],
              ),
            ),
            SizedBox(height: tema.espaco + 4),

            // ---------------- OCORRÊNCIAS ----------------
            TituloBloco(
              tema: tema,
              texto: 'Ocorrências',
              acao: linhas.isEmpty
                  ? null
                  : TextButton(
                      onPressed: () {
                        DiarioDeErros.limpar();
                        setState(() {});
                      },
                      child: const Text('Limpar'),
                    ),
            ),
            Caixa(
              tema: tema,
              child: linhas.isEmpty
                  ? Text(
                      'Nada registrado. É assim que tem que ser.',
                      style: context.textos.bodySmall,
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        for (final l in linhas)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 9),
                            child: SelectableText(
                              l,
                              style: tema.numero(
                                tamanho: 11.5,
                                peso: FontWeight.w400,
                                cor: tema.texto,
                                espacamento: 0,
                              ),
                            ),
                          ),
                      ],
                    ),
            ),
            SizedBox(height: tema.espaco + 4),

            // ---------------- EXPLICAÇÃO ----------------
            Caixa(
              tema: tema,
              child: Text(
                'Se aparecer alguma linha aqui, o aplicativo conseguiu '
                'mostrar o valor na tela, mas o celular recusou gravar no '
                'disco. Nesse caso, exporte o Excel antes de fechar o '
                'aplicativo — é a sua cópia de segurança.',
                style: context.textos.bodySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final String rotulo;
  final String valor;

  const _Linha({required this.rotulo, required this.valor});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(child: Text(rotulo, style: context.textos.bodyMedium)),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
