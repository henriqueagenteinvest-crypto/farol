/// -----------------------------------------------------------------------
/// LANÇAMENTO DO DIA
/// -----------------------------------------------------------------------
/// O motorista informa o que aconteceu no dia e vê os números se
/// calcularem NA HORA, enquanto digita. Nenhuma conta é feita nesta tela:
/// tudo vem do CalculationsService.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../data/models/lancamento_diario.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';

/// Dados que a tela pode receber de outra parte do app.
class ArgsLancamento {
  /// Quando vem preenchido, a tela entra em modo de EDIÇÃO.
  final LancamentoDiario? existente;

  /// Valores que já entram preenchidos (ex.: o dia escolhido na Semana).
  final double? horasSugeridas;
  final double? valorSugerido;
  final int? corridasSugeridas;
  final double? kmSugerido;
  final DateTime? dataSugerida;

  const ArgsLancamento({
    this.existente,
    this.horasSugeridas,
    this.valorSugerido,
    this.corridasSugeridas,
    this.kmSugerido,
    this.dataSugerida,
  });
}

class LancamentoScreen extends StatefulWidget {
  final ArgsLancamento? argumentos;

  const LancamentoScreen({super.key, this.argumentos});

  @override
  State<LancamentoScreen> createState() => _LancamentoScreenState();
}

class _LancamentoScreenState extends State<LancamentoScreen> {
  final _formulario = GlobalKey<FormState>();

  final _km = TextEditingController();
  final _valorBruto = TextEditingController();
  final _horas = TextEditingController();
  final _corridas = TextEditingController();
  final _kmPorLitro = TextEditingController();
  final _precoLitro = TextEditingController();

  // Só aparecem quando o tipo escolhido é Elétrico.
  final _autonomia = TextEditingController();
  final _bateria = TextEditingController();
  final _observacao = TextEditingController();

  late DateTime _data;
  late String _combustivel;
  late String _tipoVeiculo;
  bool _salvando = false;

  bool get _editando => widget.argumentos?.existente != null;

  /// O tipo escolhido agora é elétrico?
  bool get _ehEletrico => AppConstants.eletrico(_combustivel);

  double get _autonomiaKm => Fmt.paraDoubleOuZero(_autonomia.text);
  double get _bateriaKwh => Fmt.paraDoubleOuZero(_bateria.text);

  /// O rendimento que entra nas contas: km por litro, por m³ ou por kWh.
  ///
  /// No elétrico ele NÃO é digitado — sai da autonomia da carga dividida
  /// pela capacidade da bateria, que é como o motorista pensa. A divisão
  /// é feita no CalculationsService, nunca aqui.
  double get _rendimentoAtual {
    if (_ehEletrico) {
      return CalculationsService.rendimentoEletrico(
        autonomiaKm: _autonomiaKm,
        capacidadeKwh: _bateriaKwh,
      );
    }
    return Fmt.paraDoubleOuZero(_kmPorLitro.text);
  }

  /// Quanto custa encher a bateria do zero ao cheio.
  double get _custoDaCarga => CalculationsService.custoDaCargaCheia(
        capacidadeKwh: _bateriaKwh,
        precoKwh: Fmt.paraDoubleOuZero(_precoLitro.text),
      );

  @override
  void initState() {
    super.initState();
    final args = widget.argumentos;
    final config = context.read<AppController>().config;
    final dados = context.read<DadosController>();
    final antigo = args?.existente;

    _data = antigo?.data ?? args?.dataSugerida ?? DateTime.now();
    _combustivel = antigo?.tipoCombustivel ?? config.combustivelPadrao;
    _tipoVeiculo = antigo?.tipoVeiculo ?? config.tipoVeiculoPadrao;

    // Preenche com o que já existe (edição) ou com o que foi sugerido.
    if (antigo != null) {
      _km.text = Fmt.numero(antigo.km, casas: 1);
      _valorBruto.text = Fmt.numero(antigo.valorBruto);
      _horas.text = Fmt.numero(antigo.horas, casas: 2);
      _corridas.text = antigo.corridas.toString();
      _kmPorLitro.text = Fmt.numero(antigo.kmPorLitro, casas: 1);
      _precoLitro.text = Fmt.numero(antigo.precoLitro);
      _observacao.text = antigo.observacao;
      if (antigo.autonomiaPorCarga > 0) {
        _autonomia.text = Fmt.numero(antigo.autonomiaPorCarga, casas: 0);
      }
      if (antigo.capacidadeBateria > 0) {
        _bateria.text = Fmt.numero(antigo.capacidadeBateria, casas: 1);
      }
    } else {
      if (args?.kmSugerido != null) {
        _km.text = Fmt.numero(args!.kmSugerido!, casas: 1);
      }
      if (args?.valorSugerido != null) {
        _valorBruto.text = Fmt.numero(args!.valorSugerido!);
      }
      if (args?.horasSugeridas != null && args!.horasSugeridas! > 0) {
        _horas.text = Fmt.numero(args.horasSugeridas!, casas: 2);
      }
      if (args?.corridasSugeridas != null) {
        _corridas.text = args!.corridasSugeridas!.toString();
      }
      // Padrões do carro, que o motorista definiu nas configurações.
      _kmPorLitro.text = Fmt.numero(config.kmPorLitroPadrao, casas: 1);
      _precoLitro.text = Fmt.numero(dados.precoLitroSugerido);
      if (config.autonomiaCargaPadrao > 0) {
        _autonomia.text = Fmt.numero(config.autonomiaCargaPadrao, casas: 0);
      }
      if (config.capacidadeBateriaPadrao > 0) {
        _bateria.text = Fmt.numero(config.capacidadeBateriaPadrao, casas: 1);
      }
    }
  }

  @override
  void dispose() {
    _km.dispose();
    _valorBruto.dispose();
    _horas.dispose();
    _corridas.dispose();
    _kmPorLitro.dispose();
    _precoLitro.dispose();
    _autonomia.dispose();
    _bateria.dispose();
    _observacao.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  // OS NÚMEROS AO VIVO (recalculados a cada tecla)
  // ---------------------------------------------------------------------
  ({
    double litros,
    double combustivel,
    double lucro,
    double custoKm,
    double lucroKm,
    double porHora,
    double ticket,
    double margem,
  }) get _previa {
    final km = Fmt.paraDoubleOuZero(_km.text);
    final bruto = Fmt.paraDoubleOuZero(_valorBruto.text);
    final horas = Fmt.paraDoubleOuZero(_horas.text);
    final corridas = Fmt.paraInt(_corridas.text) ?? 0;
    final kpl = _rendimentoAtual;
    final preco = Fmt.paraDoubleOuZero(_precoLitro.text);

    final litros = CalculationsService.litrosGastos(km, kpl);
    final combustivel = CalculationsService.custoCombustivel(litros, preco);
    final lucro = CalculationsService.lucroBruto(
      valorBruto: bruto,
      custoCombustivel: combustivel,
    );

    return (
      litros: litros,
      combustivel: combustivel,
      lucro: lucro,
      custoKm: CalculationsService.custoPorKm(
        custoTotal: combustivel,
        km: km,
      ),
      lucroKm: CalculationsService.lucroPorKm(lucro: lucro, km: km),
      porHora: CalculationsService.ganhoPorHora(lucro: lucro, horas: horas),
      ticket: CalculationsService.ticketMedio(
        valorBruto: bruto,
        corridas: corridas,
      ),
      margem: CalculationsService.margemLucro(
        lucro: lucro,
        valorBruto: bruto,
      ),
    );
  }

  Future<void> _salvar() async {
    // Evita salvar duas vezes se o motorista tocar rápido no botão.
    if (_salvando) return;

    if (!_formulario.currentState!.validate()) {
      AudioService.erro();
      context.aviso('Confira os campos marcados em vermelho', erro: true);
      return;
    }
    setState(() => _salvando = true);

    final antigo = widget.argumentos?.existente;
    final lancamento = LancamentoDiario(
      id: antigo?.id,
      data: _data,
      km: Fmt.paraDoubleOuZero(_km.text),
      valorBruto: Fmt.paraDoubleOuZero(_valorBruto.text),
      horas: Fmt.paraDoubleOuZero(_horas.text),
      corridas: Fmt.paraInt(_corridas.text) ?? 0,
      tipoCombustivel: _combustivel,
      // No elétrico o rendimento é calculado; nos outros, digitado.
      kmPorLitro: _rendimentoAtual,
      autonomiaPorCarga: _ehEletrico ? _autonomiaKm : 0,
      capacidadeBateria: _ehEletrico ? _bateriaKwh : 0,
      precoLitro: Fmt.paraDoubleOuZero(_precoLitro.text),
      tipoVeiculo: _tipoVeiculo,
      observacao: _observacao.text.trim(),
      // Campo antigo: mantido só para não perder o histórico de quem já
      // usava a leitura de print nas versões anteriores.
      veioDeOcr: antigo?.veioDeOcr ?? false,
      criadoEm: antigo?.criadoEm,
    );

    // A gravação nunca estoura erro: ela devolve o que aconteceu de fato.
    final r = await context.read<DadosController>().salvarLancamento(lancamento);
    if (!mounted) return;
    setState(() => _salvando = false);

    if (r.falhouDeVez) {
      AudioService.erro();
      context.aviso(
        'Este celular recusou guardar o lançamento. '
        'Veja Mais → Diagnóstico.',
        erro: true,
      );
      return;
    }

    AudioService.sucesso();
    context.aviso(
      r.soNaMemoria
          ? 'Lançado — mas o celular não gravou no disco. '
              'Veja Mais → Diagnóstico antes de fechar o app.'
          : (_editando ? 'Lançamento atualizado!' : 'Dia lançado com sucesso!'),
      erro: r.soNaMemoria,
    );
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;
    final p = _previa;

    return Scaffold(
      appBar: AppBar(
        title: Text(_editando ? 'Editar lançamento' : 'Lançar o dia'),
        actions: <Widget>[
          if (_editando)
            IconButton(
              tooltip: 'Apagar',
              icon: Icon(Icons.delete_outline_rounded, color: tema.erro),
              onPressed: _confirmarApagar,
            ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: Form(
          key: _formulario,
          // Recalcula a prévia a cada mudança em qualquer campo.
          onChanged: () => setState(() {}),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 40),
            children: <Widget>[
              CampoData(
                data: _data,
                tema: tema,
                aoMudar: (d) => setState(() => _data = d),
              ),
              const SizedBox(height: 22),

              // ---------------- O QUE ACONTECEU ----------------
              const TituloSecao(
                texto: 'O que aconteceu no dia',
                icone: Icons.edit_note_rounded,
              ),
              CampoFarol.dinheiro(
                controlador: _valorBruto,
                rotulo: 'Quanto recebeu (bruto)',
                validador: (v) => Validadores.valorPositivo(
                  v,
                  campo: 'O valor recebido',
                ),
                ajuda: 'O valor cheio que os apps mostram, antes dos custos',
              ),
              const SizedBox(height: 14),
              Row(
                children: <Widget>[
                  Expanded(
                    child: CampoFarol.decimal(
                      controlador: _km,
                      rotulo: 'KM rodados',
                      icone: Icons.route_rounded,
                      sufixo: 'km',
                      // Opcional: dá para lançar só o valor recebido e
                      // completar o resto depois. O que não for informado
                      // entra como zero e não atrapalha nenhuma conta.
                      validador: (v) =>
                          Validadores.km(v, obrigatorioCampo: false),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CampoFarol.decimal(
                      controlador: _horas,
                      rotulo: 'Horas',
                      icone: Icons.schedule_rounded,
                      sufixo: 'h',
                      validador: (v) =>
                          Validadores.horas(v, obrigatorioCampo: false),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              CampoFarol.inteiro(
                controlador: _corridas,
                rotulo: 'Quantas corridas fez',
                icone: Icons.local_taxi_rounded,
                validador: (v) =>
                    Validadores.corridas(v, obrigatorioCampo: false),
                ajuda: 'KM, horas e corridas podem ficar em branco — '
                    'só o valor recebido é obrigatório',
              ),
              const SizedBox(height: 26),

              // ---------------- O VEÍCULO ----------------
              const TituloSecao(
                texto: 'O veículo',
                icone: Icons.two_wheeler_rounded,
              ),
              SeletorOpcoes(
                rotulo: 'Tipo de veículo',
                opcoes: AppConstants.tiposVeiculo,
                selecionada: _tipoVeiculo,
                tema: tema,
                aoSelecionar: (v) => setState(() => _tipoVeiculo = v),
              ),
              const SizedBox(height: 16),

              // ---------------- ENERGIA / COMBUSTÍVEL ----------------
              // O bloco inteiro TROCA DE CARA conforme o tipo escolhido.
              // Combustão pede consumo e preço da unidade; elétrico pede
              // a ficha da bateria, que é como quem roda elétrico pensa.
              TituloSecao(
                texto: AppConstants.tituloEnergiaDe(_combustivel),
                icone: AppConstants.eletrico(_combustivel)
                    ? Icons.bolt_rounded
                    : Icons.local_gas_station_rounded,
              ),
              SeletorOpcoes(
                rotulo: 'Tipo',
                opcoes: AppConstants.tiposCombustivel,
                selecionada: _combustivel,
                tema: tema,
                aoSelecionar: (v) => setState(() => _combustivel = v),
              ),
              const SizedBox(height: 16),

              if (_ehEletrico)
                _PainelEletrico(
                  tema: tema,
                  autonomia: _autonomia,
                  bateria: _bateria,
                  precoKwh: _precoLitro,
                  rendimento: _rendimentoAtual,
                  custoDaCarga: _custoDaCarga,
                )
              else ...<Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: CampoFarol.decimal(
                        controlador: _kmPorLitro,
                        rotulo: AppConstants.consumoDe(_combustivel),
                        icone: Icons.speed_rounded,
                        sufixo: AppConstants.rendimentoDe(_combustivel),
                        validador: Validadores.kmPorLitro,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CampoFarol.dinheiro(
                        controlador: _precoLitro,
                        rotulo: AppConstants.precoDe(_combustivel),
                        icone: Icons.local_gas_station_rounded,
                        validador: (v) => Validadores.valorPositivo(
                          v,
                          campo: AppConstants.precoDe(_combustivel),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.info_outline_rounded,
                      size: 15,
                      color: tema.textoSuave,
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        AppConstants.ajudaConsumoDe(_combustivel),
                        style: context.textos.bodySmall,
                      ),
                    ),
                  ],
                ),
              ],

              const SizedBox(height: 26),

              // ---------------- PRÉVIA DOS CÁLCULOS ----------------
              const TituloSecao(
                texto: 'Como fica o seu dia',
                icone: Icons.calculate_rounded,
              ),
              _PreviaCalculos(
                tema: tema,
                previa: p,
                unidade: AppConstants.unidadeDe(_combustivel),
              ),
              const SizedBox(height: 22),

              CampoFarol(
                controlador: _observacao,
                rotulo: 'Anotação (opcional)',
                dica: 'Ex.: dia de chuva, muito trânsito',
                icone: Icons.sticky_note_2_rounded,
                linhas: 2,
              ),
              const SizedBox(height: 30),

              BotaoGrande(
                texto: _salvando
                    ? 'Salvando...'
                    : (_editando ? 'Salvar alterações' : 'Salvar lançamento'),
                icone: Icons.check_circle_rounded,
                tema: tema,
                habilitado: !_salvando,
                aoTocar: _salvando ? () {} : _salvar,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmarApagar() async {
    final tema = context.read<AppController>().tema;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar este lançamento?'),
        content: const Text('Esta ação não pode ser desfeita.'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: tema.erro),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Apagar'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    await context
        .read<DadosController>()
        .apagarLancamento(widget.argumentos!.existente!.id);
    if (!mounted) return;
    context.aviso('Lançamento apagado');
    Navigator.of(context).pop(true);
  }
}

// =======================================================================
// PRÉVIA DOS CÁLCULOS (ao vivo)
// =======================================================================
class _PreviaCalculos extends StatelessWidget {
  final TemaFarol tema;
  final ({
    double litros,
    double combustivel,
    double lucro,
    double custoKm,
    double lucroKm,
    double porHora,
    double ticket,
    double margem,
  }) previa;

  /// A unidade do combustível escolhido: L, m³ ou kWh.
  final String unidade;

  const _PreviaCalculos({
    required this.tema,
    required this.previa,
    required this.unidade,
  });

  @override
  Widget build(BuildContext context) {
    final positivo = previa.lucro >= 0;

    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          // ---- Lucro em destaque ----
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: (positivo ? tema.sucesso : tema.erro)
                  .withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(tema.raioBorda * 0.7),
            ),
            child: Column(
              children: <Widget>[
                Text(
                  positivo ? 'SOBRA NO SEU BOLSO' : 'PREJUÍZO NO DIA',
                  style: context.textos.labelSmall?.copyWith(
                    color: positivo ? tema.sucesso : tema.erro,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  Fmt.moeda(previa.lucro),
                  style: context.textos.displaySmall?.copyWith(
                    color: positivo ? tema.sucesso : tema.erro,
                  ),
                ),
                if (previa.margem != 0) ...<Widget>[
                  const SizedBox(height: 4),
                  Text(
                    'margem de ${Fmt.percentual(previa.margem)}',
                    style: context.textos.bodySmall,
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          _Linha(
            'Combustível gasto',
            '${Fmt.quantidade(previa.litros, unidade)}'
            '  •  ${Fmt.moeda(previa.combustivel)}',
            tema.erro,
          ),
          const Divider(height: 20),
          _Linha('Custo por KM', Fmt.moeda(previa.custoKm), tema.alerta),
          const Divider(height: 20),
          _Linha('Lucro por KM', Fmt.moeda(previa.lucroKm), tema.sucesso),
          const Divider(height: 20),
          _Linha('Ganho por hora', Fmt.moeda(previa.porHora), tema.primaria),
          const Divider(height: 20),
          _Linha(
            'Valor médio da corrida',
            Fmt.moeda(previa.ticket),
            tema.secundaria,
          ),
        ],
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;
  const _Linha(this.rotulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
        ),
        const SizedBox(width: 11),
        Expanded(child: Text(rotulo, style: context.textos.bodyMedium)),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// =======================================================================
// O PAINEL DO VEÍCULO ELÉTRICO
// =======================================================================
/// Três informações, do jeito que quem roda elétrico pensa:
///
///   AUTONOMIA POR CARGA  — quantos km a bateria cheia dá
///   CAPACIDADE DA BATERIA — quantos kWh ela segura
///   PREÇO POR kWh        — quanto custa a energia
///
/// COMO ESTE PAINEL É DIFERENTE
///
/// Não é uma pilha de três caixinhas com balãozinho de ajuda. É um
/// painel só, com a cara do Farol:
///
///   • uma BARRA DE BATERIA no topo, que enche conforme a autonomia
///     digitada — o motorista vê o carro dele "carregando" enquanto
///     preenche;
///   • autonomia e capacidade LADO A LADO, porque são a ficha do carro
///     e andam juntas; o preço embaixo, porque é o que muda toda semana;
///   • e no rodapé DOIS resultados, não um: quanto custa a carga cheia
///     E quanto o carro rende por kWh. O rendimento é o número que entra
///     em todas as contas do aplicativo, então ele fica à vista.
///
/// Nenhuma conta é feita aqui: tudo vem do CalculationsService.
class _PainelEletrico extends StatelessWidget {
  final TemaFarol tema;
  final TextEditingController autonomia;
  final TextEditingController bateria;
  final TextEditingController precoKwh;

  /// km por kWh, já calculado.
  final double rendimento;

  /// Quanto custa encher a bateria, já calculado.
  final double custoDaCarga;

  const _PainelEletrico({
    required this.tema,
    required this.autonomia,
    required this.bateria,
    required this.precoKwh,
    required this.rendimento,
    required this.custoDaCarga,
  });

  @override
  Widget build(BuildContext context) {
    final km = Fmt.paraDoubleOuZero(autonomia.text);

    // A barra é só ilustrativa: 500 km de autonomia enche a barra toda.
    // É referência, não conta — por isso não passa pelo serviço.
    final carga = (km / 500).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      decoration: BoxDecoration(
        color: tema.superficie,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        border: Border.all(color: tema.secundaria.withValues(alpha: 0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // ---------------- A BARRA DE BATERIA ----------------
          Row(
            children: <Widget>[
              Icon(Icons.bolt_rounded, size: 17, color: tema.secundaria),
              const SizedBox(width: 6),
              Text(
                'CARGA',
                style: TextStyle(
                  color: tema.secundaria,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
              const Spacer(),
              Text(
                km <= 0 ? 'informe a autonomia' : '${Fmt.km(km)} por carga',
                style: TextStyle(color: tema.textoSuave, fontSize: 11.5),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _BarraDeBateria(tema: tema, carga: carga),
          const SizedBox(height: 16),

          // ---------------- A FICHA DO CARRO ----------------
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: CampoFarol.decimal(
                  controlador: autonomia,
                  rotulo: 'Autonomia por carga',
                  icone: Icons.route_rounded,
                  sufixo: 'km',
                  validador: (v) => Validadores.valorPositivo(
                    v,
                    campo: 'A autonomia por carga',
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: CampoFarol.decimal(
                  controlador: bateria,
                  rotulo: 'Capacidade da bateria',
                  icone: Icons.battery_charging_full_rounded,
                  sufixo: 'kWh',
                  validador: (v) => Validadores.valorPositivo(
                    v,
                    campo: 'A capacidade da bateria',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          CampoFarol.dinheiro(
            controlador: precoKwh,
            rotulo: 'Preço por kWh',
            icone: Icons.electric_bolt_rounded,
            validador: (v) => Validadores.valorPositivo(
              v,
              campo: 'O preço por kWh',
            ),
            ajuda: 'Quanto você paga por kWh na tomada de casa ou no '
                'eletroposto',
          ),
          const SizedBox(height: 14),
          Divider(height: 1, color: tema.divisor),
          const SizedBox(height: 12),

          // ---------------- OS DOIS RESULTADOS ----------------
          Row(
            children: <Widget>[
              Expanded(
                child: _ResultadoEletrico(
                  tema: tema,
                  rotulo: 'Carga cheia custa',
                  valor: custoDaCarga <= 0 ? '—' : Fmt.moeda(custoDaCarga),
                  cor: tema.alerta,
                ),
              ),
              Container(width: 1, height: 34, color: tema.divisor),
              Expanded(
                child: _ResultadoEletrico(
                  tema: tema,
                  rotulo: 'O carro rende',
                  valor: rendimento <= 0
                      ? '—'
                      : '${Fmt.numero(rendimento, casas: 2)} km/kWh',
                  cor: tema.secundaria,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'O rendimento sai da autonomia dividida pela bateria — é ele '
            'que entra em todas as contas do aplicativo.',
            style: context.textos.bodySmall,
          ),
        ],
      ),
    );
  }
}

/// A barra de bateria: enche conforme a autonomia digitada.
class _BarraDeBateria extends StatelessWidget {
  final TemaFarol tema;
  final double carga;

  const _BarraDeBateria({required this.tema, required this.carga});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
            height: 14,
            padding: const EdgeInsets.all(2.5),
            decoration: BoxDecoration(
              color: tema.superficieAlta,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: tema.secundaria.withValues(alpha: 0.5),
                width: 1.4,
              ),
            ),
            child: Align(
              alignment: Alignment.centerLeft,
              child: FractionallySizedBox(
                widthFactor: carga <= 0 ? 0.0 : carga,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOut,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: <Color>[tema.secundaria, tema.primaria],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
          ),
        ),
        // O "bico" da pilha, do lado direito.
        Container(
          width: 3,
          height: 7,
          margin: const EdgeInsets.only(left: 2),
          decoration: BoxDecoration(
            color: tema.secundaria.withValues(alpha: 0.5),
            borderRadius: const BorderRadius.horizontal(
              right: Radius.circular(2),
            ),
          ),
        ),
      ],
    );
  }
}

class _ResultadoEletrico extends StatelessWidget {
  final TemaFarol tema;
  final String rotulo;
  final String valor;
  final Color cor;

  const _ResultadoEletrico({
    required this.tema,
    required this.rotulo,
    required this.valor,
    required this.cor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          rotulo.toUpperCase(),
          style: TextStyle(
            color: tema.textoSuave,
            fontSize: 9.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(valor, style: tema.numero(tamanho: 16, cor: cor)),
        ),
      ],
    );
  }
}
