/// -----------------------------------------------------------------------
/// LANÇAMENTO DO DIA
/// -----------------------------------------------------------------------
/// O motorista informa o que aconteceu no dia e vê os números se
/// calcularem NA HORA, enquanto digita. Nenhuma conta é feita nesta tela:
/// tudo vem do CalculationsService.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_constants.dart';
import '../../data/models/lancamento_diario.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';

/// Dados que a tela pode receber de outra parte do app.
class ArgsLancamento {
  /// Quando vem preenchido, a tela entra em modo de EDIÇÃO.
  final LancamentoDiario? existente;

  /// Valores que já entram preenchidos (ex.: o dia escolhido na Semana).
  final double? horasSugeridas;
  final double? valorSugerido;
  final int? corridasSugeridas;
  final double? kmSugerido;
  final DateTime? dataSugerida;

  const ArgsLancamento({
    this.existente,
    this.horasSugeridas,
    this.valorSugerido,
    this.corridasSugeridas,
    this.kmSugerido,
    this.dataSugerida,
  });
}

class LancamentoScreen extends StatefulWidget {
  final ArgsLancamento? argumentos;

  const LancamentoScreen({super.key, this.argumentos});

  @override
  State<LancamentoScreen> createState() => _LancamentoScreenState();
}

class _LancamentoScreenState extends State<LancamentoScreen> {
  final _formulario = GlobalKey<FormState>();

  final _km = TextEditingController();
  final _valorBruto = TextEditingController();
  final _horas = TextEditingController();
  final _corridas = TextEditingController();
  final _kmPorLitro = TextEditingController();
  final _precoLitro = TextEditingController();
  final _observacao = TextEditingController();

  late DateTime _data;
  late String _combustivel;
  late String _tipoVeiculo;
  bool _salvando = false;

  bool get _editando => widget.argumentos?.existente != null;

  @override
  void initState() {
    super.initState();
    final args = widget.argumentos;
    final config = context.read<AppController>().config;
    final dados = context.read<DadosController>();
    final antigo = args?.existente;

    _data = antigo?.data ?? args?.dataSugerida ?? DateTime.now();
    _combustivel = antigo?.tipoCombustivel ?? config.combustivelPadrao;
    _tipoVeiculo = antigo?.tipoVeiculo ?? config.tipoVeiculoPadrao;

    // Preenche com o que já existe (edição) ou com o que foi sugerido.
    if (antigo != null) {
      _km.text = Fmt.numero(antigo.km, casas: 1);
      _valorBruto.text = Fmt.numero(antigo.valorBruto);
      _horas.text = Fmt.numero(antigo.horas, casas: 2);
      _corridas.text = antigo.corridas.toString();
      _kmPorLitro.text = Fmt.numero(antigo.kmPorLitro, casas: 1);
      _precoLitro.text = Fmt.numero(antigo.precoLitro);
      _observacao.text = antigo.observacao;
    } else {
      if (args?.kmSugerido != null) {
        _km.text = Fmt.numero(args!.kmSugerido!, casas: 1);
      }
      if (args?.valorSugerido != null) {
        _valorBruto.text = Fmt.numero(args!.valorSugerido!);
      }
      if (args?.horasSugeridas != null && args!.horasSugeridas! > 0) {
        _horas.text = Fmt.numero(args.horasSugeridas!, casas: 2);
      }
      if (args?.corridasSugeridas != null) {
        _corridas.text = args!.corridasSugeridas!.toString();
      }
      // Padrões do carro, que o motorista definiu nas configurações.
      _kmPorLitro.text = Fmt.numero(config.kmPorLitroPadrao, casas: 1);
      _precoLitro.text = Fmt.numero(dados.precoLitroSugerido);
    }
  }

  @override
  void dispose() {
    _km.dispose();
    _valorBruto.dispose();
    _horas.dispose();
    _corridas.dispose();
    _kmPorLitro.dispose();
    _precoLitro.dispose();
    _observacao.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  // OS NÚMEROS AO VIVO (recalculados a cada tecla)
  // ---------------------------------------------------------------------
  ({
    double litros,
    double combustivel,
    double lucro,
    double custoKm,
    double lucroKm,
    double porHora,
    double ticket,
    double margem,
  }) get _previa {
    final km = Fmt.paraDoubleOuZero(_km.text);
    final bruto = Fmt.paraDoubleOuZero(_valorBruto.text);
    final horas = Fmt.paraDoubleOuZero(_horas.text);
    final corridas = Fmt.paraInt(_corridas.text) ?? 0;
    final kpl = Fmt.paraDoubleOuZero(_kmPorLitro.text);
    final preco = Fmt.paraDoubleOuZero(_precoLitro.text);

    final litros = CalculationsService.litrosGastos(km, kpl);
    final combustivel = CalculationsService.custoCombustivel(litros, preco);
    final lucro = CalculationsService.lucroBruto(
      valorBruto: bruto,
      custoCombustivel: combustivel,
    );

    return (
      litros: litros,
      combustivel: combustivel,
      lucro: lucro,
      custoKm: CalculationsService.custoPorKm(
        custoTotal: combustivel,
        km: km,
      ),
      lucroKm: CalculationsService.lucroPorKm(lucro: lucro, km: km),
      porHora: CalculationsService.ganhoPorHora(lucro: lucro, horas: horas),
      ticket: CalculationsService.ticketMedio(
        valorBruto: bruto,
        corridas: corridas,
      ),
      margem: CalculationsService.margemLucro(
        lucro: lucro,
        valorBruto: bruto,
      ),
    );
  }

  Future<void> _salvar() async {
    // Evita salvar duas vezes se o motorista tocar rápido no botão.
    if (_salvando) return;

    if (!_formulario.currentState!.validate()) {
      AudioService.erro();
      context.aviso('Confira os campos marcados em vermelho', erro: true);
      return;
    }
    setState(() => _salvando = true);

    final antigo = widget.argumentos?.existente;
    final lancamento = LancamentoDiario(
      id: antigo?.id,
      data: _data,
      km: Fmt.paraDoubleOuZero(_km.text),
      valorBruto: Fmt.paraDoubleOuZero(_valorBruto.text),
      horas: Fmt.paraDoubleOuZero(_horas.text),
      corridas: Fmt.paraInt(_corridas.text) ?? 0,
      tipoCombustivel: _combustivel,
      kmPorLitro: Fmt.paraDoubleOuZero(_kmPorLitro.text),
      precoLitro: Fmt.paraDoubleOuZero(_precoLitro.text),
      tipoVeiculo: _tipoVeiculo,
      observacao: _observacao.text.trim(),
      // Campo antigo: mantido só para não perder o histórico de quem já
      // usava a leitura de print nas versões anteriores.
      veioDeOcr: antigo?.veioDeOcr ?? false,
      criadoEm: antigo?.criadoEm,
    );

    // A gravação nunca estoura erro: ela devolve o que aconteceu de fato.
    final r = await context.read<DadosController>().salvarLancamento(lancamento);
    if (!mounted) return;
    setState(() => _salvando = false);

    if (r.falhouDeVez) {
      AudioService.erro();
      context.aviso(
        'Este celular recusou guardar o lançamento. '
        'Veja Mais → Diagnóstico.',
        erro: true,
      );
      return;
    }

    AudioService.sucesso();
    context.aviso(
      r.soNaMemoria
          ? 'Lançado — mas o celular não gravou no disco. '
              'Veja Mais → Diagnóstico antes de fechar o app.'
          : (_editando ? 'Lançamento atualizado!' : 'Dia lançado com sucesso!'),
      erro: r.soNaMemoria,
    );
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;
    final p = _previa;

    return Scaffold(
      appBar: AppBar(
        title: Text(_editando ? 'Editar lançamento' : 'Lançar o dia'),
        actions: <Widget>[
          if (_editando)
            IconButton(
              tooltip: 'Apagar',
              icon: Icon(Icons.delete_outline_rounded, color: tema.erro),
              onPressed: _confirmarApagar,
            ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: Form(
          key: _formulario,
          // Recalcula a prévia a cada mudança em qualquer campo.
          onChanged: () => setState(() {}),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 40),
            children: <Widget>[
              CampoData(
                data: _data,
                tema: tema,
                aoMudar: (d) => setState(() => _data = d),
              ),
              const SizedBox(height: 22),

              // ---------------- O QUE ACONTECEU ----------------
              const TituloSecao(
                texto: 'O que aconteceu no dia',
                icone: Icons.edit_note_rounded,
              ),
              CampoFarol.dinheiro(
                controlador: _valorBruto,
                rotulo: 'Quanto recebeu (bruto)',
                validador: (v) => Validadores.valorPositivo(
                  v,
                  campo: 'O valor recebido',
                ),
                ajuda: 'O valor cheio que os apps mostram, antes dos custos',
              ),
              const SizedBox(height: 14),
              Row(
                children: <Widget>[
                  Expanded(
                    child: CampoFarol.decimal(
                      controlador: _km,
                      rotulo: 'KM rodados',
                      icone: Icons.route_rounded,
                      sufixo: 'km',
                      // Opcional: dá para lançar só o valor recebido e
                      // completar o resto depois. O que não for informado
                      // entra como zero e não atrapalha nenhuma conta.
                      validador: (v) =>
                          Validadores.km(v, obrigatorioCampo: false),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CampoFarol.decimal(
                      controlador: _horas,
                      rotulo: 'Horas',
                      icone: Icons.schedule_rounded,
                      sufixo: 'h',
                      validador: (v) =>
                          Validadores.horas(v, obrigatorioCampo: false),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              CampoFarol.inteiro(
                controlador: _corridas,
                rotulo: 'Quantas corridas fez',
                icone: Icons.local_taxi_rounded,
                validador: (v) =>
                    Validadores.corridas(v, obrigatorioCampo: false),
                ajuda: 'KM, horas e corridas podem ficar em branco — '
                    'só o valor recebido é obrigatório',
              ),
              const SizedBox(height: 26),

              // ---------------- O VEÍCULO ----------------
              const TituloSecao(
                texto: 'O veículo',
                icone: Icons.two_wheeler_rounded,
              ),
              SeletorOpcoes(
                rotulo: 'Tipo de veículo',
                opcoes: AppConstants.tiposVeiculo,
                selecionada: _tipoVeiculo,
                tema: tema,
                aoSelecionar: (v) => setState(() => _tipoVeiculo = v),
              ),
              const SizedBox(height: 16),

              // ---------------- ENERGIA / COMBUSTÍVEL ----------------
              // O TÍTULO, OS RÓTULOS E AS UNIDADES MUDAM SOZINHOS conforme
              // o tipo escolhido: quem roda a gasolina vê "litro" e "km/L";
              // quem roda a GNV vê "m³" e "km/m³"; quem tem carro elétrico
              // vê "kWh" e "km/kWh". A CONTA É EXATAMENTE A MESMA nos três
              // casos (rodado ÷ rendimento × preço), então nenhuma fórmula
              // do CalculationsService precisou mudar — só a etiqueta.
              TituloSecao(
                texto: AppConstants.tituloEnergiaDe(_combustivel),
                icone: AppConstants.eletrico(_combustivel)
                    ? Icons.bolt_rounded
                    : Icons.local_gas_station_rounded,
              ),
              SeletorOpcoes(
                rotulo: 'Tipo',
                opcoes: AppConstants.tiposCombustivel,
                selecionada: _combustivel,
                tema: tema,
                aoSelecionar: (v) => setState(() => _combustivel = v),
              ),
              const SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Expanded(
                    child: CampoFarol.decimal(
                      controlador: _kmPorLitro,
                      rotulo: 'Consumo',
                      icone: Icons.speed_rounded,
                      sufixo: AppConstants.rendimentoDe(_combustivel),
                      validador: Validadores.kmPorLitro,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CampoFarol.dinheiro(
                      controlador: _precoLitro,
                      rotulo: AppConstants.precoDe(_combustivel),
                      icone: AppConstants.eletrico(_combustivel)
                          ? Icons.bolt_rounded
                          : Icons.local_gas_station_rounded,
                      validador: (v) => Validadores.valorPositivo(
                        v,
                        campo: AppConstants.precoDe(_combustivel),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 26),

              // ---------------- PRÉVIA DOS CÁLCULOS ----------------
              const TituloSecao(
                texto: 'Como fica o seu dia',
                icone: Icons.calculate_rounded,
              ),
              _PreviaCalculos(
                tema: tema,
                previa: p,
                unidade: AppConstants.unidadeDe(_combustivel),
              ),
              const SizedBox(height: 22),

              CampoFarol(
                controlador: _observacao,
                rotulo: 'Anotação (opcional)',
                dica: 'Ex.: dia de chuva, muito trânsito',
                icone: Icons.sticky_note_2_rounded,
                linhas: 2,
              ),
              const SizedBox(height: 30),

              BotaoGrande(
                texto: _salvando
                    ? 'Salvando...'
                    : (_editando ? 'Salvar alterações' : 'Salvar lançamento'),
                icone: Icons.check_circle_rounded,
                tema: tema,
                habilitado: !_salvando,
                aoTocar: _salvando ? () {} : _salvar,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmarApagar() async {
    final tema = context.read<AppController>().tema;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar este lançamento?'),
        content: const Text('Esta ação não pode ser desfeita.'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: tema.erro),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Apagar'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    await context
        .read<DadosController>()
        .apagarLancamento(widget.argumentos!.existente!.id);
    if (!mounted) return;
    context.aviso('Lançamento apagado');
    Navigator.of(context).pop(true);
  }
}

// =======================================================================
// PRÉVIA DOS CÁLCULOS (ao vivo)
// =======================================================================
class _PreviaCalculos extends StatelessWidget {
  final TemaFarol tema;
  final ({
    double litros,
    double combustivel,
    double lucro,
    double custoKm,
    double lucroKm,
    double porHora,
    double ticket,
    double margem,
  }) previa;

  /// A unidade do combustível escolhido: L, m³ ou kWh.
  final String unidade;

  const _PreviaCalculos({
    required this.tema,
    required this.previa,
    required this.unidade,
  });

  @override
  Widget build(BuildContext context) {
    final positivo = previa.lucro >= 0;

    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          // ---- Lucro em destaque ----
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: (positivo ? tema.sucesso : tema.erro)
                  .withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(tema.raioBorda * 0.7),
            ),
            child: Column(
              children: <Widget>[
                Text(
                  positivo ? 'SOBRA NO SEU BOLSO' : 'PREJUÍZO NO DIA',
                  style: context.textos.labelSmall?.copyWith(
                    color: positivo ? tema.sucesso : tema.erro,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  Fmt.moeda(previa.lucro),
                  style: context.textos.displaySmall?.copyWith(
                    color: positivo ? tema.sucesso : tema.erro,
                  ),
                ),
                if (previa.margem != 0) ...<Widget>[
                  const SizedBox(height: 4),
                  Text(
                    'margem de ${Fmt.percentual(previa.margem)}',
                    style: context.textos.bodySmall,
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          _Linha(
            'Combustível gasto',
            '${Fmt.quantidade(previa.litros, unidade)}'
            '  •  ${Fmt.moeda(previa.combustivel)}',
            tema.erro,
          ),
          const Divider(height: 20),
          _Linha('Custo por KM', Fmt.moeda(previa.custoKm), tema.alerta),
          const Divider(height: 20),
          _Linha('Lucro por KM', Fmt.moeda(previa.lucroKm), tema.sucesso),
          const Divider(height: 20),
          _Linha('Ganho por hora', Fmt.moeda(previa.porHora), tema.primaria),
          const Divider(height: 20),
          _Linha(
            'Valor médio da corrida',
            Fmt.moeda(previa.ticket),
            tema.secundaria,
          ),
        ],
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;
  const _Linha(this.rotulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
        ),
        const SizedBox(width: 11),
        Expanded(child: Text(rotulo, style: context.textos.bodyMedium)),
        Text(
          valor,
          style: context.textos.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
