/// -----------------------------------------------------------------------
/// MAIS — tudo o que não cabe nas outras duas abas
/// -----------------------------------------------------------------------
/// Organizado em grupos, para o motorista achar o que quer sem ler tudo:
///   • Lançar        — o que ele faz todo dia
///   • Consultar     — o que ele olha de vez em quando
///   • Ajustar       — o que ele mexe uma vez e esquece
///
/// No topo, um resumo curto do mês, para a tela não ser só uma lista.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../data/gravacao_segura.dart';
import '../../domain/entities/periodo_escolhido.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/entrada_suave.dart';
import '../widgets/painel_widgets.dart';

class MaisScreen extends StatelessWidget {
  const MaisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;

    final mes = dados.resumoDe(
      PeriodoEscolhido.hoje(escopo: EscopoPeriodo.mes),
    );

    return SafeArea(
      child: ListView(
        padding: EdgeInsets.fromLTRB(
          tema.compacto ? 12 : 16,
          14,
          tema.compacto ? 12 : 16,
          110,
        ),
        children: <Widget>[
          Text('Mais', style: context.textos.headlineMedium),
          const SizedBox(height: 3),
          Text(
            'Lançamentos, consultas e ajustes do aplicativo.',
            style: context.textos.bodySmall,
          ),
          SizedBox(height: tema.espaco),

          // ---------------- RESUMO CURTO DO MÊS ----------------
          _ResumoDoMes(tema: tema, mes: mes),
          SizedBox(height: tema.espaco + 4),

          // ---------------- LANÇAR ----------------
          TituloBloco(tema: tema, texto: 'Lançar'),
          _Grupo(
            tema: tema,
            itens: <_Item>[
              _Item(
                icone: Icons.add_circle_rounded,
                titulo: 'Lançar o dia',
                descricao: 'Valor recebido, KM, horas e corridas',
                rota: AppRoutes.lancamento,
                cor: tema.primaria,
              ),
              _Item(
                icone: Icons.local_gas_station_rounded,
                titulo: 'Abastecimentos',
                descricao: 'Quanto o litro saiu de verdade, com desconto',
                rota: AppRoutes.abastecimento,
                cor: tema.alerta,
              ),
              _Item(
                icone: Icons.receipt_long_rounded,
                titulo: 'Gastos',
                descricao: 'Lavagem, alimentação, limpeza e as outras',
                rota: AppRoutes.gastos,
                cor: tema.erro,
              ),
            ],
          ),
          SizedBox(height: tema.espaco + 4),

          // ---------------- CONSULTAR ----------------
          TituloBloco(tema: tema, texto: 'Consultar'),
          _Grupo(
            tema: tema,
            itens: <_Item>[
              _Item(
                icone: Icons.workspace_premium_rounded,
                titulo: 'Pontos e recompensas',
                descricao: 'Categorias e horários de ponto em dobro',
                rota: AppRoutes.pontos,
                cor: tema.alerta,
              ),
              _Item(
                icone: Icons.ios_share_rounded,
                titulo: 'Exportar Excel e PDF',
                descricao: 'Sua cópia de segurança para guardar ou mandar',
                rota: AppRoutes.exportar,
                cor: tema.sucesso,
              ),
            ],
          ),
          SizedBox(height: tema.espaco + 4),

          // ---------------- AJUSTAR ----------------
          TituloBloco(tema: tema, texto: 'Ajustar'),
          _Grupo(
            tema: tema,
            itens: <_Item>[
              _Item(
                icone: Icons.palette_rounded,
                titulo: 'Aparência',
                descricao: 'Cor, tamanho da letra, fonte e modo compacto',
                rota: AppRoutes.aparencia,
                cor: tema.primaria,
              ),
              _Item(
                icone: Icons.settings_rounded,
                titulo: 'Configurações',
                descricao: 'Perfil, metas, custos fixos e padrões do carro',
                rota: AppRoutes.configuracoes,
                cor: tema.textoSuave,
              ),
              _Item(
                icone: Icons.health_and_safety_rounded,
                titulo: 'Diagnóstico',
                descricao: DiarioDeErros.temErro
                    ? '${DiarioDeErros.falhas} falha(s) de gravação — veja aqui'
                    : 'Confere se está tudo sendo gravado no celular',
                rota: AppRoutes.diagnostico,
                cor: DiarioDeErros.temErro ? tema.erro : tema.secundaria,
                alerta: DiarioDeErros.temErro,
              ),
            ],
          ),
          SizedBox(height: tema.espaco + 6),

          // ---------------- RODAPÉ ----------------
          Center(
            child: Column(
              children: <Widget>[
                Icon(Icons.lock_rounded, size: 15, color: tema.textoSuave),
                const SizedBox(height: 6),
                Text(
                  'Farol · 100% offline\n'
                  'Seus dados nunca saem deste celular',
                  textAlign: TextAlign.center,
                  style: context.textos.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
class _ResumoDoMes extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo mes;

  const _ResumoDoMes({required this.tema, required this.mes});

  @override
  Widget build(BuildContext context) {
    return Caixa(
      tema: tema,
      child: Row(
        children: <Widget>[
          Expanded(
            child: _Mini(
              tema: tema,
              rotulo: 'Lucro do mês',
              valor: Fmt.moeda(mes.lucroLiquido),
              cor: mes.lucroLiquido >= 0 ? tema.sucesso : tema.erro,
            ),
          ),
          Container(width: 1, height: 34, color: tema.divisor),
          Expanded(
            child: _Mini(
              tema: tema,
              rotulo: 'Corridas',
              valor: Fmt.inteiro(mes.corridas),
              cor: tema.texto,
            ),
          ),
          Container(width: 1, height: 34, color: tema.divisor),
          Expanded(
            child: _Mini(
              tema: tema,
              rotulo: 'Dias',
              valor: '${mes.diasTrabalhados}',
              cor: tema.texto,
            ),
          ),
        ],
      ),
    );
  }
}

class _Mini extends StatelessWidget {
  final TemaFarol tema;
  final String rotulo;
  final String valor;
  final Color cor;

  const _Mini({
    required this.tema,
    required this.rotulo,
    required this.valor,
    required this.cor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(valor, style: tema.numero(tamanho: 17, cor: cor)),
        ),
        const SizedBox(height: 3),
        Text(
          rotulo.toUpperCase(),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: tema.textoSuave,
            fontSize: 9.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }
}

// =======================================================================
class _Item {
  final IconData icone;
  final String titulo;
  final String descricao;
  final String rota;
  final Color cor;
  final bool alerta;

  const _Item({
    required this.icone,
    required this.titulo,
    required this.descricao,
    required this.rota,
    required this.cor,
    this.alerta = false,
  });
}

class _Grupo extends StatelessWidget {
  final TemaFarol tema;
  final List<_Item> itens;

  const _Grupo({required this.tema, required this.itens});

  @override
  Widget build(BuildContext context) {
    final animar = context.watch<AppController>().animacoesAtivas;

    return EntradaSuave(
      animar: animar,
      child: Caixa(
        tema: tema,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Column(
          children: <Widget>[
            for (var i = 0; i < itens.length; i++) ...<Widget>[
              if (i > 0)
                Divider(height: 1, indent: 58, color: tema.divisor),
              _Linha(tema: tema, item: itens[i]),
            ],
          ],
        ),
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final TemaFarol tema;
  final _Item item;

  const _Linha({required this.tema, required this.item});

  @override
  Widget build(BuildContext context) {
    return ToqueQueAfunda(
      escala: 0.985,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            AudioService.clique();
            Navigator.of(context).pushNamed(item.rota);
          },
          borderRadius: BorderRadius.circular(10),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
            child: Row(
              children: <Widget>[
                Container(
                  width: 38,
                  height: 38,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: item.cor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Icon(item.icone, color: item.cor, size: 20),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(item.titulo, style: context.textos.titleMedium),
                      const SizedBox(height: 2),
                      Text(
                        item.descricao,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: context.textos.bodySmall?.copyWith(
                          color: item.alerta ? item.cor : null,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.chevron_right_rounded,
                  color: tema.textoSuave,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
