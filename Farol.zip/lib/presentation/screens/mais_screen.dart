/// -----------------------------------------------------------------------
/// ABA "MAIS"
/// -----------------------------------------------------------------------
/// Reúne o que não cabe nas outras abas, com blocos grandes e fáceis
/// de acertar com o dedo.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/logo_farol.dart';

class MaisScreen extends StatelessWidget {
  const MaisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final total = dados.resumo(FiltroPeriodo.total);

    final itens = <_Opcao>[
      _Opcao(
        icone: Icons.photo_camera_rounded,
        titulo: 'Importar print',
        descricao: 'O app lê o print do Uber ou da 99 sozinho',
        rota: AppRoutes.importarPrint,
        cor: tema.secundaria,
      ),
      _Opcao(
        icone: Icons.local_gas_station_rounded,
        titulo: 'Abastecimentos',
        descricao: 'Registre e veja quanto o litro saiu de verdade',
        rota: AppRoutes.abastecimento,
        cor: tema.alerta,
      ),
      _Opcao(
        icone: Icons.receipt_long_rounded,
        titulo: 'Gastos',
        descricao: 'Manutenção, pedágio, seguro e mais 9 categorias',
        rota: AppRoutes.gastos,
        cor: tema.erro,
      ),
      _Opcao(
        icone: Icons.calculate_rounded,
        titulo: 'Vale a pena?',
        descricao: 'Descubra na hora se a corrida compensa',
        rota: AppRoutes.valeAPena,
        cor: tema.sucesso,
      ),
      _Opcao(
        icone: Icons.trending_up_rounded,
        titulo: 'Simulador de patrimônio',
        descricao: 'Veja no que dá guardar um pouco todo mês',
        rota: AppRoutes.simulador,
        cor: tema.primaria,
      ),
      _Opcao(
        icone: Icons.history_rounded,
        titulo: 'Histórico de jornadas',
        descricao: 'Todo o tempo que você já trabalhou',
        rota: AppRoutes.historicoJornadas,
        cor: tema.secundaria,
      ),
      _Opcao(
        icone: Icons.ios_share_rounded,
        titulo: 'Exportar Excel e PDF',
        descricao: 'Relatório completo para guardar ou mandar',
        rota: AppRoutes.exportar,
        cor: tema.sucesso,
      ),
      _Opcao(
        icone: Icons.workspace_premium_rounded,
        titulo: 'Pontos e recompensas',
        descricao: 'Categorias, horários de pico e o que conta ponto',
        rota: AppRoutes.pontos,
        cor: tema.alerta,
      ),
      _Opcao(
        icone: Icons.palette_rounded,
        titulo: 'Aparência',
        descricao: 'Claro, escuro, cor do aplicativo e modo de exibição',
        rota: AppRoutes.aparencia,
        cor: tema.primaria,
      ),
      _Opcao(
        icone: Icons.health_and_safety_rounded,
        titulo: 'Diagnóstico',
        descricao: 'Confere se está tudo sendo gravado no celular',
        rota: AppRoutes.diagnostico,
        cor: tema.secundaria,
      ),
      _Opcao(
        icone: Icons.settings_rounded,
        titulo: 'Configurações',
        descricao: 'Perfil, metas, custos, sons e animações',
        rota: AppRoutes.configuracoes,
        cor: tema.textoSuave,
      ),
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
        children: <Widget>[
          // ---------------- Cartão do motorista ----------------
          CartaoFarol(
            tema: tema,
            comGradiente: true,
            child: Row(
              children: <Widget>[
                LogoFarol(tema: tema, tamanho: 52, comFundo: false),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        app.motorista?.nome ?? 'Motorista',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        app.motorista?.descricaoCarro ?? '',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.85),
                          fontSize: 12,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // ---------------- Números de sempre ----------------
          if (!total.vazio)
            CartaoFarol(
              tema: tema,
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: _Total(
                      rotulo: 'Lucro total',
                      valor: Fmt.moeda(total.lucroLiquido),
                      cor: tema.sucesso,
                    ),
                  ),
                  Container(width: 1, height: 34, color: tema.superficieAlta),
                  Expanded(
                    child: _Total(
                      rotulo: 'Corridas',
                      valor: Fmt.inteiro(total.corridas),
                      cor: tema.primaria,
                    ),
                  ),
                  Container(width: 1, height: 34, color: tema.superficieAlta),
                  Expanded(
                    child: _Total(
                      rotulo: 'KM',
                      valor: Fmt.numero(total.km, casas: 0),
                      cor: tema.secundaria,
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 20),

          for (final o in itens)
            Padding(
              padding: const EdgeInsets.only(bottom: 11),
              child: CartaoFarol(
                tema: tema,
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
                aoTocar: () {
                  AudioService.clique();
                  Navigator.of(context).pushNamed(o.rota);
                },
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: o.cor.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: Icon(o.icone, color: o.cor, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(o.titulo, style: context.textos.titleMedium),
                          const SizedBox(height: 2),
                          Text(
                            o.descricao,
                            style: context.textos.bodySmall,
                            maxLines: 2,
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.chevron_right_rounded,
                      color: tema.textoSuave,
                      size: 21,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _Opcao {
  final IconData icone;
  final String titulo;
  final String descricao;
  final String rota;
  final Color cor;

  const _Opcao({
    required this.icone,
    required this.titulo,
    required this.descricao,
    required this.rota,
    required this.cor,
  });
}

class _Total extends StatelessWidget {
  final String rotulo;
  final String valor;
  final Color cor;

  const _Total({
    required this.rotulo,
    required this.valor,
    required this.cor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          rotulo,
          style: context.textos.labelSmall,
          maxLines: 1,
        ),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            valor,
            style: context.textos.titleLarge?.copyWith(
              color: cor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}
