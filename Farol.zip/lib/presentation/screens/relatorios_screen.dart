/// -----------------------------------------------------------------------
/// RELATÓRIOS
/// -----------------------------------------------------------------------
/// IMPORTANTE: aqui NÃO existe planilha. Os dados aparecem em painéis,
/// indicadores e gráficos interativos. A planilha só existe na hora de
/// EXPORTAR para Excel (tela de Exportação).
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../domain/entities/resumo_periodo.dart';
import '../../services/audio_service.dart';
import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';
import '../widgets/estado_vazio.dart';
import '../widgets/graficos_farol.dart';
import '../widgets/kpi_card.dart';

class RelatoriosScreen extends StatefulWidget {
  const RelatoriosScreen({super.key});

  @override
  State<RelatoriosScreen> createState() => _RelatoriosScreenState();
}

class _RelatoriosScreenState extends State<RelatoriosScreen> {
  FiltroPeriodo _filtro = FiltroPeriodo.mes;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final animar = app.animacoesAtivas;

    final resumo = dados.resumo(_filtro);
    final anterior = dados.resumoAnterior(_filtro);

    return SafeArea(
      child: Column(
        children: <Widget>[
          // ---------------- Cabeçalho ----------------
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 12, 8),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Relatórios',
                        style: context.textos.headlineMedium,
                      ),
                      const SizedBox(height: 2),
                      Text(resumo.rotulo, style: context.textos.bodySmall),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  tooltip: 'Exportar Excel e PDF',
                  onPressed: () {
                    AudioService.clique();
                    Navigator.of(context).pushNamed(AppRoutes.exportar);
                  },
                  icon: const Icon(Icons.ios_share_rounded),
                ),
              ],
            ),
          ),

          // ---------------- Filtro de período ----------------
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: <Widget>[
                for (final f in FiltroPeriodo.values)
                  Padding(
                    padding: const EdgeInsets.only(right: 8, top: 4, bottom: 4),
                    child: GestureDetector(
                      onTap: () {
                        AudioService.toqueLeve();
                        setState(() => _filtro = f);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          gradient:
                              _filtro == f ? tema.gradienteLinear : null,
                          color: _filtro == f ? null : tema.superficieAlta,
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          f.rotulo,
                          style: TextStyle(
                            color: _filtro == f
                                ? (tema.primaria.computeLuminance() > 0.5
                                    ? Colors.black
                                    : Colors.white)
                                : tema.texto,
                            fontSize: 13.5,
                            fontWeight: _filtro == f
                                ? FontWeight.w700
                                : FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // ---------------- Conteúdo ----------------
          Expanded(
            child: resumo.vazio
                ? EstadoVazio(
                    icone: Icons.insert_chart_outlined_rounded,
                    titulo: 'Nada lançado neste período',
                    mensagem: 'Assim que você lançar um dia de trabalho, '
                        'os indicadores e gráficos aparecem aqui.',
                    tema: tema,
                    textoBotao: 'Lançar o dia',
                    aoTocarBotao: () {
                      AudioService.clique();
                      Navigator.of(context).pushNamed(AppRoutes.lancamento);
                    },
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
                    children: <Widget>[
                      // ---- Resultado principal ----
                      _CartaoResultado(
                        tema: tema,
                        resumo: resumo,
                        animar: animar,
                      ),
                      const SizedBox(height: 18),

                      // ---- Comparação com o período anterior ----
                      if (_filtro != FiltroPeriodo.total &&
                          !anterior.vazio) ...<Widget>[
                        _CartaoComparacao(
                          tema: tema,
                          atual: resumo,
                          anterior: anterior,
                          filtro: _filtro,
                        ),
                        const SizedBox(height: 18),
                      ],

                      // ---- Números do período ----
                      const TituloSecao(
                        texto: 'Números do período',
                        icone: Icons.numbers_rounded,
                      ),
                      _GradeNumeros(tema: tema, resumo: resumo),
                      const SizedBox(height: 22),

                      // ---- Médias e desempenho ----
                      const TituloSecao(
                        texto: 'Seu desempenho',
                        icone: Icons.speed_rounded,
                      ),
                      _CartaoDesempenho(tema: tema, resumo: resumo),
                      const SizedBox(height: 22),

                      // ---- Gráfico de barras por dia ----
                      if (resumo.lucroPorDia.length > 1) ...<Widget>[
                        const TituloSecao(
                          texto: 'Lucro por dia',
                          icone: Icons.bar_chart_rounded,
                        ),
                        CartaoFarol(
                          tema: tema,
                          child: Column(
                            children: <Widget>[
                              Text(
                                'Toque numa barra para ver o valor exato',
                                style: context.textos.bodySmall,
                              ),
                              const SizedBox(height: 14),
                              GraficoBarrasDias(
                                dados: <({DateTime dia, double lucro})>[
                                  for (final e in resumo.lucroPorDia.entries)
                                    (dia: e.key, lucro: e.value),
                                ],
                                tema: tema,
                                animar: animar,
                                altura: 200,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 22),

                        // ---- Gráfico de linha ----
                        const TituloSecao(
                          texto: 'Evolução',
                          icone: Icons.show_chart_rounded,
                        ),
                        CartaoFarol(
                          tema: tema,
                          child: GraficoLinhaEvolucao(
                            dados: <({DateTime dia, double lucro})>[
                              for (final e in resumo.lucroPorDia.entries)
                                (dia: e.key, lucro: e.value),
                            ],
                            tema: tema,
                            animar: animar,
                          ),
                        ),
                        const SizedBox(height: 22),
                      ],

                      // ---- Pizza de gastos ----
                      if (resumo.gastosPorCategoria.isNotEmpty) ...<Widget>[
                        const TituloSecao(
                          texto: 'Para onde foi o dinheiro',
                          icone: Icons.pie_chart_rounded,
                        ),
                        CartaoFarol(
                          tema: tema,
                          child: Column(
                            children: <Widget>[
                              Text(
                                'Toque numa fatia para ver o valor',
                                style: context.textos.bodySmall,
                              ),
                              const SizedBox(height: 10),
                              GraficoPizzaGastos(
                                gastosPorCategoria: resumo.gastosPorCategoria,
                                tema: tema,
                                animar: animar,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// CARTÃO DE RESULTADO
// =======================================================================
class _CartaoResultado extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;
  final bool animar;

  const _CartaoResultado({
    required this.tema,
    required this.resumo,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final positivo = resumo.lucroLiquido >= 0;

    return CartaoFarol(
      tema: tema,
      comGradiente: true,
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            positivo ? 'LUCRO DO PERÍODO' : 'PREJUÍZO DO PERÍODO',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.88),
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 10),
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: resumo.lucroLiquido),
            duration:
                animar ? const Duration(milliseconds: 850) : Duration.zero,
            curve: Curves.easeOutCubic,
            builder: (context, v, _) => FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                Fmt.moeda(v),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 38,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -1.2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Composição: bruto − combustível − gastos
          _LinhaComposicao(
            'Recebido bruto',
            Fmt.moeda(resumo.valorBruto),
            positivo: true,
          ),
          _LinhaComposicao(
            'Combustível',
            '− ${Fmt.moeda(resumo.custoCombustivel)}',
          ),
          _LinhaComposicao(
            'Outros gastos',
            '− ${Fmt.moeda(resumo.outrosGastos)}',
          ),
          if (resumo.custosFixosRateados > 0) ...<Widget>[
            _LinhaComposicao(
              'Custos fixos do período',
              '− ${Fmt.moeda(resumo.custosFixosRateados)}',
            ),
            const Divider(color: Colors.white24, height: 18),
            _LinhaComposicao(
              'Sobra final',
              Fmt.moeda(resumo.lucroFinal),
              positivo: true,
              destaque: true,
            ),
          ],
        ],
      ),
    );
  }
}

class _LinhaComposicao extends StatelessWidget {
  final String rotulo;
  final String valor;
  final bool positivo;
  final bool destaque;

  const _LinhaComposicao(
    this.rotulo,
    this.valor, {
    this.positivo = false,
    this.destaque = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(
            rotulo,
            style: TextStyle(
              color: Colors.white.withValues(alpha: destaque ? 1 : 0.82),
              fontSize: destaque ? 14 : 13,
              fontWeight: destaque ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
          Text(
            valor,
            style: TextStyle(
              color: Colors.white.withValues(alpha: destaque ? 1 : 0.95),
              fontSize: destaque ? 15 : 13.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// COMPARAÇÃO COM O PERÍODO ANTERIOR
// =======================================================================
class _CartaoComparacao extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo atual;
  final ResumoPeriodo anterior;
  final FiltroPeriodo filtro;

  const _CartaoComparacao({
    required this.tema,
    required this.atual,
    required this.anterior,
    required this.filtro,
  });

  @override
  Widget build(BuildContext context) {
    final variacao = CalculationsService.variacaoPercentual(
      atual: atual.lucroLiquido,
      anterior: anterior.lucroLiquido,
    );
    final subiu = variacao >= 0;
    final cor = subiu ? tema.sucesso : tema.erro;

    final String nomeAnterior;
    switch (filtro) {
      case FiltroPeriodo.dia:
        nomeAnterior = 'ontem';
      case FiltroPeriodo.semana:
        nomeAnterior = 'a semana passada';
      case FiltroPeriodo.mes:
        nomeAnterior = 'o mês passado';
      case FiltroPeriodo.ano:
        nomeAnterior = 'o ano passado';
      case FiltroPeriodo.total:
        nomeAnterior = 'o período anterior';
    }

    return CartaoFarol(
      tema: tema,
      corBorda: cor,
      child: Row(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: cor.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              subiu
                  ? Icons.trending_up_rounded
                  : Icons.trending_down_rounded,
              color: cor,
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '${subiu ? "Subiu" : "Caiu"} '
                  '${Fmt.percentual(variacao.abs())}',
                  style: context.textos.titleLarge?.copyWith(color: cor),
                ),
                const SizedBox(height: 2),
                Text(
                  'comparado com $nomeAnterior '
                  '(${Fmt.moeda(anterior.lucroLiquido)})',
                  style: context.textos.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// GRADE DE NÚMEROS
// =======================================================================
class _GradeNumeros extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;

  const _GradeNumeros({required this.tema, required this.resumo});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.5,
      children: <Widget>[
        KpiCard(
          rotulo: 'RECEBIDO BRUTO',
          valor: Fmt.moeda(resumo.valorBruto),
          icone: Icons.account_balance_wallet_rounded,
          cor: tema.primaria,
          tema: tema,
        ),
        KpiCard(
          rotulo: 'COMBUSTÍVEL',
          valor: Fmt.moeda(resumo.custoCombustivel),
          icone: Icons.local_gas_station_rounded,
          cor: tema.erro,
          tema: tema,
          complemento: Fmt.litros(resumo.litros),
        ),
        KpiCard(
          rotulo: 'OUTROS GASTOS',
          valor: Fmt.moeda(resumo.outrosGastos),
          icone: Icons.receipt_long_rounded,
          cor: tema.alerta,
          tema: tema,
        ),
        KpiCard(
          rotulo: 'KM RODADOS',
          valor: Fmt.km(resumo.km),
          icone: Icons.route_rounded,
          cor: tema.secundaria,
          tema: tema,
        ),
        KpiCard(
          rotulo: 'HORAS TRABALHADAS',
          valor: Fmt.horasTexto(resumo.horas),
          icone: Icons.schedule_rounded,
          cor: tema.primaria,
          tema: tema,
          complemento: '${resumo.diasTrabalhados} dias trabalhados',
        ),
        KpiCard(
          rotulo: 'CORRIDAS',
          valor: Fmt.inteiro(resumo.corridas),
          icone: Icons.local_taxi_rounded,
          cor: tema.sucesso,
          tema: tema,
        ),
      ],
    );
  }
}

// =======================================================================
// DESEMPENHO (médias)
// =======================================================================
class _CartaoDesempenho extends StatelessWidget {
  final TemaFarol tema;
  final ResumoPeriodo resumo;

  const _CartaoDesempenho({required this.tema, required this.resumo});

  @override
  Widget build(BuildContext context) {
    final itens = <(String, String, String, Color)>[
      (
        'Ganho por hora',
        Fmt.moeda(resumo.ganhoPorHora),
        'quanto sobra por hora trabalhada',
        tema.sucesso
      ),
      (
        'Custo por KM',
        Fmt.moeda(resumo.custoPorKm),
        'quanto custa cada quilômetro',
        tema.erro
      ),
      (
        'Lucro por KM',
        Fmt.moeda(resumo.lucroPorKm),
        'quanto sobra em cada quilômetro',
        tema.primaria
      ),
      (
        'Valor médio da corrida',
        Fmt.moeda(resumo.ticketMedio),
        'ticket médio',
        tema.secundaria
      ),
      (
        'Margem de lucro',
        Fmt.percentual(resumo.margemLucro),
        'do bruto que virou lucro',
        tema.alerta
      ),
      (
        'Lucro médio por dia',
        Fmt.moeda(resumo.lucroMedioDia),
        'nos dias em que trabalhou',
        tema.sucesso
      ),
    ];

    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < itens.length; i++) ...<Widget>[
            if (i > 0) const Divider(height: 22),
            Row(
              children: <Widget>[
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: itens[i].$4,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        itens[i].$1,
                        style: context.textos.bodyMedium,
                      ),
                      Text(
                        itens[i].$3,
                        style: context.textos.bodySmall,
                      ),
                    ],
                  ),
                ),
                Text(
                  itens[i].$2,
                  style: context.textos.titleLarge?.copyWith(
                    color: itens[i].$4,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
