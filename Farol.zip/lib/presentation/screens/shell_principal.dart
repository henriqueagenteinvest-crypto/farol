/// -----------------------------------------------------------------------
/// ESTRUTURA PRINCIPAL — abas de baixo
/// -----------------------------------------------------------------------
/// Quatro abas grandes e um botão central de atalho. Poucas opções, ícones
/// reconhecíveis e texto embaixo: o motorista não precisa adivinhar nada.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../core/navegacao_app.dart';
import '../../services/audio_service.dart';
import '../controllers/app_controller.dart';
import 'home_screen.dart';
import 'jornada_screen.dart';
import 'mais_screen.dart';
import 'relatorios_screen.dart';

class ShellPrincipal extends StatefulWidget {
  const ShellPrincipal({super.key});

  @override
  State<ShellPrincipal> createState() => _ShellPrincipalState();
}

class _ShellPrincipalState extends State<ShellPrincipal> {
  int _aba = 0;

  @override
  void initState() {
    super.initState();
    // Outras telas podem pedir a troca de aba pelo NavegacaoApp.
    NavegacaoApp.abaAtual.addListener(_aoPedirTrocaDeAba);
  }

  @override
  void dispose() {
    NavegacaoApp.abaAtual.removeListener(_aoPedirTrocaDeAba);
    super.dispose();
  }

  void _aoPedirTrocaDeAba() {
    final pedida = NavegacaoApp.abaAtual.value;
    if (pedida != _aba && mounted) setState(() => _aba = pedida);
  }

  /// As telas ficam guardadas para não recarregar ao trocar de aba
  /// (troca instantânea, sem piscar).
  final List<Widget> _telas = const <Widget>[
    HomeScreen(),
    JornadaScreen(),
    RelatoriosScreen(),
    MaisScreen(),
  ];

  void _trocarAba(int i) {
    if (i == _aba) return;
    AudioService.toqueLeve();
    setState(() => _aba = i);
    NavegacaoApp.abaAtual.value = i;
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        // IndexedStack mantém o estado de cada aba (rolagem, filtros).
        child: IndexedStack(index: _aba, children: _telas),
      ),

      // ---- Botão central: lançar o dia rapidamente ----
      floatingActionButton: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: tema.brilhoDe(tema.primaria),
        ),
        child: FloatingActionButton.large(
          onPressed: () {
            AudioService.clique();
            Navigator.of(context).pushNamed(AppRoutes.lancamento);
          },
          backgroundColor: tema.primaria,
          foregroundColor: tema.primaria.computeLuminance() > 0.5
              ? Colors.black
              : Colors.white,
          elevation: 0,
          shape: const CircleBorder(),
          tooltip: 'Lançar o dia de trabalho',
          child: const Icon(Icons.add_rounded, size: 36),
        ),
      ),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.centerDocked,

      // ---- Barra de abas ----
      bottomNavigationBar: BottomAppBar(
        color: tema.superficie,
        elevation: 0,
        height: 68,
        padding: EdgeInsets.zero,
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            _ItemAba(
              icone: Icons.home_rounded,
              rotulo: 'Início',
              ativo: _aba == 0,
              aoTocar: () => _trocarAba(0),
            ),
            _ItemAba(
              icone: Icons.timer_rounded,
              rotulo: 'Jornada',
              ativo: _aba == 1,
              aoTocar: () => _trocarAba(1),
            ),
            const SizedBox(width: 62), // espaço do botão central
            _ItemAba(
              icone: Icons.insert_chart_rounded,
              rotulo: 'Relatórios',
              ativo: _aba == 2,
              aoTocar: () => _trocarAba(2),
            ),
            _ItemAba(
              icone: Icons.menu_rounded,
              rotulo: 'Mais',
              ativo: _aba == 3,
              aoTocar: () => _trocarAba(3),
            ),
          ],
        ),
      ),
    );
  }
}

class _ItemAba extends StatelessWidget {
  final IconData icone;
  final String rotulo;
  final bool ativo;
  final VoidCallback aoTocar;

  const _ItemAba({
    required this.icone,
    required this.rotulo,
    required this.ativo,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final tema = context.read<AppController>().tema;
    final cor = ativo ? tema.primaria : tema.textoSuave;

    return Expanded(
      child: InkWell(
        onTap: aoTocar,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              // O ícone dá um pulinho ao ser selecionado.
              AnimatedScale(
                scale: ativo ? 1.12 : 1.0,
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeOutBack,
                child: Icon(icone, color: cor, size: 25),
              ),
              const SizedBox(height: 3),
              Text(
                rotulo,
                style: TextStyle(
                  color: cor,
                  fontSize: 10.5,
                  fontWeight: ativo ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
