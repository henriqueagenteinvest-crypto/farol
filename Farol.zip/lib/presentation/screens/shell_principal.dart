/// -----------------------------------------------------------------------
/// ESTRUTURA PRINCIPAL — a barra de baixo
/// -----------------------------------------------------------------------
/// Três abas grandes e um botão central de lançamento:
///
///     [ Semana ]  [ Painel ]  ( + )  [ Mais ]
///
/// ANIMAÇÃO DA TROCA DE ABA (pedido do motorista):
///   1. um indicador em forma de pílula DESLIZA por baixo do ícone da aba
///      escolhida — ele não pula, ele anda até lá (curva easeOutCubic);
///   2. o ícone da aba escolhida dá um pequeno salto e cresce um pouco;
///   3. o conteúdo da tela entra com um fade + deslize curto para cima.
///
/// Tudo isso passa por `app.duracao(...)`: com "Animações" desligado nas
/// configurações, a duração vira zero e a troca fica instantânea — do
/// jeito que celular fraco precisa.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../core/navegacao_app.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../controllers/app_controller.dart';
import 'mais_screen.dart';
import 'painel_screen.dart';
import 'semana_screen.dart';

class ShellPrincipal extends StatefulWidget {
  const ShellPrincipal({super.key});

  @override
  State<ShellPrincipal> createState() => _ShellPrincipalState();
}

class _ShellPrincipalState extends State<ShellPrincipal> {
  int _aba = 0;

  /// De qual aba viemos — a animação de entrada usa isso para saber se o
  /// conteúdo entra da esquerda ou da direita.
  int _abaAnterior = 0;

  @override
  void initState() {
    super.initState();
    // Outras telas podem pedir a troca de aba pelo NavegacaoApp.
    NavegacaoApp.abaAtual.addListener(_aoPedirTrocaDeAba);
  }

  @override
  void dispose() {
    NavegacaoApp.abaAtual.removeListener(_aoPedirTrocaDeAba);
    super.dispose();
  }

  void _aoPedirTrocaDeAba() {
    final pedida = NavegacaoApp.abaAtual.value;
    if (pedida != _aba && mounted) {
      setState(() {
        _abaAnterior = _aba;
        _aba = pedida;
        _abertas.add(pedida);
      });
    }
  }

  /// As telas ficam guardadas para não recarregar ao trocar de aba
  /// (troca instantânea, sem piscar).
  static const List<Widget> _telas = <Widget>[
    SemanaScreen(),
    PainelScreen(),
    MaisScreen(),
  ];

  /// Quais abas o motorista já abriu.
  ///
  /// POR QUE ISTO IMPORTA: o IndexedStack constrói TODAS as telas de
  /// uma vez. Na abertura, isso significava montar o Painel inteiro e o
  /// Mais antes mesmo de o motorista tocar neles — e a primeira tela
  /// demorava a aparecer por causa disso. Agora cada aba só nasce quando
  /// é aberta pela primeira vez, e depois fica pronta.
  final Set<int> _abertas = <int>{0};

  void _trocarAba(int i) {
    if (i == _aba) return;
    AudioService.toqueLeve();
    setState(() {
      _abaAnterior = _aba;
      _aba = i;
      _abertas.add(i);
    });
    NavegacaoApp.abaAtual.value = i;
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;

    return Scaffold(
      backgroundColor: tema.fundo,
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        // IndexedStack mantém o estado de cada aba (rolagem, filtros).
        // O _EntradaDeAba por cima dá o fade/deslize da troca sem jogar
        // fora o estado da tela.
        child: _EntradaDeAba(
          aba: _aba,
          anterior: _abaAnterior,
          duracao: app.duracao(260),
          child: IndexedStack(
            index: _aba,
            children: <Widget>[
              for (var i = 0; i < _telas.length; i++)
                _abertas.contains(i) ? _telas[i] : const SizedBox.shrink(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _BarraDeAbas(
        tema: tema,
        aba: _aba,
        duracao: app.duracao(340),
        aoTrocar: _trocarAba,
        aoLancar: () {
          AudioService.clique();
          Navigator.of(context).pushNamed(AppRoutes.lancamento);
        },
      ),
    );
  }
}

// =======================================================================
// ENTRADA DA ABA — fade + deslize curto
// =======================================================================
/// Toda vez que a aba muda, este widget refaz a animação do zero.
/// O truque é a `ValueKey(aba)` no TweenAnimationBuilder: mudando a
/// chave, o Flutter recomeça a animação em 0 e anda até 1.
class _EntradaDeAba extends StatelessWidget {
  final int aba;
  final int anterior;
  final Duration duracao;
  final Widget child;

  const _EntradaDeAba({
    required this.aba,
    required this.anterior,
    required this.duracao,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    if (duracao == Duration.zero) return child;

    // Veio de uma aba à esquerda? O conteúdo entra vindo da direita.
    final sentido = aba >= anterior ? 1.0 : -1.0;

    return TweenAnimationBuilder<double>(
      key: ValueKey<int>(aba),
      tween: Tween<double>(begin: 0, end: 1),
      duration: duracao,
      curve: Curves.easeOutCubic,
      builder: (context, t, filho) {
        return Opacity(
          // Começa em 0.35 (e não em 0) para a tela não "sumir" na troca.
          opacity: 0.35 + 0.65 * t,
          child: Transform.translate(
            // 18 pixels de deslize: percebe-se o movimento sem enjoar.
            offset: Offset(18 * sentido * (1 - t), 0),
            child: filho,
          ),
        );
      },
      child: child,
    );
  }
}

// =======================================================================
// A BARRA DE BAIXO
// =======================================================================
class _BarraDeAbas extends StatelessWidget {
  final TemaFarol tema;
  final int aba;
  final Duration duracao;
  final ValueChanged<int> aoTrocar;
  final VoidCallback aoLancar;

  const _BarraDeAbas({
    required this.tema,
    required this.aba,
    required this.duracao,
    required this.aoTrocar,
    required this.aoLancar,
  });

  /// As abas, na ordem em que aparecem. O botão "+" fica entre a 2ª e a 3ª.
  static const List<({IconData icone, IconData iconeCheio, String rotulo})>
      _abas = <({IconData icone, IconData iconeCheio, String rotulo})>[
    (
      icone: Icons.calendar_view_week_outlined,
      iconeCheio: Icons.calendar_view_week_rounded,
      rotulo: 'Semana'
    ),
    (
      icone: Icons.insights_outlined,
      iconeCheio: Icons.insights_rounded,
      rotulo: 'Painel'
    ),
    (
      icone: Icons.grid_view_outlined,
      iconeCheio: Icons.grid_view_rounded,
      rotulo: 'Mais'
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: tema.superficie,
        border: Border(top: BorderSide(color: tema.divisor)),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: <Widget>[
              _Item(
                tema: tema,
                dados: _abas[0],
                ativo: aba == 0,
                duracao: duracao,
                aoTocar: () => aoTrocar(0),
              ),
              _Item(
                tema: tema,
                dados: _abas[1],
                ativo: aba == 1,
                duracao: duracao,
                aoTocar: () => aoTrocar(1),
              ),

              // ---- Botão de lançar: presente, mas sem exagero ----
              _BotaoLancar(tema: tema, duracao: duracao, aoTocar: aoLancar),

              _Item(
                tema: tema,
                dados: _abas[2],
                ativo: aba == 2,
                duracao: duracao,
                aoTocar: () => aoTrocar(2),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// UM ITEM DA BARRA
// =======================================================================
/// A animação de cada item tem três partes que acontecem juntas:
///   • a pílula colorida atrás do ícone cresce e ganha cor;
///   • o ícone sobe 3 pixels e fica 12% maior;
///   • a cor do ícone e do texto vai do cinza para a cor principal.
class _Item extends StatelessWidget {
  final TemaFarol tema;
  final ({IconData icone, IconData iconeCheio, String rotulo}) dados;
  final bool ativo;
  final Duration duracao;
  final VoidCallback aoTocar;

  const _Item({
    required this.tema,
    required this.dados,
    required this.ativo,
    required this.duracao,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Semantics(
        button: true,
        selected: ativo,
        label: dados.rotulo,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(14),
          child: TweenAnimationBuilder<double>(
            // 0 = aba apagada, 1 = aba escolhida. O Flutter anda entre os
            // dois sozinho, então o movimento é sempre suave nos dois
            // sentidos (a aba que sai desanima na mesma velocidade).
            tween: Tween<double>(begin: 0, end: ativo ? 1 : 0),
            duration: duracao,
            curve: Curves.easeOutCubic,
            builder: (context, t, _) {
              final cor = Color.lerp(tema.textoSuave, tema.primaria, t)!;
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  // A pílula que desliza/cresce por trás do ícone.
                  Container(
                    height: 28,
                    width: 34 + 20 * t,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: tema.primaria.withValues(alpha: 0.16 * t),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Transform.translate(
                      offset: Offset(0, -3 * t),
                      child: Transform.scale(
                        scale: 1 + 0.12 * t,
                        child: Icon(
                          t > 0.5 ? dados.iconeCheio : dados.icone,
                          color: cor,
                          size: 21,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    dados.rotulo,
                    style: TextStyle(
                      color: cor,
                      fontSize: 10.5,
                      height: 1.1,
                      letterSpacing: 0.1,
                      fontWeight:
                          t > 0.5 ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// O BOTÃO CENTRAL DE LANÇAR
// =======================================================================
/// Ao tocar, ele encolhe e volta — o "afunda e sobe" que dá a sensação
/// de botão físico. É o botão mais usado do aplicativo.
class _BotaoLancar extends StatefulWidget {
  final TemaFarol tema;
  final Duration duracao;
  final VoidCallback aoTocar;

  const _BotaoLancar({
    required this.tema,
    required this.duracao,
    required this.aoTocar,
  });

  @override
  State<_BotaoLancar> createState() => _BotaoLancarState();
}

class _BotaoLancarState extends State<_BotaoLancar> {
  bool _pressionado = false;

  @override
  Widget build(BuildContext context) {
    final tema = widget.tema;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Semantics(
        button: true,
        label: 'Lançar o dia de trabalho',
        child: GestureDetector(
          onTapDown: (_) => setState(() => _pressionado = true),
          onTapUp: (_) => setState(() => _pressionado = false),
          onTapCancel: () => setState(() => _pressionado = false),
          onTap: widget.aoTocar,
          child: AnimatedScale(
            scale: _pressionado ? 0.88 : 1,
            duration: widget.duracao == Duration.zero
                ? Duration.zero
                : const Duration(milliseconds: 110),
            curve: Curves.easeOut,
            child: Container(
              // 48x48: o mínimo recomendado para o dedo, e nada além
              // disso — antes ele tomava a tela inteira.
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                gradient: tema.gradienteLinear,
                borderRadius: BorderRadius.circular(16),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: tema.primaria.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(
                Icons.add_rounded,
                size: 27,
                color: tema.textoSobrePrimaria,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
