/// -----------------------------------------------------------------------
/// ESTRUTURA PRINCIPAL — a barra de baixo
/// -----------------------------------------------------------------------
/// Quatro abas grandes e um botão central de lançamento.
///
/// O botão do meio é o que mais se usa (lançar o dia), mas ele não pode
/// roubar a tela: por isso ficou num tamanho que se acerta com o dedo
/// sem ocupar meio aparelho.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../core/navegacao_app.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../controllers/app_controller.dart';
import 'home_screen.dart';
import 'jornada_screen.dart';
import 'mais_screen.dart';
import 'painel_screen.dart';

class ShellPrincipal extends StatefulWidget {
  const ShellPrincipal({super.key});

  @override
  State<ShellPrincipal> createState() => _ShellPrincipalState();
}

class _ShellPrincipalState extends State<ShellPrincipal> {
  int _aba = 0;

  @override
  void initState() {
    super.initState();
    // Outras telas podem pedir a troca de aba pelo NavegacaoApp.
    NavegacaoApp.abaAtual.addListener(_aoPedirTrocaDeAba);
  }

  @override
  void dispose() {
    NavegacaoApp.abaAtual.removeListener(_aoPedirTrocaDeAba);
    super.dispose();
  }

  void _aoPedirTrocaDeAba() {
    final pedida = NavegacaoApp.abaAtual.value;
    if (pedida != _aba && mounted) {
      setState(() {
        _aba = pedida;
        _abertas.add(pedida);
      });
    }
  }

  /// As telas ficam guardadas para não recarregar ao trocar de aba
  /// (troca instantânea, sem piscar).
  static const List<Widget> _telas = <Widget>[
    HomeScreen(),
    PainelScreen(),
    JornadaScreen(),
    MaisScreen(),
  ];

  /// Quais abas o motorista já abriu.
  ///
  /// POR QUE ISTO IMPORTA: o IndexedStack constrói TODAS as telas de
  /// uma vez. Na abertura, isso significava montar o Painel inteiro,
  /// a Jornada e o Mais antes mesmo de o motorista tocar neles — e a
  /// primeira tela demorava a aparecer por causa disso. Agora cada aba
  /// só nasce quando é aberta pela primeira vez, e depois fica pronta.
  final Set<int> _abertas = <int>{0};

  void _trocarAba(int i) {
    if (i == _aba) return;
    AudioService.toqueLeve();
    setState(() {
      _aba = i;
      _abertas.add(i);
    });
    NavegacaoApp.abaAtual.value = i;
  }

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;

    return Scaffold(
      backgroundColor: tema.fundo,
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        // IndexedStack mantém o estado de cada aba (rolagem, filtros).
        child: IndexedStack(
          index: _aba,
          children: <Widget>[
            for (var i = 0; i < _telas.length; i++)
              _abertas.contains(i) ? _telas[i] : const SizedBox.shrink(),
          ],
        ),
      ),
      bottomNavigationBar: _BarraDeAbas(
        tema: tema,
        aba: _aba,
        aoTrocar: _trocarAba,
        aoLancar: () {
          AudioService.clique();
          Navigator.of(context).pushNamed(AppRoutes.lancamento);
        },
      ),
    );
  }
}

// =======================================================================
// A BARRA DE BAIXO
// =======================================================================
class _BarraDeAbas extends StatelessWidget {
  final TemaFarol tema;
  final int aba;
  final ValueChanged<int> aoTrocar;
  final VoidCallback aoLancar;

  const _BarraDeAbas({
    required this.tema,
    required this.aba,
    required this.aoTrocar,
    required this.aoLancar,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: tema.superficie,
        border: Border(top: BorderSide(color: tema.divisor)),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 62,
          child: Row(
            children: <Widget>[
              _Item(
                tema: tema,
                icone: Icons.today_rounded,
                rotulo: 'Hoje',
                ativo: aba == 0,
                aoTocar: () => aoTrocar(0),
              ),
              _Item(
                tema: tema,
                icone: Icons.dashboard_rounded,
                rotulo: 'Painel',
                ativo: aba == 1,
                aoTocar: () => aoTrocar(1),
              ),

              // ---- Botão de lançar: presente, mas sem exagero ----
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Semantics(
                  button: true,
                  label: 'Lançar o dia de trabalho',
                  child: Material(
                    color: tema.primaria,
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      onTap: aoLancar,
                      borderRadius: BorderRadius.circular(14),
                      child: SizedBox(
                        // 48x48: o mínimo recomendado para o dedo, e nada
                        // além disso — antes ele tomava a tela inteira.
                        width: 48,
                        height: 48,
                        child: Icon(
                          Icons.add_rounded,
                          size: 26,
                          color: tema.textoSobrePrimaria,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              _Item(
                tema: tema,
                icone: Icons.timer_rounded,
                rotulo: 'Jornada',
                ativo: aba == 2,
                aoTocar: () => aoTrocar(2),
              ),
              _Item(
                tema: tema,
                icone: Icons.menu_rounded,
                rotulo: 'Mais',
                ativo: aba == 3,
                aoTocar: () => aoTrocar(3),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final String rotulo;
  final bool ativo;
  final VoidCallback aoTocar;

  const _Item({
    required this.tema,
    required this.icone,
    required this.rotulo,
    required this.ativo,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final cor = ativo ? tema.primaria : tema.textoSuave;

    return Expanded(
      child: Semantics(
        button: true,
        selected: ativo,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icone, color: cor, size: 22),
              const SizedBox(height: 3),
              Text(
                rotulo,
                style: TextStyle(
                  color: cor,
                  fontSize: 10.5,
                  fontWeight: ativo ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
