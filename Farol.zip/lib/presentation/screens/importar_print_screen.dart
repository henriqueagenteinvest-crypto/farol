/// =======================================================================
/// IMPORTAR PRINT — A FUNÇÃO PRINCIPAL DO FAROL
/// =======================================================================
/// O motorista tira um print da tela de ganhos do Uber ou da 99, escolhe a
/// imagem aqui, e o app lê tudo sozinho: valor, corridas, horas e KM.
///
/// Depois da leitura ele SEMPRE vai para a tela de confirmação. Nada é
/// salvo sem revisão — é essa regra que garante zero erro nos números.
/// =======================================================================
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../services/audio_service.dart';
import '../../services/ocr_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../controllers/app_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/cartao_farol.dart';

class ImportarPrintScreen extends StatefulWidget {
  const ImportarPrintScreen({super.key});

  @override
  State<ImportarPrintScreen> createState() => _ImportarPrintScreenState();
}

class _ImportarPrintScreenState extends State<ImportarPrintScreen> {
  final OCRService _ocr = OCRService();

  File? _imagem;
  bool _lendo = false;
  String _etapa = '';

  @override
  void dispose() {
    // Libera o reconhecedor de texto ao sair da tela.
    _ocr.encerrar();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  Future<void> _escolher({required bool camera}) async {
    AudioService.clique();
    try {
      final arquivo =
          camera ? await _ocr.tirarFoto() : await _ocr.escolherDaGaleria();
      if (arquivo == null) return; // o motorista desistiu
      setState(() => _imagem = arquivo);
      await _ler(arquivo);
    } catch (e) {
      if (!mounted) return;
      context.aviso(
        'Não consegui abrir ${camera ? "a câmera" : "a galeria"}. '
        'Verifique a permissão nas configurações do celular.',
        erro: true,
      );
    }
  }

  Future<void> _ler(File arquivo) async {
    setState(() {
      _lendo = true;
      _etapa = 'Preparando...';
    });

    final resultado = await _ocr.lerPrint(
      arquivo,
      aoProgredir: (etapa) {
        if (mounted) setState(() => _etapa = etapa);
      },
    );

    if (!mounted) return;
    setState(() => _lendo = false);

    if (!resultado.temDadosUteis) {
      AudioService.erro();
      _mostrarFalha(resultado.avisos.isEmpty
          ? 'Não consegui identificar nenhum dado nesta imagem.'
          : resultado.avisos.first);
      return;
    }

    AudioService.sucesso();
    // SEMPRE passa pela confirmação. Nunca salva direto.
    await Navigator.of(context).pushReplacementNamed(
      AppRoutes.confirmacaoOcr,
      arguments: resultado,
    );
  }

  void _mostrarFalha(String mensagem) {
    final tema = context.read<AppController>().tema;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: Icon(Icons.image_not_supported_rounded, color: tema.alerta),
        title: const Text('Não deu para ler'),
        content: Text(mensagem),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              setState(() => _imagem = null);
            },
            child: const Text('Tentar outra imagem'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              Navigator.of(context).pushReplacementNamed(
                AppRoutes.lancamento,
              );
            },
            child: const Text('Digitar na mão'),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    final tema = context.watch<AppController>().tema;

    return Scaffold(
      appBar: AppBar(title: const Text('Importar print')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: _lendo
            ? _Lendo(tema: tema, etapa: _etapa, imagem: _imagem)
            : ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                children: <Widget>[
                  _ComoFunciona(tema: tema),
                  const SizedBox(height: 26),

                  if (_imagem != null) ...<Widget>[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(tema.raioBorda),
                      child: Image.file(
                        _imagem!,
                        height: 220,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(height: 16),
                    BotaoGrande(
                      texto: 'Ler esta imagem de novo',
                      icone: Icons.refresh_rounded,
                      tema: tema,
                      aoTocar: () => _ler(_imagem!),
                    ),
                    const SizedBox(height: 12),
                  ],

                  BotaoGrande(
                    texto: 'Escolher print da galeria',
                    icone: Icons.photo_library_rounded,
                    tema: tema,
                    altura: 68,
                    aoTocar: () => _escolher(camera: false),
                  ),
                  const SizedBox(height: 12),
                  BotaoGrande(
                    texto: 'Tirar foto da tela',
                    icone: Icons.photo_camera_rounded,
                    tema: tema,
                    cor: tema.secundaria,
                    altura: 68,
                    aoTocar: () => _escolher(camera: true),
                  ),
                  const SizedBox(height: 22),

                  _Dicas(tema: tema),
                  const SizedBox(height: 20),

                  Center(
                    child: TextButton.icon(
                      onPressed: () {
                        AudioService.toqueLeve();
                        Navigator.of(context)
                            .pushReplacementNamed(AppRoutes.lancamento);
                      },
                      icon: const Icon(Icons.edit_rounded, size: 18),
                      label: const Text('Prefiro digitar na mão'),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

// =======================================================================
// EXPLICAÇÃO EM 3 PASSOS
// =======================================================================
class _ComoFunciona extends StatelessWidget {
  final TemaFarol tema;
  const _ComoFunciona({required this.tema});

  @override
  Widget build(BuildContext context) {
    final passos = <(int, String)>[
      (1, 'Abra o app do Uber ou da 99 e vá na tela de ganhos'),
      (2, 'Tire um print (foto da tela) pelo próprio celular'),
      (3, 'Escolha o print aqui embaixo — o Farol lê tudo sozinho'),
    ];

    return CartaoFarol(
      tema: tema,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.auto_awesome_rounded, color: tema.primaria, size: 20),
              const SizedBox(width: 9),
              Text('Como funciona', style: context.textos.titleLarge),
            ],
          ),
          const SizedBox(height: 16),
          for (final p in passos)
            Padding(
              padding: const EdgeInsets.only(bottom: 13),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    width: 26,
                    height: 26,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      gradient: tema.gradienteLinear,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${p.$1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: Text(
                        p.$2,
                        style: context.textos.bodyMedium,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// DICAS PARA UMA LEITURA MELHOR
// =======================================================================
class _Dicas extends StatelessWidget {
  final TemaFarol tema;
  const _Dicas({required this.tema});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: tema.superficieAlta,
        borderRadius: BorderRadius.circular(tema.raioBorda * 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.lightbulb_rounded, size: 17, color: tema.alerta),
              const SizedBox(width: 8),
              Text(
                'Para o app acertar mais',
                style: context.textos.titleMedium,
              ),
            ],
          ),
          const SizedBox(height: 11),
          for (final d in const <String>[
            'Print feito pelo próprio celular lê muito melhor que foto da tela',
            'Deixe a tela inteira aparecer, com os números e os títulos',
            'Se for fotografar outra tela, evite reflexo e segure firme',
            'Você sempre confere tudo antes de salvar',
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: BoxDecoration(
                        color: tema.textoSuave,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(d, style: context.textos.bodySmall),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// TELA DE "LENDO..."
// =======================================================================
class _Lendo extends StatelessWidget {
  final TemaFarol tema;
  final String etapa;
  final File? imagem;

  const _Lendo({required this.tema, required this.etapa, this.imagem});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (imagem != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(tema.raioBorda),
                child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Opacity(
                      opacity: 0.35,
                      child: Image.file(
                        imagem!,
                        height: 240,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    // Linha de leitura que percorre a imagem, como um scanner.
                    _LinhaScanner(tema: tema),
                  ],
                ),
              ),
            const SizedBox(height: 34),
            SizedBox(
              width: 42,
              height: 42,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                color: tema.primaria,
              ),
            ),
            const SizedBox(height: 22),
            Text(
              etapa,
              textAlign: TextAlign.center,
              style: context.textos.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Estou testando várias versões da imagem para acertar '
              'o máximo possível. Leva só alguns segundos.',
              textAlign: TextAlign.center,
              style: context.textos.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _LinhaScanner extends StatefulWidget {
  final TemaFarol tema;
  const _LinhaScanner({required this.tema});

  @override
  State<_LinhaScanner> createState() => _LinhaScannerState();
}

class _LinhaScannerState extends State<_LinhaScanner>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      width: double.infinity,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => Align(
          alignment: Alignment(0, _c.value * 2 - 1),
          child: Container(
            height: 3,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: <Color>[
                  Colors.transparent,
                  widget.tema.primaria,
                  Colors.transparent,
                ],
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: widget.tema.primaria.withValues(alpha: 0.7),
                  blurRadius: 12,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
