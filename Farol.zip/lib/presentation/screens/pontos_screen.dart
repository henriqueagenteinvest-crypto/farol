/// -----------------------------------------------------------------------
/// PONTOS E RECOMPENSAS
/// -----------------------------------------------------------------------
/// Mostra quantos pontos as corridas do mês renderam, em que categoria
/// isso coloca o motorista e quais são os horários que valem ponto em
/// dobro.
///
/// HONESTIDADE ANTES DE TUDO: o Farol é offline e não conversa com a
/// Uber. Os pontos aqui são contados a partir das CORRIDAS QUE VOCÊ
/// LANÇOU, e as metas de categoria são uma REFERÊNCIA — a Uber muda
/// esses números conforme a cidade. A tela diz isso com todas as letras,
/// para nunca passar informação errada.
///
/// Esta tela não pede nenhum dado novo: ela só olha o que já existe.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../domain/entities/periodo_escolhido.dart';
import '../../services/pontos_service.dart';
import '../../theme/modo_tema.dart';
import '../../theme/tema_farol.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../controllers/app_controller.dart';
import '../controllers/dados_controller.dart';
import '../widgets/campo_farol.dart';
import '../widgets/cartao_farol.dart';

class PontosScreen extends StatelessWidget {
  const PontosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final dados = context.watch<DadosController>();
    final tema = app.tema;
    final animar = app.animacoesAtivas;

    final agora = DateTime.now();
    final mes = dados.resumoDe(
      PeriodoEscolhido.hoje(escopo: EscopoPeriodo.mes),
    );

    final pontos = PontosService.calcularPontos(corridas: mes.corridas);
    final categoria = PontosService.categoriaPara(pontos);
    final progresso = PontosService.progressoParaProxima(pontos);
    final faltam = PontosService.faltamParaProxima(pontos);
    final emPico = PontosService.ehHorarioPico(agora);

    return Scaffold(
      appBar: AppBar(title: const Text('Pontos e recompensas')),
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 40),
          children: <Widget>[
            // ---------------- AVISO DE HORÁRIO DE PICO ----------------
            _AvisoPico(tema: tema, emPico: emPico, agora: agora),
            const SizedBox(height: 16),

            // ---------------- PONTOS DO MÊS ----------------
            _CartaoPontos(
              tema: tema,
              pontos: pontos,
              corridas: mes.corridas,
              categoria: categoria,
              progresso: progresso,
              faltam: faltam,
              animar: animar,
            ),
            const SizedBox(height: 22),

            // ---------------- CATEGORIAS ----------------
            const TituloSecao(
              texto: 'As categorias',
              icone: Icons.workspace_premium_rounded,
            ),
            _ListaCategorias(tema: tema, atual: categoria, pontos: pontos),
            const SizedBox(height: 22),

            // ---------------- HORÁRIOS DE PICO ----------------
            const TituloSecao(
              texto: 'Horários de ponto em dobro',
              icone: Icons.schedule_rounded,
            ),
            _TabelaPico(tema: tema, hoje: agora.weekday),
            const SizedBox(height: 22),

            // ---------------- REQUISITOS ----------------
            const TituloSecao(
              texto: 'O que a Uber também exige',
              icone: Icons.checklist_rounded,
            ),
            _ListaRequisitos(tema: tema),
            const SizedBox(height: 22),

            // ---------------- TRANSPARÊNCIA ----------------
            _Observacao(tema: tema),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
// AVISO: AGORA VALE O DOBRO?
// =======================================================================
class _AvisoPico extends StatelessWidget {
  final TemaFarol tema;
  final bool emPico;
  final DateTime agora;

  const _AvisoPico({
    required this.tema,
    required this.emPico,
    required this.agora,
  });

  @override
  Widget build(BuildContext context) {
    final cor = emPico ? tema.sucesso : tema.textoSuave;
    final falta = PontosService.proximoPicoHoje(agora);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.13),
        borderRadius: BorderRadius.circular(tema.raioBorda),
        border: Border.all(color: cor.withValues(alpha: 0.45)),
      ),
      child: Row(
        children: <Widget>[
          Icon(
            emPico ? Icons.bolt_rounded : Icons.access_time_rounded,
            color: cor,
            size: 26,
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  emPico
                      ? 'Agora vale ponto em dobro'
                      : 'Agora é horário normal',
                  style: context.textos.titleMedium?.copyWith(color: cor),
                ),
                const SizedBox(height: 3),
                Text(
                  emPico
                      ? 'Cada corrida conta 2 pontos neste momento.'
                      : (falta == null
                          ? 'Hoje não tem mais horário de pico.'
                          : 'Falta ${Fmt.cronometro(falta)} para o '
                              'próximo horário de pico.'),
                  style: context.textos.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// CARTÃO PRINCIPAL DE PONTOS
// =======================================================================
class _CartaoPontos extends StatelessWidget {
  final TemaFarol tema;
  final int pontos;
  final int corridas;
  final CategoriaMotorista categoria;
  final double progresso;
  final int faltam;
  final bool animar;

  const _CartaoPontos({
    required this.tema,
    required this.pontos,
    required this.corridas,
    required this.categoria,
    required this.progresso,
    required this.faltam,
    required this.animar,
  });

  @override
  Widget build(BuildContext context) {
    final corCategoria = CoresCategoria.porNome(categoria.name);
    final proxima = categoria.proxima;

    return CartaoFarol(
      tema: tema,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: corCategoria.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  Icons.workspace_premium_rounded,
                  color: corCategoria,
                  size: 25,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'CATEGORIA ${categoria.rotulo.toUpperCase()}',
                      style: TextStyle(
                        color: corCategoria,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.1,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'pelos pontos deste mês',
                      style: context.textos.bodySmall,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),

          // ---- O número grande ----
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: pontos.toDouble()),
            duration:
                animar ? const Duration(milliseconds: 700) : Duration.zero,
            curve: Curves.easeOutCubic,
            builder: (context, v, _) => Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: <Widget>[
                Text(
                  Fmt.inteiro(v),
                  style: TextStyle(
                    color: tema.texto,
                    fontSize: 42,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -1.2,
                  ),
                ),
                const SizedBox(width: 8),
                Text('pontos', style: context.textos.bodyMedium),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${Fmt.inteiro(corridas)} corridas lançadas neste mês',
            style: context.textos.bodySmall,
          ),
          const SizedBox(height: 18),

          // ---- Barra de progresso ----
          if (proxima != null) ...<Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: progresso),
                duration: animar
                    ? const Duration(milliseconds: 700)
                    : Duration.zero,
                curve: Curves.easeOutCubic,
                builder: (context, v, _) => LinearProgressIndicator(
                  value: v,
                  minHeight: 12,
                  backgroundColor: tema.superficieAlta,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    CoresCategoria.porNome(proxima.name),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 9),
            Text(
              'Faltam ${Fmt.inteiro(faltam)} pontos para a categoria '
              '${proxima.rotulo}',
              style: context.textos.bodySmall,
            ),
          ] else
            Text(
              'Você está na categoria mais alta.',
              style: context.textos.bodyMedium?.copyWith(
                color: tema.sucesso,
                fontWeight: FontWeight.w600,
              ),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// LISTA DE CATEGORIAS
// =======================================================================
class _ListaCategorias extends StatelessWidget {
  final TemaFarol tema;
  final CategoriaMotorista atual;
  final int pontos;

  const _ListaCategorias({
    required this.tema,
    required this.atual,
    required this.pontos,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        for (final c in CategoriaMotorista.values)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _LinhaCategoria(
              tema: tema,
              categoria: c,
              alcancada: pontos >= c.pontosNecessarios,
              ehAtual: c == atual,
            ),
          ),
      ],
    );
  }
}

class _LinhaCategoria extends StatelessWidget {
  final TemaFarol tema;
  final CategoriaMotorista categoria;
  final bool alcancada;
  final bool ehAtual;

  const _LinhaCategoria({
    required this.tema,
    required this.categoria,
    required this.alcancada,
    required this.ehAtual,
  });

  @override
  Widget build(BuildContext context) {
    final cor = CoresCategoria.porNome(categoria.name);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tema.superficie,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        border: Border.all(
          color: ehAtual ? cor : tema.textoSuave.withValues(alpha: 0.15),
          width: ehAtual ? 2 : 1,
        ),
        boxShadow: tema.sombraCartao,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                alcancada
                    ? Icons.check_circle_rounded
                    : Icons.lock_outline_rounded,
                color: alcancada ? cor : tema.textoSuave,
                size: 21,
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Text(
                  categoria.rotulo,
                  style: context.textos.titleMedium?.copyWith(
                    color: alcancada ? cor : tema.texto,
                  ),
                ),
              ),
              Text(
                categoria.pontosNecessarios == 0
                    ? 'a partir de 0'
                    : 'a partir de ${Fmt.inteiro(categoria.pontosNecessarios)}',
                style: context.textos.bodySmall,
              ),
            ],
          ),
          const SizedBox(height: 9),
          for (final v in categoria.vantagens)
            Padding(
              padding: const EdgeInsets.only(left: 32, bottom: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('• ', style: context.textos.bodySmall),
                  Expanded(
                    child: Text(v, style: context.textos.bodySmall),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// =======================================================================
// TABELA DE HORÁRIOS DE PICO
// =======================================================================
class _TabelaPico extends StatelessWidget {
  final TemaFarol tema;

  /// Dia da semana de hoje (1 = segunda ... 7 = domingo).
  final int hoje;

  const _TabelaPico({required this.tema, required this.hoje});

  @override
  Widget build(BuildContext context) {
    // Segunda a domingo, na ordem do calendário.
    const ordem = <int>[
      DateTime.monday,
      DateTime.tuesday,
      DateTime.wednesday,
      DateTime.thursday,
      DateTime.friday,
      DateTime.saturday,
      DateTime.sunday,
    ];

    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < ordem.length; i++) ...<Widget>[
            if (i > 0) const Divider(height: 18),
            _LinhaPico(
              tema: tema,
              dia: ordem[i],
              ehHoje: ordem[i] == hoje,
            ),
          ],
        ],
      ),
    );
  }
}

class _LinhaPico extends StatelessWidget {
  final TemaFarol tema;
  final int dia;
  final bool ehHoje;

  const _LinhaPico({
    required this.tema,
    required this.dia,
    required this.ehHoje,
  });

  @override
  Widget build(BuildContext context) {
    final faixas = PontosService.faixasDoDia(dia);

    return Row(
      children: <Widget>[
        SizedBox(
          width: 76,
          child: Text(
            PontosService.nomeDia(dia),
            style: context.textos.bodyMedium?.copyWith(
              fontWeight: ehHoje ? FontWeight.w700 : FontWeight.w500,
              color: ehHoje ? tema.primaria : tema.texto,
            ),
          ),
        ),
        Expanded(
          child: Wrap(
            spacing: 7,
            runSpacing: 6,
            children: <Widget>[
              if (faixas.isEmpty)
                Text('sem pico', style: context.textos.bodySmall)
              else
                for (final f in faixas)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 11,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: tema.alerta.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      f.rotulo,
                      style: context.textos.bodySmall?.copyWith(
                        color: tema.alerta,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
            ],
          ),
        ),
      ],
    );
  }
}

// =======================================================================
// REQUISITOS DE QUALIDADE
// =======================================================================
class _ListaRequisitos extends StatelessWidget {
  final TemaFarol tema;

  const _ListaRequisitos({required this.tema});

  @override
  Widget build(BuildContext context) {
    return CartaoFarol(
      tema: tema,
      child: Column(
        children: <Widget>[
          for (var i = 0; i < PontosService.requisitos.length; i++) ...<Widget>[
            if (i > 0) const Divider(height: 20),
            Row(
              children: <Widget>[
                Icon(
                  Icons.verified_outlined,
                  size: 19,
                  color: tema.secundaria,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        PontosService.requisitos[i].nome,
                        style: context.textos.bodyMedium,
                      ),
                      Text(
                        PontosService.requisitos[i].explicacao,
                        style: context.textos.bodySmall,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  PontosService.requisitos[i].alvo,
                  style: context.textos.titleMedium?.copyWith(
                    color: tema.secundaria,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// =======================================================================
// OBSERVAÇÃO HONESTA
// =======================================================================
class _Observacao extends StatelessWidget {
  final TemaFarol tema;

  const _Observacao({required this.tema});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: tema.superficieAlta,
        borderRadius: BorderRadius.circular(tema.raioBorda),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.info_outline_rounded, size: 19, color: tema.textoSuave),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              'O Farol funciona sem internet e não conversa com a Uber. '
              'Os pontos acima são contados pelas corridas que você lançou '
              'aqui, e as metas de cada categoria são uma referência — a '
              'Uber muda esses números conforme a cidade e o período. '
              'Sua avaliação, aceitação e cancelamento continuam sendo os '
              'que aparecem no aplicativo da Uber.',
              style: context.textos.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}
