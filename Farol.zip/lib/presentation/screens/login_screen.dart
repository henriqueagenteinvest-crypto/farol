/// -----------------------------------------------------------------------
/// TELA DE ENTRADA (CADASTRO SIMPLES)
/// -----------------------------------------------------------------------
/// Sem senha, sem e-mail, sem cadastro na internet: só o nome do motorista
/// e o carro. Tudo fica salvo no próprio celular.
///
/// A placa saiu de propósito: o aplicativo não precisa dela para calcular
/// nada, e pedir menos é o caminho mais curto para o motorista começar.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_routes.dart';
import '../../data/models/motorista.dart';
import '../../services/audio_service.dart';
import '../../utils/extensions.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../controllers/app_controller.dart';
import '../widgets/botao_grande.dart';
import '../widgets/campo_farol.dart';
import '../widgets/logo_farol.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formulario = GlobalKey<FormState>();
  final _nome = TextEditingController();
  final _modelo = TextEditingController();
  final _ano = TextEditingController();
  final _cor = TextEditingController();

  bool _salvando = false;

  /// Guarda a placa que já estava cadastrada, para não apagar o que o
  /// motorista informou em versões anteriores do aplicativo.
  String _placaAntiga = '';

  @override
  void initState() {
    super.initState();
    // Se já existir cadastro (edição de perfil), preenche os campos.
    final m = context.read<AppController>().motorista;
    if (m != null) {
      _nome.text = m.nome;
      _modelo.text = m.modeloCarro;
      _ano.text = m.anoCarro?.toString() ?? '';
      _cor.text = m.corCarro;
      _placaAntiga = m.placa;
    }
  }

  @override
  void dispose() {
    _nome.dispose();
    _modelo.dispose();
    _ano.dispose();
    _cor.dispose();
    super.dispose();
  }

  Future<void> _entrar() async {
    if (_salvando) return;
    if (!_formulario.currentState!.validate()) {
      AudioService.erro();
      context.aviso('Confira os campos marcados em vermelho', erro: true);
      return;
    }
    setState(() => _salvando = true);
    AudioService.sucesso();

    final app = context.read<AppController>();
    final primeiraVez = !app.temCadastro;

    // O cadastro já vale na hora; a gravação nunca derruba esta tela.
    final r = await app.salvarMotorista(
      Motorista(
        nome: _nome.text.trim(),
        modeloCarro: _modelo.text.trim(),
        placa: _placaAntiga,
        anoCarro: Fmt.paraInt(_ano.text),
        corCarro: _cor.text.trim(),
      ),
    );

    if (!mounted) return;
    setState(() => _salvando = false);

    if (r.falhouDeVez || r.soNaMemoria) {
      context.aviso(
        'Entrou, mas este celular não gravou o cadastro no disco. '
        'Veja Mais → Diagnóstico.',
        erro: true,
      );
    }

    // Na primeira vez tem festa. Depois, volta direto para o aplicativo.
    Navigator.of(context).pushReplacementNamed(
      primeiraVez ? AppRoutes.bemVindo : AppRoutes.principal,
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final tema = app.tema;
    final textos = context.textos;
    final editando = app.temCadastro;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: tema.gradienteFundo),
        child: SafeArea(
          child: Form(
            key: _formulario,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(22, 20, 22, 40),
              children: <Widget>[
                if (editando)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back_rounded),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                const SizedBox(height: 10),
                Center(child: LogoFarol(tema: tema, tamanho: 92)),
                const SizedBox(height: 22),
                Text(
                  editando ? 'Editar meu perfil' : 'Bem-vindo ao Farol',
                  textAlign: TextAlign.center,
                  style: textos.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  editando
                      ? 'Altere seus dados quando quiser.'
                      : 'Só o seu nome e o seu carro. Sem senha e sem '
                          'e-mail — tudo fica guardado aqui no celular.',
                  textAlign: TextAlign.center,
                  style: textos.bodyMedium?.copyWith(color: tema.textoSuave),
                ),
                const SizedBox(height: 30),

                // ---------------- Motorista ----------------
                const TituloSecao(
                  texto: 'Você',
                  icone: Icons.person_rounded,
                ),
                CampoFarol(
                  controlador: _nome,
                  rotulo: 'Seu nome',
                  dica: 'Como você quer ser chamado',
                  icone: Icons.badge_rounded,
                  validador: Validadores.nome,
                  capitalizacao: TextCapitalization.words,
                ),
                const SizedBox(height: 26),

                // ---------------- Carro ----------------
                const TituloSecao(
                  texto: 'Seu carro',
                  icone: Icons.directions_car_rounded,
                ),
                CampoFarol(
                  controlador: _modelo,
                  rotulo: 'Modelo',
                  dica: 'Ex.: Onix Plus',
                  icone: Icons.directions_car_filled_rounded,
                  capitalizacao: TextCapitalization.words,
                  ajuda: 'É o que aparece no topo do aplicativo',
                ),
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: CampoFarol.inteiro(
                        controlador: _ano,
                        rotulo: 'Ano (opcional)',
                        icone: Icons.event_rounded,
                        validador: Validadores.ano,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CampoFarol(
                        controlador: _cor,
                        rotulo: 'Cor (opcional)',
                        dica: 'Ex.: Prata',
                        icone: Icons.palette_rounded,
                        capitalizacao: TextCapitalization.words,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 34),

                BotaoGrande(
                  texto: _salvando
                      ? 'Salvando...'
                      : (editando ? 'Salvar alterações' : 'Começar a usar'),
                  icone: editando
                      ? Icons.check_rounded
                      : Icons.arrow_forward_rounded,
                  aoTocar: _salvando ? () {} : _entrar,
                  tema: tema,
                  habilitado: !_salvando,
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(
                      Icons.lock_rounded,
                      size: 14,
                      color: tema.textoSuave,
                    ),
                    const SizedBox(width: 7),
                    Flexible(
                      child: Text(
                        'Seus dados nunca saem deste celular',
                        style: textos.bodySmall,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
