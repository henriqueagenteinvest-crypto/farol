/// -----------------------------------------------------------------------
/// PEÇAS DO PAINEL (v2)
/// -----------------------------------------------------------------------
/// As peças que montam as telas Hoje e Painel, no formato que o motorista
/// pediu: rótulo pequeno em maiúsculas, número grande com as casas
/// alinhadas, e uma explicação curta embaixo.
///
/// Nenhuma peça daqui faz conta. Todas recebem o número já pronto.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';

// =======================================================================
// BARRA DE CIMA — quem é o motorista e qual o carro
// =======================================================================
class BarraTopo extends StatelessWidget {
  final TemaFarol tema;
  final String nome;
  final String carro;

  /// Mostra que os dados estão guardados no celular.
  final bool salvo;

  /// Aviso quando a gravação falhou.
  final String? alerta;

  final VoidCallback aoTrocarBrilho;
  final VoidCallback aoAbrirPerfil;

  const BarraTopo({
    super.key,
    required this.tema,
    required this.nome,
    required this.carro,
    required this.salvo,
    required this.aoTrocarBrilho,
    required this.aoAbrirPerfil,
    this.alerta,
  });

  @override
  Widget build(BuildContext context) {
    final inicial = nome.trim().isEmpty ? '?' : nome.trim()[0].toUpperCase();
    final problema = alerta != null;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 8, 12, 12),
      decoration: BoxDecoration(
        color: tema.superficie,
        border: Border(
          bottom: BorderSide(color: tema.divisor, width: 1),
        ),
      ),
      child: Row(
        children: <Widget>[
          // ---- Avatar ----
          Container(
            width: 42,
            height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tema.primaria.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              inicial,
              style: tema.numero(tamanho: 18, cor: tema.primaria),
            ),
          ),
          const SizedBox(width: 11),

          // ---- Nome e carro ----
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  nome.isEmpty ? 'Motorista' : nome,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                if (carro.isNotEmpty)
                  Text(
                    carro,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),

          // ---- Selo de estado ----
          _Selo(
            tema: tema,
            texto: problema ? 'Atenção' : (salvo ? 'Salvo' : '—'),
            cor: problema ? tema.erro : tema.sucesso,
          ),
          const SizedBox(width: 6),

          // ---- Claro/escuro ----
          _BotaoIcone(
            tema: tema,
            icone: tema.ehEscuro
                ? Icons.light_mode_rounded
                : Icons.dark_mode_rounded,
            dica: 'Trocar claro e escuro',
            aoTocar: aoTrocarBrilho,
          ),
          const SizedBox(width: 6),
          _BotaoIcone(
            tema: tema,
            icone: Icons.person_rounded,
            dica: 'Meu cadastro',
            aoTocar: aoAbrirPerfil,
          ),
        ],
      ),
    );
  }
}

class _Selo extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  final Color cor;

  const _Selo({required this.tema, required this.texto, required this.cor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 6),
          Text(
            texto,
            style: TextStyle(
              color: cor,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _BotaoIcone extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final String dica;
  final VoidCallback aoTocar;

  const _BotaoIcone({
    required this.tema,
    required this.icone,
    required this.dica,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: dica,
      child: Material(
        color: tema.superficieAlta,
        borderRadius: BorderRadius.circular(11),
        child: InkWell(
          onTap: () {
            AudioService.toqueLeve();
            aoTocar();
          },
          borderRadius: BorderRadius.circular(11),
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icone, size: 19, color: tema.texto),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// ANEL DE META — o círculo que mostra quanto por cento você já fez
// =======================================================================
class AnelMeta extends StatelessWidget {
  /// De 0.0 a 1.0.
  final double progresso;

  /// O que aparece dentro do anel (ex.: "29%").
  final String texto;

  final String legenda;
  final Color corAnel;
  final Color corTrilho;
  final Color corTexto;
  final double tamanho;
  final bool animar;
  final TemaFarol tema;

  const AnelMeta({
    super.key,
    required this.progresso,
    required this.texto,
    required this.legenda,
    required this.corAnel,
    required this.corTrilho,
    required this.corTexto,
    required this.tema,
    required this.animar,
    this.tamanho = 104,
  });

  @override
  Widget build(BuildContext context) {
    final p = progresso.isFinite ? progresso.clamp(0.0, 1.0) : 0.0;

    return SizedBox(
      width: tamanho,
      height: tamanho,
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: p),
        duration: animar ? const Duration(milliseconds: 750) : Duration.zero,
        curve: Curves.easeOutCubic,
        builder: (context, v, _) => CustomPaint(
          painter: _PintorAnel(
            progresso: v,
            corAnel: corAnel,
            corTrilho: corTrilho,
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  texto,
                  style: tema.numero(
                    tamanho: 19,
                    cor: corTexto,
                    espacamento: -0.3,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  legenda,
                  style: TextStyle(
                    color: corTexto.withValues(alpha: 0.8),
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PintorAnel extends CustomPainter {
  final double progresso;
  final Color corAnel;
  final Color corTrilho;

  _PintorAnel({
    required this.progresso,
    required this.corAnel,
    required this.corTrilho,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const largura = 7.0;
    final centro = Offset(size.width / 2, size.height / 2);
    final raio = (math.min(size.width, size.height) - largura) / 2;

    final trilho = Paint()
      ..color = corTrilho
      ..style = PaintingStyle.stroke
      ..strokeWidth = largura
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(centro, raio, trilho);

    if (progresso <= 0) return;

    final arco = Paint()
      ..color = corAnel
      ..style = PaintingStyle.stroke
      ..strokeWidth = largura
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: centro, radius: raio),
      -math.pi / 2, // começa no topo
      2 * math.pi * progresso,
      false,
      arco,
    );
  }

  @override
  bool shouldRepaint(_PintorAnel anterior) =>
      anterior.progresso != progresso ||
      anterior.corAnel != corAnel ||
      anterior.corTrilho != corTrilho;
}

// =======================================================================
// CARTÃO DE DESTAQUE — o número principal da tela
// =======================================================================
class CartaoDestaque extends StatelessWidget {
  final TemaFarol tema;

  /// "LUCRO DE HOJE", "LUCRO LÍQUIDO DE AGOSTO"...
  final String rotulo;

  /// O valor já formatado.
  final String valor;

  /// Linha de apoio embaixo do número.
  final String detalhe;

  /// De 0.0 a 1.0 — quanto da meta já foi feito.
  final double progressoMeta;
  final String textoAnel;

  final bool animar;

  /// Pinta em vermelho quando o resultado é negativo.
  final bool negativo;

  const CartaoDestaque({
    super.key,
    required this.tema,
    required this.rotulo,
    required this.valor,
    required this.detalhe,
    required this.progressoMeta,
    required this.textoAnel,
    required this.animar,
    this.negativo = false,
  });

  @override
  Widget build(BuildContext context) {
    final base = negativo ? tema.erro : tema.primaria;
    final corTexto = TemaFarol.contrasteSobre(base);
    final bateu = progressoMeta >= 1.0;

    return Container(
      padding: EdgeInsets.all(tema.compacto ? 16 : 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[
            base,
            Color.lerp(base, Colors.black, tema.ehEscuro ? 0.30 : 0.18)!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(tema.raioBorda + 2),
        boxShadow: tema.brilhoDe(base),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  rotulo.toUpperCase(),
                  style: TextStyle(
                    color: corTexto.withValues(alpha: 0.88),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 8),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    valor,
                    style: tema.numero(
                      tamanho: 34,
                      cor: corTexto,
                      espacamento: -1,
                    ),
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  detalhe,
                  style: TextStyle(
                    color: corTexto.withValues(alpha: 0.85),
                    fontSize: 12.5,
                    fontWeight: FontWeight.w500,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          AnelMeta(
            tema: tema,
            progresso: progressoMeta,
            texto: textoAnel,
            legenda: 'DA META',
            corAnel: bateu ? const Color(0xFF7BE495) : const Color(0xFF9AE6B4),
            corTrilho: corTexto.withValues(alpha: 0.22),
            corTexto: corTexto,
            animar: animar,
            tamanho: tema.compacto ? 88 : 100,
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// CARTÃO DE MÉTRICA — rótulo pequeno, número grande, explicação embaixo
// =======================================================================
class CartaoMetrica extends StatelessWidget {
  final TemaFarol tema;
  final String rotulo;
  final String valor;
  final String detalhe;

  /// Cor do número. Nulo = cor normal do texto.
  final Color? corValor;

  /// Faixa colorida na lateral esquerda, para destacar o cartão.
  final Color? faixa;

  final VoidCallback? aoTocar;

  const CartaoMetrica({
    super.key,
    required this.tema,
    required this.rotulo,
    required this.valor,
    required this.detalhe,
    this.corValor,
    this.faixa,
    this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final conteudo = Container(
      padding: EdgeInsets.fromLTRB(tema.compacto ? 12 : 14, 12,
          tema.compacto ? 12 : 14, 12),
      decoration: BoxDecoration(
        color: tema.superficie,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        border: faixa == null
            ? Border.all(color: tema.divisor)
            : Border(
                left: BorderSide(color: faixa!, width: 3),
                top: BorderSide(color: tema.divisor),
                right: BorderSide(color: tema.divisor),
                bottom: BorderSide(color: tema.divisor),
              ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(
            rotulo.toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: tema.textoSuave,
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.9,
            ),
          ),
          const SizedBox(height: 9),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              valor,
              style: tema.numero(tamanho: 22, cor: corValor),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            detalhe,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: tema.textoSuave,
              fontSize: 11.5,
              height: 1.25,
            ),
          ),
        ],
      ),
    );

    if (aoTocar == null) return conteudo;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: aoTocar,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        child: conteudo,
      ),
    );
  }
}

// =======================================================================
// TÍTULO DE BLOCO — a barrinha colorida com o texto em maiúsculas
// =======================================================================
class TituloBloco extends StatelessWidget {
  final TemaFarol tema;
  final String texto;
  final Widget? acao;

  const TituloBloco({
    super.key,
    required this.tema,
    required this.texto,
    this.acao,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: <Widget>[
          Container(
            width: 3,
            height: 15,
            decoration: BoxDecoration(
              color: tema.primaria,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              texto.toUpperCase(),
              style: TextStyle(
                color: tema.texto,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.1,
              ),
            ),
          ),
          if (acao != null) acao!,
        ],
      ),
    );
  }
}

// =======================================================================
// BOTÃO DE AÇÃO RÁPIDA
// =======================================================================
class BotaoAcao extends StatelessWidget {
  final TemaFarol tema;
  final IconData icone;
  final String texto;
  final Color cor;
  final VoidCallback aoTocar;

  const BotaoAcao({
    super.key,
    required this.tema,
    required this.icone,
    required this.texto,
    required this.cor,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: cor.withValues(alpha: tema.ehEscuro ? 0.14 : 0.10),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: () {
          AudioService.clique();
          aoTocar();
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          // 48 de altura: alvo confortável para o dedo dentro do carro.
          constraints: const BoxConstraints(minHeight: 48),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: <Widget>[
              Icon(icone, size: 18, color: cor),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  texto,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: cor,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// CAIXA — o cartão neutro que agrupa conteúdo
// =======================================================================
class Caixa extends StatelessWidget {
  final TemaFarol tema;
  final Widget child;
  final EdgeInsetsGeometry? padding;

  const Caixa({
    super.key,
    required this.tema,
    required this.child,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? tema.recheio,
      decoration: BoxDecoration(
        color: tema.superficie,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        border: Border.all(color: tema.divisor),
      ),
      child: child,
    );
  }
}
