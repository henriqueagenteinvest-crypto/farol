/// -----------------------------------------------------------------------
/// MICROINTERAÇÕES — as animações pequenas do dia a dia
/// -----------------------------------------------------------------------
/// São os detalhes que fazem o aplicativo parecer vivo sem atrapalhar
/// ninguém. Todos aqui obedecem ao interruptor "Animações" das
/// configurações: desligado, a duração vira zero e nada anima.
///
/// O que tem aqui:
///
///   EntradaSuave   — o conteúdo aparece subindo alguns pixels. Usado em
///                    cartões e blocos que entram na tela. Com `ordem`,
///                    os itens de uma lista entram um atrás do outro
///                    (efeito escada), o que dá a sensação de que a tela
///                    "monta" na frente do motorista.
///
///   ToqueQueAfunda — qualquer coisa tocável encolhe enquanto o dedo está
///                    em cima e volta ao soltar. É o retorno físico que
///                    faz o toque parecer que "pegou".
///
/// CUSTO: ambos usam uma animação por widget, sem imagem e sem sombra
/// nova. Em celular fraco isso é barato — e, mesmo assim, dá para
/// desligar tudo em Aparência → Detalhes → Animações.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

class EntradaSuave extends StatelessWidget {
  final Widget child;

  /// Posição do item na lista. Cada posição atrasa a entrada em 45 ms,
  /// até no máximo 8 posições — passando disso, tudo entra junto (para
  /// uma lista longa não demorar uma eternidade para aparecer).
  final int ordem;

  /// Quando falso, nada anima: o conteúdo já nasce no lugar.
  final bool animar;

  /// Quanto o conteúdo sobe ao entrar.
  final double deslocamento;

  const EntradaSuave({
    super.key,
    required this.child,
    this.animar = true,
    this.ordem = 0,
    this.deslocamento = 14,
  });

  @override
  Widget build(BuildContext context) {
    if (!animar) return child;

    final atraso = Duration(milliseconds: 45 * ordem.clamp(0, 8));

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 320) + atraso,
      // O Interval faz o item ficar parado durante o atraso e só então
      // começar a andar — é assim que sai o efeito escada com uma
      // animação só, sem controlador nem timer.
      curve: Interval(
        atraso.inMilliseconds / (320 + atraso.inMilliseconds),
        1,
        curve: Curves.easeOutCubic,
      ),
      builder: (context, t, filho) => Opacity(
        opacity: t,
        child: Transform.translate(
          offset: Offset(0, deslocamento * (1 - t)),
          child: filho,
        ),
      ),
      child: child,
    );
  }
}

/// =======================================================================
/// O TOQUE QUE AFUNDA
/// =======================================================================
/// Envolve QUALQUER coisa tocável e faz ela encolher enquanto o dedo
/// está em cima, voltando ao soltar.
///
/// DETALHE IMPORTANTE: este widget NÃO trata o toque. Ele usa um
/// `Listener`, que só escuta o dedo passar e não disputa o gesto com
/// ninguém. Assim, o InkWell (ou o botão) que está dentro continua
/// recebendo o toque normalmente — sem risco de a tela abrir duas vezes.
class ToqueQueAfunda extends StatefulWidget {
  final Widget child;
  final bool animar;

  /// Quanto encolhe no toque (0.97 = 3% menor).
  final double escala;

  const ToqueQueAfunda({
    super.key,
    required this.child,
    this.animar = true,
    this.escala = 0.97,
  });

  @override
  State<ToqueQueAfunda> createState() => _ToqueQueAfundaState();
}

class _ToqueQueAfundaState extends State<ToqueQueAfunda> {
  bool _pressionado = false;

  void _mudar(bool v) {
    if (!widget.animar || _pressionado == v || !mounted) return;
    setState(() => _pressionado = v);
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.animar) return widget.child;

    return Listener(
      onPointerDown: (_) => _mudar(true),
      onPointerUp: (_) => _mudar(false),
      onPointerCancel: (_) => _mudar(false),
      child: AnimatedScale(
        scale: _pressionado ? widget.escala : 1,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}
