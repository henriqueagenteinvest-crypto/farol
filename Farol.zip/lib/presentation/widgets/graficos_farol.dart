/// -----------------------------------------------------------------------
/// GRÁFICOS DO FAROL (fl_chart)
/// -----------------------------------------------------------------------
/// Todos os gráficos são INTERATIVOS: ao tocar em uma barra, fatia ou ponto,
/// aparece o valor exato em R$. As cores vêm sempre do tema escolhido, e as
/// animações respeitam o interruptor das configurações.
/// -----------------------------------------------------------------------
library;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../core/app_icons.dart';
import '../../theme/tema_farol.dart';
import '../../utils/formatters.dart';

// =======================================================================
// 1. GRÁFICO DE BARRAS — ganho por dia
// =======================================================================
class GraficoBarrasDias extends StatelessWidget {
  /// Lista de (dia, valor) já pronta, na ordem em que deve aparecer.
  final List<({DateTime dia, double lucro})> dados;
  final TemaFarol tema;
  final bool animar;
  final double altura;

  const GraficoBarrasDias({
    super.key,
    required this.dados,
    required this.tema,
    this.animar = true,
    this.altura = 180,
  });

  @override
  Widget build(BuildContext context) {
    if (dados.isEmpty) {
      return SizedBox(
        height: altura,
        child: Center(
          child: Text(
            'Sem dados para mostrar',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      );
    }

    // O topo do gráfico é 20% acima do maior valor, para a barra não
    // encostar no teto.
    final maior = dados
        .map((d) => d.lucro.abs())
        .fold<double>(0, (a, b) => a > b ? a : b);
    final topo = maior <= 0 ? 100.0 : maior * 1.2;

    return SizedBox(
      height: altura,
      child: BarChart(
        BarChartData(
          maxY: topo,
          minY: 0,
          alignment: BarChartAlignment.spaceAround,
          barTouchData: BarTouchData(
            enabled: true,
            touchTooltipData: BarTouchTooltipData(
              getTooltipColor: (_) => tema.superficieAlta,
              tooltipRoundedRadius: 10,
              tooltipPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 8,
              ),
              getTooltipItem: (grupo, indiceGrupo, barra, indiceBarra) {
                final item = dados[grupo.x];
                return BarTooltipItem(
                  '${Fmt.dataCurta(item.dia)}\n',
                  TextStyle(
                    color: tema.textoSuave,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                  children: <TextSpan>[
                    TextSpan(
                      text: Fmt.moeda(item.lucro),
                      style: TextStyle(
                        color: item.lucro >= 0 ? tema.sucesso : tema.erro,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            horizontalInterval: topo / 4,
            getDrawingHorizontalLine: (_) => FlLine(
              color: tema.textoSuave.withValues(alpha: 0.12),
              strokeWidth: 1,
            ),
          ),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            show: true,
            topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            leftTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                getTitlesWidget: (valor, meta) {
                  final i = valor.toInt();
                  if (i < 0 || i >= dados.length) return const SizedBox();
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      Fmt.diaSemana(dados[i].dia),
                      style: TextStyle(
                        color: tema.textoSuave,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          barGroups: <BarChartGroupData>[
            for (var i = 0; i < dados.length; i++)
              BarChartGroupData(
                x: i,
                barRods: <BarChartRodData>[
                  BarChartRodData(
                    toY: dados[i].lucro <= 0 ? 0.001 : dados[i].lucro,
                    width: 18,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(6),
                    ),
                    gradient: dados[i].lucro > 0
                        ? LinearGradient(
                            colors: tema.gradiente,
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          )
                        : null,
                    color: dados[i].lucro > 0
                        ? null
                        : tema.textoSuave.withValues(alpha: 0.25),
                    backDrawRodData: BackgroundBarChartRodData(
                      show: true,
                      toY: topo,
                      color: tema.superficieAlta.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
          ],
        ),
        duration: animar
            ? const Duration(milliseconds: 700)
            : Duration.zero,
        curve: Curves.easeOutCubic,
      ),
    );
  }
}

// =======================================================================
// 2. GRÁFICO DE LINHA — evolução ao longo do período
// =======================================================================
class GraficoLinhaEvolucao extends StatelessWidget {
  final List<({DateTime dia, double lucro})> dados;
  final TemaFarol tema;
  final bool animar;
  final double altura;

  const GraficoLinhaEvolucao({
    super.key,
    required this.dados,
    required this.tema,
    this.animar = true,
    this.altura = 200,
  });

  @override
  Widget build(BuildContext context) {
    if (dados.length < 2) {
      return SizedBox(
        height: altura,
        child: Center(
          child: Text(
            'Precisa de pelo menos 2 dias para desenhar a evolução',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      );
    }

    final valores = dados.map((d) => d.lucro).toList();
    final maior = valores.fold<double>(0, (a, b) => a > b ? a : b);
    final menor = valores.fold<double>(0, (a, b) => a < b ? a : b);
    final margem = ((maior - menor).abs() * 0.15).clamp(10.0, 1000.0);

    return SizedBox(
      height: altura,
      child: LineChart(
        LineChartData(
          minY: menor - margem,
          maxY: maior + margem,
          lineTouchData: LineTouchData(
            enabled: true,
            touchTooltipData: LineTouchTooltipData(
              getTooltipColor: (_) => tema.superficieAlta,
              tooltipRoundedRadius: 10,
              getTooltipItems: (pontos) => pontos.map((p) {
                final item = dados[p.x.toInt()];
                return LineTooltipItem(
                  '${Fmt.data(item.dia)}\n',
                  TextStyle(color: tema.textoSuave, fontSize: 11),
                  children: <TextSpan>[
                    TextSpan(
                      text: Fmt.moeda(item.lucro),
                      style: TextStyle(
                        color: tema.primaria,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (_) => FlLine(
              color: tema.textoSuave.withValues(alpha: 0.12),
              strokeWidth: 1,
            ),
          ),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            leftTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                // Mostra no máximo 6 rótulos para não embolar.
                interval: (dados.length / 6).ceilToDouble().clamp(1, 999),
                getTitlesWidget: (valor, meta) {
                  final i = valor.toInt();
                  if (i < 0 || i >= dados.length) return const SizedBox();
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      Fmt.dataCurta(dados[i].dia),
                      style: TextStyle(color: tema.textoSuave, fontSize: 10),
                    ),
                  );
                },
              ),
            ),
          ),
          lineBarsData: <LineChartBarData>[
            LineChartBarData(
              spots: <FlSpot>[
                for (var i = 0; i < dados.length; i++)
                  FlSpot(i.toDouble(), dados[i].lucro),
              ],
              isCurved: true,
              curveSmoothness: 0.3,
              barWidth: 3.5,
              gradient: LinearGradient(colors: tema.gradiente),
              dotData: FlDotData(
                show: dados.length <= 14,
                getDotPainter: (spot, pct, barra, i) => FlDotCirclePainter(
                  radius: 4,
                  color: tema.superficie,
                  strokeWidth: 2.5,
                  strokeColor: tema.primaria,
                ),
              ),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                    tema.primaria.withValues(alpha: 0.28),
                    tema.primaria.withValues(alpha: 0.0),
                  ],
                ),
              ),
            ),
          ],
        ),
        duration: animar
            ? const Duration(milliseconds: 700)
            : Duration.zero,
        curve: Curves.easeOutCubic,
      ),
    );
  }
}

// =======================================================================
// 3. GRÁFICO DE PIZZA — para onde foi o dinheiro
// =======================================================================
class GraficoPizzaGastos extends StatefulWidget {
  final Map<String, double> gastosPorCategoria;
  final TemaFarol tema;
  final bool animar;

  const GraficoPizzaGastos({
    super.key,
    required this.gastosPorCategoria,
    required this.tema,
    this.animar = true,
  });

  @override
  State<GraficoPizzaGastos> createState() => _GraficoPizzaGastosState();
}

class _GraficoPizzaGastosState extends State<GraficoPizzaGastos> {
  /// Índice da fatia que o dedo está tocando (-1 = nenhuma).
  int _tocada = -1;

  @override
  Widget build(BuildContext context) {
    final t = widget.tema;
    final textos = Theme.of(context).textTheme;

    final itens = widget.gastosPorCategoria.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    if (itens.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 28),
        child: Center(
          child: Text(
            'Nenhum gasto lançado neste período',
            style: textos.bodySmall,
          ),
        ),
      );
    }

    final total = itens.fold<double>(0, (a, e) => a + e.value);

    return Column(
      children: <Widget>[
        SizedBox(
          height: 210,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2.5,
              centerSpaceRadius: 52,
              startDegreeOffset: -90,
              pieTouchData: PieTouchData(
                enabled: true,
                touchCallback: (evento, resposta) {
                  setState(() {
                    if (!evento.isInterestedForInteractions ||
                        resposta == null ||
                        resposta.touchedSection == null) {
                      _tocada = -1;
                      return;
                    }
                    _tocada = resposta.touchedSection!.touchedSectionIndex;
                  });
                },
              ),
              sections: <PieChartSectionData>[
                for (var i = 0; i < itens.length; i++)
                  PieChartSectionData(
                    value: itens[i].value,
                    // A fatia tocada cresce e mostra o valor em R$.
                    radius: _tocada == i ? 62 : 52,
                    color: AppIcons.porCategoria(itens[i].key).cor,
                    title: _tocada == i
                        ? Fmt.moeda(itens[i].value)
                        : (itens[i].value / total >= 0.08
                            ? '${(itens[i].value / total * 100).round()}%'
                            : ''),
                    titleStyle: TextStyle(
                      fontSize: _tocada == i ? 12 : 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      shadows: const <Shadow>[
                        Shadow(color: Colors.black54, blurRadius: 3),
                      ],
                    ),
                  ),
              ],
            ),
            duration: widget.animar
                ? const Duration(milliseconds: 500)
                : Duration.zero,
          ),
        ),
        const SizedBox(height: 16),
        // ---- Legenda tocável ----
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            for (var i = 0; i < itens.length; i++)
              GestureDetector(
                onTap: () => setState(() => _tocada = _tocada == i ? -1 : i),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: _tocada == i
                        ? AppIcons.porCategoria(itens[i].key)
                            .cor
                            .withValues(alpha: 0.18)
                        : t.superficieAlta,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: _tocada == i
                          ? AppIcons.porCategoria(itens[i].key).cor
                          : Colors.transparent,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: AppIcons.porCategoria(itens[i].key).cor,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 7),
                      Text(itens[i].key, style: textos.bodySmall),
                      const SizedBox(width: 6),
                      Text(
                        Fmt.moeda(itens[i].value),
                        style: textos.bodySmall?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: t.texto,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

// =======================================================================
// 4. MINI GRÁFICO DA TELA INICIAL (7 dias, bem compacto)
// =======================================================================
class MiniGrafico7Dias extends StatelessWidget {
  final List<({DateTime dia, double lucro})> dados;
  final TemaFarol tema;
  final bool animar;

  const MiniGrafico7Dias({
    super.key,
    required this.dados,
    required this.tema,
    this.animar = true,
  });

  @override
  Widget build(BuildContext context) {
    final maior = dados
        .map((d) => d.lucro)
        .fold<double>(0, (a, b) => a > b ? a : b);

    return SizedBox(
      height: 76,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          for (final d in dados)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    // A barra cresce de baixo para cima ao entrar na tela.
                    TweenAnimationBuilder<double>(
                      tween: Tween<double>(
                        begin: 0,
                        end: maior <= 0
                            ? 0.03
                            : (d.lucro / maior).clamp(0.03, 1.0),
                      ),
                      duration: animar
                          ? const Duration(milliseconds: 650)
                          : Duration.zero,
                      curve: Curves.easeOutCubic,
                      builder: (context, fator, _) => Container(
                        height: 48 * fator,
                        decoration: BoxDecoration(
                          gradient: d.lucro > 0
                              ? LinearGradient(
                                  colors: tema.gradiente,
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                )
                              : null,
                          color: d.lucro > 0
                              ? null
                              : tema.textoSuave.withValues(alpha: 0.22),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      Fmt.diaSemana(d.dia),
                      style: TextStyle(
                        color: tema.textoSuave,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
