/// -----------------------------------------------------------------------
/// COMEMORAÇÃO DE META BATIDA
/// -----------------------------------------------------------------------
/// Confete caindo + som + mensagem. Só aparece uma vez por dia e respeita
/// os interruptores de animação e de som das configurações.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';

import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';

class ConfeteMeta extends StatefulWidget {
  /// Vira true no momento em que a meta é batida.
  final bool comemorar;
  final TemaFarol tema;
  final bool animacoesAtivas;

  /// Chamado depois da comemoração, para o app não repetir.
  final VoidCallback? aoTerminar;

  const ConfeteMeta({
    super.key,
    required this.comemorar,
    required this.tema,
    this.animacoesAtivas = true,
    this.aoTerminar,
  });

  @override
  State<ConfeteMeta> createState() => _ConfeteMetaState();
}

class _ConfeteMetaState extends State<ConfeteMeta> {
  late final ConfettiController _controle;
  bool _jaDisparou = false;

  @override
  void initState() {
    super.initState();
    _controle = ConfettiController(duration: const Duration(seconds: 3));
    if (widget.comemorar) _disparar();
  }

  @override
  void didUpdateWidget(covariant ConfeteMeta anterior) {
    super.didUpdateWidget(anterior);
    // Só dispara na TRANSIÇÃO de "não bateu" para "bateu".
    if (widget.comemorar && !anterior.comemorar) _disparar();
  }

  void _disparar() {
    if (_jaDisparou) return;
    _jaDisparou = true;
    // O som e a vibração acontecem mesmo com as animações desligadas —
    // o motorista merece saber que bateu a meta de qualquer jeito.
    AudioService.comemorar();
    if (widget.animacoesAtivas) _controle.play();
    Future<void>.delayed(const Duration(seconds: 4), () {
      if (mounted) widget.aoTerminar?.call();
    });
  }

  @override
  void dispose() {
    _controle.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.animacoesAtivas) return const SizedBox.shrink();

    return IgnorePointer(
      child: Align(
        alignment: Alignment.topCenter,
        child: ConfettiWidget(
          confettiController: _controle,
          blastDirection: math.pi / 2, // para baixo
          blastDirectionality: BlastDirectionality.explosive,
          emissionFrequency: 0.05,
          numberOfParticles: 18,
          maxBlastForce: 22,
          minBlastForce: 8,
          gravity: 0.25,
          shouldLoop: false,
          colors: <Color>[
            widget.tema.primaria,
            widget.tema.secundaria,
            widget.tema.sucesso,
            widget.tema.alerta,
            Colors.white,
          ],
        ),
      ),
    );
  }
}
