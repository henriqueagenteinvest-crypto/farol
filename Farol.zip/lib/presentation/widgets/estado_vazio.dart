/// -----------------------------------------------------------------------
/// ESTADO VAZIO
/// -----------------------------------------------------------------------
/// Aparece quando ainda não há dados. Em vez de uma tela em branco, explica
/// o que fazer e oferece o botão da ação certa.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';
import 'botao_grande.dart';

class EstadoVazio extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String mensagem;
  final TemaFarol tema;
  final String? textoBotao;
  final IconData? iconeBotao;
  final VoidCallback? aoTocarBotao;

  const EstadoVazio({
    super.key,
    required this.icone,
    required this.titulo,
    required this.mensagem,
    required this.tema,
    this.textoBotao,
    this.iconeBotao,
    this.aoTocarBotao,
  });

  @override
  Widget build(BuildContext context) {
    final textos = Theme.of(context).textTheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: tema.primaria.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(icone, size: 44, color: tema.primaria),
            ),
            const SizedBox(height: 22),
            Text(
              titulo,
              textAlign: TextAlign.center,
              style: textos.headlineSmall,
            ),
            const SizedBox(height: 10),
            Text(
              mensagem,
              textAlign: TextAlign.center,
              style: textos.bodyMedium?.copyWith(color: tema.textoSuave),
            ),
            if (textoBotao != null && aoTocarBotao != null) ...<Widget>[
              const SizedBox(height: 26),
              BotaoGrande(
                texto: textoBotao!,
                icone: iconeBotao ?? Icons.add_rounded,
                aoTocar: aoTocarBotao!,
                tema: tema,
                altura: 56,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
