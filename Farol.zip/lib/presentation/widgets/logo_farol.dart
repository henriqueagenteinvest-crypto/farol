/// -----------------------------------------------------------------------
/// LOGO DO FAROL — desenhado em código (nenhuma imagem, nenhum arquivo)
/// -----------------------------------------------------------------------
/// Reproduz a identidade do app: um carro visto de frente com os faróis
/// acesos, em azul elétrico sobre fundo escuro, com o brilho ao redor.
/// Por ser desenhado, fica perfeito em qualquer tamanho de tela.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class LogoFarol extends StatelessWidget {
  final double tamanho;
  final TemaFarol tema;

  /// Quando false, desenha só o símbolo, sem o quadrado de fundo.
  final bool comFundo;

  const LogoFarol({
    super.key,
    required this.tema,
    this.tamanho = 88,
    this.comFundo = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: tamanho,
      height: tamanho,
      decoration: comFundo
          ? BoxDecoration(
              color: tema.ehEscuro
                  ? const Color(0xFF0B1120)
                  : tema.superficieAlta,
              borderRadius: BorderRadius.circular(tamanho * 0.26),
              boxShadow: tema.brilhoDe(tema.primaria),
            )
          : null,
      child: CustomPaint(
        painter: _PintorFarol(
          corCarro: tema.primaria,
          corFarol: tema.ehEscuro ? Colors.white : tema.texto,
        ),
      ),
    );
  }
}

class _PintorFarol extends CustomPainter {
  final Color corCarro;
  final Color corFarol;

  _PintorFarol({required this.corCarro, required this.corFarol});

  @override
  void paint(Canvas canvas, Size size) {
    final l = size.width;
    final a = size.height;

    final traco = Paint()
      ..color = corCarro
      ..style = PaintingStyle.stroke
      ..strokeWidth = l * 0.055
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // ---- Teto / para-brisa (trapézio arredondado) ----
    final teto = Path()
      ..moveTo(l * 0.245, a * 0.545)
      ..lineTo(l * 0.325, a * 0.335)
      ..quadraticBezierTo(l * 0.345, a * 0.295, l * 0.395, a * 0.295)
      ..lineTo(l * 0.605, a * 0.295)
      ..quadraticBezierTo(l * 0.655, a * 0.295, l * 0.675, a * 0.335)
      ..lineTo(l * 0.755, a * 0.545);
    canvas.drawPath(teto, traco);

    // ---- Linha do capô ----
    canvas.drawLine(
      Offset(l * 0.225, a * 0.545),
      Offset(l * 0.775, a * 0.545),
      traco,
    );

    // ---- Retrovisores ----
    final espelho = Paint()
      ..color = corCarro
      ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(l * 0.135, a * 0.435, l * 0.105, a * 0.055),
        Radius.circular(l * 0.03),
      ),
      espelho,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(l * 0.76, a * 0.435, l * 0.105, a * 0.055),
        Radius.circular(l * 0.03),
      ),
      espelho,
    );

    // ---- OS FARÓIS ACESOS (a alma do app) ----
    // Brilho: uma camada borrada por trás de cada farol.
    final brilho = Paint()
      ..color = corFarol.withValues(alpha: 0.55)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

    final farolEsq = Path()
      ..moveTo(l * 0.225, a * 0.575)
      ..lineTo(l * 0.395, a * 0.615)
      ..lineTo(l * 0.375, a * 0.665)
      ..lineTo(l * 0.235, a * 0.645)
      ..close();

    final farolDir = Path()
      ..moveTo(l * 0.775, a * 0.575)
      ..lineTo(l * 0.605, a * 0.615)
      ..lineTo(l * 0.625, a * 0.665)
      ..lineTo(l * 0.765, a * 0.645)
      ..close();

    canvas.drawPath(farolEsq, brilho);
    canvas.drawPath(farolDir, brilho);

    final luz = Paint()..color = corFarol;
    canvas.drawPath(farolEsq, luz);
    canvas.drawPath(farolDir, luz);

    // ---- Para-choque ----
    final paraChoque = Path()
      ..moveTo(l * 0.335, a * 0.775)
      ..quadraticBezierTo(l * 0.355, a * 0.735, l * 0.405, a * 0.735)
      ..lineTo(l * 0.595, a * 0.735)
      ..quadraticBezierTo(l * 0.645, a * 0.735, l * 0.665, a * 0.775);
    canvas.drawPath(paraChoque, traco);
  }

  @override
  bool shouldRepaint(covariant _PintorFarol antigo) =>
      antigo.corCarro != corCarro || antigo.corFarol != corFarol;
}
