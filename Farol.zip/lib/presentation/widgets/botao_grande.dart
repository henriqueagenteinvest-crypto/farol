/// -----------------------------------------------------------------------
/// BOTÃO GRANDE
/// -----------------------------------------------------------------------
/// Pensado para quem está no carro: alvo largo, letras grandes, alto
/// contraste. É o botão principal da tela inicial e do controle de jornada.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../services/audio_service.dart';
import '../../theme/app_theme_builder.dart';
import '../../theme/tema_farol.dart';

class BotaoGrande extends StatefulWidget {
  final String texto;
  final IconData icone;
  final VoidCallback aoTocar;
  final TemaFarol tema;

  /// Cor sólida do botão. Quando nulo, usa o gradiente da marca.
  final Color? cor;

  final bool habilitado;
  final double altura;

  const BotaoGrande({
    super.key,
    required this.texto,
    required this.icone,
    required this.aoTocar,
    required this.tema,
    this.cor,
    this.habilitado = true,
    this.altura = 64,
  });

  @override
  State<BotaoGrande> createState() => _BotaoGrandeState();
}

class _BotaoGrandeState extends State<BotaoGrande> {
  bool _pressionado = false;

  @override
  Widget build(BuildContext context) {
    final t = widget.tema;
    final corBase = widget.cor ?? t.primaria;
    final corTexto = AppThemeBuilder.textoSobre(corBase);
    final ativo = widget.habilitado;

    return GestureDetector(
      onTapDown: ativo ? (_) => setState(() => _pressionado = true) : null,
      onTapUp: ativo ? (_) => setState(() => _pressionado = false) : null,
      onTapCancel: ativo ? () => setState(() => _pressionado = false) : null,
      onTap: ativo
          ? () {
              AudioService.clique();
              widget.aoTocar();
            }
          : null,
      child: AnimatedScale(
        // Leve "afundada" ao apertar: dá a sensação física de botão.
        scale: _pressionado ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: Container(
          height: widget.altura,
          width: double.infinity,
          decoration: BoxDecoration(
            color: widget.cor != null
                ? (ativo ? corBase : corBase.withValues(alpha: 0.4))
                : null,
            gradient: widget.cor == null && ativo ? t.gradienteLinear : null,
            borderRadius: BorderRadius.circular(t.raioBorda),
            boxShadow: ativo ? t.brilhoDe(corBase) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(widget.icone, color: corTexto, size: 26),
              const SizedBox(width: 12),
              Flexible(
                child: Text(
                  widget.texto,
                  style: TextStyle(
                    color: corTexto,
                    fontSize: 17.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.2,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
