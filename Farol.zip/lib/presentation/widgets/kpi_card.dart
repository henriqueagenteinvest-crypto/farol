/// -----------------------------------------------------------------------
/// CARTÃO DE INDICADOR (KPI)
/// -----------------------------------------------------------------------
/// Mostra um número grande com um rótulo curto. O número entra na tela
/// contando de zero até o valor final quando as animações estão ligadas.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';
import 'cartao_farol.dart';

class KpiCard extends StatelessWidget {
  final String rotulo;
  final String valor;
  final IconData icone;
  final Color cor;
  final TemaFarol tema;
  final String? complemento;
  final VoidCallback? aoTocar;

  /// Deixa o cartão mais alto e o número maior (usado no KPI principal).
  final bool destaque;

  const KpiCard({
    super.key,
    required this.rotulo,
    required this.valor,
    required this.icone,
    required this.cor,
    required this.tema,
    this.complemento,
    this.aoTocar,
    this.destaque = false,
  });

  @override
  Widget build(BuildContext context) {
    final textos = Theme.of(context).textTheme;

    return CartaoFarol(
      tema: tema,
      aoTocar: aoTocar,
      padding: EdgeInsets.all(destaque ? 18 : 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: cor.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icone, size: destaque ? 20 : 17, color: cor),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  rotulo,
                  style: textos.labelSmall,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          SizedBox(height: destaque ? 14 : 10),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              valor,
              style: (destaque ? textos.displaySmall : textos.headlineSmall)
                  ?.copyWith(color: cor, fontWeight: FontWeight.w700),
            ),
          ),
          if (complemento != null) ...<Widget>[
            const SizedBox(height: 4),
            Text(
              complemento!,
              style: textos.bodySmall,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );
  }
}
