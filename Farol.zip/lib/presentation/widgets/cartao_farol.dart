/// -----------------------------------------------------------------------
/// CARTÃO PADRÃO DO APP
/// -----------------------------------------------------------------------
/// Todo bloco de conteúdo do Farol usa este cartão, garantindo que sombra,
/// arredondamento e cores mudem juntos quando o motorista troca de tema.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class CartaoFarol extends StatelessWidget {
  final Widget child;
  final TemaFarol tema;
  final EdgeInsetsGeometry padding;
  final VoidCallback? aoTocar;

  /// Quando true, o cartão recebe o gradiente da marca.
  final bool comGradiente;

  /// Cor de destaque da borda esquerda (opcional).
  final Color? corBorda;

  const CartaoFarol({
    super.key,
    required this.child,
    required this.tema,
    this.padding = const EdgeInsets.all(16),
    this.aoTocar,
    this.comGradiente = false,
    this.corBorda,
  });

  @override
  Widget build(BuildContext context) {
    // VISUAL v2: contorno fino em vez de sombra pesada. Além de ficar
    // mais limpo, sombra custa caro para o celular desenhar — e esta
    // tela tem dezenas de cartões.
    final conteudo = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: comGradiente ? null : tema.superficie,
        gradient: comGradiente ? tema.gradienteLinear : null,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        boxShadow: comGradiente ? tema.brilhoDe(tema.primaria) : null,
        border: comGradiente
            ? null
            : (corBorda == null
                ? Border.all(color: tema.divisor)
                : Border(
                    left: BorderSide(color: corBorda!, width: 3),
                    top: BorderSide(color: tema.divisor),
                    right: BorderSide(color: tema.divisor),
                    bottom: BorderSide(color: tema.divisor),
                  )),
      ),
      child: child,
    );

    if (aoTocar == null) return conteudo;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: aoTocar,
        borderRadius: BorderRadius.circular(tema.raioBorda),
        child: conteudo,
      ),
    );
  }
}
