/// -----------------------------------------------------------------------
/// BARRA DE PROGRESSO DA META
/// -----------------------------------------------------------------------
/// Mostra o quanto da meta do dia já foi batido, com animação suave.
/// Quando bate 100%, muda de cor e ganha um brilho.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../services/calculations_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/formatters.dart';

class BarraMeta extends StatelessWidget {
  final double realizado;
  final double meta;
  final TemaFarol tema;
  final bool animar;
  final String titulo;

  const BarraMeta({
    super.key,
    required this.realizado,
    required this.meta,
    required this.tema,
    this.animar = true,
    this.titulo = 'Meta do dia',
  });

  @override
  Widget build(BuildContext context) {
    final textos = Theme.of(context).textTheme;

    // Os números vêm do serviço de cálculo — a tela não faz conta.
    final progresso = CalculationsService.progressoMeta(
      realizado: realizado,
      meta: meta,
    );
    final percentual = CalculationsService.percentualMeta(
      realizado: realizado,
      meta: meta,
    );
    final bateu = CalculationsService.metaAtingida(
      realizado: realizado,
      meta: meta,
    );
    final falta = CalculationsService.faltaParaMeta(
      realizado: realizado,
      meta: meta,
    );

    final cor = bateu ? tema.sucesso : tema.primaria;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(
                  bateu ? Icons.emoji_events_rounded : Icons.flag_rounded,
                  size: 17,
                  color: cor,
                ),
                const SizedBox(width: 7),
                Text(titulo, style: textos.labelMedium),
              ],
            ),
            Text(
              Fmt.percentual(percentual, casas: 0),
              style: textos.titleMedium?.copyWith(
                color: cor,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        // ---- A barra ----
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: Stack(
            children: <Widget>[
              Container(height: 14, color: tema.superficieAlta),
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: progresso),
                duration: animar
                    ? const Duration(milliseconds: 900)
                    : Duration.zero,
                curve: Curves.easeOutCubic,
                builder: (context, valor, _) {
                  return FractionallySizedBox(
                    widthFactor: valor.clamp(0.0, 1.0),
                    child: Container(
                      height: 14,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: bateu
                              ? <Color>[tema.sucesso, tema.sucesso]
                              : tema.gradiente,
                        ),
                        borderRadius: BorderRadius.circular(99),
                        boxShadow: <BoxShadow>[
                          BoxShadow(
                            color: cor.withValues(alpha: 0.5),
                            blurRadius: 10,
                            spreadRadius: -2,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          bateu
              ? 'Meta batida! ${Fmt.moeda(realizado)} de ${Fmt.moeda(meta)}'
              : 'Faltam ${Fmt.moeda(falta)} para ${Fmt.moeda(meta)}',
          style: textos.bodySmall?.copyWith(
            color: bateu ? tema.sucesso : tema.textoSuave,
            fontWeight: bateu ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
