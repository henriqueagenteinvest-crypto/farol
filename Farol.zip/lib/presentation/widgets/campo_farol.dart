/// -----------------------------------------------------------------------
/// CAMPOS DE FORMULÁRIO
/// -----------------------------------------------------------------------
/// Campos grandes, com rótulo claro e teclado certo para cada tipo de dado.
/// O motorista digita com o celular na mão, muitas vezes com pressa.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import '../../utils/formatters.dart';

/// Campo de texto genérico.
class CampoFarol extends StatelessWidget {
  final TextEditingController controlador;
  final String rotulo;
  final String? dica;
  final IconData? icone;
  final String? sufixo;
  final TextInputType tipoTeclado;
  final List<TextInputFormatter>? formatadores;
  final String? Function(String?)? validador;
  final void Function(String)? aoMudar;
  final int linhas;
  final bool ativo;
  final String? ajuda;
  final TextCapitalization capitalizacao;

  const CampoFarol({
    super.key,
    required this.controlador,
    required this.rotulo,
    this.dica,
    this.icone,
    this.sufixo,
    this.tipoTeclado = TextInputType.text,
    this.formatadores,
    this.validador,
    this.aoMudar,
    this.linhas = 1,
    this.ativo = true,
    this.ajuda,
    this.capitalizacao = TextCapitalization.sentences,
  });

  /// Atalho para campo de dinheiro (R$), já com máscara e teclado numérico.
  factory CampoFarol.dinheiro({
    Key? key,
    required TextEditingController controlador,
    required String rotulo,
    IconData icone = Icons.attach_money_rounded,
    String? Function(String?)? validador,
    void Function(String)? aoMudar,
    String? ajuda,
  }) {
    return CampoFarol(
      key: key,
      controlador: controlador,
      rotulo: rotulo,
      icone: icone,
      dica: '0,00',
      sufixo: 'R\$',
      tipoTeclado: const TextInputType.numberWithOptions(decimal: true),
      formatadores: <TextInputFormatter>[const MascaraMoeda()],
      validador: validador,
      aoMudar: aoMudar,
      ajuda: ajuda,
    );
  }

  /// Atalho para campo numérico com vírgula (KM, litros, horas).
  factory CampoFarol.decimal({
    Key? key,
    required TextEditingController controlador,
    required String rotulo,
    required IconData icone,
    String? sufixo,
    String? Function(String?)? validador,
    void Function(String)? aoMudar,
    String? ajuda,
  }) {
    return CampoFarol(
      key: key,
      controlador: controlador,
      rotulo: rotulo,
      icone: icone,
      sufixo: sufixo,
      dica: '0,00',
      tipoTeclado: const TextInputType.numberWithOptions(decimal: true),
      formatadores: <TextInputFormatter>[
        FilteringTextInputFormatter.allow(RegExp(r'[\d,.]')),
      ],
      validador: validador,
      aoMudar: aoMudar,
      ajuda: ajuda,
    );
  }

  /// Atalho para campo de número inteiro (corridas, ano).
  factory CampoFarol.inteiro({
    Key? key,
    required TextEditingController controlador,
    required String rotulo,
    required IconData icone,
    String? Function(String?)? validador,
    void Function(String)? aoMudar,
    String? ajuda,
  }) {
    return CampoFarol(
      key: key,
      controlador: controlador,
      rotulo: rotulo,
      icone: icone,
      dica: '0',
      tipoTeclado: TextInputType.number,
      formatadores: <TextInputFormatter>[
        FilteringTextInputFormatter.digitsOnly,
      ],
      validador: validador,
      aoMudar: aoMudar,
      ajuda: ajuda,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        TextFormField(
          controller: controlador,
          keyboardType: tipoTeclado,
          inputFormatters: formatadores,
          validator: validador,
          onChanged: aoMudar,
          maxLines: linhas,
          enabled: ativo,
          textCapitalization: capitalizacao,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          decoration: InputDecoration(
            labelText: rotulo,
            hintText: dica,
            prefixIcon: icone == null ? null : Icon(icone),
            suffixText: sufixo,
          ),
        ),
        if (ajuda != null)
          Padding(
            padding: const EdgeInsets.only(left: 14, top: 5),
            child: Text(
              ajuda!,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
      ],
    );
  }
}

/// -----------------------------------------------------------------------
/// SELETOR EM FORMA DE BOTÕES (em vez de menu suspenso)
/// -----------------------------------------------------------------------
/// Muito mais fácil de acertar com o dedo do que um dropdown pequeno.
/// -----------------------------------------------------------------------
class SeletorOpcoes extends StatelessWidget {
  final String rotulo;
  final List<String> opcoes;
  final String selecionada;
  final ValueChanged<String> aoSelecionar;
  final TemaFarol tema;

  const SeletorOpcoes({
    super.key,
    required this.rotulo,
    required this.opcoes,
    required this.selecionada,
    required this.aoSelecionar,
    required this.tema,
  });

  @override
  Widget build(BuildContext context) {
    final textos = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(rotulo, style: textos.labelMedium),
        const SizedBox(height: 9),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            for (final o in opcoes)
              GestureDetector(
                onTap: () {
                  AudioService.toqueLeve();
                  aoSelecionar(o);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: o == selecionada
                        ? tema.primaria
                        : tema.superficieAlta,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: o == selecionada
                          ? tema.primaria
                          : tema.textoSuave.withValues(alpha: 0.2),
                    ),
                  ),
                  child: Text(
                    o,
                    style: textos.titleMedium?.copyWith(
                      color: o == selecionada
                          ? (tema.primaria.computeLuminance() > 0.5
                              ? Colors.black
                              : Colors.white)
                          : tema.texto,
                      fontWeight: o == selecionada
                          ? FontWeight.w700
                          : FontWeight.w500,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

/// -----------------------------------------------------------------------
/// SELETOR DE DATA
/// -----------------------------------------------------------------------
class CampoData extends StatelessWidget {
  final DateTime data;
  final ValueChanged<DateTime> aoMudar;
  final String rotulo;
  final TemaFarol tema;

  const CampoData({
    super.key,
    required this.data,
    required this.aoMudar,
    required this.tema,
    this.rotulo = 'Data',
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(tema.raioBorda * 0.7),
      onTap: () async {
        AudioService.toqueLeve();
        final escolhida = await showDatePicker(
          context: context,
          initialDate: data,
          firstDate: DateTime(2020),
          lastDate: DateTime.now().add(const Duration(days: 1)),
          locale: const Locale('pt', 'BR'),
          helpText: 'Escolha a data',
          cancelText: 'Cancelar',
          confirmText: 'Confirmar',
        );
        if (escolhida != null) aoMudar(escolhida);
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: rotulo,
          prefixIcon: const Icon(Icons.calendar_today_rounded),
        ),
        child: Text(
          Fmt.data(data),
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
    );
  }
}

/// -----------------------------------------------------------------------
/// TÍTULO DE SEÇÃO
/// -----------------------------------------------------------------------
class TituloSecao extends StatelessWidget {
  final String texto;
  final IconData? icone;
  final Widget? acao;

  const TituloSecao({super.key, required this.texto, this.icone, this.acao});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 4),
      child: Row(
        children: <Widget>[
          if (icone != null) ...<Widget>[
            Icon(icone, size: 19, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 8),
          ],
          Expanded(
            child: Text(texto, style: Theme.of(context).textTheme.titleLarge),
          ),
          if (acao != null) acao!,
        ],
      ),
    );
  }
}
