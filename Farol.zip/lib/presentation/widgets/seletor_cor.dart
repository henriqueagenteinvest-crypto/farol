/// -----------------------------------------------------------------------
/// SELETOR DE COR — INFINITAS CORES
/// -----------------------------------------------------------------------
/// Antes o motorista escolhia entre nove cores prontas. Agora ele escolhe
/// QUALQUER cor: são três barras que, combinadas, dão mais de 16 milhões
/// de tons.
///
///   MATIZ   — o arco-íris: azul, verde, amarelo, laranja, vermelho, roxo
///   VIVEZA  — do cinza (cor lavada) até a cor no talo
///   CLARIDADE — do escuro até o claro
///
/// Quem não quiser mexer em nada continua tendo os atalhos de cores
/// prontas logo acima. E quem tiver a cor exata (a da empresa, por
/// exemplo) pode digitar o código dela, tipo #1F5CFF.
///
/// POR QUE TRÊS BARRAS E NÃO UM QUADRADO DE CORES: barra é muito mais
/// fácil de acertar com o dedo, ainda mais dirigindo o dia inteiro. Cada
/// uma mexe em uma coisa só, então dá para ajustar sem estragar o resto.
///
/// UM LIMITE DE PROPÓSITO: a claridade não desce até o preto. Uma cor
/// quase preta deixaria os botões e os textos do aplicativo ilegíveis.
/// O limite de baixo é o ponto em que o app ainda se lê bem.
///
/// A cor escolhida é guardada como código hexadecimal no Hive — do mesmo
/// jeito que já era. Nenhum dado do motorista muda por causa disso.
/// -----------------------------------------------------------------------
library;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../theme/tema_farol.dart';

/// A claridade mínima que ainda deixa o aplicativo legível.
const double _claridadeMinima = 0.32;

class SeletorCorInfinita extends StatefulWidget {
  final TemaFarol tema;

  /// A cor que está valendo agora.
  final Color cor;

  /// Chamado enquanto o dedo arrasta (para a tela acompanhar ao vivo).
  final ValueChanged<Color> aoMudar;

  const SeletorCorInfinita({
    super.key,
    required this.tema,
    required this.cor,
    required this.aoMudar,
  });

  @override
  State<SeletorCorInfinita> createState() => _SeletorCorInfinitaState();
}

class _SeletorCorInfinitaState extends State<SeletorCorInfinita> {
  late HSVColor _hsv;
  late final TextEditingController _codigo;

  /// Guarda o último aviso mandado para fora, para não gravar no disco
  /// 60 vezes por segundo enquanto o dedo arrasta.
  Timer? _espera;

  @override
  void initState() {
    super.initState();
    _hsv = HSVColor.fromColor(widget.cor);
    _codigo = TextEditingController(text: _hexDe(widget.cor));
  }

  @override
  void didUpdateWidget(SeletorCorInfinita antigo) {
    super.didUpdateWidget(antigo);
    // Alguém mudou a cor por fora (um atalho de cor pronta, por exemplo).
    if (widget.cor.toARGB32() != antigo.cor.toARGB32() &&
        widget.cor.toARGB32() != _hsv.toColor().toARGB32()) {
      _hsv = HSVColor.fromColor(widget.cor);
      _codigo.text = _hexDe(widget.cor);
    }
  }

  @override
  void dispose() {
    _espera?.cancel();
    _codigo.dispose();
    super.dispose();
  }

  static String _hexDe(Color c) =>
      '#${(c.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';

  Color get _corAtual => _hsv.toColor();

  /// Atualiza a cor. Com [agora] em true, avisa na hora (fim do arrasto);
  /// senão espera um instantinho, para não gravar a cada pixel.
  void _mudar(HSVColor novo, {bool agora = false}) {
    setState(() {
      _hsv = novo;
      _codigo.text = _hexDe(novo.toColor());
    });

    _espera?.cancel();
    if (agora) {
      widget.aoMudar(novo.toColor());
    } else {
      _espera = Timer(
        const Duration(milliseconds: 90),
        () => widget.aoMudar(_hsv.toColor()),
      );
    }
  }

  void _aplicarCodigo(String texto) {
    var t = texto.replaceAll('#', '').replaceAll(' ', '').trim();
    if (t.length == 3) {
      // Aceita a forma curta, tipo #09F.
      t = '${t[0]}${t[0]}${t[1]}${t[1]}${t[2]}${t[2]}';
    }
    if (t.length != 6) {
      _codigo.text = _hexDe(_corAtual);
      return;
    }
    final v = int.tryParse(t, radix: 16);
    if (v == null) {
      _codigo.text = _hexDe(_corAtual);
      return;
    }
    final escolhida = Color(0xFF000000 | v);
    final novo = HSVColor.fromColor(escolhida);
    _mudar(
      novo.withValue(novo.value.clamp(_claridadeMinima, 1.0)),
      agora: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final tema = widget.tema;
    final cor = _corAtual;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        // ---------------- A COR ESCOLHIDA ----------------
        Row(
          children: <Widget>[
            AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: cor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: tema.divisor),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: cor.withValues(alpha: 0.45),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: TextField(
                controller: _codigo,
                textCapitalization: TextCapitalization.characters,
                maxLength: 7,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(
                    RegExp('[0-9a-fA-F#]'),
                  ),
                ],
                decoration: InputDecoration(
                  labelText: 'Código da cor',
                  counterText: '',
                  helperText: 'Ex.: #1F5CFF',
                  helperStyle: TextStyle(
                    color: tema.textoSuave,
                    fontSize: 11,
                  ),
                  isDense: true,
                ),
                style: tema.numero(tamanho: 15, espacamento: 0.5),
                onSubmitted: _aplicarCodigo,
                onEditingComplete: () => _aplicarCodigo(_codigo.text),
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),

        // ---------------- MATIZ (o arco-íris) ----------------
        _Barra(
          tema: tema,
          rotulo: 'Matiz',
          valor: _hsv.hue / 360,
          bolinha: HSVColor.fromAHSV(1, _hsv.hue, 1, 1).toColor(),
          cores: <Color>[
            for (var i = 0; i <= 6; i++)
              HSVColor.fromAHSV(1, (i * 60).toDouble() % 360, 1, 1).toColor(),
          ],
          aoMudar: (v, fim) => _mudar(
            _hsv.withHue((v * 360).clamp(0.0, 359.99)),
            agora: fim,
          ),
        ),
        const SizedBox(height: 16),

        // ---------------- VIVEZA ----------------
        _Barra(
          tema: tema,
          rotulo: 'Viveza',
          valor: _hsv.saturation,
          bolinha: cor,
          cores: <Color>[
            HSVColor.fromAHSV(1, _hsv.hue, 0, _hsv.value).toColor(),
            HSVColor.fromAHSV(1, _hsv.hue, 1, _hsv.value).toColor(),
          ],
          aoMudar: (v, fim) => _mudar(
            _hsv.withSaturation(v.clamp(0.0, 1.0)),
            agora: fim,
          ),
        ),
        const SizedBox(height: 16),

        // ---------------- CLARIDADE ----------------
        _Barra(
          tema: tema,
          rotulo: 'Claridade',
          valor: (_hsv.value - _claridadeMinima) / (1 - _claridadeMinima),
          bolinha: cor,
          cores: <Color>[
            HSVColor.fromAHSV(1, _hsv.hue, _hsv.saturation, _claridadeMinima)
                .toColor(),
            HSVColor.fromAHSV(1, _hsv.hue, _hsv.saturation, 1).toColor(),
          ],
          aoMudar: (v, fim) => _mudar(
            _hsv.withValue(
              (_claridadeMinima + v * (1 - _claridadeMinima))
                  .clamp(_claridadeMinima, 1.0),
            ),
            agora: fim,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Icon(Icons.palette_rounded, size: 15, color: tema.textoSuave),
            const SizedBox(width: 7),
            Expanded(
              child: Text(
                'Arraste as barras para criar a sua cor. A tela inteira '
                'muda junto, na hora.',
                style: TextStyle(color: tema.textoSuave, fontSize: 12),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// =======================================================================
// UMA BARRA DE ESCOLHA
// =======================================================================
/// Uma faixa colorida com uma bolinha em cima. Toque em qualquer ponto
/// ou arraste: a bolinha vai junto com o dedo.
///
/// A altura é generosa de propósito (30 pixels de alvo de toque): dedo
/// grosso e tela pequena precisam de espaço para acertar.
class _Barra extends StatelessWidget {
  final TemaFarol tema;
  final String rotulo;

  /// De 0 a 1: onde a bolinha está.
  final double valor;

  /// As cores que a faixa mostra, da esquerda para a direita.
  final List<Color> cores;

  /// A cor da bolinha.
  final Color bolinha;

  /// Avisa o novo valor. O segundo parâmetro é `true` quando o dedo
  /// saiu da tela (aí a escolha é gravada de verdade).
  final void Function(double valor, bool fim) aoMudar;

  const _Barra({
    required this.tema,
    required this.rotulo,
    required this.valor,
    required this.cores,
    required this.bolinha,
    required this.aoMudar,
  });

  @override
  Widget build(BuildContext context) {
    final v = valor.isFinite ? valor.clamp(0.0, 1.0) : 0.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          rotulo.toUpperCase(),
          style: TextStyle(
            color: tema.textoSuave,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 7),
        LayoutBuilder(
          builder: (context, limites) {
            final largura = limites.maxWidth;

            void avisar(double x, bool fim) {
              if (largura <= 0) return;
              aoMudar((x / largura).clamp(0.0, 1.0), fim);
            }

            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (d) => avisar(d.localPosition.dx, true),
              onHorizontalDragStart: (d) => avisar(d.localPosition.dx, false),
              onHorizontalDragUpdate: (d) =>
                  avisar(d.localPosition.dx, false),
              onHorizontalDragEnd: (_) => aoMudar(v, true),
              child: SizedBox(
                height: 30,
                width: largura,
                child: Stack(
                  alignment: Alignment.centerLeft,
                  children: <Widget>[
                    // A faixa colorida.
                    Container(
                      height: 16,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: tema.divisor),
                        gradient: LinearGradient(colors: cores),
                      ),
                    ),
                    // A bolinha, presa dentro da faixa.
                    Positioned(
                      left: (v * largura - 13).clamp(0.0, largura - 26),
                      child: Container(
                        width: 26,
                        height: 26,
                        decoration: BoxDecoration(
                          color: bolinha,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2.5),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.35),
                              blurRadius: 5,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
