/// -----------------------------------------------------------------------
/// SELETOR DE PERÍODO
/// -----------------------------------------------------------------------
/// É aqui que o motorista escolhe EXATAMENTE o que quer ver:
///
///   ANO ......... 2024, 2025, 2026, 2027, 2028...
///   MÊS ......... Janeiro a Dezembro (toca em Junho, vê Junho)
///   SEMANA ...... Semana 1, 2, 3, 4, 5 do mês, com as datas de cada uma
///   DIA ......... um calendário do mês: toca no dia 1, 2, 3...
///   TUDO ........ o histórico inteiro
///
/// As setas ‹ › andam para o período anterior ou seguinte sem precisar
/// escolher nada de novo, e o botão "Hoje" volta para o dia de hoje.
///
/// Este widget NÃO faz conta de dinheiro: ele só devolve o período que
/// foi escolhido. Quem calcula é sempre o CalculationsService.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

import '../../domain/entities/periodo_escolhido.dart';
import '../../services/audio_service.dart';
import '../../theme/tema_farol.dart';
import 'cartao_farol.dart';

class SeletorPeriodo extends StatelessWidget {
  final PeriodoEscolhido periodo;

  /// Os anos que aparecem para escolher.
  final List<int> anos;

  final TemaFarol tema;
  final ValueChanged<PeriodoEscolhido> aoMudar;

  /// Mostra (ou não) a opção "Tudo".
  final bool permitirTudo;

  const SeletorPeriodo({
    super.key,
    required this.periodo,
    required this.anos,
    required this.tema,
    required this.aoMudar,
    this.permitirTudo = true,
  });

  void _mudar(PeriodoEscolhido novo) {
    AudioService.toqueLeve();
    aoMudar(novo);
  }

  @override
  Widget build(BuildContext context) {
    final escopo = periodo.escopo;
    final podeAndar = escopo != EscopoPeriodo.tudo;

    return CartaoFarol(
      tema: tema,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // ---------- Linha de cima: ‹ período › ----------
          Row(
            children: <Widget>[
              _BotaoSeta(
                icone: Icons.chevron_left_rounded,
                dica: 'Período anterior',
                tema: tema,
                aoTocar: podeAndar ? () => _mudar(periodo.anterior) : null,
              ),
              Expanded(
                child: Column(
                  children: <Widget>[
                    Text(
                      periodo.rotulo,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Toque abaixo para trocar de período',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              _BotaoSeta(
                icone: Icons.chevron_right_rounded,
                dica: 'Próximo período',
                tema: tema,
                aoTocar: podeAndar ? () => _mudar(periodo.proximo) : null,
              ),
            ],
          ),
          const SizedBox(height: 12),

          // ---------- Tipo de recorte ----------
          _FaixaRolagem(
            children: <Widget>[
              for (final e in EscopoPeriodo.values)
                if (permitirTudo || e != EscopoPeriodo.tudo)
                  _Pilula(
                    texto: e.rotulo,
                    selecionado: escopo == e,
                    tema: tema,
                    aoTocar: () => _mudar(periodo.copiarCom(escopo: e)),
                  ),
            ],
          ),

          // ---------- MÊS E ANO (os dois menus) ----------
          if (escopo != EscopoPeriodo.tudo) ...<Widget>[
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                if (escopo != EscopoPeriodo.ano)
                  Expanded(
                    child: _Menu<int>(
                      tema: tema,
                      valor: periodo.mes,
                      itens: <int>[for (var m = 1; m <= 12; m++) m],
                      textoDe: PeriodoEscolhido.nomeMes,
                      aoMudar: (m) => _mudar(periodo.copiarCom(mes: m)),
                    ),
                  ),
                if (escopo != EscopoPeriodo.ano) const SizedBox(width: 10),
                Expanded(
                  child: _Menu<int>(
                    tema: tema,
                    valor: anos.contains(periodo.ano) ? periodo.ano : anos.last,
                    itens: anos,
                    textoDe: (a) => '$a',
                    aoMudar: (a) => _mudar(periodo.copiarCom(ano: a)),
                  ),
                ),
              ],
            ),
          ],

          // ---------- SEMANA DO MÊS ----------
          if (escopo == EscopoPeriodo.semana) ...<Widget>[
            const SizedBox(height: 12),
            _Rotulo(texto: 'Semana do mês', tema: tema),
            Column(
              children: <Widget>[
                for (final s in periodo.semanasDisponiveis)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: _LinhaSemana(
                      semana: s,
                      selecionada: periodo.semana == s.numero,
                      tema: tema,
                      aoTocar: () =>
                          _mudar(periodo.copiarCom(semana: s.numero)),
                    ),
                  ),
              ],
            ),
          ],

          // ---------- DIA (calendário do mês) ----------
          if (escopo == EscopoPeriodo.dia) ...<Widget>[
            const SizedBox(height: 12),
            _Rotulo(texto: 'Dia', tema: tema),
            const SizedBox(height: 4),
            _Calendario(
              periodo: periodo,
              tema: tema,
              aoEscolher: (d) => _mudar(periodo.copiarCom(dia: d)),
            ),
          ],

          // ---------- Voltar para hoje ----------
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () => _mudar(
                PeriodoEscolhido.hoje(escopo: escopo),
              ),
              icon: const Icon(Icons.today_rounded, size: 18),
              label: const Text('Voltar para hoje'),
            ),
          ),
        ],
      ),
    );
  }
}

// =======================================================================
// PEÇAS DA TELA
// =======================================================================

/// Faixa que rola para o lado, com espaçamento igual entre os itens.
class _FaixaRolagem extends StatelessWidget {
  final List<Widget> children;
  const _FaixaRolagem({required this.children});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: children.length,
        padding: EdgeInsets.zero,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) => Center(child: children[i]),
      ),
    );
  }
}

/// Um menu suspenso simples, do jeito que o motorista já conhece.
class _Menu<T> extends StatelessWidget {
  final TemaFarol tema;
  final T valor;
  final List<T> itens;
  final String Function(T) textoDe;
  final ValueChanged<T> aoMudar;

  const _Menu({
    required this.tema,
    required this.valor,
    required this.itens,
    required this.textoDe,
    required this.aoMudar,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: tema.superficieAlta,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tema.divisor),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          value: valor,
          isExpanded: true,
          borderRadius: BorderRadius.circular(12),
          dropdownColor: tema.superficieAlta,
          icon: Icon(Icons.expand_more_rounded, color: tema.textoSuave),
          style: TextStyle(
            color: tema.texto,
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
          items: <DropdownMenuItem<T>>[
            for (final i in itens)
              DropdownMenuItem<T>(value: i, child: Text(textoDe(i))),
          ],
          onChanged: (v) {
            if (v != null) aoMudar(v);
          },
        ),
      ),
    );
  }
}

class _Rotulo extends StatelessWidget {
  final String texto;
  final TemaFarol tema;
  const _Rotulo({required this.texto, required this.tema});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 2, left: 2),
      child: Text(
        texto.toUpperCase(),
        style: TextStyle(
          color: tema.textoSuave,
          fontSize: 10.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.1,
        ),
      ),
    );
  }
}

/// Botão redondo das setas ‹ ›.
class _BotaoSeta extends StatelessWidget {
  final IconData icone;
  final String dica;
  final TemaFarol tema;
  final VoidCallback? aoTocar;

  const _BotaoSeta({
    required this.icone,
    required this.dica,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    final ativo = aoTocar != null;
    return Semantics(
      button: true,
      label: dica,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(99),
          // 44x44: o mínimo para acertar com o dedo sem errar.
          child: SizedBox(
            width: 44,
            height: 44,
            child: Icon(
              icone,
              size: 26,
              color: ativo
                  ? tema.texto
                  : tema.textoSuave.withValues(alpha: 0.35),
            ),
          ),
        ),
      ),
    );
  }
}

/// Botão em formato de pílula (usado em escopo, ano e mês).
class _Pilula extends StatelessWidget {
  final String texto;
  final bool selecionado;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _Pilula({
    required this.texto,
    required this.selecionado,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionado,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(99),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOut,
            constraints: const BoxConstraints(minWidth: 56, minHeight: 38),
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: selecionado ? tema.primaria : tema.superficieAlta,
              borderRadius: BorderRadius.circular(99),
              border: Border.all(
                color: selecionado
                    ? tema.primaria
                    : tema.textoSuave.withValues(alpha: 0.18),
              ),
            ),
            child: Text(
              texto,
              style: TextStyle(
                color: selecionado ? tema.textoSobrePrimaria : tema.texto,
                fontSize: 13.5,
                fontWeight: selecionado ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Linha de uma semana do mês, com as datas que ela cobre.
class _LinhaSemana extends StatelessWidget {
  final SemanaDoMes semana;
  final bool selecionada;
  final TemaFarol tema;
  final VoidCallback aoTocar;

  const _LinhaSemana({
    required this.semana,
    required this.selecionada,
    required this.tema,
    required this.aoTocar,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selecionada,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: aoTocar,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            constraints: const BoxConstraints(minHeight: 46),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: selecionada
                  ? tema.primaria.withValues(alpha: 0.16)
                  : tema.superficieAlta,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selecionada
                    ? tema.primaria
                    : tema.textoSuave.withValues(alpha: 0.15),
                width: selecionada ? 1.6 : 1,
              ),
            ),
            child: Row(
              children: <Widget>[
                Icon(
                  selecionada
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_unchecked_rounded,
                  size: 19,
                  color: selecionada ? tema.primaria : tema.textoSuave,
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Text(
                    'Semana ${semana.numero}',
                    style: TextStyle(
                      color: tema.texto,
                      fontSize: 14.5,
                      fontWeight:
                          selecionada ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ),
                Text(
                  semana.intervaloCurto,
                  style: TextStyle(
                    color: selecionada ? tema.primaria : tema.textoSuave,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Calendário simples do mês selecionado, para escolher o dia.
class _Calendario extends StatelessWidget {
  final PeriodoEscolhido periodo;
  final TemaFarol tema;
  final ValueChanged<int> aoEscolher;

  const _Calendario({
    required this.periodo,
    required this.tema,
    required this.aoEscolher,
  });

  /// Cabeçalho: segunda a domingo (mesma ordem do calendário brasileiro
  /// impresso e do próprio Flutter).
  static const List<String> _diasSemana = <String>[
    'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom',
  ];

  @override
  Widget build(BuildContext context) {
    final totalDias = periodo.diasDisponiveis;
    final primeiro = DateTime(periodo.ano, periodo.mes, 1);

    // Quantas casas ficam vazias antes do dia 1.
    final vazios = primeiro.weekday - 1;

    final hoje = DateTime.now();
    final ehMesDeHoje =
        hoje.year == periodo.ano && hoje.month == periodo.mes;

    // O dia realmente selecionado (já protegido contra dia 31 em mês de 30).
    final diaSelecionado =
        periodo.dia > totalDias ? totalDias : periodo.dia;

    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            for (final d in _diasSemana)
              Expanded(
                child: Center(
                  child: Text(
                    d,
                    style: TextStyle(
                      color: tema.textoSuave,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          itemCount: vazios + totalDias,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7,
            mainAxisSpacing: 4,
            crossAxisSpacing: 4,
            childAspectRatio: 1,
          ),
          itemBuilder: (context, i) {
            if (i < vazios) return const SizedBox.shrink();

            final dia = i - vazios + 1;
            final selecionado = dia == diaSelecionado;
            final ehHoje = ehMesDeHoje && hoje.day == dia;

            return Semantics(
              button: true,
              selected: selecionado,
              label: 'Dia $dia',
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => aoEscolher(dia),
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selecionado
                          ? tema.primaria
                          : (ehHoje
                              ? tema.primaria.withValues(alpha: 0.14)
                              : tema.superficieAlta),
                      borderRadius: BorderRadius.circular(10),
                      border: ehHoje && !selecionado
                          ? Border.all(color: tema.primaria, width: 1.4)
                          : null,
                    ),
                    child: Text(
                      '$dia',
                      style: TextStyle(
                        color: selecionado
                            ? tema.textoSobrePrimaria
                            : tema.texto,
                        fontSize: 13.5,
                        fontWeight:
                            selecionado ? FontWeight.w700 : FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
