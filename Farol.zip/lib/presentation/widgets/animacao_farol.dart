/// -----------------------------------------------------------------------
/// A ABERTURA — A AVENIDA DE MADRUGADA E O CARRO DO FAROL
/// -----------------------------------------------------------------------
/// Ocupa a TELA INTEIRA, sem moldura e sem borda. É uma cena desenhada
/// quadro a quadro, e o carro é o MESMO do ícone do aplicativo.
///
/// O QUE ACONTECE (a animação vai de 0 a 1):
///
///   0.00 → 0.14   A avenida nasce: céu estrelado com a lua, os prédios
///                 da cidade lá no fundo com as janelas acesas, a bruma
///                 do horizonte, as árvores da beira, o asfalto com a
///                 textura e as marcas de pneu, as faixas, o guard-rail
///                 e os postes acesos.
///   0.05 → 0.62   O CARRO FAZ A CURVA. Entra do tamanho de um grão lá no
///                 fundo, NA FAIXA DELE, e vem vindo — crescendo porque
///                 chega perto e virando junto com a pista: no meio da
///                 curva aparece a lateral; no fim ele se endireita de
///                 frente para quem olha.
///   0.55 → 0.70   PISCA: dois lampejos, como quem gira a chave.
///   0.66 → 0.92   ACENDE: os faróis estouram de branco com o risco de
///                 luz atravessado, os cones se abrem na sua direção, o
///                 asfalto fica lavado e a luz se reflete no chão molhado.
///   0.78 → 1.00   O nome FAROL surge e o aplicativo abre.
///
/// AS CAMADAS DA CENA, do fundo para a frente
///
///   céu · estrelas · lua · duas fileiras de prédios · bruma · árvores ·
///   acostamento · asfalto · textura · marcas de pneu · faixas (bordas
///   brancas, dupla amarela do meio, tracejado das pistas e tachinhas
///   refletivas) · guard-rail · postes · lanternas de um carro distante ·
///   luz no chão · reflexo molhado · O CARRO · cones de luz · vinheta
///
/// O CARRO
///
/// É NEON, igual ao ícone: nenhuma imagem, nenhuma foto. Cada peça é uma
/// CURVA DE BÉZIER de verdade, com os pontos tirados do próprio ícone —
///
///   silhueta · cabine e para-brisa · brilho no vidro · sorriso do capô ·
///   vinco · faróis em cunha · grade com as barrinhas · placa · entradas
///   de ar com os faróis de neblina · rodas · espelhos
///
/// DESEMPENHO — como uma cena deste tamanho roda lisa em celular simples
///
///   • Os traços de neon não são borrados um a um: TODOS entram num
///     caminho só, e o borrão é feito UMA vez para o grupo inteiro.
///     São 6 desfoques no carro em vez de trinta.
///   • O mesmo vale para os postes: todas as lâmpadas num caminho, todas
///     as poças em outro. Dois desfoques para a avenida inteira.
///   • A textura do asfalto sai em duas chamadas de `drawPoints`, e não
///     em quatrocentos círculos.
///   • A cena inteira fica dentro de um RepaintBoundary, isolada do
///     resto da tela.
///   • Nada é sorteado: as estrelas, as janelas acesas e os grãos do
///     asfalto saem de contas fixas, então a abertura é sempre a mesma e
///     não pisca diferente a cada vez que o app abre.
///
/// E quem desliga "Animações" em Aparência nem chega a ver esta tela.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;
import 'dart:ui' as ui show PointMode;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class AnimacaoFarolLigando extends StatelessWidget {
  /// A animação que comanda tudo, de 0 a 1.
  final Animation<double> animacao;

  final TemaFarol tema;

  const AnimacaoFarolLigando({
    super.key,
    required this.animacao,
    required this.tema,
  });

  @override
  Widget build(BuildContext context) {
    // Sem tamanho fixo: a cena toma o espaço que o pai der. Na abertura,
    // isso é a tela inteira.
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: animacao,
        builder: (context, _) => CustomPaint(
          painter: _CenaDaAvenida(t: animacao.value, tema: tema),
          size: Size.infinite,
        ),
      ),
    );
  }
}

// =======================================================================
// A AVENIDA — as contas da pista
// =======================================================================
class Pista {
  Pista._();

  /// Onde fica a linha do horizonte, em fração da altura da tela.
  static const double horizonte = 0.335;

  /// Até onde o carro chega. Não vai até 1 de propósito: assim ele para
  /// com a avenida ainda aparecendo embaixo dele.
  static const double avancoMaximo = 0.675;

  /// O quanto o carro anda para o lado, dentro da faixa dele.
  ///
  /// É NEGATIVO porque um carro que vem na nossa direção anda na faixa
  /// que, para quem olha, fica à ESQUERDA da dupla amarela do meio.
  static const double faixaDoCarro = -0.42;

  // Os três pontos que definem o meio da avenida. O do meio é o que cria
  // a CURVA: puxa a pista para a direita antes de ela voltar ao centro.
  static Offset _longe(Size s) => Offset(s.width * 0.42, s.height * horizonte);
  static Offset _guia(Size s) => Offset(s.width * 0.97, s.height * 0.575);
  static Offset _perto(Size s) => Offset(s.width * 0.50, s.height * 1.00);

  /// O meio da pista na profundidade [p] — 0 é o fundo, 1 é bem perto.
  static Offset meio(double p, Size s) {
    final a = p.clamp(0.0, 1.0);
    final u = 1 - a;
    final l = _longe(s);
    final g = _guia(s);
    final n = _perto(s);
    return Offset(
      u * u * l.dx + 2 * u * a * g.dx + a * a * n.dx,
      u * u * l.dy + 2 * u * a * g.dy + a * a * n.dy,
    );
  }

  /// Metade da largura da avenida na profundidade [p].
  ///
  /// Longe é quase um risco; perto ela transborda a tela. O expoente 1.75
  /// é o que dá a perspectiva de verdade: cresce devagar no começo e
  /// dispara no fim.
  static double meiaLargura(double p, Size s) {
    final a = p.clamp(0.0, 1.0);
    return s.width * (0.010 + 1.06 * math.pow(a, 1.75));
  }

  /// O tamanho relativo das coisas na profundidade [p]: 0 lá no fundo,
  /// 1 na boca da tela. Serve para postes, árvores e guard-rail
  /// crescerem junto com a pista.
  static double escala(double p, Size s) =>
      meiaLargura(p, s) / meiaLargura(1.0, s);

  /// O quanto o carro aparece virado na profundidade [p], em radianos.
  static double viradaEm(double p, Size s) {
    final atras = meio((p - 0.16).clamp(0.0, 1.0), s);
    final aqui = meio(p, s);
    final dx = aqui.dx - atras.dx;
    final dy = aqui.dy - atras.dy;
    if (dy.abs() < 0.0001) return 0;

    // Quanto a pista anda para o lado comparado com o quanto ela vem
    // para frente. É a conta do volante.
    final bruto = math.atan2(dx, dy);

    // No máximo ~40 graus: mais do que isso some a frente do carro, e a
    // graça é justamente ver a frente virando.
    final limitado = bruto.clamp(-0.70, 0.70);

    // No último terço ele vai se endireitando, para terminar de frente.
    final endireitando =
        ((avancoMaximo - p) / (avancoMaximo * 0.32)).clamp(0.0, 1.0);
    return limitado * endireitando;
  }

  /// Onde o carro está na avenida no instante [t] da animação.
  static double avanco(double t) {
    final f = ((t - 0.05) / 0.57).clamp(0.0, 1.0);
    // Sai devagar, ganha velocidade no meio da curva e estaciona macio.
    return Curves.easeInOutCubic.transform(f) * avancoMaximo;
  }

  /// Força do farol (0 = apagado, 1 = aceso no talo).
  ///
  /// Os dois lampejos são de propósito: o brilho sobe e desce duas vezes
  /// antes de firmar — é o que faz parecer que alguém girou a chave.
  static double brilho(double t) {
    if (t < 0.55) return 0;
    if (t < 0.595) return 0.80; // primeiro lampejo
    if (t < 0.625) return 0.04; // apaga
    if (t < 0.670) return 0.95; // segundo lampejo
    if (t < 0.700) return 0.10; // apaga de novo
    final f = ((t - 0.700) / 0.22).clamp(0.0, 1.0);
    return Curves.easeOutCubic.transform(f);
  }

  /// Sequência fixa, entre 0 e 1, para espalhar estrelas, janelas acesas
  /// e grãos do asfalto.
  ///
  /// POR QUE NÃO SORTEIO: se fosse aleatório, a abertura sairia diferente
  /// a cada vez que o motorista abrisse o app — e uma marca que muda toda
  /// hora não vira marca. Com conta fixa, é sempre a mesma cena.
  static double espalhar(int i, int canal) {
    final base = canal == 0
        ? i * 0.7548776662 + i * i * 0.1234
        : i * 0.5698402909 + i * i * 0.3170;
    return base % 1.0;
  }
}

// =======================================================================
// AS MEDIDAS DO CARRO
// =======================================================================
/// Onde o carro está, que tamanho tem e o quanto está virado.
///
/// POR QUE ISTO EXISTE: o corpo, os faróis, os cones de luz e o reflexo
/// no asfalto precisam bater no MESMO ponto. A conta é feita uma vez,
/// aqui, e todo mundo usa — em vez de cada pedaço refazer por conta
/// própria e sair desencontrado.
class _MedidasDoCarro {
  /// Meio do carro na horizontal, já dentro da faixa dele.
  final double meio;

  /// Onde as rodas encostam no asfalto.
  final double baseY;

  /// Largura e altura do carro inteiro.
  final double largura;
  final double altura;

  /// De 1 (todo de frente) a 0 (todo de lado): o quanto a frente ainda
  /// aparece. É o que espreme o desenho na horizontal.
  final double espremer;

  /// Comprimento da lateral que aparece. Zero quando está de frente.
  final double lateral;

  const _MedidasDoCarro._({
    required this.meio,
    required this.baseY,
    required this.largura,
    required this.altura,
    required this.espremer,
    required this.lateral,
  });

  factory _MedidasDoCarro(Size size, double p) {
    final c = Pista.meio(p, size);
    final w = Pista.meiaLargura(p, size);
    final virada = Pista.viradaEm(p, size);

    // O carro ocupa um pouco mais do que a metade da pista — é a
    // proporção de um carro numa avenida de duas faixas.
    final largura = w * 1.02;
    final altura = largura * 0.74;

    // cos = o quanto ainda se vê da frente; sin = o quanto já se vê da
    // lateral. É toda a perspectiva da virada em duas contas.
    final frente = math.cos(virada).abs();
    final lado = math.sin(virada);

    return _MedidasDoCarro._(
      // O deslocamento da faixa acompanha a perspectiva: lá no fundo a
      // faixa é estreita, então ele quase não sai do meio; perto, ele
      // está claramente do lado dele da avenida.
      meio: c.dx + w * Pista.faixaDoCarro + largura * 0.20 * lado,
      baseY: c.dy + altura * 0.30,
      largura: largura,
      altura: altura,
      espremer: frente,
      lateral: largura * 0.92 * lado,
    );
  }

  /// Converte um ponto do desenho para a tela.
  ///
  /// [u] vai de -0.5 (esquerda do carro) a 0.5 (direita).
  /// [v] vai de 0 (chão, onde a roda encosta) a 1 (teto).
  Offset ponto(double u, double v) =>
      Offset(meio + u * largura * espremer, baseY - v * altura);

  /// A altura em que ficam os dois faróis.
  double get alturaDoFarol => baseY - altura * 0.545;

  /// De que lado aparece a lateral: -1 ou 1.
  double get ladoVisivel => lateral >= 0 ? 1.0 : -1.0;

  /// Onde ficam os dois faróis.
  List<Offset> get farois => <Offset>[
        Offset(meio - largura * espremer * 0.37, alturaDoFarol),
        Offset(meio + largura * espremer * 0.37, alturaDoFarol),
      ];
}

// =======================================================================
// O DESENHO DA CENA
// =======================================================================
class _CenaDaAvenida extends CustomPainter {
  final double t;
  final TemaFarol tema;

  const _CenaDaAvenida({required this.t, required this.tema});

  /// Em quantos pedaços a pista é fatiada para desenhar. Quanto mais,
  /// mais lisa a curva — 46 já não mostra canto nenhum na tela do
  /// celular e continua barato.
  static const int _passos = 46;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width < 8 || size.height < 8) return;

    final p = Pista.avanco(t);
    final brilho = Pista.brilho(t);
    // A cena inteira nasce junto, nos primeiros quadros.
    final ent = Curves.easeOut.transform((t / 0.14).clamp(0.0, 1.0));

    canvas.save();
    canvas.clipRect(Offset.zero & size);

    _ceu(canvas, size, ent);
    _estrelas(canvas, size, ent);
    _lua(canvas, size, ent);
    _skyline(canvas, size, ent);
    _bruma(canvas, size, ent);
    _arvores(canvas, size, ent);
    _acostamento(canvas, size, ent);
    _asfalto(canvas, size, ent);
    _textura(canvas, size, ent);
    _marcasDePneu(canvas, size, ent);
    _faixas(canvas, size, ent, p);
    _guardRail(canvas, size, ent);
    _postes(canvas, size, ent);
    _carroDistante(canvas, size, ent);

    // A luz no chão e o reflexo vêm ANTES do carro: assim passam por
    // baixo dele, como acontece de verdade.
    if (brilho > 0.01) {
      _luzNoChao(canvas, size, p, brilho);
      _reflexo(canvas, size, p, brilho);
    }

    _carro(canvas, size, p, brilho, ent);

    // Os cones vêm por último: a luz que vem na sua direção ofusca tudo
    // o que está atrás dela.
    if (brilho > 0.01) _cones(canvas, size, p, brilho);

    _vinheta(canvas, size, ent);
    canvas.restore();
  }

  // =====================================================================
  // O CÉU, AS ESTRELAS E A LUA
  // =====================================================================
  void _ceu(Canvas canvas, Size size, double ent) {
    final alturaCeu = size.height * Pista.horizonte + 2;
    final area = Rect.fromLTWH(0, 0, size.width, alturaCeu);
    canvas.drawRect(
      area,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            // Nunca preto puro: céu de cidade sempre tem um resto de luz.
            Color.lerp(tema.fundo, Colors.black, 0.45)!,
            Color.lerp(tema.fundo, tema.primaria, 0.22 * ent)!,
          ],
          stops: const <double>[0, 1],
        ).createShader(area),
    );
  }

  void _estrelas(Canvas canvas, Size size, double ent) {
    final limite = size.height * Pista.horizonte * 0.82;
    final tinta = Paint();
    for (var i = 0; i < 90; i++) {
      final x = Pista.espalhar(i, 0) * size.width;
      final y = Pista.espalhar(i, 1) * limite;
      // Perto do horizonte a estrela some na luz da cidade.
      final desbota = 1 - (y / (limite * 1.05));
      final a = (0.12 + ((i * 13) % 10) * 0.035) * ent * desbota;
      if (a <= 0) continue;
      tinta.color = tema.texto.withValues(alpha: a);
      canvas.drawCircle(
        Offset(x, y),
        0.5 + ((i * 7) % 4) * 0.22,
        tinta,
      );
    }
  }

  void _lua(Canvas canvas, Size size, double ent) {
    final r = size.width * 0.038;
    final centro = Offset(
      size.width * 0.80,
      size.height * Pista.horizonte * 0.24,
    );
    // O halo primeiro, borrado, depois o disco.
    canvas.drawCircle(
      centro,
      r * 2.8,
      Paint()
        ..color = const Color(0xFFD2E1FF).withValues(alpha: 0.10 * ent)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * 1.2),
    );
    canvas.drawCircle(
      centro,
      r,
      Paint()..color = const Color(0xFFE2EAFA).withValues(alpha: 0.82 * ent),
    );
    // A mancha da lua, que tira o ar de bolinha perfeita.
    canvas.drawCircle(
      centro.translate(-r * 0.18, 0.02 * r),
      r * 0.34,
      Paint()..color = const Color(0xFFC4D0E8).withValues(alpha: 0.45 * ent),
    );
  }

  // =====================================================================
  // OS PRÉDIOS — duas fileiras, para dar profundidade
  // =====================================================================
  void _skyline(Canvas canvas, Size size, double ent) {
    // A de trás é mais apagada e não tem janela: some na distância.
    _fileiraDePredios(
      canvas,
      size,
      ent,
      const <double>[
        0.062, 0.040, 0.088, 0.052, 0.104, 0.046, 0.070, 0.036, 0.094,
        0.058, 0.042,
      ],
      Color.lerp(tema.fundo, tema.texto, 0.075 * ent)!,
      -6,
      janelas: false,
    );
    _fileiraDePredios(
      canvas,
      size,
      ent,
      const <double>[
        0.044, 0.082, 0.030, 0.100, 0.055, 0.126, 0.038, 0.070, 0.090,
        0.034,
      ],
      Color.lerp(tema.fundo, tema.texto, 0.13 * ent)!,
      4,
      janelas: true,
    );
  }

  void _fileiraDePredios(
    Canvas canvas,
    Size size,
    double ent,
    List<double> alturas,
    Color cor,
    double desloc, {
    required bool janelas,
  }) {
    final baseY = size.height * Pista.horizonte;
    final largura = size.width / alturas.length;
    final tinta = Paint()..color = cor;
    final luz = Paint()
      ..color = tema.alerta.withValues(alpha: 0.45 * ent);

    for (var i = 0; i < alturas.length; i++) {
      final h = size.height * alturas[i];
      final x = i * largura + desloc;
      if (x > size.width) continue;
      canvas.drawRect(
        Rect.fromLTWH(x + 1, baseY - h, largura - 2, h),
        tinta,
      );
      // A antena dos prédios mais altos.
      if (alturas[i] > 0.085) {
        canvas.drawRect(
          Rect.fromLTWH(
            x + largura * 0.5,
            baseY - h - size.height * 0.016,
            1.2,
            size.height * 0.016,
          ),
          tinta,
        );
      }
      if (!janelas) continue;

      // As janelas acesas: uma grade, com um padrão fixo decidindo
      // quais estão acesas. Sem sorteio — a cidade é sempre a mesma.
      final colunas = math.max(1, (largura / 7).floor());
      final linhas = math.max(1, (h / 9).floor());
      for (var c = 0; c < colunas; c++) {
        for (var l = 0; l < linhas; l++) {
          if ((i * 31 + c * 17 + l * 13) % 5 != 0) continue;
          final jx = x + 4 + c * 7;
          final jy = baseY - h + 5 + l * 9;
          if (jx + 3 >= x + largura - 2) continue;
          if (jy <= baseY - h + 2 || jy >= baseY - 5) continue;
          canvas.drawRect(Rect.fromLTWH(jx, jy, 2.6, 3.4), luz);
        }
      }
    }
  }

  /// A bruma do horizonte: a faixa embaçada onde a cidade encontra a
  /// avenida. É ela que dá a sensação de distância de verdade.
  void _bruma(Canvas canvas, Size size, double ent) {
    final hy = size.height * Pista.horizonte;
    canvas.drawRect(
      Rect.fromLTRB(0, hy - size.height * 0.035, size.width,
          hy + size.height * 0.02),
      Paint()
        ..color = Color.lerp(tema.fundo, tema.primaria, 0.45)!
            .withValues(alpha: 0.30 * ent)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
    );
  }

  /// As árvores da beira da avenida. Silhuetas simples — tronco e copa —
  /// que crescem junto com a perspectiva da pista.
  void _arvores(Canvas canvas, Size size, double ent) {
    final tinta = Paint()
      ..color = Color.lerp(tema.fundo, tema.texto, 0.085 * ent)!;
    for (var i = 0; i < 14; i++) {
      final d = 0.03 + (i % 7) * 0.135 + (i >= 7 ? 0.06 : 0.0);
      if (d > 0.98) continue;
      final lado = i.isEven ? -1.0 : 1.0;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final e = Pista.escala(d, size);
      final x = c.dx + lado * w * (1.20 + 0.06 * ((i * 5) % 3));
      if (x < -40 || x > size.width + 40) continue;

      final altura = size.height * 0.055 * e * (0.7 + 0.25 * ((i * 3) % 3));
      final raio = altura * 0.42;
      canvas.drawRect(
        Rect.fromLTWH(
          x - raio * 0.08,
          c.dy - altura * 0.45,
          math.max(1.0, raio * 0.16),
          altura * 0.45,
        ),
        tinta,
      );
      canvas.drawOval(
        Rect.fromLTRB(
          x - raio,
          c.dy - altura,
          x + raio,
          c.dy - altura * 0.30,
        ),
        tinta,
      );
    }
  }

  // =====================================================================
  // O ASFALTO
  // =====================================================================

  /// O contorno da pista, com [folga] multiplicando a largura. Com folga
  /// 1 sai a própria pista; com 1.16, o acostamento em volta dela.
  Path _contorno(Size size, double folga) {
    final esquerda = <Offset>[];
    final direita = <Offset>[];
    for (var i = 0; i <= _passos; i++) {
      final p = i / _passos;
      final c = Pista.meio(p, size);
      final w = Pista.meiaLargura(p, size) * folga;
      esquerda.add(Offset(c.dx - w, c.dy));
      direita.add(Offset(c.dx + w, c.dy));
    }
    final caminho = Path()..moveTo(esquerda.first.dx, esquerda.first.dy);
    for (final o in esquerda.skip(1)) {
      caminho.lineTo(o.dx, o.dy);
    }
    for (final o in direita.reversed) {
      caminho.lineTo(o.dx, o.dy);
    }
    return caminho..close();
  }

  void _acostamento(Canvas canvas, Size size, double ent) {
    canvas.drawPath(
      _contorno(size, 1.16),
      Paint()..color = Color.lerp(tema.fundo, tema.texto, 0.055 * ent)!,
    );
  }

  void _asfalto(Canvas canvas, Size size, double ent) {
    final hy = size.height * Pista.horizonte;
    canvas.drawPath(
      _contorno(size, 1.0),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.lerp(tema.fundo, tema.texto, 0.045 * ent)!,
            Color.lerp(tema.fundo, tema.texto, 0.155 * ent)!,
          ],
        ).createShader(
          Rect.fromLTRB(0, hy, size.width, size.height),
        ),
    );
  }

  /// A textura do asfalto: grãozinhos claros e escuros espalhados.
  ///
  /// São duas chamadas de `drawPoints` — uma para os claros e outra para
  /// os escuros — e não quatrocentos círculos, que é o que faria a
  /// abertura engasgar em celular simples.
  void _textura(Canvas canvas, Size size, double ent) {
    final claros = <Offset>[];
    final escuros = <Offset>[];
    for (var i = 0; i < 420; i++) {
      final d = Pista.espalhar(i, 0) * 0.96 + 0.02;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final desvio = (Pista.espalhar(i, 1) * 2 - 1) * 0.98;
      final ponto = Offset(
        c.dx + desvio * w,
        c.dy + ((i * 0.37) % 1.0 - 0.5) * size.height * 0.006,
      );
      (i % 3 == 0 ? escuros : claros).add(ponto);
    }

    canvas.drawPoints(
      ui.PointMode.points,
      claros,
      Paint()
        ..strokeWidth = 1.2
        ..strokeCap = StrokeCap.round
        ..color = tema.texto.withValues(alpha: 0.055 * ent),
    );
    canvas.drawPoints(
      ui.PointMode.points,
      escuros,
      Paint()
        ..strokeWidth = 1.6
        ..strokeCap = StrokeCap.round
        ..color = Colors.black.withValues(alpha: 0.10 * ent),
    );
  }

  /// As duas trilhas mais escuras deixadas pelos pneus de quem passa
  /// todo dia. É um detalhe pequeno que muda muito: sem ele o asfalto
  /// parece um tapete liso.
  void _marcasDePneu(Canvas canvas, Size size, double ent) {
    final tinta = Paint()..color = Colors.black.withValues(alpha: 0.10 * ent);
    for (final lado in <double>[-0.45, 0.45]) {
      final faixa = Path();
      for (var i = 0; i <= _passos; i++) {
        final d = i / _passos;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final x = c.dx + lado * w - w * 0.10;
        if (i == 0) {
          faixa.moveTo(x, c.dy);
        } else {
          faixa.lineTo(x, c.dy);
        }
      }
      for (var i = _passos; i >= 0; i--) {
        final d = i / _passos;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        faixa.lineTo(c.dx + lado * w + w * 0.10, c.dy);
      }
      canvas.drawPath(faixa..close(), tinta);
    }
  }

  // =====================================================================
  // AS FAIXAS
  // =====================================================================
  // Sinalização de avenida brasileira: bordas brancas contínuas, DUPLA
  // AMARELA no meio separando os sentidos, tracejado branco dividindo as
  // faixas de cada lado, e as tachinhas refletivas na borda.
  void _faixas(Canvas canvas, Size size, double ent, double p) {
    // ---- Bordas brancas ----
    _fitaContinua(canvas, size, -1.0, 0.040, 0.6, 2.2,
        const Color(0xFFECF0F8), 0.42 * ent);
    _fitaContinua(canvas, size, 1.0, 0.040, 0.6, 2.2,
        const Color(0xFFECF0F8), 0.42 * ent);

    // ---- Dupla amarela do meio ----
    _fitaNoMeio(canvas, size, -0.030, const Color(0xFFE2B23C), 0.40 * ent);
    _fitaNoMeio(canvas, size, 0.030, const Color(0xFFE2B23C), 0.40 * ent);

    // ---- Tracejado das faixas ----
    // Ele ANDA junto com o carro: é esse deslocamento que faz o olho
    // entender que a avenida está passando por baixo.
    const quantidade = 11;
    final fase = (p * 1.1) % (1 / quantidade);
    final tinta = Paint()
      ..color = const Color(0xFFECF0F8).withValues(alpha: 0.34 * ent);

    for (final lado in <double>[-0.50, 0.50]) {
      for (var i = 0; i < quantidade; i++) {
        final ini = (i / quantidade + fase).clamp(0.0, 1.0);
        final fim = (ini + 0.040).clamp(0.0, 1.0);
        if (fim <= ini) continue;
        final a = Pista.meio(ini, size);
        final b = Pista.meio(fim, size);
        final wa = Pista.meiaLargura(ini, size);
        final wb = Pista.meiaLargura(fim, size);
        final ea = math.max(0.4, wa * 0.018);
        final eb = math.max(0.4, wb * 0.018);
        canvas.drawPath(
          Path()
            ..moveTo(a.dx + lado * wa - ea, a.dy)
            ..lineTo(a.dx + lado * wa + ea, a.dy)
            ..lineTo(b.dx + lado * wb + eb, b.dy)
            ..lineTo(b.dx + lado * wb - eb, b.dy)
            ..close(),
          tinta,
        );
      }
    }

    // ---- As tachinhas refletivas ----
    // São os "olhos de gato" grudados na borda, que devolvem a luz do
    // farol. De noite, são eles que desenham a curva à frente.
    final tacha = Paint()
      ..color = Color.lerp(tema.alerta, Colors.white, 0.4)!
          .withValues(alpha: 0.55 * ent);
    for (var i = 0; i < 16; i++) {
      final d = 0.05 + i * 0.060;
      if (d > 0.99) continue;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final e = math.max(0.7, w * 0.012);
      for (final lado in <double>[-1, 1]) {
        canvas.drawOval(
          Rect.fromCenter(
            center: Offset(c.dx + lado * w * 0.985, c.dy),
            width: e * 2,
            height: e * 1.2,
          ),
          tacha,
        );
      }
    }
  }

  /// Uma fita contínua colada na borda da pista.
  void _fitaContinua(
    Canvas canvas,
    Size size,
    double lado,
    double espessura,
    double interno,
    double externo,
    Color cor,
    double alpha,
  ) {
    final faixa = Path();
    for (var i = 0; i <= _passos; i++) {
      final d = i / _passos;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final e = math.max(0.5, w * espessura);
      final x = c.dx + lado * (w - e * interno);
      if (i == 0) {
        faixa.moveTo(x, c.dy);
      } else {
        faixa.lineTo(x, c.dy);
      }
    }
    for (var i = _passos; i >= 0; i--) {
      final d = i / _passos;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final e = math.max(0.5, w * espessura);
      faixa.lineTo(c.dx + lado * (w - e * externo), c.dy);
    }
    canvas.drawPath(faixa..close(), Paint()..color = cor.withValues(alpha: alpha));
  }

  /// Uma das duas fitas amarelas do meio da avenida.
  void _fitaNoMeio(
    Canvas canvas,
    Size size,
    double desvio,
    Color cor,
    double alpha,
  ) {
    final faixa = Path();
    for (var i = 0; i <= _passos; i++) {
      final d = i / _passos;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final e = math.max(0.5, w * 0.016);
      final x = c.dx + desvio * w - e;
      if (i == 0) {
        faixa.moveTo(x, c.dy);
      } else {
        faixa.lineTo(x, c.dy);
      }
    }
    for (var i = _passos; i >= 0; i--) {
      final d = i / _passos;
      final c = Pista.meio(d, size);
      final w = Pista.meiaLargura(d, size);
      final e = math.max(0.5, w * 0.016);
      faixa.lineTo(c.dx + desvio * w + e, c.dy);
    }
    canvas.drawPath(faixa..close(), Paint()..color = cor.withValues(alpha: alpha));
  }

  // =====================================================================
  // O GUARD-RAIL E OS POSTES
  // =====================================================================
  void _guardRail(Canvas canvas, Size size, double ent) {
    final trilho = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = tema.textoSuave.withValues(alpha: 0.17 * ent);
    final segundo = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = tema.textoSuave.withValues(alpha: 0.10 * ent);
    final mourao = Paint()
      ..color = tema.textoSuave.withValues(alpha: 0.13 * ent);

    for (final lado in <double>[-1, 1]) {
      final alto = Path();
      final baixo = Path();
      for (var i = 0; i <= _passos; i++) {
        final d = i / _passos;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final e = Pista.escala(d, size);
        final x = c.dx + lado * w * 1.14;
        final y1 = c.dy - size.height * 0.026 * e;
        final y2 = y1 + size.height * 0.010 * e;
        if (i == 0) {
          alto.moveTo(x, y1);
          baixo.moveTo(x, y2);
        } else {
          alto.lineTo(x, y1);
          baixo.lineTo(x, y2);
        }
      }
      canvas.drawPath(alto, trilho);
      canvas.drawPath(baixo, segundo);

      // Os mourões de sustentação, um a cada quatro pedaços.
      for (var i = 0; i <= _passos; i += 4) {
        final d = i / _passos;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final e = Pista.escala(d, size);
        final x = c.dx + lado * w * 1.14;
        canvas.drawRect(
          Rect.fromLTWH(
            x - math.max(0.6, e),
            c.dy - size.height * 0.030 * e,
            math.max(1.2, 2 * e),
            size.height * 0.030 * e,
          ),
          mourao,
        );
      }
    }
  }

  /// Os postes da avenida: haste, braço curvo, lâmpada acesa, o cone de
  /// luz descendo e a poça amarela no asfalto.
  ///
  /// DESEMPENHO: as lâmpadas de TODOS os postes entram num caminho só e
  /// são borradas de uma vez; as poças, em outro. São dois desfoques
  /// para a avenida inteira, em vez de dois por poste.
  void _postes(Canvas canvas, Size size, double ent) {
    final ferro = Paint()
      ..style = PaintingStyle.stroke
      ..color = tema.textoSuave.withValues(alpha: 0.34 * ent);

    final lampadas = Path();
    final halos = Path();
    final cones = Path();
    final pocas = Path();

    for (final d in const <double>[0.055, 0.16, 0.33, 0.60]) {
      for (final lado in <double>[-1, 1]) {
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final baseX = c.dx + lado * w * 1.22;
        if (baseX < -60 || baseX > size.width + 60) continue;

        final altura = size.height * (0.045 + 0.20 * d);
        final topoY = c.dy - altura;
        ferro.strokeWidth = math.max(1.0, size.width * 0.006 * (0.35 + d));
        canvas.drawLine(Offset(baseX, c.dy), Offset(baseX, topoY), ferro);

        final pontaX = baseX - lado * altura * 0.26;
        final pontaY = topoY + altura * 0.055;
        canvas.drawLine(
          Offset(baseX, topoY),
          Offset(pontaX, pontaY),
          ferro,
        );

        final r = math.max(1.2, altura * 0.050);
        lampadas.addOval(
          Rect.fromCircle(center: Offset(pontaX, pontaY), radius: r),
        );
        halos.addOval(
          Rect.fromCircle(center: Offset(pontaX, pontaY), radius: r * 2.6),
        );
        cones.addPolygon(
          <Offset>[
            Offset(pontaX - r * 0.8, pontaY),
            Offset(pontaX + r * 0.8, pontaY),
            Offset(pontaX + w * 0.30, c.dy),
            Offset(pontaX - w * 0.30, c.dy),
          ],
          true,
        );
        pocas.addOval(
          Rect.fromCenter(
            center: Offset(pontaX, c.dy),
            width: w * 0.68,
            height: w * 0.26,
          ),
        );
      }
    }

    // A luz suja do poste descendo até o chão.
    canvas.drawPath(
      cones,
      Paint()
        ..color = tema.alerta.withValues(alpha: 0.032 * ent)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawPath(
      pocas,
      Paint()
        ..color = tema.alerta.withValues(alpha: 0.065 * ent)
        ..maskFilter = MaskFilter.blur(
          BlurStyle.normal,
          math.max(4.0, size.width * 0.035),
        ),
    );
    canvas.drawPath(
      halos,
      Paint()
        ..color = tema.alerta.withValues(alpha: 0.14 * ent)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
    canvas.drawPath(
      lampadas,
      Paint()
        ..color = Color.lerp(tema.alerta, Colors.white, 0.6)!
            .withValues(alpha: 0.85 * ent),
    );
  }

  /// As lanternas vermelhas de um carro que segue na frente, lá no
  /// fundo. É o detalhe que faz a avenida parecer viva em vez de vazia.
  void _carroDistante(Canvas canvas, Size size, double ent) {
    const d = 0.20;
    final c = Pista.meio(d, size);
    final w = Pista.meiaLargura(d, size);
    final lanternas = Path();
    for (final lado in <double>[-1, 1]) {
      lanternas.addOval(
        Rect.fromCenter(
          center: Offset(c.dx + lado * w * 0.30, c.dy - w * 0.22),
          width: math.max(1.6, w * 0.15),
          height: math.max(1.0, w * 0.09),
        ),
      );
    }
    canvas.drawPath(
      lanternas,
      Paint()
        ..color = tema.erro.withValues(alpha: 0.85 * ent)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.2),
    );
  }

  // =====================================================================
  // A LUZ DO FAROL NO CHÃO, O REFLEXO E OS CONES
  // =====================================================================
  void _luzNoChao(Canvas canvas, Size size, double p, double brilho) {
    final c = Pista.meio(p, size);
    final w = Pista.meiaLargura(p, size);
    final area = Rect.fromCenter(
      center: Offset(c.dx + w * Pista.faixaDoCarro, c.dy + w * 0.55),
      width: w * (1.15 + 0.85 * brilho),
      height: w * (0.60 + 0.50 * brilho),
    );
    canvas.drawOval(
      area,
      Paint()
        ..blendMode = BlendMode.plus
        ..shader = RadialGradient(
          colors: <Color>[
            Color.lerp(tema.secundaria, Colors.white, 0.40)!
                .withValues(alpha: 0.16 * brilho),
            tema.primaria.withValues(alpha: 0.07 * brilho),
            tema.primaria.withValues(alpha: 0),
          ],
          stops: const <double>[0, 0.55, 1],
        ).createShader(area),
    );
  }

  /// As duas listras de luz descendo no asfalto molhado. É o detalhe que
  /// faz a cena parecer madrugada depois da chuva.
  void _reflexo(Canvas canvas, Size size, double p, double brilho) {
    final m = _MedidasDoCarro(size, p);
    final w = Pista.meiaLargura(p, size);
    final comprimento = w * (0.35 + 0.60 * brilho);
    final listras = Path();
    for (final farol in m.farois) {
      listras.addPolygon(
        <Offset>[
          Offset(farol.dx - w * 0.045, m.baseY),
          Offset(farol.dx + w * 0.045, m.baseY),
          Offset(farol.dx + w * 0.09, m.baseY + comprimento),
          Offset(farol.dx - w * 0.09, m.baseY + comprimento),
        ],
        true,
      );
    }
    canvas.drawPath(
      listras,
      Paint()
        ..blendMode = BlendMode.plus
        ..color = Color.lerp(tema.secundaria, Colors.white, 0.45)!
            .withValues(alpha: 0.17 * brilho)
        ..maskFilter = MaskFilter.blur(
          BlurStyle.normal,
          math.max(3.0, w * 0.08),
        ),
    );
  }

  void _cones(Canvas canvas, Size size, double p, double brilho) {
    final m = _MedidasDoCarro(size, p);
    final w = Pista.meiaLargura(p, size);
    if (w < 4) return;

    final alcance = size.height * (0.10 + 0.20 * brilho);
    final abertura = w * (0.32 + 0.45 * brilho);

    // Os dois feixes, num caminho só.
    final feixes = Path();
    for (final origem in m.farois) {
      feixes.addPolygon(
        <Offset>[
          Offset(origem.dx - w * 0.055, origem.dy),
          Offset(origem.dx + w * 0.055, origem.dy),
          Offset(origem.dx + abertura, origem.dy + alcance),
          Offset(origem.dx - abertura, origem.dy + alcance),
        ],
        true,
      );
    }
    canvas.drawPath(
      feixes,
      Paint()
        // "plus" faz duas luzes que se cruzam ficarem MAIS claras no
        // encontro — é assim que farol se comporta de verdade.
        ..blendMode = BlendMode.plus
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 4 + 9 * brilho)
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.lerp(tema.primaria, tema.secundaria, 0.50)!
                .withValues(alpha: 0.30 * brilho),
            tema.primaria.withValues(alpha: 0.10 * brilho),
            tema.primaria.withValues(alpha: 0),
          ],
          stops: const <double>[0, 0.55, 1],
        ).createShader(
          Rect.fromLTRB(
            m.meio - abertura * 2,
            m.alturaDoFarol,
            m.meio + abertura * 2,
            m.alturaDoFarol + alcance,
          ),
        ),
    );

    // O estouro da lâmpada e o RISCO DE LUZ atravessado — aquele
    // espeto horizontal que farol forte faz de noite.
    final estouro = Path();
    for (final origem in m.farois) {
      estouro.addOval(
        Rect.fromCircle(center: origem, radius: w * 0.11 * (0.5 + brilho)),
      );
      final risco = w * (0.35 + 0.75 * brilho);
      estouro.addPolygon(
        <Offset>[
          Offset(origem.dx - risco, origem.dy),
          Offset(origem.dx, origem.dy - w * 0.030),
          Offset(origem.dx + risco, origem.dy),
          Offset(origem.dx, origem.dy + w * 0.030),
        ],
        true,
      );
    }
    canvas.drawPath(
      estouro,
      Paint()
        ..blendMode = BlendMode.plus
        ..color = Color.lerp(tema.secundaria, Colors.white, 0.80)!
            .withValues(alpha: 0.80 * brilho)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 3 + 8 * brilho),
    );
  }

  /// Um escurecido suave nos cantos. Não é enfeite: é o que impede a
  /// cena de vazar nas bordas e joga o olho para o meio, onde o carro
  /// está. É o mesmo truque de fotografia noturna.
  void _vinheta(Canvas canvas, Size size, double ent) {
    final area = Offset.zero & size;
    canvas.drawRect(
      area,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0, 0.04),
          radius: 1.0,
          colors: <Color>[
            Colors.black.withValues(alpha: 0),
            Colors.black.withValues(alpha: 0.14 * ent),
            Colors.black.withValues(alpha: 0.46 * ent),
          ],
          stops: const <double>[0.42, 0.76, 1.0],
        ).createShader(area),
    );
  }

  // =====================================================================
  // O CARRO DE NEON — o mesmo do ícone do aplicativo
  // =====================================================================
  // Cada peça é uma CURVA DE BÉZIER de verdade (`cubicTo`), com os pontos
  // tirados do próprio ícone.
  //
  // O SEGREDO DO DESEMPENHO: os traços NÃO são borrados um a um. Todos
  // entram em dois caminhos — o grosso e o fino — e cada um é pintado em
  // três camadas (halo largo, halo curto, linha nítida). São 6 desfoques
  // no carro inteiro, em vez de um por peça.
  void _carro(
    Canvas canvas,
    Size size,
    double p,
    double brilho,
    double ent,
  ) {
    if (ent <= 0.01) return;

    final m = _MedidasDoCarro(size, p);
    if (m.largura < 10) return; // ainda é um pontinho lá no fundo

    final traco = math.max(1.6, m.largura * 0.016);
    final corNeon = Color.lerp(tema.primaria, Colors.white, 0.34)!;
    final escuro = Paint()..color = Colors.black.withValues(alpha: 0.88);

    // Os dois caminhos que juntam tudo.
    final grosso = Path();
    final fino = Path();

    // ---- A LATERAL, quando o carro está virado ----
    // É o PERFIL do carro, fechado e grudado na frente — e não linhas
    // soltas. Assim os dois pedaços leem como um carro só, virado.
    if (m.lateral.abs() > m.largura * 0.06) {
      final sg = m.ladoVisivel;
      final fundoX = m.meio + m.lateral;
      final topoX = m.meio + m.lateral * 0.66;

      final flanco = Path()
        ..moveTo(m.ponto(0.50 * sg, 0.13).dx, m.ponto(0.50 * sg, 0.13).dy)
        ..lineTo(fundoX, m.baseY - m.altura * 0.11)
        ..lineTo(fundoX, m.baseY - m.altura * 0.55)
        ..quadraticBezierTo(
          fundoX,
          m.baseY - m.altura * 0.82,
          topoX,
          m.baseY - m.altura * 0.90,
        )
        ..lineTo(m.ponto(0.295 * sg, 0.945).dx, m.ponto(0.295 * sg, 0.945).dy)
        ..lineTo(m.ponto(0.50 * sg, 0.62).dx, m.ponto(0.50 * sg, 0.62).dy)
        ..close();
      canvas.drawPath(flanco, escuro);
      grosso.addPath(flanco, Offset.zero);

      // O vidro da porta e a roda de trás.
      fino
        ..moveTo(m.ponto(0.33 * sg, 0.735).dx, m.ponto(0.33 * sg, 0.735).dy)
        ..lineTo(fundoX * 0.94 + topoX * 0.06, m.baseY - m.altura * 0.60)
        ..lineTo(topoX, m.baseY - m.altura * 0.855)
        ..lineTo(m.ponto(0.285 * sg, 0.905).dx, m.ponto(0.285 * sg, 0.905).dy)
        ..close();
      final rodaTras = fundoX - m.lateral * 0.16;
      fino
        ..moveTo(rodaTras, m.baseY - m.altura * 0.13)
        ..lineTo(rodaTras, m.baseY - m.altura * 0.01);
    }

    // ---- A SILHUETA ----
    // Do canto de baixo, subindo pelo para-lama, entrando no ombro,
    // levantando na coluna e abaulando no teto. Depois o espelho do
    // outro lado, ponto por ponto.
    final silhueta = Path()
      ..moveTo(m.ponto(0.480, 0.130).dx, m.ponto(0.480, 0.130).dy)
      ..cubicTo(
        m.ponto(0.517, 0.300).dx, m.ponto(0.517, 0.300).dy, //
        m.ponto(0.517, 0.500).dx, m.ponto(0.517, 0.500).dy, //
        m.ponto(0.500, 0.620).dx, m.ponto(0.500, 0.620).dy,
      )
      ..cubicTo(
        m.ponto(0.489, 0.690).dx, m.ponto(0.489, 0.690).dy, //
        m.ponto(0.452, 0.716).dx, m.ponto(0.452, 0.716).dy, //
        m.ponto(0.400, 0.735).dx, m.ponto(0.400, 0.735).dy,
      )
      ..cubicTo(
        m.ponto(0.356, 0.755).dx, m.ponto(0.356, 0.755).dy, //
        m.ponto(0.326, 0.850).dx, m.ponto(0.326, 0.850).dy, //
        m.ponto(0.295, 0.945).dx, m.ponto(0.295, 0.945).dy,
      )
      ..cubicTo(
        m.ponto(0.281, 0.978).dx, m.ponto(0.281, 0.978).dy, //
        m.ponto(0.222, 0.998).dx, m.ponto(0.222, 0.998).dy, //
        m.ponto(0.150, 1.000).dx, m.ponto(0.150, 1.000).dy,
      )
      ..cubicTo(
        m.ponto(0.070, 1.006).dx, m.ponto(0.070, 1.006).dy, //
        m.ponto(-0.070, 1.006).dx, m.ponto(-0.070, 1.006).dy, //
        m.ponto(-0.150, 1.000).dx, m.ponto(-0.150, 1.000).dy,
      )
      ..cubicTo(
        m.ponto(-0.222, 0.998).dx, m.ponto(-0.222, 0.998).dy, //
        m.ponto(-0.281, 0.978).dx, m.ponto(-0.281, 0.978).dy, //
        m.ponto(-0.295, 0.945).dx, m.ponto(-0.295, 0.945).dy,
      )
      ..cubicTo(
        m.ponto(-0.326, 0.850).dx, m.ponto(-0.326, 0.850).dy, //
        m.ponto(-0.356, 0.755).dx, m.ponto(-0.356, 0.755).dy, //
        m.ponto(-0.400, 0.735).dx, m.ponto(-0.400, 0.735).dy,
      )
      ..cubicTo(
        m.ponto(-0.452, 0.716).dx, m.ponto(-0.452, 0.716).dy, //
        m.ponto(-0.489, 0.690).dx, m.ponto(-0.489, 0.690).dy, //
        m.ponto(-0.500, 0.620).dx, m.ponto(-0.500, 0.620).dy,
      )
      ..cubicTo(
        m.ponto(-0.517, 0.500).dx, m.ponto(-0.517, 0.500).dy, //
        m.ponto(-0.517, 0.300).dx, m.ponto(-0.517, 0.300).dy, //
        m.ponto(-0.480, 0.130).dx, m.ponto(-0.480, 0.130).dy,
      )
      ..close();

    // O miolo escuro: sem ele o brilho vazaria para dentro e o carro
    // ficaria translúcido em vez de sólido.
    canvas.drawPath(silhueta, escuro);
    grosso.addPath(silhueta, Offset.zero);

    // ---- A CABINE ----
    grosso.addPath(
      Path()
        ..moveTo(m.ponto(0.330, 0.725).dx, m.ponto(0.330, 0.725).dy)
        ..cubicTo(
          m.ponto(0.312, 0.800).dx, m.ponto(0.312, 0.800).dy, //
          m.ponto(0.276, 0.885).dx, m.ponto(0.276, 0.885).dy, //
          m.ponto(0.235, 0.935).dx, m.ponto(0.235, 0.935).dy,
        )
        ..cubicTo(
          m.ponto(0.160, 0.962).dx, m.ponto(0.160, 0.962).dy, //
          m.ponto(-0.160, 0.962).dx, m.ponto(-0.160, 0.962).dy, //
          m.ponto(-0.235, 0.935).dx, m.ponto(-0.235, 0.935).dy,
        )
        ..cubicTo(
          m.ponto(-0.276, 0.885).dx, m.ponto(-0.276, 0.885).dy, //
          m.ponto(-0.312, 0.800).dx, m.ponto(-0.312, 0.800).dy, //
          m.ponto(-0.330, 0.725).dx, m.ponto(-0.330, 0.725).dy,
        )
        ..cubicTo(
          m.ponto(-0.200, 0.688).dx, m.ponto(-0.200, 0.688).dy, //
          m.ponto(0.200, 0.688).dx, m.ponto(0.200, 0.688).dy, //
          m.ponto(0.330, 0.725).dx, m.ponto(0.330, 0.725).dy,
        )
        ..close(),
      Offset.zero,
    );

    // ---- O SORRISO DO CAPÔ ----
    grosso.addPath(
      Path()
        ..moveTo(m.ponto(-0.492, 0.648).dx, m.ponto(-0.492, 0.648).dy)
        ..cubicTo(
          m.ponto(-0.270, 0.520).dx, m.ponto(-0.270, 0.520).dy, //
          m.ponto(0.270, 0.520).dx, m.ponto(0.270, 0.520).dy, //
          m.ponto(0.492, 0.648).dx, m.ponto(0.492, 0.648).dy,
        ),
      Offset.zero,
    );

    // ---- A GRADE DE BAIXO ----
    grosso.addPath(
      Path()
        ..moveTo(m.ponto(-0.437, 0.135).dx, m.ponto(-0.437, 0.135).dy)
        ..cubicTo(
          m.ponto(-0.437, 0.200).dx, m.ponto(-0.437, 0.200).dy, //
          m.ponto(-0.432, 0.245).dx, m.ponto(-0.432, 0.245).dy, //
          m.ponto(-0.372, 0.262).dx, m.ponto(-0.372, 0.262).dy,
        )
        ..cubicTo(
          m.ponto(-0.200, 0.285).dx, m.ponto(-0.200, 0.285).dy, //
          m.ponto(0.200, 0.285).dx, m.ponto(0.200, 0.285).dy, //
          m.ponto(0.372, 0.262).dx, m.ponto(0.372, 0.262).dy,
        )
        ..cubicTo(
          m.ponto(0.432, 0.245).dx, m.ponto(0.432, 0.245).dy, //
          m.ponto(0.437, 0.200).dx, m.ponto(0.437, 0.200).dy, //
          m.ponto(0.437, 0.135).dx, m.ponto(0.437, 0.135).dy,
        )
        ..close(),
      Offset.zero,
    );

    // ---- OS DETALHES FINOS ----
    // O vinco do capô.
    fino
      ..moveTo(m.ponto(-0.400, 0.690).dx, m.ponto(-0.400, 0.690).dy)
      ..cubicTo(
        m.ponto(-0.220, 0.640).dx, m.ponto(-0.220, 0.640).dy, //
        m.ponto(0.220, 0.640).dx, m.ponto(0.220, 0.640).dy, //
        m.ponto(0.400, 0.690).dx, m.ponto(0.400, 0.690).dy,
      );
    // O brilho que escorre no para-brisa — o mesmo do ícone.
    fino
      ..moveTo(m.ponto(-0.290, 0.755).dx, m.ponto(-0.290, 0.755).dy)
      ..cubicTo(
        m.ponto(-0.255, 0.845).dx, m.ponto(-0.255, 0.845).dy, //
        m.ponto(-0.205, 0.895).dx, m.ponto(-0.205, 0.895).dy, //
        m.ponto(-0.140, 0.922).dx, m.ponto(-0.140, 0.922).dy,
      );
    // A placa.
    fino.addPolygon(
      <Offset>[
        m.ponto(-0.115, 0.232),
        m.ponto(0.115, 0.232),
        m.ponto(0.115, 0.162),
        m.ponto(-0.115, 0.162),
      ],
      true,
    );
    // As barrinhas da grade.
    for (var k = -3; k <= 3; k++) {
      final x = m.ponto(k * 0.085, 0.20).dx;
      fino
        ..moveTo(x, m.ponto(0, 0.165).dy)
        ..lineTo(x, m.ponto(0, 0.245).dy);
    }

    // ---- ENTRADAS DE AR, RODAS E ESPELHOS ----
    for (final lado in <double>[-1, 1]) {
      grosso.addPolygon(
        <Offset>[
          m.ponto(0.430 * lado, 0.262),
          m.ponto(0.252 * lado, 0.244),
          m.ponto(0.312 * lado, 0.138),
          m.ponto(0.430 * lado, 0.138),
        ],
        true,
      );

      // A roda: um quadrado de cantos arredondados encostado no chão,
      // como no ícone.
      final a = m.ponto(0.348 * lado, 0.145);
      final b = m.ponto(0.487 * lado, 0.0);
      final canto = (b.dx - a.dx).abs() * 0.28;
      grosso.addRRect(
        RRect.fromRectAndCorners(
          Rect.fromLTRB(
            math.min(a.dx, b.dx),
            math.min(a.dy, b.dy),
            math.max(a.dx, b.dx),
            math.max(a.dy, b.dy),
          ),
          topLeft: Radius.circular(canto),
          topRight: Radius.circular(canto),
          bottomLeft: Radius.circular(canto * 0.45),
          bottomRight: Radius.circular(canto * 0.45),
        ),
      );

      // O espelho: o lacinho que aparece no ombro do carro.
      fino
        ..moveTo(
          m.ponto(0.492 * lado, 0.706).dx,
          m.ponto(0.492 * lado, 0.706).dy,
        )
        ..cubicTo(
          m.ponto(0.540 * lado, 0.716).dx, m.ponto(0.540 * lado, 0.716).dy,
          m.ponto(0.578 * lado, 0.742).dx, m.ponto(0.578 * lado, 0.742).dy,
          m.ponto(0.566 * lado, 0.760).dx, m.ponto(0.566 * lado, 0.760).dy,
        )
        ..cubicTo(
          m.ponto(0.552 * lado, 0.776).dx, m.ponto(0.552 * lado, 0.776).dy,
          m.ponto(0.512 * lado, 0.752).dx, m.ponto(0.512 * lado, 0.752).dy,
          m.ponto(0.489 * lado, 0.700).dx, m.ponto(0.489 * lado, 0.700).dy,
        )
        ..close();
    }

    // ---- OS FARÓIS DE NEBLINA ----
    // Dois pontinhos âmbar dentro das entradas de ar. Acendem junto.
    final neblina = Paint()
      ..color = Color.lerp(tema.alerta, Colors.white, 0.30 * brilho)!
          .withValues(alpha: 0.35 + 0.50 * brilho);
    for (final lado in <double>[-1, 1]) {
      canvas.drawCircle(
        m.ponto(0.345 * lado, 0.185),
        math.max(1.0, m.largura * 0.018),
        neblina,
      );
    }

    // ---- OS FARÓIS ----
    // A cunha inclinada do ícone. Apagados são vidro escuro; acesos
    // ficam brancos de luz.
    final corVidro = Color.lerp(
      Color.lerp(tema.textoSuave, Colors.black, 0.50)!,
      Colors.white,
      brilho,
    )!;
    for (final lado in <double>[-1, 1]) {
      final farol = Path()
        ..moveTo(
          m.ponto(0.482 * lado, 0.612).dx,
          m.ponto(0.482 * lado, 0.612).dy,
        )
        ..cubicTo(
          m.ponto(0.400 * lado, 0.600).dx, m.ponto(0.400 * lado, 0.600).dy,
          m.ponto(0.330 * lado, 0.578).dx, m.ponto(0.330 * lado, 0.578).dy,
          m.ponto(0.282 * lado, 0.556).dx, m.ponto(0.282 * lado, 0.556).dy,
        )
        ..lineTo(
          m.ponto(0.262 * lado, 0.487).dx,
          m.ponto(0.262 * lado, 0.487).dy,
        )
        ..cubicTo(
          m.ponto(0.340 * lado, 0.492).dx, m.ponto(0.340 * lado, 0.492).dy,
          m.ponto(0.420 * lado, 0.498).dx, m.ponto(0.420 * lado, 0.498).dy,
          m.ponto(0.470 * lado, 0.505).dx, m.ponto(0.470 * lado, 0.505).dy,
        )
        ..close();
      canvas.drawPath(
        farol,
        Paint()..color = corVidro.withValues(alpha: 0.32 + 0.68 * brilho),
      );
      grosso.addPath(farol, Offset.zero);
    }

    // ---- E AGORA O NEON, DE UMA VEZ SÓ ----
    _neon(canvas, fino, corNeon, traco * 0.62, forca: 0.62);
    _neon(canvas, grosso, corNeon, traco);
  }

  /// Pinta um caminho inteiro como tubo de NEON: o halo largo e fraco, o
  /// halo curto e forte, e a linha nítida por cima. São essas três
  /// camadas que fazem parecer neon aceso, e não um risco com sombra.
  ///
  /// [forca] permite apagar um pouco o grupo inteiro — é o que deixa os
  /// detalhes finos (vinco, placa, grade) mais discretos do que o
  /// contorno do carro, em vez de competirem com ele.
  void _neon(
    Canvas canvas,
    Path caminho,
    Color cor,
    double espessura, {
    double forca = 1.0,
  }) {
    Paint risco(double largura, double opacidade, double desfoque) {
      final tinta = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..strokeWidth = largura
        ..color = cor.withValues(alpha: (opacidade * forca).clamp(0.0, 1.0));
      if (desfoque > 0) {
        tinta.maskFilter = MaskFilter.blur(BlurStyle.normal, desfoque);
      }
      return tinta;
    }

    canvas.drawPath(
      caminho,
      risco(espessura * 2.8, 0.30, math.max(2.0, espessura * 2.4)),
    );
    canvas.drawPath(
      caminho,
      risco(espessura * 1.7, 0.50, math.max(1.0, espessura * 0.9)),
    );
    canvas.drawPath(caminho, risco(espessura, 0.97, 0));
  }

  @override
  bool shouldRepaint(_CenaDaAvenida antiga) =>
      antiga.t != t || antiga.tema != tema;
}
