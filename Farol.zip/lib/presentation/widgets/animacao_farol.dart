/// -----------------------------------------------------------------------
/// A ABERTURA DO APLICATIVO — O CARRO QUE FAZ A CURVA E ACENDE O FAROL
/// -----------------------------------------------------------------------
/// É a primeira coisa que o motorista vê, e é o nome do aplicativo
/// acontecendo na tela.
///
/// O QUE ACONTECE, NA ORDEM (a animação inteira vai de 0 a 1):
///
///   0.00 → 0.12   A estrada aparece: uma pista que vem de longe e faz
///                 uma curva para a esquerda.
///   0.05 → 0.55   O CARRO FAZ A CURVA. Ele entra pequeno, lá no fundo
///                 da estrada, e vem vindo pela pista — crescendo (está
///                 chegando perto) e INCLINANDO para dentro da curva,
///                 como carro de verdade faz. No fim da curva ele se
///                 endireita de frente para quem está olhando.
///   0.50 → 0.68   PISCA: o farol dá dois lampejos, como quem liga.
///   0.62 → 0.92   ACENDE DE VEZ: os dois cones de luz se abrem para a
///                 frente, ficam mais compridos e mais fortes, e o carro
///                 ganha um halo em volta.
///   0.75 → 1.00   O nome FAROL surge dentro da luz.
///
/// COMO FOI FEITO — sem pacote nenhum, sem vídeo e sem GIF:
///   • o caminho da curva é uma CURVA DE BÉZIER (três pontos), e a
///     posição do carro é só "onde estou nessa curva agora";
///   • a inclinação do carro sai da PRÓPRIA curva: comparo onde ele está
///     com onde ele estava um instante antes e uso esse ângulo;
///   • a estrada e os cones de luz são desenhados por um CustomPainter —
///     figuras simples, sem imagem, que custam quase nada de
///     processamento e rodam lisas em celular fraco.
///
/// A imagem do carro é o próprio ícone do aplicativo
/// (assets/images/farol_icone.png). Se ela não carregar por algum motivo,
/// entra um carro de ícone do sistema no lugar — a tela nunca quebra.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class AnimacaoFarolLigando extends StatelessWidget {
  /// A animação que comanda tudo, de 0 a 1.
  final Animation<double> animacao;

  final TemaFarol tema;

  /// Largura total do desenho.
  final double tamanho;

  const AnimacaoFarolLigando({
    super.key,
    required this.animacao,
    required this.tema,
    this.tamanho = 240,
  });

  // =====================================================================
  // AS CONTAS DA ANIMAÇÃO
  // =====================================================================
  // Ficam como funções estáticas, separadas do desenho: assim dá para
  // conferir cada número sem precisar rodar o aplicativo.

  /// Onde o carro está na curva, de 0 (lá no fundo) a 1 (chegou).
  static double avancoNaCurva(double t) {
    final f = ((t - 0.05) / 0.50).clamp(0.0, 1.0);
    // easeInOut: sai devagar, ganha velocidade no meio da curva e
    // estaciona macio no fim. É o jeito que carro anda.
    return Curves.easeInOutCubic.transform(f);
  }

  /// Força do farol em cada instante (0 = apagado, 1 = aceso).
  ///
  /// Os dois lampejos são feitos "na mão": em vez de uma curva suave, o
  /// brilho sobe e desce de propósito duas vezes antes de firmar.
  static double brilhoEm(double t) {
    if (t < 0.50) return 0;
    if (t < 0.55) return 0.80; // primeiro lampejo
    if (t < 0.59) return 0.05; // apaga
    if (t < 0.64) return 0.95; // segundo lampejo
    if (t < 0.68) return 0.10; // apaga de novo
    // A partir daqui acende de vez e vai firmando.
    final f = ((t - 0.68) / 0.24).clamp(0.0, 1.0);
    return Curves.easeOutCubic.transform(f);
  }

  /// O ponto da curva no avanço [a], dentro de um retângulo [tamanho].
  ///
  /// É uma curva de Bézier de três pontos:
  ///   início  — lá no fundo, à direita e bem pequeno
  ///   guia    — puxa o traçado para a direita, criando a curva
  ///   fim     — na frente, no meio da tela
  static Offset pontoDaCurva(double a, Size area) {
    final inicio = Offset(area.width * 0.80, area.height * 0.30);
    final guia = Offset(area.width * 1.02, area.height * 0.78);
    final fim = Offset(area.width * 0.50, area.height * 0.58);

    final u = 1 - a;
    return Offset(
      u * u * inicio.dx + 2 * u * a * guia.dx + a * a * fim.dx,
      u * u * inicio.dy + 2 * u * a * guia.dy + a * a * fim.dy,
    );
  }

  /// Quanto o carro está inclinado, em radianos.
  ///
  /// Sai da própria curva: comparo o ponto de agora com o ponto de um
  /// instante atrás. No fim da curva a inclinação vai a zero, para o
  /// carro terminar de frente para quem olha.
  static double inclinacaoNaCurva(double a, Size area) {
    final antes = pontoDaCurva((a - 0.06).clamp(0.0, 1.0), area);
    final agora = pontoDaCurva(a, area);
    final bruto = math.atan2(agora.dy - antes.dy, agora.dx - antes.dx);

    // Limite de bom senso: no máximo ~20 graus de inclinação.
    final limitado = bruto.clamp(-0.35, 0.35);

    // Nos últimos 25% do trajeto a inclinação vai sumindo.
    final endireitando = ((1 - a) / 0.25).clamp(0.0, 1.0);
    return limitado * endireitando;
  }

  /// O tamanho do carro no avanço [a]: pequeno lá no fundo, inteiro na
  /// frente. É o que dá a sensação de que ele está VINDO.
  static double escalaNaCurva(double a) => 0.42 + 0.58 * a;

  @override
  Widget build(BuildContext context) {
    final altura = tamanho * 0.86;

    return SizedBox(
      width: tamanho,
      height: altura,
      child: AnimatedBuilder(
        animation: animacao,
        builder: (context, _) {
          final t = animacao.value;
          final area = Size(tamanho, altura);

          final avanco = avancoNaCurva(t);
          final brilho = brilhoEm(t);
          final posicao = pontoDaCurva(avanco, area);
          final inclinacao = inclinacaoNaCurva(avanco, area);
          final escala = escalaNaCurva(avanco);

          // O carro só aparece depois que a estrada já está na tela.
          final aparecendo =
              Curves.easeOut.transform((t / 0.10).clamp(0.0, 1.0));

          final ladoCarro = tamanho * 0.42 * escala;

          return Stack(
            children: <Widget>[
              // ---- A ESTRADA E OS CONES DE LUZ ----
              // Um CustomPaint só, desenhando tudo o que é figura.
              Positioned.fill(
                child: CustomPaint(
                  painter: _PintorDaAbertura(
                    avanco: avanco,
                    brilho: brilho,
                    posicaoCarro: posicao,
                    cor: tema.primaria,
                    corQuente: tema.secundaria,
                    corEstrada: tema.textoSuave,
                  ),
                ),
              ),

              // ---- O CARRO ----
              Positioned(
                left: posicao.dx - ladoCarro / 2,
                top: posicao.dy - ladoCarro / 2,
                width: ladoCarro,
                height: ladoCarro,
                child: Opacity(
                  opacity: aparecendo,
                  child: Transform.rotate(
                    angle: inclinacao,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(ladoCarro * 0.28),
                        boxShadow: <BoxShadow>[
                          // O halo acompanha o farol: quanto mais aceso,
                          // mais o carro brilha.
                          BoxShadow(
                            color: tema.primaria
                                .withValues(alpha: 0.55 * brilho),
                            blurRadius: 38 * brilho + 6,
                            spreadRadius: 2 * brilho,
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius:
                            BorderRadius.circular(ladoCarro * 0.28),
                        child: Image.asset(
                          'assets/images/farol_icone.png',
                          fit: BoxFit.cover,
                          // Sem a imagem, um carro de ícone no lugar.
                          errorBuilder: (context, _, __) => Container(
                            color: tema.superficieAlta,
                            alignment: Alignment.center,
                            child: Icon(
                              Icons.directions_car_rounded,
                              size: ladoCarro * 0.58,
                              color: Color.lerp(
                                tema.textoSuave,
                                tema.primaria,
                                brilho,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// =======================================================================
/// O DESENHO: A ESTRADA E OS DOIS CONES DE LUZ
/// =======================================================================
class _PintorDaAbertura extends CustomPainter {
  /// Onde o carro está na curva (0 a 1).
  final double avanco;

  /// Força do farol (0 a 1).
  final double brilho;

  /// Onde o carro está agora — é de lá que a luz sai.
  final Offset posicaoCarro;

  final Color cor;
  final Color corQuente;
  final Color corEstrada;

  const _PintorDaAbertura({
    required this.avanco,
    required this.brilho,
    required this.posicaoCarro,
    required this.cor,
    required this.corQuente,
    required this.corEstrada,
  });

  /// O traçado da estrada — a MESMA curva por onde o carro anda.
  Path _caminho(Size size) {
    final inicio = AnimacaoFarolLigando.pontoDaCurva(0, size);
    final fim = AnimacaoFarolLigando.pontoDaCurva(1, size);
    return Path()
      ..moveTo(inicio.dx, inicio.dy)
      ..quadraticBezierTo(
        size.width * 1.02,
        size.height * 0.78,
        fim.dx,
        fim.dy,
      );
  }

  @override
  void paint(Canvas canvas, Size size) {
    _pintarEstrada(canvas, size);
    if (brilho > 0.01) _pintarFarol(canvas, size);
  }

  // -------------------------------------------------------------------
  // A ESTRADA
  // -------------------------------------------------------------------
  void _pintarEstrada(Canvas canvas, Size size) {
    final caminho = _caminho(size);

    // A pista: uma faixa larga e apagada, que some no fundo.
    final pista = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = size.width * 0.085
      ..shader = LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: <Color>[
          corEstrada.withValues(alpha: 0),
          corEstrada.withValues(alpha: 0.16),
          corEstrada.withValues(alpha: 0.05),
        ],
        stops: const <double>[0, 0.55, 1],
      ).createShader(Offset.zero & size);
    canvas.drawPath(caminho, pista);

    // O tracejado do meio da pista, que vai sendo "riscado" conforme o
    // carro passa — dá a sensação de movimento sem custar nada.
    final medidas = caminho.computeMetrics().toList();
    if (medidas.isEmpty) return;
    final medidor = medidas.first;
    final percorrido = medidor.length * avanco.clamp(0.0, 1.0);
    if (percorrido > 1) {
      final rastro = medidor.extractPath(0, percorrido);
      final tintaRastro = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = size.width * 0.012
        ..color = cor.withValues(alpha: 0.35);
      canvas.drawPath(rastro, tintaRastro);
    }
  }

  // -------------------------------------------------------------------
  // OS CONES DE LUZ
  // -------------------------------------------------------------------
  void _pintarFarol(Canvas canvas, Size size) {
    // A luz sai da frente do carro e aponta para cima da tela.
    final origemY = posicaoCarro.dy - size.height * 0.04;
    final centroX = posicaoCarro.dx;

    final alcance = size.height * (0.18 + 0.36 * brilho);
    final abertura = size.width * (0.14 + 0.28 * brilho);

    for (final lado in <double>[-1, 1]) {
      final origem = Offset(centroX + lado * size.width * 0.075, origemY);
      final pontaLonge = Offset(
        origem.dx + lado * abertura * 1.2,
        origemY - alcance,
      );
      final pontaPerto = Offset(
        origem.dx + lado * abertura * 0.22,
        origemY - alcance * 0.70,
      );

      final caminho = Path()
        ..moveTo(origem.dx, origem.dy)
        ..lineTo(pontaLonge.dx, pontaLonge.dy)
        ..lineTo(pontaPerto.dx, pontaPerto.dy)
        ..close();

      final tinta = Paint()
        ..shader = _gradienteDoFeixe(origem, pontaLonge)
        // O modo "plus" faz duas luzes que se cruzam ficarem MAIS claras
        // no encontro — é assim que farol se comporta de verdade.
        ..blendMode = BlendMode.plus
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 10 + 14 * brilho);

      canvas.drawPath(caminho, tinta);
    }

    // O estouro de luz na própria lâmpada.
    final miolo = Paint()
      ..color = Color.lerp(corQuente, Colors.white, 0.55)!
          .withValues(alpha: 0.85 * brilho)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 + 10 * brilho);
    canvas.drawCircle(
      Offset(centroX, origemY),
      size.width * 0.05 * (0.6 + brilho),
      miolo,
    );
  }

  /// Gradiente do feixe: claro na saída do farol, transparente na ponta.
  Shader _gradienteDoFeixe(Offset origem, Offset ponta) {
    return LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: <Color>[
        Color.lerp(cor, corQuente, 0.35)!.withValues(alpha: 0.55 * brilho),
        cor.withValues(alpha: 0.20 * brilho),
        cor.withValues(alpha: 0),
      ],
      stops: const <double>[0, 0.55, 1],
    ).createShader(
      Rect.fromPoints(
        Offset(math.min(origem.dx, ponta.dx), ponta.dy),
        Offset(math.max(origem.dx, ponta.dx), origem.dy),
      ),
    );
  }

  @override
  bool shouldRepaint(_PintorDaAbertura antigo) =>
      antigo.avanco != avanco ||
      antigo.brilho != brilho ||
      antigo.posicaoCarro != posicaoCarro ||
      antigo.cor != cor ||
      antigo.corQuente != corQuente ||
      antigo.corEstrada != corEstrada;
}
