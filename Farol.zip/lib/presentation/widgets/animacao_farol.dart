/// -----------------------------------------------------------------------
/// A ABERTURA — UM CARRO FAZENDO A CURVA NA AVENIDA E LIGANDO O FAROL
/// -----------------------------------------------------------------------
/// É a primeira coisa que o motorista vê ao abrir o aplicativo. Não é uma
/// figura parada nem o ícone girando: é uma CENA, desenhada de verdade,
/// quadro a quadro.
///
/// O QUE ACONTECE (a animação vai de 0 a 1):
///
///   0.00 → 0.12   A avenida aparece de madrugada: o asfalto vindo do
///                 fundo, as faixas, as calçadas, os postes e os prédios
///                 lá atrás.
///   0.05 → 0.62   O CARRO FAZ A CURVA. Entra lá no fundo, do tamanho de
///                 um grão, e vem VINDO pela avenida — crescendo porque
///                 está chegando perto e VIRANDO junto com a pista: no
///                 meio da curva ele fica de três quartos (dá para ver a
///                 lateral), no fim ele se endireita de frente para você.
///   0.55 → 0.70   PISCA: dois lampejos curtos, como quem liga o farol.
///   0.66 → 0.92   ACENDE DE VEZ: os dois faróis estouram de luz, os
///                 cones se abrem na sua direção e o asfalto à frente do
///                 carro fica lavado de claro.
///   0.78 → 1.00   O nome FAROL surge dentro da luz e o app abre.
///
/// COMO FOI FEITO — sem pacote novo, sem vídeo e sem GIF:
///
///   • A AVENIDA é uma curva de Bézier de três pontos (o traçado do meio
///     da pista) com uma largura que cresce conforme chega perto. Isso
///     sozinho já dá a perspectiva: longe é estreito, perto é largo.
///   • O CARRO é desenhado peça por peça — carroceria, capô, para-brisa,
///     grade, para-choque, rodas, faróis, lanternas. Nada de imagem.
///   • A VIRADA é um truque honesto de perspectiva: a frente do carro é
///     espremida por `cos(ângulo)` e, do lado de dentro da curva, aparece
///     uma LATERAL com largura de `sin(ângulo)`. É assim que o olho lê
///     "o carro está virado".
///   • O ângulo não é inventado: sai da própria pista. Comparo onde o
///     carro está com onde ele estava um instante antes.
///
/// DESEMPENHO: é tudo figura geométrica numa passada só de pintura —
/// nenhuma imagem, nenhuma sombra de widget. Roda liso em celular
/// simples, e quem desligar "Animações" em Aparência nem vê a tela.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class AnimacaoFarolLigando extends StatelessWidget {
  /// A animação que comanda tudo, de 0 a 1.
  final Animation<double> animacao;

  final TemaFarol tema;

  /// Largura total da cena.
  final double tamanho;

  const AnimacaoFarolLigando({
    super.key,
    required this.animacao,
    required this.tema,
    this.tamanho = 260,
  });

  /// A cena é um pouco mais alta do que larga: cabe a avenida inteira,
  /// do horizonte até o asfalto perto do pé de quem olha.
  static const double proporcao = 1.06;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: tamanho,
      height: tamanho * proporcao,
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: animacao,
          builder: (context, _) => CustomPaint(
            painter: _CenaDaAvenida(
              t: animacao.value,
              tema: tema,
            ),
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// AS CONTAS DA CENA
// =======================================================================
// Ficam separadas do desenho, e cada uma faz uma coisa só. Assim dá para
// conferir qualquer número sem precisar abrir o aplicativo.
class Pista {
  Pista._();

  /// Onde fica a linha do horizonte, em fração da altura.
  static const double horizonte = 0.30;

  // Os três pontos que definem o meio da avenida. O ponto do meio é o
  // que cria a CURVA: ele puxa a pista para a direita antes de ela
  // voltar para o centro, lá na frente.
  static Offset _longe(Size s) => Offset(s.width * 0.44, s.height * horizonte);
  static Offset _guia(Size s) => Offset(s.width * 0.98, s.height * 0.60);
  static Offset _perto(Size s) => Offset(s.width * 0.48, s.height * 1.00);

  /// Até onde o carro chega. Não vai até 1 de propósito: assim ele para
  /// com a avenida ainda aparecendo embaixo dele, e não colado na borda.
  static const double avancoMaximo = 0.80;

  /// O meio da pista na profundidade [p] — 0 é o fundo, 1 é bem perto.
  static Offset meio(double p, Size s) {
    final a = p.clamp(0.0, 1.0);
    final u = 1 - a;
    final l = _longe(s);
    final g = _guia(s);
    final n = _perto(s);
    return Offset(
      u * u * l.dx + 2 * u * a * g.dx + a * a * n.dx,
      u * u * l.dy + 2 * u * a * g.dy + a * a * n.dy,
    );
  }

  /// Metade da largura da avenida na profundidade [p].
  ///
  /// Longe é quase um risco; perto ocupa quase a tela toda. O expoente
  /// 1.7 é o que dá a sensação de perspectiva de verdade (a largura
  /// cresce devagar no começo e dispara no fim).
  static double meiaLargura(double p, Size s) {
    final a = p.clamp(0.0, 1.0);
    return s.width * (0.012 + 0.44 * math.pow(a, 1.7));
  }

  /// O quanto o carro aparece virado na profundidade [p], em radianos.
  ///
  /// Sai da inclinação da própria pista: para onde ela estava apontando
  /// um pouco atrás. Nos últimos trechos vai a zero, porque no fim da
  /// curva o carro se endireita de frente para quem olha.
  static double viradaEm(double p, Size s) {
    final atras = meio((p - 0.16).clamp(0.0, 1.0), s);
    final aqui = meio(p, s);
    final dx = aqui.dx - atras.dx;
    final dy = aqui.dy - atras.dy;
    if (dy.abs() < 0.0001) return 0;

    // Quanto a pista "anda para o lado" comparado com o quanto ela
    // "vem para frente". É a conta do volante.
    final bruto = math.atan2(dx, dy);

    // No máximo ~46 graus: mais do que isso o carro vira tanto que some
    // a frente, e a graça é ver a frente virando.
    final limitado = bruto.clamp(-0.80, 0.80);

    // No último terço do trajeto ele vai se endireitando, para terminar
    // de frente para quem está olhando.
    final endireitando =
        ((avancoMaximo - p) / (avancoMaximo * 0.30)).clamp(0.0, 1.0);
    return limitado * endireitando;
  }

  /// Onde o carro está na avenida, de 0 (fundo) a 1 (perto), no
  /// instante [t] da animação.
  static double avanco(double t) {
    final f = ((t - 0.05) / 0.57).clamp(0.0, 1.0);
    // Sai devagar, ganha velocidade no meio da curva e estaciona macio.
    // É o jeito que carro anda de verdade.
    return Curves.easeInOutCubic.transform(f) * avancoMaximo;
  }

  /// Força do farol (0 = apagado, 1 = aceso no talo).
  ///
  /// Os dois lampejos são de propósito: em vez de uma curva suave, o
  /// brilho sobe e desce duas vezes antes de firmar — é o que faz
  /// parecer que alguém girou a chave.
  static double brilho(double t) {
    if (t < 0.55) return 0;
    if (t < 0.595) return 0.80; // primeiro lampejo
    if (t < 0.625) return 0.04; // apaga
    if (t < 0.670) return 0.95; // segundo lampejo
    if (t < 0.700) return 0.10; // apaga de novo
    final f = ((t - 0.700) / 0.22).clamp(0.0, 1.0);
    return Curves.easeOutCubic.transform(f);
  }
}

// =======================================================================
// AS MEDIDAS DO CARRO
// =======================================================================
/// Todas as contas do carro em um lugar só: onde ele está, que tamanho
/// tem e o quanto está virado.
///
/// POR QUE ISTO EXISTE: o carro, os faróis e os cones de luz precisam
/// bater no MESMO ponto. Antes, cada um refazia a conta por conta
/// própria — e bastava mudar um número para a luz sair de fora da
/// lâmpada. Agora a conta é feita uma vez e todo mundo usa.
class _MedidasDoCarro {
  /// Meio do carro na horizontal.
  final double meio;

  /// Onde as rodas encostam no asfalto.
  final double baseY;

  /// Largura e altura do carro inteiro.
  final double largura;
  final double altura;

  /// Metade da FRENTE visível. Quando o carro está virado, a frente
  /// aparece espremida — é esse valor que encolhe.
  final double meiaFrente;

  /// Largura da LATERAL que aparece. Zero quando o carro está de frente;
  /// negativa ou positiva conforme o lado da curva.
  final double larguraLateral;

  /// -1 ou 1: de que lado do carro a lateral aparece.
  final double ladoVisivel;

  /// Altura em que ficam os dois faróis.
  final double alturaDoFarol;

  factory _MedidasDoCarro(Size size, double p) {
    final c = Pista.meio(p, size);
    final w = Pista.meiaLargura(p, size);
    final virada = Pista.viradaEm(p, size);

    // O carro ocupa um pouco mais do que a metade da pista: é o que dá
    // a proporção certa de carro numa avenida de duas faixas.
    final largura = w * 1.05;
    final altura = largura * 0.78;

    // cos = o quanto ainda se vê da frente; sin = o quanto já se vê da
    // lateral. É toda a perspectiva da virada, em duas contas.
    final frente = math.cos(virada).abs();
    final lateral = math.sin(virada);

    final baseY = c.dy + altura * 0.36;
    final meio = c.dx + largura * 0.22 * lateral;

    return _MedidasDoCarro._(
      meio: meio,
      baseY: baseY,
      largura: largura,
      altura: altura,
      meiaFrente: largura * 0.5 * frente,
      larguraLateral: largura * 0.95 * lateral,
      ladoVisivel: lateral >= 0 ? 1.0 : -1.0,
      alturaDoFarol: baseY - altura * 0.40,
    );
  }

  const _MedidasDoCarro._({
    required this.meio,
    required this.baseY,
    required this.largura,
    required this.altura,
    required this.meiaFrente,
    required this.larguraLateral,
    required this.ladoVisivel,
    required this.alturaDoFarol,
  });
}

// =======================================================================
// O DESENHO DA CENA
// =======================================================================
class _CenaDaAvenida extends CustomPainter {
  final double t;
  final TemaFarol tema;

  const _CenaDaAvenida({required this.t, required this.tema});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Pista.avanco(t);
    final brilho = Pista.brilho(t);

    // A cena inteira nasce junto, nos dois primeiros décimos.
    final entrada = Curves.easeOut.transform((t / 0.12).clamp(0.0, 1.0));

    canvas.save();
    canvas.clipRect(Offset.zero & size);

    _pintarCeu(canvas, size, entrada);
    _pintarPredios(canvas, size, entrada);
    _pintarAsfalto(canvas, size, entrada);
    _pintarFaixas(canvas, size, entrada, p);
    _pintarPostes(canvas, size, entrada);

    // A luz que o farol joga no chão vem ANTES do carro: assim ela
    // passa por baixo dele, como acontece de verdade.
    if (brilho > 0.01) _pintarLuzNoChao(canvas, size, p, brilho);

    _pintarCarro(canvas, size, p, brilho, entrada);

    // Os cones vêm por último, por cima de tudo, porque a luz que vem
    // na sua direção ofusca o que está atrás dela.
    if (brilho > 0.01) _pintarCones(canvas, size, p, brilho);

    canvas.restore();
  }

  // -------------------------------------------------------------------
  // O CÉU DE MADRUGADA
  // -------------------------------------------------------------------
  void _pintarCeu(Canvas canvas, Size size, double entrada) {
    final alturaCeu = size.height * Pista.horizonte + 1;
    final ceu = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          tema.fundo,
          Color.lerp(tema.fundo, tema.primaria, 0.16 * entrada)!,
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, alturaCeu));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, alturaCeu), ceu);
  }

  // -------------------------------------------------------------------
  // OS PRÉDIOS LÁ NO FUNDO
  // -------------------------------------------------------------------
  // Silhuetas simples, com algumas janelas acesas. Dão a ideia de
  // avenida de cidade sem custar quase nada para desenhar.
  void _pintarPredios(Canvas canvas, Size size, double entrada) {
    final baseY = size.height * Pista.horizonte;
    final silhueta = Paint()
      ..color = Color.lerp(tema.fundo, tema.texto, 0.10 * entrada)!;
    final janela = Paint()
      ..color = tema.alerta.withValues(alpha: 0.50 * entrada);

    // Alturas e larguras fixas: a cena é sempre a mesma, e assim ela
    // nunca "pisca" diferente de uma abertura para a outra.
    const alturas = <double>[
      0.10, 0.17, 0.07, 0.21, 0.12, 0.26, 0.09, 0.15, 0.19, 0.08,
    ];
    final largura = size.width / alturas.length;

    for (var i = 0; i < alturas.length; i++) {
      final h = size.height * alturas[i];
      final x = i * largura;
      canvas.drawRect(
        Rect.fromLTWH(x + 1, baseY - h, largura - 2, h),
        silhueta,
      );

      // Duas janelas acesas por prédio, sempre nos mesmos lugares.
      for (var j = 0; j < 2; j++) {
        final jy = baseY - h + h * (0.25 + 0.35 * j);
        if (jy < baseY - 3) {
          canvas.drawRect(
            Rect.fromLTWH(x + largura * 0.30, jy, largura * 0.16, 2.2),
            janela,
          );
        }
      }
    }
  }

  // -------------------------------------------------------------------
  // O ASFALTO
  // -------------------------------------------------------------------
  void _pintarAsfalto(Canvas canvas, Size size, double entrada) {
    final borda = _bordasDaPista(size, folga: 1.0);
    final asfalto = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          Color.lerp(tema.fundo, tema.texto, 0.05 * entrada)!,
          Color.lerp(tema.fundo, tema.texto, 0.17 * entrada)!,
        ],
      ).createShader(Offset.zero & size);
    canvas.drawPath(borda, asfalto);

    // As calçadas: uma tirinha clara de cada lado da pista.
    final calcada = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..color = tema.textoSuave.withValues(alpha: 0.22 * entrada);
    canvas.drawPath(borda, calcada);
  }

  /// O contorno fechado da avenida: desce por um lado e volta pelo outro.
  Path _bordasDaPista(Size size, {double folga = 0}) {
    const passos = 26;
    final esquerda = <Offset>[];
    final direita = <Offset>[];

    for (var i = 0; i <= passos; i++) {
      final p = i / passos;
      final c = Pista.meio(p, size);
      final w = Pista.meiaLargura(p, size) + folga;
      esquerda.add(Offset(c.dx - w, c.dy));
      direita.add(Offset(c.dx + w, c.dy));
    }

    final caminho = Path()..moveTo(esquerda.first.dx, esquerda.first.dy);
    for (final o in esquerda.skip(1)) {
      caminho.lineTo(o.dx, o.dy);
    }
    for (final o in direita.reversed) {
      caminho.lineTo(o.dx, o.dy);
    }
    return caminho..close();
  }

  // -------------------------------------------------------------------
  // AS FAIXAS DA AVENIDA
  // -------------------------------------------------------------------
  void _pintarFaixas(Canvas canvas, Size size, double entrada, double p) {
    // ---- As duas contínuas das laterais ----
    final lateral = Paint()..color = tema.textoSuave.withValues(alpha: 0.30 * entrada);
    for (final lado in <double>[-1, 1]) {
      final faixa = Path();
      var comecou = false;
      for (var i = 0; i <= 26; i++) {
        final d = i / 26;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final esp = math.max(0.6, w * 0.055);
        final x = c.dx + lado * (w - esp);
        if (!comecou) {
          faixa.moveTo(x, c.dy);
          comecou = true;
        } else {
          faixa.lineTo(x, c.dy);
        }
      }
      // Volta pelo outro lado da espessura, fechando a fita.
      for (var i = 26; i >= 0; i--) {
        final d = i / 26;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final esp = math.max(0.6, w * 0.055);
        faixa.lineTo(c.dx + lado * (w - esp * 2.6), c.dy);
      }
      canvas.drawPath(faixa..close(), lateral);
    }

    // ---- O tracejado do meio ----
    // Ele "anda" junto com o carro: o deslocamento das faixas é o que
    // faz o olho entender que a avenida está passando.
    final tinta = Paint()
      ..color = tema.textoSuave.withValues(alpha: 0.45 * entrada);
    const quantidade = 9;
    final fase = (p * 1.4) % (1 / quantidade);

    for (var i = 0; i < quantidade; i++) {
      final ini = (i / quantidade + fase).clamp(0.0, 1.0);
      final fim = (ini + 0.045).clamp(0.0, 1.0);
      if (fim <= ini) continue;

      final a = Pista.meio(ini, size);
      final b = Pista.meio(fim, size);
      final wa = math.max(0.5, Pista.meiaLargura(ini, size) * 0.035);
      final wb = math.max(0.5, Pista.meiaLargura(fim, size) * 0.035);

      canvas.drawPath(
        Path()
          ..moveTo(a.dx - wa, a.dy)
          ..lineTo(a.dx + wa, a.dy)
          ..lineTo(b.dx + wb, b.dy)
          ..lineTo(b.dx - wb, b.dy)
          ..close(),
        tinta,
      );
    }
  }

  // -------------------------------------------------------------------
  // OS POSTES DA AVENIDA
  // -------------------------------------------------------------------
  void _pintarPostes(Canvas canvas, Size size, double entrada) {
    final haste = Paint()
      ..style = PaintingStyle.stroke
      ..color = tema.textoSuave.withValues(alpha: 0.30 * entrada);
    final lampada = Paint()
      ..color = tema.alerta.withValues(alpha: 0.55 * entrada)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    // Três de cada lado, em profundidades fixas. Quanto mais perto,
    // maior o poste — é a mesma perspectiva da pista.
    const profundidades = <double>[0.12, 0.34, 0.62];
    for (final d in profundidades) {
      for (final lado in <double>[-1, 1]) {
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final baseX = c.dx + lado * (w + size.width * 0.03);
        final altura = size.height * (0.05 + 0.22 * d);
        final topoY = c.dy - altura;

        haste.strokeWidth = math.max(0.8, size.width * 0.006 * (0.4 + d));
        canvas.drawLine(Offset(baseX, c.dy), Offset(baseX, topoY), haste);
        // O braço curvo, virado para dentro da avenida.
        canvas.drawLine(
          Offset(baseX, topoY),
          Offset(baseX - lado * altura * 0.22, topoY + altura * 0.05),
          haste,
        );
        canvas.drawCircle(
          Offset(baseX - lado * altura * 0.22, topoY + altura * 0.05),
          math.max(1.0, altura * 0.045),
          lampada,
        );
      }
    }
  }

  // -------------------------------------------------------------------
  // A LUZ DO FAROL NO ASFALTO
  // -------------------------------------------------------------------
  void _pintarLuzNoChao(Canvas canvas, Size size, double p, double brilho) {
    final c = Pista.meio(p, size);
    final w = Pista.meiaLargura(p, size);

    // Uma mancha oval na frente do carro (ou seja, mais perto de quem
    // olha), esticada no sentido da pista.
    final centro = Offset(c.dx, c.dy + w * 0.75);
    final area = Rect.fromCenter(
      center: centro,
      width: w * (1.9 + 1.4 * brilho),
      height: w * (1.1 + 0.9 * brilho),
    );

    canvas.drawOval(
      area,
      Paint()
        ..blendMode = BlendMode.plus
        ..shader = RadialGradient(
          colors: <Color>[
            Color.lerp(tema.secundaria, Colors.white, 0.35)!
                .withValues(alpha: 0.38 * brilho),
            tema.primaria.withValues(alpha: 0.14 * brilho),
            tema.primaria.withValues(alpha: 0),
          ],
          stops: const <double>[0, 0.55, 1],
        ).createShader(area),
    );
  }

  // -------------------------------------------------------------------
  // OS CONES DE LUZ VINDO NA SUA DIREÇÃO
  // -------------------------------------------------------------------
  void _pintarCones(Canvas canvas, Size size, double p, double brilho) {
    final farois = _posicaoDosFarois(size, p);
    final w = Pista.meiaLargura(p, size);
    if (w < 4) return;

    for (final origem in farois) {
      // O cone se abre para baixo (para quem olha) e sai da tela.
      final alcance = size.height * (0.20 + 0.42 * brilho);
      final abertura = w * (0.55 + 0.75 * brilho);

      final caminho = Path()
        ..moveTo(origem.dx - w * 0.07, origem.dy)
        ..lineTo(origem.dx + w * 0.07, origem.dy)
        ..lineTo(origem.dx + abertura, origem.dy + alcance)
        ..lineTo(origem.dx - abertura, origem.dy + alcance)
        ..close();

      canvas.drawPath(
        caminho,
        Paint()
          // "plus" faz duas luzes que se cruzam ficarem MAIS claras no
          // encontro — é assim que farol se comporta de verdade.
          ..blendMode = BlendMode.plus
          ..maskFilter =
              MaskFilter.blur(BlurStyle.normal, 6 + 14 * brilho)
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[
              Color.lerp(tema.primaria, tema.secundaria, 0.4)!
                  .withValues(alpha: 0.50 * brilho),
              tema.primaria.withValues(alpha: 0.16 * brilho),
              tema.primaria.withValues(alpha: 0),
            ],
            stops: const <double>[0, 0.55, 1],
          ).createShader(
            Rect.fromLTRB(
              origem.dx - abertura,
              origem.dy,
              origem.dx + abertura,
              origem.dy + alcance,
            ),
          ),
      );

      // O estouro de luz na própria lâmpada.
      canvas.drawCircle(
        origem,
        w * 0.16 * (0.5 + brilho),
        Paint()
          ..blendMode = BlendMode.plus
          ..color = Color.lerp(tema.secundaria, Colors.white, 0.7)!
              .withValues(alpha: 0.85 * brilho)
          ..maskFilter =
              MaskFilter.blur(BlurStyle.normal, 4 + 9 * brilho),
      );
    }
  }

  /// Onde ficam os dois faróis, já considerando a virada do carro.
  /// Serve para o cone de luz sair exatamente de dentro da lâmpada.
  List<Offset> _posicaoDosFarois(Size size, double p) {
    final m = _MedidasDoCarro(size, p);
    return <Offset>[
      Offset(m.meio - m.meiaFrente * 0.68, m.alturaDoFarol),
      Offset(m.meio + m.meiaFrente * 0.68, m.alturaDoFarol),
    ];
  }

  // -------------------------------------------------------------------
  // O CARRO
  // -------------------------------------------------------------------
  // Desenhado peça por peça — nenhuma imagem. A ordem importa: primeiro
  // a sombra no chão, depois as rodas, depois a LATERAL (que fica atrás),
  // e só então a frente por cima. É assim que o carro fica sólido em vez
  // de parecer figuras soltas.
  void _pintarCarro(
    Canvas canvas,
    Size size,
    double p,
    double brilho,
    double entrada,
  ) {
    if (entrada <= 0.01) return;

    final m = _MedidasDoCarro(size, p);
    if (m.largura < 4) return; // tão longe que ainda é um pontinho

    final mx = m.meio;
    final mf = m.meiaFrente;
    final ll = m.larguraLateral;
    final sg = m.ladoVisivel;
    final base = m.baseY;
    final ac = m.altura;

    final corCarroceria = Color.lerp(tema.primaria, Colors.black, 0.18)!;
    final corLado = Color.lerp(corCarroceria, Colors.black, 0.34)!;
    final corVidro = Color.lerp(tema.fundo, tema.primaria, 0.22)!;
    final corEscura = Color.lerp(tema.fundo, Colors.black, 0.55)!;

    // ---- A SOMBRA NO ASFALTO ----
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(mx, base + ac * 0.04),
        width: m.largura * 1.15,
        height: ac * 0.20,
      ),
      Paint()
        ..color = Colors.black.withValues(alpha: 0.35 * entrada)
        ..maskFilter = MaskFilter.blur(
          BlurStyle.normal,
          math.max(1.0, ac * 0.06),
        ),
    );

    // ---- AS RODAS ----
    final raio = ac * 0.15;
    final tintaRoda = Paint()..color = corEscura;
    for (final lado in <double>[-1, 1]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(mx + lado * mf * 0.88, base - raio * 0.30),
            width: raio * 1.20,
            height: raio * 1.90,
          ),
          Radius.circular(raio * 0.45),
        ),
        tintaRoda,
      );
    }
    // A roda de trás só existe quando dá para ver a lateral.
    if (ll.abs() > m.largura * 0.12) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(mx + ll * 0.72, base - raio * 0.50),
            width: raio * 1.00,
            height: raio * 1.60,
          ),
          Radius.circular(raio * 0.40),
        ),
        tintaRoda,
      );
    }

    // ---- A LATERAL ----
    // É uma silhueta de carro de perfil: para-lama, porta, coluna do
    // teto e traseira. Ela nasce grudada na frente, então os dois
    // pedaços leem como UM carro virado.
    if (ll.abs() > m.largura * 0.04) {
      canvas.drawPath(
        Path()
          ..moveTo(mx + mf * sg, base - ac * 0.02)
          ..lineTo(mx + ll, base - ac * 0.06)
          ..lineTo(mx + ll, base - ac * 0.56)
          ..lineTo(mx + ll * 0.70, base - ac * 0.90)
          ..lineTo(mx + mf * sg * 0.78, base - ac * 0.96)
          ..lineTo(mx + mf * sg, base - ac * 0.60)
          ..close(),
        Paint()..color = corLado,
      );
      // O vidro da porta.
      canvas.drawPath(
        Path()
          ..moveTo(mx + mf * sg * 0.86, base - ac * 0.64)
          ..lineTo(mx + ll * 0.90, base - ac * 0.60)
          ..lineTo(mx + ll * 0.74, base - ac * 0.85)
          ..lineTo(mx + mf * sg * 0.76, base - ac * 0.90)
          ..close(),
        Paint()..color = corVidro.withValues(alpha: 0.90),
      );
    }

    // ---- A CARROCERIA DE FRENTE ----
    final corpo = RRect.fromRectAndRadius(
      Rect.fromLTRB(mx - mf, base - ac * 0.62, mx + mf, base - ac * 0.02),
      Radius.circular(ac * 0.13),
    );
    canvas.drawRRect(
      corpo,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.lerp(corCarroceria, Colors.white, 0.14)!,
            corCarroceria,
          ],
        ).createShader(corpo.outerRect),
    );

    // ---- O TETO E O PARA-BRISA ----
    final mt = mf * 0.74;
    canvas.drawPath(
      Path()
        ..moveTo(mx - mf * 0.95, base - ac * 0.58)
        ..lineTo(mx - mt, base - ac * 0.96)
        ..lineTo(mx + mt, base - ac * 0.96)
        ..lineTo(mx + mf * 0.95, base - ac * 0.58)
        ..close(),
      Paint()..color = corCarroceria,
    );

    final paraBrisa = Path()
      ..moveTo(mx - mf * 0.82, base - ac * 0.64)
      ..lineTo(mx - mt * 0.86, base - ac * 0.92)
      ..lineTo(mx + mt * 0.86, base - ac * 0.92)
      ..lineTo(mx + mf * 0.82, base - ac * 0.64)
      ..close();
    canvas.drawPath(
      paraBrisa,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color.lerp(corVidro, Colors.white, 0.20)!,
            corVidro,
          ],
        ).createShader(paraBrisa.getBounds()),
    );

    // ---- O VINCO DO CAPÔ ----
    canvas.drawLine(
      Offset(mx - mf * 0.90, base - ac * 0.56),
      Offset(mx + mf * 0.90, base - ac * 0.56),
      Paint()
        ..color = Colors.black.withValues(alpha: 0.25)
        ..strokeWidth = math.max(1.0, ac * 0.02),
    );

    // ---- A GRADE E O PARA-CHOQUE ----
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(
          mx - mf * 0.46,
          base - ac * 0.44,
          mx + mf * 0.46,
          base - ac * 0.32,
        ),
        Radius.circular(ac * 0.035),
      ),
      Paint()..color = corEscura,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(
          mx - mf * 0.95,
          base - ac * 0.22,
          mx + mf * 0.95,
          base - ac * 0.06,
        ),
        Radius.circular(ac * 0.05),
      ),
      Paint()..color = Color.lerp(corCarroceria, Colors.black, 0.42)!,
    );

    // ---- OS FARÓIS ----
    // Apagados são dois vidros escuros; acesos ficam brancos de luz.
    final corFarol = Color.lerp(
      Color.lerp(tema.textoSuave, Colors.black, 0.45)!,
      Colors.white,
      brilho,
    )!;
    for (final lado in <double>[-1, 1]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(mx + lado * mf * 0.68, m.alturaDoFarol),
            width: mf * 0.48,
            height: ac * 0.14,
          ),
          Radius.circular(ac * 0.055),
        ),
        Paint()..color = corFarol,
      );
    }
  }

  @override
  bool shouldRepaint(_CenaDaAvenida antiga) =>
      antiga.t != t || antiga.tema != tema;
}
