/// -----------------------------------------------------------------------
/// A ABERTURA — O CARRO DO FAROL FAZENDO A CURVA NA AVENIDA
/// -----------------------------------------------------------------------
/// Ocupa a TELA INTEIRA, sem moldura e sem borda. É uma cena desenhada
/// quadro a quadro, e o carro é o MESMO do ícone do aplicativo: o carro
/// de neon, de frente, com os faróis apagados até a hora de acender.
///
/// O QUE ACONTECE (a animação vai de 0 a 1):
///
///   0.00 → 0.12   A avenida de madrugada aparece: o céu estrelado, os
///                 prédios lá no fundo, o asfalto vindo do horizonte, as
///                 faixas e os postes.
///   0.05 → 0.62   O CARRO FAZ A CURVA. Entra do tamanho de um grão lá no
///                 fundo e vem VINDO — crescendo porque chega perto e
///                 VIRANDO junto com a pista: no meio da curva aparece a
///                 lateral dele; no fim ele se endireita de frente.
///   0.55 → 0.70   PISCA: dois lampejos, como quem gira a chave.
///   0.66 → 0.92   ACENDE: os faróis estouram de branco, os cones se
///                 abrem na sua direção, o asfalto fica lavado de luz e
///                 a luz se reflete no chão molhado.
///   0.78 → 1.00   O nome FAROL surge e o aplicativo abre.
///
/// COMO O CARRO FOI FEITO
///
/// Ele é NEON, igual ao ícone: nenhuma imagem, nenhuma foto. É uma
/// sequência de traços brilhantes desenhados na hora —
///
///   silhueta · cabine · vinco do capô · faróis · grade inferior ·
///   entradas de ar · rodas · espelhos
///
/// Cada traço é pintado em TRÊS camadas — o halo largo e fraco, o halo
/// curto e forte, e a linha nítida por cima. É essa sobreposição que faz
/// parecer um tubo de neon aceso, e não um risco com sombra. O miolo do
/// carro é preenchido de escuro para o brilho não vazar por dentro.
///
/// As curvas do corpo são BÉZIER DE VERDADE (`cubicTo`), com os pontos
/// tirados do próprio ícone — não é polígono suavizado. Por isso o traço
/// sai redondo e limpo em qualquer tamanho de tela, do pontinho lá no
/// fundo até o carro ocupando meia tela.
///
/// A VIRADA é perspectiva honesta: a frente é espremida por `cos(ângulo)`
/// e, do lado de dentro da curva, nascem as linhas da LATERAL com
/// comprimento `sin(ângulo)`. O ângulo sai da própria pista — comparo
/// onde o carro está com onde ele estava um instante antes.
///
/// DESEMPENHO: é tudo geometria, sem imagem e sem sombra de widget, com
/// um RepaintBoundary isolando a cena do resto da tela. Roda liso em
/// celular simples — e quem desliga "Animações" em Aparência nem vê.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class AnimacaoFarolLigando extends StatelessWidget {
  /// A animação que comanda tudo, de 0 a 1.
  final Animation<double> animacao;

  final TemaFarol tema;

  const AnimacaoFarolLigando({
    super.key,
    required this.animacao,
    required this.tema,
  });

  @override
  Widget build(BuildContext context) {
    // Sem tamanho fixo: a cena toma o espaço que o pai der. Na abertura,
    // isso é a tela inteira.
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: animacao,
        builder: (context, _) => CustomPaint(
          painter: _CenaDaAvenida(t: animacao.value, tema: tema),
          size: Size.infinite,
        ),
      ),
    );
  }
}

// =======================================================================
// A AVENIDA
// =======================================================================
// As contas da pista ficam aqui, separadas do desenho. Cada uma faz uma
// coisa só, e dá para conferir qualquer número sem abrir o aplicativo.
class Pista {
  Pista._();

  /// Onde fica a linha do horizonte, em fração da altura da tela.
  static const double horizonte = 0.34;

  /// Até onde o carro chega. Não vai até 1 de propósito: assim ele para
  /// com a avenida ainda aparecendo embaixo dele.
  static const double avancoMaximo = 0.72;

  // Os três pontos que definem o meio da avenida. O do meio é o que cria
  // a CURVA: puxa a pista para a direita antes de ela voltar ao centro.
  static Offset _longe(Size s) => Offset(s.width * 0.42, s.height * horizonte);
  static Offset _guia(Size s) => Offset(s.width * 0.96, s.height * 0.58);
  static Offset _perto(Size s) => Offset(s.width * 0.50, s.height * 0.99);

  /// O meio da pista na profundidade [p] — 0 é o fundo, 1 é bem perto.
  static Offset meio(double p, Size s) {
    final a = p.clamp(0.0, 1.0);
    final u = 1 - a;
    final l = _longe(s);
    final g = _guia(s);
    final n = _perto(s);
    return Offset(
      u * u * l.dx + 2 * u * a * g.dx + a * a * n.dx,
      u * u * l.dy + 2 * u * a * g.dy + a * a * n.dy,
    );
  }

  /// Metade da largura da avenida na profundidade [p].
  ///
  /// Longe é quase um risco; perto ela transborda a tela. O expoente 1.7
  /// é o que dá a perspectiva de verdade: cresce devagar no começo e
  /// dispara no fim.
  static double meiaLargura(double p, Size s) {
    final a = p.clamp(0.0, 1.0);
    return s.width * (0.012 + 1.02 * math.pow(a, 1.7));
  }

  /// O quanto o carro aparece virado na profundidade [p], em radianos.
  static double viradaEm(double p, Size s) {
    final atras = meio((p - 0.16).clamp(0.0, 1.0), s);
    final aqui = meio(p, s);
    final dx = aqui.dx - atras.dx;
    final dy = aqui.dy - atras.dy;
    if (dy.abs() < 0.0001) return 0;

    // Quanto a pista anda para o lado comparado com o quanto ela vem
    // para frente. É a conta do volante.
    final bruto = math.atan2(dx, dy);

    // No máximo ~40 graus: mais do que isso some a frente do carro, e a
    // graça é justamente ver a frente virando.
    final limitado = bruto.clamp(-0.70, 0.70);

    // No último terço ele vai se endireitando, para terminar de frente
    // para quem está olhando.
    final endireitando =
        ((avancoMaximo - p) / (avancoMaximo * 0.32)).clamp(0.0, 1.0);
    return limitado * endireitando;
  }

  /// Onde o carro está na avenida no instante [t] da animação.
  static double avanco(double t) {
    final f = ((t - 0.05) / 0.57).clamp(0.0, 1.0);
    // Sai devagar, ganha velocidade no meio da curva e estaciona macio.
    return Curves.easeInOutCubic.transform(f) * avancoMaximo;
  }

  /// Força do farol (0 = apagado, 1 = aceso no talo).
  ///
  /// Os dois lampejos são de propósito: o brilho sobe e desce duas vezes
  /// antes de firmar — é o que faz parecer que alguém girou a chave.
  static double brilho(double t) {
    if (t < 0.55) return 0;
    if (t < 0.595) return 0.80; // primeiro lampejo
    if (t < 0.625) return 0.04; // apaga
    if (t < 0.670) return 0.95; // segundo lampejo
    if (t < 0.700) return 0.10; // apaga de novo
    final f = ((t - 0.700) / 0.22).clamp(0.0, 1.0);
    return Curves.easeOutCubic.transform(f);
  }
}

// =======================================================================
// AS MEDIDAS DO CARRO
// =======================================================================
/// Onde o carro está, que tamanho tem e o quanto está virado.
///
/// POR QUE ISTO EXISTE: o corpo, os faróis, os cones de luz e o reflexo
/// no asfalto precisam bater no MESMO ponto. A conta é feita uma vez,
/// aqui, e todo mundo usa — em vez de cada pedaço refazer por conta
/// própria e sair desencontrado.
class _MedidasDoCarro {
  /// Meio do carro na horizontal.
  final double meio;

  /// Onde as rodas encostam no asfalto.
  final double baseY;

  /// Largura e altura do carro inteiro.
  final double largura;
  final double altura;

  /// De 1 (todo de frente) a 0 (todo de lado): o quanto a frente ainda
  /// aparece. É o que espreme o desenho na horizontal.
  final double espremer;

  /// Comprimento da lateral que aparece. Zero quando está de frente.
  final double lateral;

  const _MedidasDoCarro._({
    required this.meio,
    required this.baseY,
    required this.largura,
    required this.altura,
    required this.espremer,
    required this.lateral,
  });

  factory _MedidasDoCarro(Size size, double p) {
    final c = Pista.meio(p, size);
    final w = Pista.meiaLargura(p, size);
    final virada = Pista.viradaEm(p, size);

    // O carro ocupa um pouco mais do que a metade da pista — é a
    // proporção de um carro numa avenida de duas faixas.
    final largura = w * 1.05;
    final altura = largura * 0.74;

    // cos = o quanto ainda se vê da frente; sin = o quanto já se vê da
    // lateral. É toda a perspectiva da virada em duas contas.
    final frente = math.cos(virada).abs();
    final lado = math.sin(virada);

    return _MedidasDoCarro._(
      meio: c.dx + largura * 0.20 * lado,
      baseY: c.dy + altura * 0.30,
      largura: largura,
      altura: altura,
      espremer: frente,
      lateral: largura * 0.92 * lado,
    );
  }

  /// Converte um ponto do desenho para a tela.
  ///
  /// [u] vai de -0.5 (esquerda do carro) a 0.5 (direita).
  /// [v] vai de 0 (chão, onde a roda encosta) a 1 (teto).
  Offset ponto(double u, double v) =>
      Offset(meio + u * largura * espremer, baseY - v * altura);

  /// A altura em que ficam os dois faróis.
  double get alturaDoFarol => baseY - altura * 0.525;

  /// De que lado aparece a lateral: -1 ou 1.
  double get ladoVisivel => lateral >= 0 ? 1.0 : -1.0;

  /// Onde ficam os dois faróis.
  List<Offset> get farois => <Offset>[
        Offset(meio - largura * espremer * 0.37, alturaDoFarol),
        Offset(meio + largura * espremer * 0.37, alturaDoFarol),
      ];
}

// =======================================================================
// O DESENHO DA CENA
// =======================================================================
class _CenaDaAvenida extends CustomPainter {
  final double t;
  final TemaFarol tema;

  const _CenaDaAvenida({required this.t, required this.tema});

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width < 8 || size.height < 8) return;

    final p = Pista.avanco(t);
    final brilho = Pista.brilho(t);
    final entrada = Curves.easeOut.transform((t / 0.12).clamp(0.0, 1.0));

    canvas.save();
    canvas.clipRect(Offset.zero & size);

    _pintarCeu(canvas, size, entrada);
    _pintarEstrelas(canvas, size, entrada);
    _pintarPredios(canvas, size, entrada);
    _pintarAsfalto(canvas, size, entrada);
    _pintarFaixas(canvas, size, entrada, p);
    _pintarPostes(canvas, size, entrada);

    // A luz no chão e o reflexo vêm ANTES do carro: assim passam por
    // baixo dele, como acontece de verdade.
    if (brilho > 0.01) {
      _pintarLuzNoChao(canvas, size, p, brilho);
      _pintarReflexo(canvas, size, p, brilho);
    }

    _pintarCarro(canvas, size, p, brilho, entrada);

    // Os cones vêm por último: a luz que vem na sua direção ofusca tudo
    // o que está atrás dela.
    if (brilho > 0.01) _pintarCones(canvas, size, p, brilho);

    _pintarVinheta(canvas, size, entrada);

    canvas.restore();
  }

  // -------------------------------------------------------------------
  // A VINHETA
  // -------------------------------------------------------------------
  // Um escurecido suave nos cantos. Não é enfeite: é o que impede a cena
  // de "vazar" nas bordas da tela e joga o olho para o meio, onde o
  // carro está. É o mesmo truque de fotografia noturna.
  void _pintarVinheta(Canvas canvas, Size size, double entrada) {
    final area = Offset.zero & size;
    canvas.drawRect(
      area,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 0.95,
          colors: <Color>[
            Colors.black.withValues(alpha: 0),
            Colors.black.withValues(alpha: 0.12 * entrada),
            Colors.black.withValues(alpha: 0.42 * entrada),
          ],
          stops: const <double>[0.45, 0.78, 1.0],
        ).createShader(area),
    );
  }

  // -------------------------------------------------------------------
  // FERRAMENTAS DE TRAÇO
  // -------------------------------------------------------------------

  /// Liga os pontos com retas — para as peças de canto vivo: rodas,
  /// grade, entradas de ar, faróis.
  static Path _caminhoReto(List<Offset> pontos, {bool fechar = true}) {
    final caminho = Path();
    if (pontos.isEmpty) return caminho;
    caminho.moveTo(pontos.first.dx, pontos.first.dy);
    for (final o in pontos.skip(1)) {
      caminho.lineTo(o.dx, o.dy);
    }
    if (fechar) caminho.close();
    return caminho;
  }

  /// Pinta um traço de NEON: primeiro o brilho borrado que vaza para
  /// fora, depois a linha nítida por cima.
  void _neon(
    Canvas canvas,
    Path caminho,
    Color cor,
    double espessura,
    double desfoque,
  ) {
    // TRÊS camadas, e é isso que faz parecer neon de verdade em vez de
    // um risco com sombra:
    //   1. o halo largo e fraco, que vaza longe;
    //   2. o halo curto e forte, logo em volta do tubo;
    //   3. a linha nítida, que é o "vidro" aceso.
    canvas.drawPath(
      caminho,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = espessura * 2.6
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..color = cor.withValues(alpha: 0.32)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, desfoque * 2.6),
    );
    canvas.drawPath(
      caminho,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = espessura * 1.7
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..color = cor.withValues(alpha: 0.50)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, desfoque),
    );
    canvas.drawPath(
      caminho,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = espessura
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..color = cor,
    );
  }

  // -------------------------------------------------------------------
  // O CÉU
  // -------------------------------------------------------------------
  void _pintarCeu(Canvas canvas, Size size, double entrada) {
    final alturaCeu = size.height * Pista.horizonte + 1;
    final area = Rect.fromLTWH(0, 0, size.width, alturaCeu);
    canvas.drawRect(
      area,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            tema.fundo,
            Color.lerp(tema.fundo, tema.primaria, 0.16 * entrada)!,
          ],
        ).createShader(area),
    );
  }

  // -------------------------------------------------------------------
  // AS ESTRELAS
  // -------------------------------------------------------------------
  // Posições tiradas de uma conta, e não de sorteio: assim a abertura é
  // sempre a mesma e não "pisca" diferente a cada vez que o app abre.
  void _pintarEstrelas(Canvas canvas, Size size, double entrada) {
    final limite = size.height * Pista.horizonte * 0.86;
    final tinta = Paint();
    for (var i = 0; i < 46; i++) {
      // Sequência de baixa discrepância: espalha bem, sem amontoar.
      final x = ((i * 0.7548776662) % 1.0) * size.width;
      final y = ((i * 0.5698402909) % 1.0) * limite;
      final r = 0.6 + ((i * 7) % 4) * 0.24;
      tinta.color = tema.texto.withValues(
        alpha: (0.16 + ((i * 13) % 10) * 0.034) * entrada,
      );
      canvas.drawCircle(Offset(x, y), r, tinta);
    }
  }

  // -------------------------------------------------------------------
  // OS PRÉDIOS
  // -------------------------------------------------------------------
  void _pintarPredios(Canvas canvas, Size size, double entrada) {
    final baseY = size.height * Pista.horizonte;
    final silhueta = Paint()
      ..color = Color.lerp(tema.fundo, tema.texto, 0.10 * entrada)!;
    final janela = Paint()
      ..color = tema.alerta.withValues(alpha: 0.50 * entrada);

    const alturas = <double>[
      0.050, 0.085, 0.035, 0.105, 0.060, 0.130, 0.045, 0.075, 0.095, 0.040,
    ];
    final largura = size.width / alturas.length;

    for (var i = 0; i < alturas.length; i++) {
      final h = size.height * alturas[i];
      final x = i * largura;
      canvas.drawRect(
        Rect.fromLTWH(x + 1, baseY - h, largura - 2, h),
        silhueta,
      );
      for (var j = 0; j < 2; j++) {
        final jy = baseY - h + h * (0.25 + 0.35 * j);
        if (jy < baseY - 3) {
          canvas.drawRect(
            Rect.fromLTWH(x + largura * 0.30, jy, largura * 0.16, 2.2),
            janela,
          );
        }
      }
    }
  }

  // -------------------------------------------------------------------
  // O ASFALTO
  // -------------------------------------------------------------------
  void _pintarAsfalto(Canvas canvas, Size size, double entrada) {
    final borda = _bordasDaPista(size, folga: 1.0);
    canvas.drawPath(
      borda,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.lerp(tema.fundo, tema.texto, 0.05 * entrada)!,
            Color.lerp(tema.fundo, tema.texto, 0.17 * entrada)!,
          ],
        ).createShader(Offset.zero & size),
    );
    canvas.drawPath(
      borda,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0
        ..color = tema.textoSuave.withValues(alpha: 0.22 * entrada),
    );
  }

  /// O contorno fechado da avenida: desce por um lado e volta pelo outro.
  Path _bordasDaPista(Size size, {double folga = 0}) {
    const passos = 46;
    final esquerda = <Offset>[];
    final direita = <Offset>[];
    for (var i = 0; i <= passos; i++) {
      final p = i / passos;
      final c = Pista.meio(p, size);
      final w = Pista.meiaLargura(p, size) + folga;
      esquerda.add(Offset(c.dx - w, c.dy));
      direita.add(Offset(c.dx + w, c.dy));
    }
    final caminho = Path()..moveTo(esquerda.first.dx, esquerda.first.dy);
    for (final o in esquerda.skip(1)) {
      caminho.lineTo(o.dx, o.dy);
    }
    for (final o in direita.reversed) {
      caminho.lineTo(o.dx, o.dy);
    }
    return caminho..close();
  }

  // -------------------------------------------------------------------
  // AS FAIXAS
  // -------------------------------------------------------------------
  void _pintarFaixas(Canvas canvas, Size size, double entrada, double p) {
    // ---- As duas contínuas das laterais ----
    final lateral = Paint()
      ..color = tema.textoSuave.withValues(alpha: 0.30 * entrada);
    for (final lado in <double>[-1, 1]) {
      final faixa = Path();
      for (var i = 0; i <= 46; i++) {
        final d = i / 46;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final esp = math.max(0.6, w * 0.055);
        final x = c.dx + lado * (w - esp);
        if (i == 0) {
          faixa.moveTo(x, c.dy);
        } else {
          faixa.lineTo(x, c.dy);
        }
      }
      for (var i = 46; i >= 0; i--) {
        final d = i / 46;
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final esp = math.max(0.6, w * 0.055);
        faixa.lineTo(c.dx + lado * (w - esp * 2.6), c.dy);
      }
      canvas.drawPath(faixa..close(), lateral);
    }

    // ---- O tracejado do meio ----
    // Ele ANDA junto com o carro. É esse deslocamento que faz o olho
    // entender que a avenida está passando por baixo.
    final tinta = Paint()
      ..color = tema.textoSuave.withValues(alpha: 0.45 * entrada);
    const quantidade = 9;
    final fase = (p * 1.4) % (1 / quantidade);

    for (var i = 0; i < quantidade; i++) {
      final ini = (i / quantidade + fase).clamp(0.0, 1.0);
      final fim = (ini + 0.045).clamp(0.0, 1.0);
      if (fim <= ini) continue;
      final a = Pista.meio(ini, size);
      final b = Pista.meio(fim, size);
      final wa = math.max(0.5, Pista.meiaLargura(ini, size) * 0.035);
      final wb = math.max(0.5, Pista.meiaLargura(fim, size) * 0.035);
      canvas.drawPath(
        Path()
          ..moveTo(a.dx - wa, a.dy)
          ..lineTo(a.dx + wa, a.dy)
          ..lineTo(b.dx + wb, b.dy)
          ..lineTo(b.dx - wb, b.dy)
          ..close(),
        tinta,
      );
    }
  }

  // -------------------------------------------------------------------
  // OS POSTES
  // -------------------------------------------------------------------
  void _pintarPostes(Canvas canvas, Size size, double entrada) {
    final haste = Paint()
      ..style = PaintingStyle.stroke
      ..color = tema.textoSuave.withValues(alpha: 0.30 * entrada);
    final lampada = Paint()
      ..color = tema.alerta.withValues(alpha: 0.55 * entrada)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    const profundidades = <double>[0.10, 0.30, 0.55];
    for (final d in profundidades) {
      for (final lado in <double>[-1, 1]) {
        final c = Pista.meio(d, size);
        final w = Pista.meiaLargura(d, size);
        final baseX = c.dx + lado * (w + size.width * 0.03);
        final altura = size.height * (0.03 + 0.13 * d);
        final topoY = c.dy - altura;

        haste.strokeWidth = math.max(0.8, size.width * 0.006 * (0.4 + d));
        canvas.drawLine(Offset(baseX, c.dy), Offset(baseX, topoY), haste);
        final pontaX = baseX - lado * altura * 0.22;
        final pontaY = topoY + altura * 0.05;
        canvas.drawLine(Offset(baseX, topoY), Offset(pontaX, pontaY), haste);
        canvas.drawCircle(
          Offset(pontaX, pontaY),
          math.max(1.0, altura * 0.045),
          lampada,
        );
      }
    }
  }

  // -------------------------------------------------------------------
  // A LUZ DO FAROL NO ASFALTO
  // -------------------------------------------------------------------
  void _pintarLuzNoChao(Canvas canvas, Size size, double p, double brilho) {
    final c = Pista.meio(p, size);
    final w = Pista.meiaLargura(p, size);
    final area = Rect.fromCenter(
      center: Offset(c.dx, c.dy + w * 0.70),
      width: w * (1.9 + 1.4 * brilho),
      height: w * (1.1 + 0.9 * brilho),
    );
    canvas.drawOval(
      area,
      Paint()
        ..blendMode = BlendMode.plus
        ..shader = RadialGradient(
          colors: <Color>[
            Color.lerp(tema.secundaria, Colors.white, 0.35)!
                .withValues(alpha: 0.34 * brilho),
            tema.primaria.withValues(alpha: 0.12 * brilho),
            tema.primaria.withValues(alpha: 0),
          ],
          stops: const <double>[0, 0.55, 1],
        ).createShader(area),
    );
  }

  // -------------------------------------------------------------------
  // O REFLEXO NO ASFALTO MOLHADO
  // -------------------------------------------------------------------
  // Duas listras de luz descendo de cada farol. É o detalhe que faz a
  // cena parecer madrugada depois da chuva.
  void _pintarReflexo(Canvas canvas, Size size, double p, double brilho) {
    final m = _MedidasDoCarro(size, p);
    final w = Pista.meiaLargura(p, size);
    final comprimento = w * (0.5 + 0.9 * brilho);

    for (final farol in m.farois) {
      canvas.drawPath(
        Path()
          ..moveTo(farol.dx - w * 0.055, m.baseY)
          ..lineTo(farol.dx + w * 0.055, m.baseY)
          ..lineTo(farol.dx + w * 0.10, m.baseY + comprimento)
          ..lineTo(farol.dx - w * 0.10, m.baseY + comprimento)
          ..close(),
        Paint()
          ..blendMode = BlendMode.plus
          ..color = Color.lerp(tema.secundaria, Colors.white, 0.4)!
              .withValues(alpha: 0.30 * brilho)
          ..maskFilter = MaskFilter.blur(
            BlurStyle.normal,
            math.max(3.0, w * 0.09),
          ),
      );
    }
  }

  // -------------------------------------------------------------------
  // OS CONES DE LUZ
  // -------------------------------------------------------------------
  void _pintarCones(Canvas canvas, Size size, double p, double brilho) {
    final m = _MedidasDoCarro(size, p);
    final w = Pista.meiaLargura(p, size);
    if (w < 4) return;

    for (final origem in m.farois) {
      final alcance = size.height * (0.14 + 0.30 * brilho);
      final abertura = w * (0.55 + 0.75 * brilho);
      final area = Rect.fromLTRB(
        origem.dx - abertura,
        origem.dy,
        origem.dx + abertura,
        origem.dy + alcance,
      );

      canvas.drawPath(
        Path()
          ..moveTo(origem.dx - w * 0.07, origem.dy)
          ..lineTo(origem.dx + w * 0.07, origem.dy)
          ..lineTo(origem.dx + abertura, origem.dy + alcance)
          ..lineTo(origem.dx - abertura, origem.dy + alcance)
          ..close(),
        Paint()
          // "plus" faz duas luzes que se cruzam ficarem MAIS claras no
          // encontro — é assim que farol se comporta de verdade.
          ..blendMode = BlendMode.plus
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 6 + 14 * brilho)
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[
              Color.lerp(tema.primaria, tema.secundaria, 0.45)!
                  .withValues(alpha: 0.46 * brilho),
              tema.primaria.withValues(alpha: 0.14 * brilho),
              tema.primaria.withValues(alpha: 0),
            ],
            stops: const <double>[0, 0.55, 1],
          ).createShader(area),
      );

      // O estouro de luz na própria lâmpada.
      canvas.drawCircle(
        origem,
        w * 0.13 * (0.5 + brilho),
        Paint()
          ..blendMode = BlendMode.plus
          ..color = Color.lerp(tema.secundaria, Colors.white, 0.75)!
              .withValues(alpha: 0.90 * brilho)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 4 + 10 * brilho),
      );
    }
  }

  // -------------------------------------------------------------------
  // O CARRO DE NEON — o mesmo do ícone do aplicativo
  // -------------------------------------------------------------------
  // Cada peça é uma CURVA DE BÉZIER de verdade (`cubicTo`), com os
  // pontos tirados do próprio ícone. Não é polígono suavizado nem
  // aproximação: é a mesma curva que um desenho vetorial usaria, então o
  // traço sai redondo e limpo em qualquer tamanho de tela.
  void _pintarCarro(
    Canvas canvas,
    Size size,
    double p,
    double brilho,
    double entrada,
  ) {
    if (entrada <= 0.01) return;

    final m = _MedidasDoCarro(size, p);
    if (m.largura < 8) return; // ainda é um pontinho lá no fundo

    final traco = math.max(1.5, m.largura * 0.017);
    final desfoque = math.max(1.5, m.largura * 0.014);
    final corNeon = Color.lerp(tema.primaria, Colors.white, 0.32)!;

    // ---- A LATERAL, quando o carro está virado ----
    // É o PERFIL do carro, fechado e grudado na frente — e não linhas
    // soltas. Assim os dois pedaços leem como um carro só, virado.
    if (m.lateral.abs() > m.largura * 0.06) {
      final sg = m.ladoVisivel;
      final fundoX = m.meio + m.lateral;
      final topoX = m.meio + m.lateral * 0.66;

      final flanco = Path()
        ..moveTo(m.ponto(0.50 * sg, 0.13).dx, m.ponto(0.50 * sg, 0.13).dy)
        ..lineTo(fundoX, m.baseY - m.altura * 0.11)
        ..lineTo(fundoX, m.baseY - m.altura * 0.55)
        ..quadraticBezierTo(
          fundoX,
          m.baseY - m.altura * 0.82,
          topoX,
          m.baseY - m.altura * 0.90,
        )
        ..lineTo(m.ponto(0.295 * sg, 0.945).dx, m.ponto(0.295 * sg, 0.945).dy)
        ..lineTo(m.ponto(0.50 * sg, 0.62).dx, m.ponto(0.50 * sg, 0.62).dy)
        ..close();

      // Miolo escuro primeiro, para o brilho não vazar por dentro.
      canvas.drawPath(
        flanco,
        Paint()..color = Colors.black.withValues(alpha: 0.86),
      );
      _neon(canvas, flanco, corNeon, traco, desfoque);

      // O vidro da porta, dentro do flanco.
      final vidro = Path()
        ..moveTo(
          m.ponto(0.33 * sg, 0.735).dx,
          m.ponto(0.33 * sg, 0.735).dy,
        )
        ..lineTo(topoX * 0.06 + fundoX * 0.94, m.baseY - m.altura * 0.60)
        ..lineTo(topoX, m.baseY - m.altura * 0.855)
        ..lineTo(
          m.ponto(0.285 * sg, 0.905).dx,
          m.ponto(0.285 * sg, 0.905).dy,
        )
        ..close();
      _neon(canvas, vidro, corNeon, traco * 0.78, desfoque);
    }

    // ---- A SILHUETA ----
    // Do canto de baixo, subindo pelo para-lama, entrando no ombro,
    // levantando na coluna e abaulando no teto. Depois o espelho do
    // outro lado, ponto por ponto.
    final silhueta = Path()
      ..moveTo(m.ponto(0.48, 0.13).dx, m.ponto(0.48, 0.13).dy)
      ..cubicTo(
        m.ponto(0.517, 0.30).dx, m.ponto(0.517, 0.30).dy, //
        m.ponto(0.517, 0.50).dx, m.ponto(0.517, 0.50).dy, //
        m.ponto(0.500, 0.62).dx, m.ponto(0.500, 0.62).dy,
      )
      ..cubicTo(
        m.ponto(0.489, 0.690).dx, m.ponto(0.489, 0.690).dy, //
        m.ponto(0.452, 0.716).dx, m.ponto(0.452, 0.716).dy, //
        m.ponto(0.400, 0.735).dx, m.ponto(0.400, 0.735).dy,
      )
      ..cubicTo(
        m.ponto(0.356, 0.755).dx, m.ponto(0.356, 0.755).dy, //
        m.ponto(0.326, 0.850).dx, m.ponto(0.326, 0.850).dy, //
        m.ponto(0.295, 0.945).dx, m.ponto(0.295, 0.945).dy,
      )
      ..cubicTo(
        m.ponto(0.281, 0.978).dx, m.ponto(0.281, 0.978).dy, //
        m.ponto(0.222, 0.998).dx, m.ponto(0.222, 0.998).dy, //
        m.ponto(0.150, 1.000).dx, m.ponto(0.150, 1.000).dy,
      )
      ..cubicTo(
        m.ponto(0.070, 1.005).dx, m.ponto(0.070, 1.005).dy, //
        m.ponto(-0.070, 1.005).dx, m.ponto(-0.070, 1.005).dy, //
        m.ponto(-0.150, 1.000).dx, m.ponto(-0.150, 1.000).dy,
      )
      ..cubicTo(
        m.ponto(-0.222, 0.998).dx, m.ponto(-0.222, 0.998).dy, //
        m.ponto(-0.281, 0.978).dx, m.ponto(-0.281, 0.978).dy, //
        m.ponto(-0.295, 0.945).dx, m.ponto(-0.295, 0.945).dy,
      )
      ..cubicTo(
        m.ponto(-0.326, 0.850).dx, m.ponto(-0.326, 0.850).dy, //
        m.ponto(-0.356, 0.755).dx, m.ponto(-0.356, 0.755).dy, //
        m.ponto(-0.400, 0.735).dx, m.ponto(-0.400, 0.735).dy,
      )
      ..cubicTo(
        m.ponto(-0.452, 0.716).dx, m.ponto(-0.452, 0.716).dy, //
        m.ponto(-0.489, 0.690).dx, m.ponto(-0.489, 0.690).dy, //
        m.ponto(-0.500, 0.620).dx, m.ponto(-0.500, 0.620).dy,
      )
      ..cubicTo(
        m.ponto(-0.517, 0.50).dx, m.ponto(-0.517, 0.50).dy, //
        m.ponto(-0.517, 0.30).dx, m.ponto(-0.517, 0.30).dy, //
        m.ponto(-0.480, 0.13).dx, m.ponto(-0.480, 0.13).dy,
      )
      ..close();

    // O miolo escuro: sem ele, o brilho vazaria para dentro e o carro
    // ficaria translúcido em vez de sólido.
    canvas.drawPath(
      silhueta,
      Paint()..color = Colors.black.withValues(alpha: 0.86),
    );
    _neon(canvas, silhueta, corNeon, traco, desfoque);

    // ---- A CABINE (para-brisa e colunas) ----
    _neon(
      canvas,
      Path()
        ..moveTo(m.ponto(0.330, 0.725).dx, m.ponto(0.330, 0.725).dy)
        ..cubicTo(
          m.ponto(0.312, 0.800).dx, m.ponto(0.312, 0.800).dy, //
          m.ponto(0.276, 0.885).dx, m.ponto(0.276, 0.885).dy, //
          m.ponto(0.235, 0.935).dx, m.ponto(0.235, 0.935).dy,
        )
        ..cubicTo(
          m.ponto(0.160, 0.962).dx, m.ponto(0.160, 0.962).dy, //
          m.ponto(-0.160, 0.962).dx, m.ponto(-0.160, 0.962).dy, //
          m.ponto(-0.235, 0.935).dx, m.ponto(-0.235, 0.935).dy,
        )
        ..cubicTo(
          m.ponto(-0.276, 0.885).dx, m.ponto(-0.276, 0.885).dy, //
          m.ponto(-0.312, 0.800).dx, m.ponto(-0.312, 0.800).dy, //
          m.ponto(-0.330, 0.725).dx, m.ponto(-0.330, 0.725).dy,
        )
        ..cubicTo(
          m.ponto(-0.200, 0.688).dx, m.ponto(-0.200, 0.688).dy, //
          m.ponto(0.200, 0.688).dx, m.ponto(0.200, 0.688).dy, //
          m.ponto(0.330, 0.725).dx, m.ponto(0.330, 0.725).dy,
        )
        ..close(),
      corNeon,
      traco,
      desfoque,
    );

    // ---- O SORRISO DO CAPÔ ----
    _neon(
      canvas,
      Path()
        ..moveTo(m.ponto(-0.492, 0.648).dx, m.ponto(-0.492, 0.648).dy)
        ..cubicTo(
          m.ponto(-0.270, 0.520).dx, m.ponto(-0.270, 0.520).dy, //
          m.ponto(0.270, 0.520).dx, m.ponto(0.270, 0.520).dy, //
          m.ponto(0.492, 0.648).dx, m.ponto(0.492, 0.648).dy,
        ),
      corNeon,
      traco,
      desfoque,
    );

    // ---- A GRADE DE BAIXO ----
    _neon(
      canvas,
      Path()
        ..moveTo(m.ponto(-0.437, 0.135).dx, m.ponto(-0.437, 0.135).dy)
        ..cubicTo(
          m.ponto(-0.437, 0.200).dx, m.ponto(-0.437, 0.200).dy, //
          m.ponto(-0.432, 0.245).dx, m.ponto(-0.432, 0.245).dy, //
          m.ponto(-0.372, 0.262).dx, m.ponto(-0.372, 0.262).dy,
        )
        ..cubicTo(
          m.ponto(-0.200, 0.285).dx, m.ponto(-0.200, 0.285).dy, //
          m.ponto(0.200, 0.285).dx, m.ponto(0.200, 0.285).dy, //
          m.ponto(0.372, 0.262).dx, m.ponto(0.372, 0.262).dy,
        )
        ..cubicTo(
          m.ponto(0.432, 0.245).dx, m.ponto(0.432, 0.245).dy, //
          m.ponto(0.437, 0.200).dx, m.ponto(0.437, 0.200).dy, //
          m.ponto(0.437, 0.135).dx, m.ponto(0.437, 0.135).dy,
        )
        ..close(),
      corNeon,
      traco,
      desfoque,
    );

    // ---- AS ENTRADAS DE AR, AS RODAS E OS ESPELHOS ----
    for (final lado in <double>[-1, 1]) {
      _neon(
        canvas,
        _caminhoReto(<Offset>[
          m.ponto(0.430 * lado, 0.262),
          m.ponto(0.252 * lado, 0.244),
          m.ponto(0.312 * lado, 0.138),
          m.ponto(0.430 * lado, 0.138),
        ]),
        corNeon,
        traco,
        desfoque,
      );

      // A roda: um quadrado de cantos arredondados encostado no chão,
      // como no ícone.
      final a = m.ponto(0.348 * lado, 0.145);
      final b = m.ponto(0.487 * lado, 0.0);
      final canto = (b.dx - a.dx).abs() * 0.28;
      _neon(
        canvas,
        Path()
          ..addRRect(
            RRect.fromRectAndCorners(
              Rect.fromLTRB(
                math.min(a.dx, b.dx),
                math.min(a.dy, b.dy),
                math.max(a.dx, b.dx),
                math.max(a.dy, b.dy),
              ),
              topLeft: Radius.circular(canto),
              topRight: Radius.circular(canto),
              bottomLeft: Radius.circular(canto * 0.45),
              bottomRight: Radius.circular(canto * 0.45),
            ),
          ),
        corNeon,
        traco,
        desfoque,
      );

      // O espelho: o lacinho que aparece no ombro do carro.
      _neon(
        canvas,
        Path()
          ..moveTo(
            m.ponto(0.492 * lado, 0.706).dx,
            m.ponto(0.492 * lado, 0.706).dy,
          )
          ..cubicTo(
            m.ponto(0.540 * lado, 0.716).dx,
            m.ponto(0.540 * lado, 0.716).dy,
            m.ponto(0.578 * lado, 0.742).dx,
            m.ponto(0.578 * lado, 0.742).dy,
            m.ponto(0.566 * lado, 0.760).dx,
            m.ponto(0.566 * lado, 0.760).dy,
          )
          ..cubicTo(
            m.ponto(0.552 * lado, 0.776).dx,
            m.ponto(0.552 * lado, 0.776).dy,
            m.ponto(0.512 * lado, 0.752).dx,
            m.ponto(0.512 * lado, 0.752).dy,
            m.ponto(0.489 * lado, 0.700).dx,
            m.ponto(0.489 * lado, 0.700).dy,
          )
          ..close(),
        corNeon,
        traco * 0.80,
        desfoque,
      );
    }

    // ---- OS FARÓIS ----
    // A cunha inclinada do ícone. Apagados são vidro escuro; acesos
    // ficam brancos de luz.
    final corVidro = Color.lerp(
      Color.lerp(tema.textoSuave, Colors.black, 0.50)!,
      Colors.white,
      brilho,
    )!;
    for (final lado in <double>[-1, 1]) {
      final farol = Path()
        ..moveTo(
          m.ponto(0.482 * lado, 0.612).dx,
          m.ponto(0.482 * lado, 0.612).dy,
        )
        ..cubicTo(
          m.ponto(0.400 * lado, 0.600).dx,
          m.ponto(0.400 * lado, 0.600).dy,
          m.ponto(0.330 * lado, 0.578).dx,
          m.ponto(0.330 * lado, 0.578).dy,
          m.ponto(0.282 * lado, 0.556).dx,
          m.ponto(0.282 * lado, 0.556).dy,
        )
        ..lineTo(
          m.ponto(0.262 * lado, 0.487).dx,
          m.ponto(0.262 * lado, 0.487).dy,
        )
        ..cubicTo(
          m.ponto(0.340 * lado, 0.492).dx,
          m.ponto(0.340 * lado, 0.492).dy,
          m.ponto(0.420 * lado, 0.498).dx,
          m.ponto(0.420 * lado, 0.498).dy,
          m.ponto(0.470 * lado, 0.505).dx,
          m.ponto(0.470 * lado, 0.505).dy,
        )
        ..close();

      canvas.drawPath(
        farol,
        Paint()..color = corVidro.withValues(alpha: 0.35 + 0.65 * brilho),
      );
      _neon(
        canvas,
        farol,
        Color.lerp(corNeon, Colors.white, brilho)!,
        traco * 0.85,
        desfoque,
      );
    }
  }

  @override
  bool shouldRepaint(_CenaDaAvenida antiga) =>
      antiga.t != t || antiga.tema != tema;
}
