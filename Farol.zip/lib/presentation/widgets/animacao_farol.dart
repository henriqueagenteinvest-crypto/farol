/// -----------------------------------------------------------------------
/// A ANIMAÇÃO DO CARRO QUE ACENDE O FAROL
/// -----------------------------------------------------------------------
/// É o que o motorista vê ao abrir o aplicativo — e é o nome do app
/// acontecendo na tela: um carro no escuro que LIGA O FAROL.
///
/// COMO FOI FEITO (sem pacote nenhum, sem vídeo, sem GIF):
///
///   0.00 → 0.25   O carro aparece vindo de baixo, ainda apagado.
///   0.20 → 0.45   PISCA: o farol dá dois lampejos curtos, como quem
///                 tenta acender. É o detalhe que dá vida.
///   0.40 → 0.85   ACENDE de vez: o cone de luz se abre para frente e
///                 vai ficando mais forte e mais comprido.
///   0.60 → 1.00   O nome FAROL surge dentro da luz.
///
/// O cone de luz é desenhado por um CustomPainter — dois triângulos com
/// gradiente que se abrem a partir dos faróis. Custa quase nada de
/// processamento (é uma figura só, sem imagem), então roda liso mesmo
/// em celular fraco.
///
/// A imagem do carro é o próprio ícone do aplicativo
/// (assets/images/farol_icone.png). Se por algum motivo ela não carregar,
/// entra um carro desenhado com ícone do sistema no lugar — a tela nunca
/// fica quebrada.
/// -----------------------------------------------------------------------
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../theme/tema_farol.dart';

class AnimacaoFarolLigando extends StatelessWidget {
  /// A animação que comanda tudo, de 0 a 1.
  final Animation<double> animacao;

  final TemaFarol tema;

  /// Largura total do desenho.
  final double tamanho;

  const AnimacaoFarolLigando({
    super.key,
    required this.animacao,
    required this.tema,
    this.tamanho = 220,
  });

  /// Força do farol em cada instante da animação (0 = apagado, 1 = aceso).
  ///
  /// Os dois lampejos são feitos "na mão": em vez de uma curva suave,
  /// o brilho sobe e desce de propósito duas vezes antes de firmar.
  static double brilhoEm(double t) {
    if (t < 0.20) return 0;
    if (t < 0.26) return 0.85; // primeiro lampejo
    if (t < 0.31) return 0.05; // apaga
    if (t < 0.37) return 0.95; // segundo lampejo
    if (t < 0.42) return 0.10; // apaga de novo
    // A partir daqui acende de vez e vai firmando.
    final f = ((t - 0.42) / 0.43).clamp(0.0, 1.0);
    return Curves.easeOutCubic.transform(f);
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: tamanho,
      height: tamanho * 0.78,
      child: AnimatedBuilder(
        animation: animacao,
        builder: (context, _) {
          final t = animacao.value;
          final brilho = brilhoEm(t);

          // Entrada do carro: sobe 30 pixels e aparece.
          final entrada =
              Curves.easeOutCubic.transform((t / 0.25).clamp(0.0, 1.0));

          return Stack(
            alignment: Alignment.center,
            children: <Widget>[
              // ---- O CONE DE LUZ, atrás do carro ----
              Positioned.fill(
                child: CustomPaint(
                  painter: _PintorDeFarol(
                    brilho: brilho,
                    cor: tema.primaria,
                    corQuente: tema.secundaria,
                  ),
                ),
              ),

              // ---- O CARRO ----
              Transform.translate(
                offset: Offset(0, 30 * (1 - entrada)),
                child: Opacity(
                  opacity: entrada,
                  child: Container(
                    width: tamanho * 0.52,
                    height: tamanho * 0.52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(tamanho * 0.14),
                      boxShadow: <BoxShadow>[
                        // O halo em volta do carro acompanha o farol:
                        // quanto mais aceso, mais o carro "brilha".
                        BoxShadow(
                          color: tema.primaria.withValues(alpha: 0.55 * brilho),
                          blurRadius: 40 * brilho + 6,
                          spreadRadius: 2 * brilho,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(tamanho * 0.14),
                      child: Image.asset(
                        'assets/images/farol_icone.png',
                        fit: BoxFit.cover,
                        // Sem a imagem, um carro de ícone entra no lugar.
                        errorBuilder: (context, _, __) => Container(
                          color: tema.superficieAlta,
                          alignment: Alignment.center,
                          child: Icon(
                            Icons.directions_car_rounded,
                            size: tamanho * 0.30,
                            color: Color.lerp(
                              tema.textoSuave,
                              tema.primaria,
                              brilho,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// =======================================================================
/// O DESENHO DO CONE DE LUZ
/// =======================================================================
/// Dois feixes que saem da frente do carro e se abrem para os lados,
/// cada um com um gradiente que vai do claro (perto do farol) ao
/// transparente (longe). Tudo em uma passada só de pintura.
class _PintorDeFarol extends CustomPainter {
  final double brilho;
  final Color cor;
  final Color corQuente;

  const _PintorDeFarol({
    required this.brilho,
    required this.cor,
    required this.corQuente,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (brilho <= 0.01) return;

    final centroX = size.width / 2;
    // Os faróis ficam um pouco abaixo do meio do carro.
    final origemY = size.height * 0.56;

    // O feixe cresce conforme o farol acende.
    final alcance = size.height * (0.30 + 0.62 * brilho);
    final abertura = size.width * (0.16 + 0.30 * brilho);

    // Um feixe para cada lado: esquerdo e direito.
    for (final lado in <double>[-1, 1]) {
      final origem = Offset(centroX + lado * size.width * 0.085, origemY);
      final pontaCima = Offset(
        origem.dx + lado * abertura * 1.15,
        origemY - alcance,
      );
      final pontaBaixo = Offset(
        origem.dx + lado * abertura * 0.25,
        origemY - alcance * 0.72,
      );

      final caminho = Path()
        ..moveTo(origem.dx, origem.dy)
        ..lineTo(pontaCima.dx, pontaCima.dy)
        ..lineTo(pontaBaixo.dx, pontaBaixo.dy)
        ..close();

      final tinta = Paint()
        ..shader = _gradienteDoFeixe(origem, pontaCima, brilho, cor, corQuente)
        // O modo "plus" é o que faz duas luzes que se cruzam ficarem
        // MAIS claras no encontro — é assim que farol se comporta.
        ..blendMode = BlendMode.plus
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 10 + 14 * brilho);

      canvas.drawPath(caminho, tinta);
    }

    // O ponto forte do farol em si — o "estouro" de luz na lâmpada.
    final miolo = Paint()
      ..color = Color.lerp(corQuente, Colors.white, 0.55)!
          .withValues(alpha: 0.85 * brilho)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 + 10 * brilho);
    canvas.drawCircle(
      Offset(centroX, origemY),
      size.width * 0.055 * (0.6 + brilho),
      miolo,
    );
  }

  /// Gradiente do feixe: claro na saída do farol, transparente na ponta.
  Shader _gradienteDoFeixe(
    Offset origem,
    Offset ponta,
    double brilho,
    Color cor,
    Color corQuente,
  ) {
    return LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: <Color>[
        Color.lerp(cor, corQuente, 0.35)!.withValues(alpha: 0.55 * brilho),
        cor.withValues(alpha: 0.20 * brilho),
        cor.withValues(alpha: 0),
      ],
      stops: const <double>[0, 0.55, 1],
    ).createShader(
      Rect.fromPoints(
        Offset(math.min(origem.dx, ponta.dx), ponta.dy),
        Offset(math.max(origem.dx, ponta.dx), origem.dy),
      ),
    );
  }

  @override
  bool shouldRepaint(_PintorDeFarol antigo) =>
      antigo.brilho != brilho ||
      antigo.cor != cor ||
      antigo.corQuente != corQuente;
}
