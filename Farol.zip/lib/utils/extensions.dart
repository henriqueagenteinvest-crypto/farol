/// -----------------------------------------------------------------------
/// EXTENSÕES ÚTEIS
/// -----------------------------------------------------------------------
library;

import 'package:flutter/material.dart';

extension DataUtil on DateTime {
  /// Zera hora/minuto/segundo — útil para comparar "mesmo dia".
  DateTime get soData => DateTime(year, month, day);

  /// Verifica se duas datas caem no mesmo dia.
  bool mesmoDia(DateTime outra) =>
      year == outra.year && month == outra.month && day == outra.day;

  /// Verifica se é hoje.
  bool get ehHoje => mesmoDia(DateTime.now());

  /// Primeiro dia da semana (segunda-feira).
  DateTime get inicioSemana => soData.subtract(Duration(days: weekday - 1));

  /// Último dia da semana (domingo, 23:59:59).
  DateTime get fimSemana =>
      inicioSemana.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));

  /// Primeiro dia do mês.
  DateTime get inicioMes => DateTime(year, month, 1);

  /// Último instante do mês.
  DateTime get fimMes => DateTime(year, month + 1, 1)
      .subtract(const Duration(seconds: 1));

  /// Primeiro dia do ano.
  DateTime get inicioAno => DateTime(year, 1, 1);

  /// Último instante do ano.
  DateTime get fimAno => DateTime(year, 12, 31, 23, 59, 59);

  /// Está dentro do intervalo (inclusivo nas duas pontas)?
  bool dentroDe(DateTime inicio, DateTime fim) =>
      !isBefore(inicio) && !isAfter(fim);
}

extension ContextUtil on BuildContext {
  /// Atalhos para não repetir Theme.of(context) em todo lugar.
  ThemeData get tema => Theme.of(this);
  ColorScheme get cores => Theme.of(this).colorScheme;
  TextTheme get textos => Theme.of(this).textTheme;
  Size get tamanhoTela => MediaQuery.sizeOf(this);
  bool get telaPequena => MediaQuery.sizeOf(this).width < 360;

  /// Mostra uma mensagem rápida na parte de baixo da tela.
  void aviso(String mensagem, {bool erro = false}) {
    ScaffoldMessenger.of(this)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            mensagem,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          backgroundColor: erro
              ? const Color(0xFFD64550)
              : Theme.of(this).colorScheme.primary,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          margin: const EdgeInsets.all(16),
        ),
      );
  }
}

extension ListaNumeros on Iterable<double> {
  /// Soma segura (lista vazia = 0).
  double get somaSegura =>
      isEmpty ? 0.0 : reduce((a, b) => a + b);

  /// Média segura (lista vazia = 0).
  double get mediaSegura => isEmpty ? 0.0 : somaSegura / length;
}
