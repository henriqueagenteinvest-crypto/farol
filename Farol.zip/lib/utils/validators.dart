/// -----------------------------------------------------------------------
/// VALIDADORES DE FORMULÁRIO
/// -----------------------------------------------------------------------
/// Devolvem `null` quando o campo está certo e uma mensagem em português
/// quando está errado. As mensagens são simples e diretas, porque quem usa
/// o app é motorista, não programador.
/// -----------------------------------------------------------------------
library;

import '../core/app_constants.dart';
import 'formatters.dart';

class Validadores {
  Validadores._();

  /// Campo obrigatório de texto.
  static String? obrigatorio(String? valor, {String campo = 'Este campo'}) {
    if (valor == null || valor.trim().isEmpty) {
      return '$campo é obrigatório';
    }
    return null;
  }

  /// Nome do motorista: pelo menos 2 letras.
  static String? nome(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'Digite seu nome';
    }
    if (valor.trim().length < 2) {
      return 'Nome muito curto';
    }
    return null;
  }

  /// Placa: ABC-1234 (antiga) ou ABC-1D23 (Mercosul). Campo opcional.
  static String? placa(String? valor) {
    if (valor == null || valor.trim().isEmpty) return null; // opcional
    final t = valor.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    final antiga = RegExp(r'^[A-Z]{3}\d{4}$');
    final mercosul = RegExp(r'^[A-Z]{3}\d[A-Z]\d{2}$');
    if (antiga.hasMatch(t) || mercosul.hasMatch(t)) return null;
    return 'Placa inválida (ex.: ABC-1234)';
  }

  /// Ano do veículo entre 1980 e o ano que vem.
  static String? ano(String? valor) {
    if (valor == null || valor.trim().isEmpty) return null; // opcional
    final n = Fmt.paraInt(valor);
    if (n == null) return 'Digite só números';
    final limite = DateTime.now().year + 1;
    if (n < 1980 || n > limite) return 'Ano entre 1980 e $limite';
    return null;
  }

  /// Valor em dinheiro obrigatório e maior que zero.
  static String? valorPositivo(String? valor, {String campo = 'O valor'}) {
    final n = Fmt.paraDouble(valor);
    if (n == null) return '$campo é obrigatório';
    if (n <= 0) return '$campo precisa ser maior que zero';
    if (n > AppConstants.valorMaximoLancamento) {
      return '$campo parece alto demais, confira';
    }
    return null;
  }

  /// Valor em dinheiro que pode ser zero (ex.: desconto).
  static String? valorNaoNegativo(String? valor, {String campo = 'O valor'}) {
    if (valor == null || valor.trim().isEmpty) return null;
    final n = Fmt.paraDouble(valor);
    if (n == null) return 'Digite um número válido';
    if (n < 0) return '$campo não pode ser negativo';
    return null;
  }

  /// Quilometragem do dia.
  static String? km(String? valor, {bool obrigatorioCampo = true}) {
    final n = Fmt.paraDouble(valor);
    if (n == null) return obrigatorioCampo ? 'Informe os KM rodados' : null;
    if (n < 0) return 'KM não pode ser negativo';
    if (n > AppConstants.kmMaximoPorDia) {
      return 'Máximo ${AppConstants.kmMaximoPorDia.toInt()} km por dia';
    }
    return null;
  }

  /// Horas trabalhadas no dia.
  static String? horas(String? valor, {bool obrigatorioCampo = true}) {
    final n = Fmt.paraDouble(valor);
    if (n == null) return obrigatorioCampo ? 'Informe as horas' : null;
    if (n < 0) return 'Horas não pode ser negativo';
    if (n > AppConstants.horasMaximoPorDia) return 'Máximo 24 horas por dia';
    return null;
  }

  /// Quantidade de corridas.
  static String? corridas(String? valor, {bool obrigatorioCampo = true}) {
    final n = Fmt.paraInt(valor);
    if (n == null) return obrigatorioCampo ? 'Informe as corridas' : null;
    if (n < 0) return 'Não pode ser negativo';
    if (n > AppConstants.corridasMaximoPorDia) {
      return 'Máximo ${AppConstants.corridasMaximoPorDia} corridas';
    }
    return null;
  }

  /// Consumo do carro (km por litro).
  static String? kmPorLitro(String? valor) {
    final n = Fmt.paraDouble(valor);
    if (n == null) return 'Informe o consumo (km/L)';
    if (n <= 0) return 'Consumo precisa ser maior que zero';
    if (n > 60) return 'Consumo parece alto demais, confira';
    return null;
  }

  /// Litros abastecidos.
  static String? litros(String? valor) {
    final n = Fmt.paraDouble(valor);
    if (n == null) return 'Informe os litros';
    if (n <= 0) return 'Litros precisa ser maior que zero';
    if (n > 300) return 'Litros parece alto demais, confira';
    return null;
  }

  /// Porcentagem de 0 a 100.
  static String? percentual(String? valor, {bool obrigatorioCampo = false}) {
    if ((valor == null || valor.trim().isEmpty) && !obrigatorioCampo) {
      return null;
    }
    final n = Fmt.paraDouble(valor);
    if (n == null) return 'Digite um número válido';
    if (n < 0 || n > 100) return 'Use um valor entre 0 e 100';
    return null;
  }

  /// Taxa de juros (permite passar de 100% em cenários de simulação longa).
  static String? taxaJuros(String? valor) {
    final n = Fmt.paraDouble(valor);
    if (n == null) return 'Informe a taxa';
    if (n < 0) return 'Taxa não pode ser negativa';
    if (n > 1000) return 'Taxa irreal, confira';
    return null;
  }
}
