/// -----------------------------------------------------------------------
/// FORMATADORES pt-BR
/// -----------------------------------------------------------------------
/// Tudo que aparece na tela passa por aqui: dinheiro em R$, datas em
/// DD/MM/AAAA e números com vírgula decimal.
/// -----------------------------------------------------------------------
library;

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class Fmt {
  Fmt._();

  // -------------------------------------------------------------------
  // OS FORMATADORES FICAM PRONTOS, E NÃO SÃO REFEITOS A CADA NÚMERO
  // -------------------------------------------------------------------
  // Antes, cada `Fmt.moeda(...)` construía um NumberFormat novo. Numa
  // tela com 30 valores, isso é 30 objetos por quadro — e o Painel
  // redesenha muitas vezes por segundo enquanto se rola a tela.
  // Agora eles são montados uma vez só e reaproveitados. É uma das
  // mudanças que mais aliviam o celular.
  static final NumberFormat _moeda =
      NumberFormat.currency(locale: 'pt_BR', symbol: r'R$', decimalDigits: 2);
  static final NumberFormat _semSimbolo = NumberFormat('#,##0.00', 'pt_BR');
  static final Map<int, NumberFormat> _porCasas = <int, NumberFormat>{};

  static final DateFormat _data = DateFormat('dd/MM/yyyy', 'pt_BR');
  static final DateFormat _dataCurta = DateFormat('dd/MM', 'pt_BR');
  static final DateFormat _hora = DateFormat('HH:mm', 'pt_BR');
  static final DateFormat _dataHora = DateFormat('dd/MM/yyyy HH:mm', 'pt_BR');
  static final DateFormat _extenso =
      DateFormat("EEEE, dd 'de' MMMM 'de' yyyy", 'pt_BR');
  static final DateFormat _mesAno = DateFormat('MMMM/yyyy', 'pt_BR');

  static NumberFormat _formatoDe(int casas) => _porCasas.putIfAbsent(
        casas,
        () => NumberFormat(
          casas == 0 ? '#,##0' : '#,##0.${'0' * casas}',
          'pt_BR',
        ),
      );

  /// Formata dinheiro: 1234.5 -> "R$ 1.234,50"
  static String moeda(num? valor) {
    final v = (valor ?? 0).toDouble();
    return _moeda.format(v.isFinite ? v : 0);
  }

  /// Formata dinheiro sem o símbolo: 1234.5 -> "1.234,50"
  static String moedaSemSimbolo(num? valor) {
    final v = (valor ?? 0).toDouble();
    return _semSimbolo.format(v.isFinite ? v : 0);
  }

  /// Número decimal com casas escolhidas: 12.345 -> "12,35" (2 casas)
  static String numero(num? valor, {int casas = 2}) {
    final v = (valor ?? 0).toDouble();
    return _formatoDe(casas).format(v.isFinite ? v : 0);
  }

  /// Inteiro: 1234 -> "1.234"
  static String inteiro(num? valor) => numero(valor, casas: 0);

  /// Porcentagem: 87.5 -> "87,5%"
  static String percentual(num? valor, {int casas = 1}) =>
      '${numero(valor, casas: casas)}%';

  /// Data: DateTime -> "01/09/2026"
  static String data(DateTime? d) => d == null ? '--/--/----' : _data.format(d);

  /// Data curta: "01/09"
  static String dataCurta(DateTime? d) =>
      d == null ? '--/--' : _dataCurta.format(d);

  /// Data por extenso: "segunda-feira, 01 de setembro de 2026"
  static String dataExtenso(DateTime d) =>
      _extenso.format(d);

  /// Dia da semana curto: "Seg"
  static String diaSemana(DateTime d) {
    const dias = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
    return dias[d.weekday - 1];
  }

  /// Mês e ano: "Setembro/2026"
  static String mesAno(DateTime d) {
    final s = _mesAno.format(d);
    return s[0].toUpperCase() + s.substring(1);
  }

  /// Hora: "14:35"
  static String hora(DateTime d) => _hora.format(d);

  /// Data e hora: "01/09/2026 14:35"
  static String dataHora(DateTime d) => _dataHora.format(d);

  /// Duração em horas decimais -> texto amigável: 8.5 -> "8h30"
  static String horasTexto(double horasDecimais) {
    if (!horasDecimais.isFinite || horasDecimais < 0) return '0h00';
    final totalMinutos = (horasDecimais * 60).round();
    final h = totalMinutos ~/ 60;
    final m = totalMinutos % 60;
    return '${h}h${m.toString().padLeft(2, '0')}';
  }

  /// Duration -> cronômetro "01:23:45"
  static String cronometro(Duration d) {
    final horas = d.inHours.toString().padLeft(2, '0');
    final min = (d.inMinutes % 60).toString().padLeft(2, '0');
    final seg = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$horas:$min:$seg';
  }

  /// Quilometragem: 123.4 -> "123,4 km"
  static String km(num? valor) => '${numero(valor, casas: 1)} km';

  /// Litros: 12.345 -> "12,35 L"
  static String litros(num? valor) => '${numero(valor, casas: 2)} L';

  /// A mesma coisa, mas com a unidade que o combustível usa:
  /// "38,50 L", "12,00 m³" ou "24,80 kWh".
  static String quantidade(num? valor, String unidade) =>
      '${numero(valor, casas: 2)} $unidade';

  /// -------------------------------------------------------------------
  /// CONVERSÃO DE TEXTO DIGITADO -> NÚMERO
  /// -------------------------------------------------------------------
  /// O motorista digita "1.234,56" ou "1234,56" ou "1234.56".
  /// Esta função entende todos os formatos e devolve 1234.56.
  /// Se não conseguir entender, devolve null (campo inválido).
  static double? paraDouble(String? texto) {
    if (texto == null) return null;
    var t = texto.trim();
    if (t.isEmpty) return null;

    // Remove tudo que não for dígito, vírgula, ponto ou sinal de menos.
    t = t.replaceAll(RegExp(r'[^\d,.\-]'), '');
    if (t.isEmpty || t == '-') return null;

    final temVirgula = t.contains(',');
    final temPonto = t.contains('.');

    if (temVirgula && temPonto) {
      // "1.234,56" -> ponto é separador de milhar, vírgula é decimal
      if (t.lastIndexOf(',') > t.lastIndexOf('.')) {
        t = t.replaceAll('.', '').replaceAll(',', '.');
      } else {
        // "1,234.56" (formato inglês) -> vírgula é milhar
        t = t.replaceAll(',', '');
      }
    } else if (temVirgula) {
      t = t.replaceAll(',', '.');
    } else if (temPonto) {
      // Se o ponto separa grupos de 3 dígitos, é milhar: "1.234"
      final partes = t.split('.');
      final ultimo = partes.last;
      if (partes.length > 1 && ultimo.length == 3) {
        t = t.replaceAll('.', '');
      }
    }
    return double.tryParse(t);
  }

  /// Igual ao anterior, mas devolve 0 quando não entende.
  static double paraDoubleOuZero(String? texto) => paraDouble(texto) ?? 0.0;

  /// Converte texto para inteiro (corridas, ano do carro etc.).
  static int? paraInt(String? texto) {
    if (texto == null) return null;
    final t = texto.replaceAll(RegExp(r'[^\d\-]'), '');
    if (t.isEmpty) return null;
    return int.tryParse(t);
  }
}

/// -----------------------------------------------------------------------
/// MÁSCARA DE ENTRADA PARA CAMPOS DE DINHEIRO
/// -----------------------------------------------------------------------
/// Faz o campo se comportar como uma calculadora de caixa: o motorista
/// digita só os números e a vírgula aparece sozinha.
/// Ex.: digita 34789 -> mostra "347,89"
/// -----------------------------------------------------------------------
class MascaraMoeda extends TextInputFormatter {
  final int casasDecimais;
  const MascaraMoeda({this.casasDecimais = 2});

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue anterior,
    TextEditingValue novo,
  ) {
    // Mantém apenas dígitos
    final digitos = novo.text.replaceAll(RegExp(r'[^\d]'), '');
    if (digitos.isEmpty) {
      return const TextEditingValue(text: '');
    }
    // Limite de segurança para não travar com números gigantes
    final limpo = digitos.length > 12 ? digitos.substring(0, 12) : digitos;
    final valor = int.parse(limpo) / 100.0;
    final texto = Fmt.numero(valor, casas: casasDecimais);
    return TextEditingValue(
      text: texto,
      selection: TextSelection.collapsed(offset: texto.length),
    );
  }
}

/// Máscara de placa de veículo: aceita ABC1234 e ABC1D23 (Mercosul).
class MascaraPlaca extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue anterior,
    TextEditingValue novo,
  ) {
    var t = novo.text.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    if (t.length > 7) t = t.substring(0, 7);
    // Insere o hífen depois das 3 primeiras letras
    final texto = t.length > 3 ? '${t.substring(0, 3)}-${t.substring(3)}' : t;
    return TextEditingValue(
      text: texto,
      selection: TextSelection.collapsed(offset: texto.length),
    );
  }
}
