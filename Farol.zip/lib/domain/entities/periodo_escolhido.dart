/// =======================================================================
/// PERÍODO ESCOLHIDO PELO MOTORISTA
/// =======================================================================
/// Guarda EXATAMENTE o que o motorista selecionou na tela:
///   • o ano   (2024, 2025, 2026, 2027, 2028...)
///   • o mês   (janeiro a dezembro)
///   • a semana do mês (semana 1, 2, 3, 4, 5)
///   • o dia   (1, 2, 3... até o último dia do mês)
///
/// É Dart puro: nenhuma tela, nenhum banco, nenhum pacote externo. Por
/// isso dá para testar cada regra de data sem abrir o aplicativo.
///
/// ATENÇÃO: aqui só se calculam DATAS (início e fim do período). Nenhum
/// valor em dinheiro é calculado neste arquivo — dinheiro é sempre com o
/// CalculationsService.
/// =======================================================================
library;

/// O tipo de recorte que o motorista quer ver.
enum EscopoPeriodo {
  dia('Dia'),
  semana('Semana'),
  mes('Mês'),
  ano('Ano'),
  tudo('Tudo');

  final String rotulo;
  const EscopoPeriodo(this.rotulo);
}

/// Uma semana dentro de um mês, com o primeiro e o último dia.
class SemanaDoMes {
  /// 1 para a primeira semana do mês, 2 para a segunda, e assim por diante.
  final int numero;

  /// Primeiro dia da semana dentro do mês.
  final DateTime inicio;

  /// Último dia da semana dentro do mês (já com 23:59:59).
  final DateTime fim;

  const SemanaDoMes({
    required this.numero,
    required this.inicio,
    required this.fim,
  });

  /// "Semana 2 · 08/09 a 14/09"
  String get rotulo =>
      'Semana $numero · ${_dm(inicio)} a ${_dm(fim)}';

  /// "08/09 a 14/09"
  String get intervaloCurto => '${_dm(inicio)} a ${_dm(fim)}';

  static String _dm(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';

  /// A data informada cai dentro desta semana?
  bool contem(DateTime d) =>
      !d.isBefore(inicio) && !d.isAfter(fim);
}

class PeriodoEscolhido {
  final EscopoPeriodo escopo;
  final int ano;

  /// 1 = janeiro ... 12 = dezembro.
  final int mes;

  /// Dia do mês (1 a 31). Sempre ajustado para um dia que existe.
  final int dia;

  /// Número da semana dentro do mês (1 em diante).
  final int semana;

  const PeriodoEscolhido({
    required this.escopo,
    required this.ano,
    required this.mes,
    required this.dia,
    required this.semana,
  });

  /// Começa mostrando o mês atual — é o recorte que o motorista mais olha.
  factory PeriodoEscolhido.hoje({
    EscopoPeriodo escopo = EscopoPeriodo.mes,
    DateTime? agora,
  }) {
    final n = agora ?? DateTime.now();
    return PeriodoEscolhido(
      escopo: escopo,
      ano: n.year,
      mes: n.month,
      dia: n.day,
      semana: numeroDaSemana(n),
    );
  }

  // ---------------------------------------------------------------------
  // NOMES EM PORTUGUÊS
  // ---------------------------------------------------------------------

  static const List<String> nomesMeses = <String>[
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
  ];

  static const List<String> nomesMesesCurtos = <String>[
    'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
    'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez',
  ];

  static String nomeMes(int mes) =>
      (mes >= 1 && mes <= 12) ? nomesMeses[mes - 1] : '';

  static String nomeMesCurto(int mes) =>
      (mes >= 1 && mes <= 12) ? nomesMesesCurtos[mes - 1] : '';

  // ---------------------------------------------------------------------
  // CONTAS DE CALENDÁRIO
  // ---------------------------------------------------------------------

  /// Quantos dias tem o mês (já resolve fevereiro e ano bissexto).
  ///
  /// O truque: o "dia 0" do mês seguinte é o último dia deste mês.
  static int diasNoMes(int ano, int mes) => DateTime(ano, mes + 1, 0).day;

  /// As semanas de um mês, do jeito que aparecem num calendário de parede:
  /// a semana termina no domingo, e a primeira/última podem ser menores
  /// porque o mês começa ou termina no meio da semana.
  static List<SemanaDoMes> semanasDoMes(int ano, int mes) {
    final ultimo = diasNoMes(ano, mes);
    final lista = <SemanaDoMes>[];

    var primeiroDia = 1;
    var numero = 1;

    while (primeiroDia <= ultimo) {
      final d = DateTime(ano, mes, primeiroDia);
      // weekday: 1 = segunda ... 7 = domingo. Faltam (7 - weekday) dias
      // para chegar no domingo.
      var ultimoDia = primeiroDia + (7 - d.weekday);
      if (ultimoDia > ultimo) ultimoDia = ultimo;

      lista.add(
        SemanaDoMes(
          numero: numero,
          inicio: DateTime(ano, mes, primeiroDia),
          fim: DateTime(ano, mes, ultimoDia, 23, 59, 59),
        ),
      );

      primeiroDia = ultimoDia + 1;
      numero++;
    }

    return lista;
  }

  /// Em que semana do mês uma data cai.
  static int numeroDaSemana(DateTime data) {
    final semanas = semanasDoMes(data.year, data.month);
    for (final s in semanas) {
      if (data.day >= s.inicio.day && data.day <= s.fim.day) return s.numero;
    }
    return 1;
  }

  /// As semanas do mês que está selecionado agora.
  List<SemanaDoMes> get semanasDisponiveis => semanasDoMes(ano, mes);

  /// Quantos dias tem o mês selecionado.
  int get diasDisponiveis => diasNoMes(ano, mes);

  // ---------------------------------------------------------------------
  // O INTERVALO QUE SAI DA ESCOLHA
  // ---------------------------------------------------------------------

  /// Primeiro instante do período escolhido.
  DateTime get inicio {
    switch (escopo) {
      case EscopoPeriodo.dia:
        return DateTime(ano, mes, _diaValido);
      case EscopoPeriodo.semana:
        return _semanaValida.inicio;
      case EscopoPeriodo.mes:
        return DateTime(ano, mes, 1);
      case EscopoPeriodo.ano:
        return DateTime(ano, 1, 1);
      case EscopoPeriodo.tudo:
        // Uma data bem antiga: quem limita de verdade é o repositório,
        // que só devolve o que existe.
        return DateTime(2000, 1, 1);
    }
  }

  /// Último instante do período escolhido.
  DateTime get fim {
    switch (escopo) {
      case EscopoPeriodo.dia:
        return DateTime(ano, mes, _diaValido, 23, 59, 59);
      case EscopoPeriodo.semana:
        return _semanaValida.fim;
      case EscopoPeriodo.mes:
        return DateTime(ano, mes, diasNoMes(ano, mes), 23, 59, 59);
      case EscopoPeriodo.ano:
        return DateTime(ano, 12, 31, 23, 59, 59);
      case EscopoPeriodo.tudo:
        return DateTime(2100, 12, 31, 23, 59, 59);
    }
  }

  /// O texto que aparece no topo da tela.
  String get rotulo {
    switch (escopo) {
      case EscopoPeriodo.dia:
        final d = _diaValido.toString().padLeft(2, '0');
        final m = mes.toString().padLeft(2, '0');
        return '$d/$m/$ano';
      case EscopoPeriodo.semana:
        final s = _semanaValida;
        return 'Semana ${s.numero} de ${nomeMes(mes)} · ${s.intervaloCurto}';
      case EscopoPeriodo.mes:
        return '${nomeMes(mes)} de $ano';
      case EscopoPeriodo.ano:
        return 'Ano de $ano';
      case EscopoPeriodo.tudo:
        return 'Desde o começo';
    }
  }

  /// Protege contra dia 31 num mês de 30 (acontece ao trocar de mês).
  int get _diaValido {
    final max = diasNoMes(ano, mes);
    if (dia < 1) return 1;
    return dia > max ? max : dia;
  }

  /// Protege contra "semana 5" num mês que só tem 4 semanas.
  SemanaDoMes get _semanaValida {
    final lista = semanasDisponiveis;
    for (final s in lista) {
      if (s.numero == semana) return s;
    }
    return lista.last;
  }

  // ---------------------------------------------------------------------
  // CÓPIAS (o seletor da tela usa isto o tempo todo)
  // ---------------------------------------------------------------------

  PeriodoEscolhido copiarCom({
    EscopoPeriodo? escopo,
    int? ano,
    int? mes,
    int? dia,
    int? semana,
  }) {
    final novoAno = ano ?? this.ano;
    final novoMes = mes ?? this.mes;
    final maxDia = diasNoMes(novoAno, novoMes);
    final novoDia = (dia ?? this.dia).clamp(1, maxDia);
    final maxSemana = semanasDoMes(novoAno, novoMes).length;
    final novaSemana = (semana ?? this.semana).clamp(1, maxSemana);

    return PeriodoEscolhido(
      escopo: escopo ?? this.escopo,
      ano: novoAno,
      mes: novoMes,
      dia: novoDia,
      semana: novaSemana,
    );
  }

  /// Anda para o período anterior (mês anterior, ano anterior, dia anterior).
  PeriodoEscolhido get anterior => _andar(-1);

  /// Anda para o próximo período.
  PeriodoEscolhido get proximo => _andar(1);

  PeriodoEscolhido _andar(int passo) {
    switch (escopo) {
      case EscopoPeriodo.dia:
        final d = DateTime(ano, mes, _diaValido + passo);
        return copiarCom(
          ano: d.year,
          mes: d.month,
          dia: d.day,
          semana: numeroDaSemana(d),
        );

      case EscopoPeriodo.semana:
        final novoNumero = semana + passo;
        if (novoNumero >= 1 && novoNumero <= semanasDisponiveis.length) {
          return copiarCom(semana: novoNumero);
        }
        // Passou do fim (ou do começo) do mês: pula para o mês vizinho.
        final vizinho = DateTime(ano, mes + passo, 1);
        final semanasVizinhas = semanasDoMes(vizinho.year, vizinho.month);
        return copiarCom(
          ano: vizinho.year,
          mes: vizinho.month,
          semana: passo > 0 ? 1 : semanasVizinhas.length,
        );

      case EscopoPeriodo.mes:
        final d = DateTime(ano, mes + passo, 1);
        return copiarCom(ano: d.year, mes: d.month);

      case EscopoPeriodo.ano:
        return copiarCom(ano: ano + passo);

      case EscopoPeriodo.tudo:
        return this;
    }
  }

  /// Duas escolhas iguais devolvem o mesmo resumo — usado para não
  /// recalcular à toa (desempenho).
  String get chave =>
      '${escopo.name}|$ano|$mes|$_diaValido|${_semanaValida.numero}';

  @override
  bool operator ==(Object other) =>
      other is PeriodoEscolhido && other.chave == chave;

  @override
  int get hashCode => chave.hashCode;
}
