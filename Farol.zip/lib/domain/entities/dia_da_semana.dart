/// =======================================================================
/// UM DIA DENTRO DA SEMANA
/// =======================================================================
/// É o "pacote pronto" de um único dia, do jeito que o painel da semana
/// precisa: quanto faturou, quanto sobrou, quanto tempo trabalhou e
/// quantas corridas fez.
///
/// Dart puro, sem tela e sem banco. Todos os valores chegam aqui já
/// calculados pelo CalculationsService — aqui não se faz conta nenhuma.
/// =======================================================================
library;

class DiaDaSemana {
  /// A data do dia, sem hora.
  final DateTime dia;

  /// 1 = segunda ... 7 = domingo.
  final int diaSemana;

  /// Valor bruto recebido no dia.
  final double faturado;

  /// O que sobrou depois de combustível e gastos.
  final double lucro;

  /// Horas trabalhadas (decimal: 8h30 = 8.5).
  final double horas;

  /// Quantas corridas foram feitas.
  final int corridas;

  /// Quilômetros rodados.
  final double km;

  /// Quantos lançamentos existem neste dia (0 = dia sem registro).
  final int lancamentos;

  const DiaDaSemana({
    required this.dia,
    required this.diaSemana,
    required this.faturado,
    required this.lucro,
    required this.horas,
    required this.corridas,
    required this.km,
    required this.lancamentos,
  });

  /// O dia não tem nada lançado.
  bool get vazio => lancamentos == 0;

  /// Nome curto do dia, em português.
  String get nomeCurto {
    const nomes = <String>['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
    return nomes[(diaSemana - 1).clamp(0, 6)];
  }

  /// Nome por extenso.
  String get nomeLongo {
    const nomes = <String>[
      'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo',
    ];
    return nomes[(diaSemana - 1).clamp(0, 6)];
  }
}

/// =======================================================================
/// A SEMANA INTEIRA
/// =======================================================================
class SemanaDeTrabalho {
  /// Segunda-feira da semana.
  final DateTime inicio;

  /// Domingo da semana (com 23:59:59).
  final DateTime fim;

  /// Os sete dias, sempre de segunda a domingo — inclusive os vazios.
  final List<DiaDaSemana> dias;

  /// Totais da semana, já calculados.
  final double faturado;
  final double lucro;
  final double horas;
  final int corridas;
  final double km;

  const SemanaDeTrabalho({
    required this.inicio,
    required this.fim,
    required this.dias,
    required this.faturado,
    required this.lucro,
    required this.horas,
    required this.corridas,
    required this.km,
  });

  /// A semana inteira está sem nenhum lançamento.
  bool get vazia => dias.every((d) => d.vazio);

  /// O dia que mais faturou. Devolve null quando a semana está vazia.
  DiaDaSemana? get melhorDia {
    DiaDaSemana? melhor;
    for (final d in dias) {
      if (d.vazio) continue;
      if (melhor == null || d.faturado > melhor.faturado) melhor = d;
    }
    return melhor;
  }

  /// O maior faturamento de um dia — serve de régua para as barras.
  double get maiorFaturamento {
    var maior = 0.0;
    for (final d in dias) {
      if (d.faturado > maior) maior = d.faturado;
    }
    return maior;
  }

  /// A maior quantidade de horas num dia.
  double get maiorHoras {
    var maior = 0.0;
    for (final d in dias) {
      if (d.horas > maior) maior = d.horas;
    }
    return maior;
  }

  /// A maior quantidade de corridas num dia.
  int get maiorCorridas {
    var maior = 0;
    for (final d in dias) {
      if (d.corridas > maior) maior = d.corridas;
    }
    return maior;
  }

  /// Quantos dias da semana tiveram trabalho.
  int get diasTrabalhados => dias.where((d) => !d.vazio).length;
}
