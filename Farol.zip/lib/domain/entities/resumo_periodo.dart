/// -----------------------------------------------------------------------
/// ENTIDADE: RESUMO DE UM PERÍODO
/// -----------------------------------------------------------------------
/// É o "pacote pronto" de números de um período (dia, semana, mês, ano ou
/// total geral). Toda tela de relatório e toda exportação leem daqui — por
/// isso NENHUMA tela precisa refazer conta nenhuma.
/// -----------------------------------------------------------------------
library;

class ResumoPeriodo {
  final DateTime inicio;
  final DateTime fim;

  /// Texto que aparece no topo do relatório (ex.: "Setembro/2026").
  final String rotulo;

  // ---------------- Valores somados ----------------
  final double valorBruto;
  final double km;
  final double horas;
  final int corridas;
  final double litros;
  final double custoCombustivel;

  /// Soma dos gastos das 12 categorias no período.
  final double outrosGastos;

  /// Parte dos custos fixos mensais que cabe neste período.
  final double custosFixosRateados;

  // ---------------- Resultados ----------------
  /// Valor bruto menos o combustível.
  final double lucroBruto;

  /// Valor bruto menos combustível e menos os outros gastos.
  final double lucroLiquido;

  /// Lucro líquido menos a parte dos custos fixos do período.
  final double lucroFinal;

  // ---------------- Médias e indicadores ----------------
  final double custoPorKm;
  final double lucroPorKm;
  final double ganhoPorHora;
  final double brutoPorHora;
  final double ticketMedio;
  final double margemLucro;
  final double kmPorCorrida;
  final double corridasPorHora;

  /// Quantos dias diferentes tiveram lançamento.
  final int diasTrabalhados;

  /// Média de lucro por dia trabalhado.
  final double lucroMedioDia;

  // ---------------- Séries para os gráficos ----------------
  /// Lucro de cada dia (chave = data sem hora), em ordem crescente.
  final Map<DateTime, double> lucroPorDia;

  /// Valor bruto de cada dia.
  final Map<DateTime, double> brutoPorDia;

  /// Total gasto em cada uma das categorias (só as que tiveram gasto).
  final Map<String, double> gastosPorCategoria;

  const ResumoPeriodo({
    required this.inicio,
    required this.fim,
    required this.rotulo,
    required this.valorBruto,
    required this.km,
    required this.horas,
    required this.corridas,
    required this.litros,
    required this.custoCombustivel,
    required this.outrosGastos,
    required this.custosFixosRateados,
    required this.lucroBruto,
    required this.lucroLiquido,
    required this.lucroFinal,
    required this.custoPorKm,
    required this.lucroPorKm,
    required this.ganhoPorHora,
    required this.brutoPorHora,
    required this.ticketMedio,
    required this.margemLucro,
    required this.kmPorCorrida,
    required this.corridasPorHora,
    required this.diasTrabalhados,
    required this.lucroMedioDia,
    required this.lucroPorDia,
    required this.brutoPorDia,
    required this.gastosPorCategoria,
  });

  /// Resumo vazio — usado quando ainda não há nenhum lançamento.
  factory ResumoPeriodo.vazio({
    DateTime? inicio,
    DateTime? fim,
    String rotulo = '',
  }) {
    final agora = DateTime.now();
    return ResumoPeriodo(
      inicio: inicio ?? agora,
      fim: fim ?? agora,
      rotulo: rotulo,
      valorBruto: 0,
      km: 0,
      horas: 0,
      corridas: 0,
      litros: 0,
      custoCombustivel: 0,
      outrosGastos: 0,
      custosFixosRateados: 0,
      lucroBruto: 0,
      lucroLiquido: 0,
      lucroFinal: 0,
      custoPorKm: 0,
      lucroPorKm: 0,
      ganhoPorHora: 0,
      brutoPorHora: 0,
      ticketMedio: 0,
      margemLucro: 0,
      kmPorCorrida: 0,
      corridasPorHora: 0,
      diasTrabalhados: 0,
      lucroMedioDia: 0,
      lucroPorDia: const <DateTime, double>{},
      brutoPorDia: const <DateTime, double>{},
      gastosPorCategoria: const <String, double>{},
    );
  }

  /// Não há nada lançado neste período?
  bool get vazio => valorBruto == 0 && km == 0 && corridas == 0 &&
      outrosGastos == 0 && horas == 0;

  /// Total de despesas do período (combustível + categorias).
  double get despesasTotais => custoCombustivel + outrosGastos;
}

/// -----------------------------------------------------------------------
/// Um mês da projeção do simulador de patrimônio.
/// -----------------------------------------------------------------------
class ProjecaoMes {
  final int mes;

  /// Quanto o motorista colocou do próprio bolso até aqui.
  final double totalAportado;

  /// Quanto os juros renderam até aqui.
  final double jurosAcumulados;

  /// Saldo total no fim do mês.
  final double saldo;

  const ProjecaoMes({
    required this.mes,
    required this.totalAportado,
    required this.jurosAcumulados,
    required this.saldo,
  });
}

/// -----------------------------------------------------------------------
/// Resultado da avaliação "vale a pena aceitar esta corrida?"
/// -----------------------------------------------------------------------
enum VeredictoCorrida {
  aceitar('Vale a pena', 'A corrida atinge a margem que você quer'),
  atencao('Atenção', 'Dá lucro, mas abaixo da margem que você quer'),
  recusar('Não compensa', 'O combustível come o valor da corrida');

  final String rotulo;
  final String explicacao;
  const VeredictoCorrida(this.rotulo, this.explicacao);
}

class AvaliacaoCorrida {
  final double valorOferta;
  final double kmTotal;
  final double custoEstimado;
  final double lucroEstimado;
  final double margem;

  /// Quanto a corrida precisaria pagar para bater a margem desejada.
  final double valorMinimoIdeal;

  final VeredictoCorrida veredicto;

  const AvaliacaoCorrida({
    required this.valorOferta,
    required this.kmTotal,
    required this.custoEstimado,
    required this.lucroEstimado,
    required this.margem,
    required this.valorMinimoIdeal,
    required this.veredicto,
  });
}
