# =====================================================================
#  Aplica o AndroidManifest.xml do Farol
# =====================================================================
#  Rodado automaticamente pelo COMPILAR.bat. Pode rodar de novo a
#  vontade: ele so copia o arquivo pronto de android_config\ por cima
#  do que o "flutter create" gerou.
#
#  ATENCAO: NAO existe permissao de INTERNET la, de proposito.
#  O Farol e 100% offline e nem deve poder acessar a rede.
#  A UNICA permissao do app e VIBRATE (o tremidinho dos botoes).
# =====================================================================

$destino = Join-Path $PSScriptRoot 'android\app\src\main\AndroidManifest.xml'
$origem  = Join-Path $PSScriptRoot 'android_config\AndroidManifest.xml'

if (-not (Test-Path $destino)) {
    Write-Output "AVISO: AndroidManifest.xml nao encontrado em $destino"
    exit 0
}

if (-not (Test-Path $origem)) {
    Write-Output "AVISO: android_config\AndroidManifest.xml nao encontrado."
    exit 0
}

Copy-Item -Path $origem -Destination $destino -Force
Write-Output "OK: manifesto aplicado (somente a permissao VIBRATE)."
