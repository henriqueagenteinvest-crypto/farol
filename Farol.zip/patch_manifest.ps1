# =====================================================================
#  Adiciona as permissoes do Farol no AndroidManifest.xml
# =====================================================================
#  Rodado automaticamente pelo COMPILAR.bat. Pode rodar de novo a
#  vontade: se as permissoes ja estiverem la, ele nao duplica nada.
#
#  ATENCAO: NAO existe permissao de INTERNET aqui, de proposito.
#  O Farol e 100% offline e nem deve poder acessar a rede.
# =====================================================================

$manifesto = Join-Path $PSScriptRoot 'android\app\src\main\AndroidManifest.xml'

if (-not (Test-Path $manifesto)) {
    Write-Output "AVISO: AndroidManifest.xml nao encontrado em $manifesto"
    exit 0
}

$conteudo = Get-Content $manifesto -Raw

if ($conteudo -match 'READ_MEDIA_IMAGES') {
    Write-Output "OK: as permissoes ja estavam aplicadas."
    exit 0
}

$permissoes = @'
    <!-- Camera: para fotografar a tela de outro celular -->
    <uses-permission android:name="android.permission.CAMERA" />
    <!-- Galeria (Android 13 ou mais novo) -->
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <!-- Galeria (Android 12 ou mais antigo) -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <!-- Vibracao dos toques e da comemoracao de meta -->
    <uses-permission android:name="android.permission.VIBRATE" />
    <!-- A camera e opcional: o app funciona so com a galeria -->
    <uses-feature android:name="android.hardware.camera" android:required="false" />

'@

# Insere as permissoes logo antes da tag <application>
$conteudo = $conteudo -replace '(?m)^(\s*)(<application)', ($permissoes + '$1$2')

Set-Content -Path $manifesto -Value $conteudo -Encoding UTF8
Write-Output "OK: permissoes de camera, galeria e vibracao aplicadas."
