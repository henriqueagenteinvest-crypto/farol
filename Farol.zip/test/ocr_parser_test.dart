/// =======================================================================
/// TESTES DO PARSER DE OCR
/// =======================================================================
/// Aqui simulamos o texto que o Google ML Kit devolve ao ler prints de
/// vários formatos: Uber, 99, e-mail de resumo e foto ruim da tela.
///
/// Estes testes rodam sem câmera e sem celular — é Dart puro.
/// =======================================================================
library;

import 'package:farol/services/ocr_parser.dart';
import 'package:farol/services/ocr_resultado.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  // =====================================================================
  group('Normalização de texto', () {
    test('tira acentos e deixa minúsculo', () {
      expect(
        OcrParser.normalizar('Distância Percorrida'),
        'distancia percorrida',
      );
      expect(OcrParser.normalizar('SOLICITAÇÕES'), 'solicitacoes');
    });

    test('junta espaços repetidos', () {
      expect(OcrParser.normalizar('R\$    347,89'), r'r$ 347,89');
    });
  });

  // =====================================================================
  group('Palavra inteira (a armadilha do "perCORRIDA")', () {
    test('"percorrida" NÃO conta como a palavra "corrida"', () {
      // Sem esta trava o app leria "distância percorrida 415,8 km"
      // como "415 corridas" — erro grave e silencioso.
      expect(
        OcrParser.contemPalavra('distancia percorrida 415,8 km', 'corrida'),
        isFalse,
      );
    });

    test('"corridas: 23" conta como a palavra "corridas"', () {
      expect(OcrParser.contemPalavra('corridas: 23', 'corridas'), isTrue);
    });

    test('rótulo com duas palavras funciona', () {
      expect(
        OcrParser.contemPalavra('tempo online 32:15', 'tempo online'),
        isTrue,
      );
    });
  });

  // =====================================================================
  group('Leitura de valores em dinheiro', () {
    test('R\$ com separador de milhar', () {
      expect(
        OcrParser.valoresMonetariosDaLinha(r'r$ 1.847,32'),
        <double>[1847.32],
      );
    });

    test('R\$ sem separador de milhar', () {
      expect(
        OcrParser.valoresMonetariosDaLinha(r'r$ 347,89'),
        <double>[347.89],
      );
    });

    test('valor no formato brasileiro sem o símbolo R\$', () {
      expect(
        OcrParser.valoresMonetariosDaLinha('1.058,40'),
        <double>[1058.40],
      );
    });

    test('número inteiro solto não é confundido com dinheiro', () {
      // "82" (viagens) não pode virar R\$ 82,00.
      expect(OcrParser.valoresMonetariosDaLinha('82'), isEmpty);
    });
  });

  // =====================================================================
  group('Leitura de horas', () {
    test('formato 8h30', () {
      expect(OcrParser.horasDaLinha('8h30'), closeTo(8.5, 0.0001));
    });

    test('formato 41h 23min', () {
      expect(
        OcrParser.horasDaLinha('41h 23min'),
        closeTo(41 + 23 / 60, 0.0001),
      );
    });

    test('formato decimal 8,5h', () {
      expect(OcrParser.horasDaLinha('8,5h'), closeTo(8.5, 0.0001));
    });

    test('formato por extenso: 168 horas 45 minutos', () {
      expect(
        OcrParser.horasDaLinha('168 horas 45 minutos'),
        closeTo(168.75, 0.0001),
      );
    });

    test('formato 08:30 SÓ quando autorizado', () {
      // Sem autorização devolve nulo: "19:42" pode ser o horário de uma
      // corrida, não o tempo trabalhado.
      expect(OcrParser.horasDaLinha('19:42'), isNull);
      expect(
        OcrParser.horasDaLinha('19:42', permitirDoisPontos: true),
        closeTo(19.7, 0.01),
      );
    });
  });

  // =====================================================================
  group('Print da Uber — resumo semanal', () {
    // Layout real: a DATA fica ENTRE o rótulo e o valor.
    const texto = '''
Uber
Seus ganhos
23 de ago - 29 de ago
R\$ 1.847,32
Viagens
82
Tempo online
41h 23min
Distância
612,4 km
''';

    test('lê o valor mesmo com a data no meio', () {
      final r = OcrParser.interpretar(texto);
      expect(r.valorBruto.valor, 1847.32);
      expect(r.valorBruto.encontrado, isTrue);
    });

    test('lê as corridas do rótulo na linha de cima', () {
      final r = OcrParser.interpretar(texto);
      expect(r.corridas.valor, 82);
    });

    test('lê as horas no formato 41h 23min', () {
      final r = OcrParser.interpretar(texto);
      expect(r.horas.valor, closeTo(41.3833, 0.001));
    });

    test('lê a quilometragem', () {
      final r = OcrParser.interpretar(texto);
      expect(r.km.valor, 612.4);
    });

    test('identifica que o print é da Uber', () {
      final r = OcrParser.interpretar(texto);
      expect(r.origem, OrigemPrint.uber);
    });

    test('entende que é um resumo SEMANAL pelo intervalo das datas', () {
      final r = OcrParser.interpretar(texto);
      expect(r.tipo, TipoResumo.semanal);
    });

    test('pega a data FINAL do intervalo', () {
      final r = OcrParser.interpretar(texto);
      expect(r.data.valor?.day, 29);
      expect(r.data.valor?.month, 8);
    });

    test('encontra os 4 campos principais', () {
      final r = OcrParser.interpretar(texto);
      expect(r.camposEncontrados, 4);
      expect(r.temDadosUteis, isTrue);
    });
  });

  // =====================================================================
  group('Print do 99 — resumo diário', () {
    const texto = '''
99
Ganhos de hoje
R\$ 347,89
Corridas: 23
Tempo em rota: 8h30
''';

    test('lê valor, corridas e horas', () {
      final r = OcrParser.interpretar(texto);
      expect(r.valorBruto.valor, 347.89);
      expect(r.corridas.valor, 23);
      expect(r.horas.valor, closeTo(8.5, 0.001));
    });

    test('identifica o app 99', () {
      final r = OcrParser.interpretar(texto);
      expect(r.origem, OrigemPrint.noventaENove);
    });

    test('entende que é diário pela palavra "hoje"', () {
      final r = OcrParser.interpretar(texto);
      expect(r.tipo, TipoResumo.diario);
    });

    test('avisa que o KM não foi encontrado', () {
      final r = OcrParser.interpretar(texto);
      expect(r.km.encontrado, isFalse);
      expect(r.avisos.any((a) => a.contains('KM')), isTrue);
    });
  });

  // =====================================================================
  group('Print com tudo na mesma linha', () {
    const texto = '''
Ganhos totais R\$ 1.234,56
Viagens 47
Tempo online 32:15
Distância percorrida 415,8 km
''';

    test('NÃO confunde "415,8 km" com 415 corridas', () {
      final r = OcrParser.interpretar(texto);
      expect(r.corridas.valor, 47, reason: 'a palavra está em "perCORRIDA"');
      expect(r.km.valor, 415.8);
    });

    test('lê o valor com confiança máxima (rótulo na mesma linha)', () {
      final r = OcrParser.interpretar(texto);
      expect(r.valorBruto.valor, 1234.56);
      expect(r.valorBruto.confiavel, isTrue);
    });

    test('lê o tempo no formato 32:15', () {
      final r = OcrParser.interpretar(texto);
      expect(r.horas.valor, closeTo(32.25, 0.001));
    });
  });

  // =====================================================================
  group('E-mail de resumo mensal', () {
    const texto = '''
Resumo do mes de agosto
Total recebido
R\$ 6.482,10
Total de corridas
341
Horas trabalhadas
168 horas 45 minutos
Distancia percorrida
2.847,6 km
Dias trabalhados
24
''';

    test('lê todos os campos', () {
      final r = OcrParser.interpretar(texto);
      expect(r.valorBruto.valor, 6482.10);
      expect(r.corridas.valor, 341);
      expect(r.horas.valor, closeTo(168.75, 0.001));
      expect(r.km.valor, 2847.6);
      expect(r.diasTrabalhados.valor, 24);
    });

    test('entende que é um resumo mensal', () {
      final r = OcrParser.interpretar(texto);
      expect(r.tipo, TipoResumo.mensal);
    });
  });

  // =====================================================================
  group('Casos difíceis e proteções', () {
    test('foto ruim: só o valor legível — ainda serve', () {
      final r = OcrParser.interpretar(r'R$ 520,00');
      expect(r.valorBruto.valor, 520.0);
      expect(r.temDadosUteis, isTrue);
      // Confiança baixa: o app pede para o motorista conferir.
      expect(r.valorBruto.duvidoso, isTrue);
      expect(r.corridas.encontrado, isFalse);
    });

    test('horário de corrida não é confundido com horas trabalhadas', () {
      const texto = '''
Ganhos do dia
R\$ 289,50
Ultima corrida 19:42
Corridas 17
''';
      final r = OcrParser.interpretar(texto);
      expect(r.corridas.valor, 17);
      expect(r.horas.encontrado, isFalse,
          reason: '19:42 é hora do relógio, não tempo trabalhado');
    });

    test('texto vazio devolve falha com mensagem clara', () {
      final r = OcrParser.interpretar('');
      expect(r.temDadosUteis, isFalse);
      expect(r.avisos, isNotEmpty);
      expect(r.camposEncontrados, 0);
    });

    test('texto sem nenhum número não inventa dados', () {
      final r = OcrParser.interpretar('Bom dia\nSeja bem-vindo ao aplicativo');
      expect(r.valorBruto.encontrado, isFalse);
      expect(r.corridas.encontrado, isFalse);
      expect(r.temDadosUteis, isFalse);
    });

    test('nota de qualidade fica entre 0 e 1', () {
      final r = OcrParser.interpretar(r'R$ 100,00');
      expect(r.qualidadeGeral, inInclusiveRange(0.0, 1.0));
    });

    test('frase de resumo é montada em português', () {
      const texto = '''
Ganhos
R\$ 347,89
Corridas 23
Tempo online 8h30
''';
      final r = OcrParser.interpretar(texto);
      expect(r.frasePreview, contains('23 corridas'));
      expect(r.frasePreview, contains('347,89'));
      expect(r.frasePreview, contains('8h30'));
    });

    test('quando não acha nada, a frase avisa em vez de mentir', () {
      final r = OcrParser.interpretar('texto sem dados');
      expect(r.frasePreview, 'Nada foi identificado');
    });

    test('valores absurdos são descartados', () {
      // 99999 corridas em um dia é impossível: não pode ser aceito.
      final r = OcrParser.interpretar('Corridas 99999');
      expect(r.corridas.encontrado, isFalse);
    });
  });
}
