/// Testes das regras de pontos e horários de pico.
library;

import 'package:farol/services/pontos_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Contagem de pontos', () {
    test('sem corridas, nenhum ponto', () {
      expect(PontosService.calcularPontos(corridas: 0), 0);
    });

    test('corrida normal vale 1 ponto', () {
      expect(PontosService.calcularPontos(corridas: 12), 12);
    });

    test('corrida em pico vale 2 pontos', () {
      // 10 corridas, 4 delas em pico: 6 x 1 + 4 x 2 = 14
      expect(
        PontosService.calcularPontos(corridas: 10, corridasEmPico: 4),
        14,
      );
    });

    test('número negativo nunca vira ponto negativo', () {
      expect(PontosService.calcularPontos(corridas: -5), 0);
    });

    test('mais corridas em pico do que o total não estoura a conta', () {
      // Se alguém informar 20 em pico com só 5 corridas, o limite é 5.
      expect(
        PontosService.calcularPontos(corridas: 5, corridasEmPico: 20),
        10,
      );
    });
  });

  group('Horários de pico', () {
    test('segunda-feira das 7h às 10h é pico', () {
      // 07/09/2026 é uma segunda-feira.
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 7, 8)), isTrue);
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 7, 7)), isTrue);
      // Às 10h já acabou.
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 7, 10)), isFalse);
    });

    test('segunda-feira das 17h às 20h é pico', () {
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 7, 18)), isTrue);
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 7, 20)), isFalse);
    });

    test('sexta-feira o pico da tarde vai até a virada do dia', () {
      // 11/09/2026 é sexta-feira.
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 11, 23)), isTrue);
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 11, 16)), isFalse);
    });

    test('sábado tem pico de madrugada e à noite', () {
      // 12/09/2026 é sábado.
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 12, 1)), isTrue);
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 12, 3)), isFalse);
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 12, 21)), isTrue);
    });

    test('domingo só tem pico de madrugada', () {
      // 13/09/2026 é domingo.
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 13, 2)), isTrue);
      expect(PontosService.ehHorarioPico(DateTime(2026, 9, 13, 19)), isFalse);
      expect(PontosService.faixasDoDia(DateTime.sunday).length, 1);
    });

    test('todo dia da semana tem uma regra cadastrada', () {
      for (var d = 1; d <= 7; d++) {
        expect(PontosService.horariosPico.containsKey(d), isTrue,
            reason: 'dia $d');
        expect(PontosService.nomeDia(d).isNotEmpty, isTrue);
      }
    });

    test('quanto falta para o próximo pico do dia', () {
      // Segunda, 6h: falta 1 hora para o pico das 7h.
      final falta = PontosService.proximoPicoHoje(DateTime(2026, 9, 7, 6));
      expect(falta, const Duration(hours: 1));

      // Segunda, 21h: já passou tudo.
      expect(PontosService.proximoPicoHoje(DateTime(2026, 9, 7, 21)), isNull);
    });
  });

  group('Categorias', () {
    test('a categoria acompanha os pontos', () {
      expect(PontosService.categoriaPara(0), CategoriaMotorista.azul);
      expect(PontosService.categoriaPara(299), CategoriaMotorista.azul);
      expect(PontosService.categoriaPara(300), CategoriaMotorista.ouro);
      expect(PontosService.categoriaPara(900), CategoriaMotorista.platina);
      expect(PontosService.categoriaPara(1800), CategoriaMotorista.diamante);
      expect(PontosService.categoriaPara(99999), CategoriaMotorista.diamante);
    });

    test('quanto falta para subir', () {
      expect(PontosService.faltamParaProxima(0), 300);
      expect(PontosService.faltamParaProxima(250), 50);
      // No topo não falta nada.
      expect(PontosService.faltamParaProxima(5000), 0);
    });

    test('o progresso fica sempre entre 0 e 1', () {
      for (final p in <int>[0, 1, 150, 299, 300, 899, 900, 1799, 1800, 9000]) {
        final v = PontosService.progressoParaProxima(p);
        expect(v >= 0 && v <= 1, isTrue, reason: 'pontos $p deu $v');
      }
    });

    test('metade do caminho entre Azul e Ouro dá 50%', () {
      expect(PontosService.progressoParaProxima(150), closeTo(0.5, 0.001));
    });

    test('no topo o progresso é 1', () {
      expect(PontosService.progressoParaProxima(1800), 1.0);
    });

    test('cada categoria tem vantagens escritas', () {
      for (final c in CategoriaMotorista.values) {
        expect(c.vantagens.isNotEmpty, isTrue);
        expect(c.rotulo.isNotEmpty, isTrue);
      }
    });
  });

  test('os três requisitos de qualidade estão descritos', () {
    expect(PontosService.requisitos.length, 3);
    expect(PontosService.requisitos.first.alvo, '4,85 ou mais');
  });
}
