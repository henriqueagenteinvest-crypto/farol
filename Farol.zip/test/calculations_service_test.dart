/// =======================================================================
/// TESTES DO CALCULATIONS SERVICE
/// =======================================================================
/// Rode com:   flutter test
///
/// Cada fórmula do app é testada aqui, incluindo os casos que costumam
/// quebrar sistemas financeiros: divisão por zero, arredondamento de meio
/// centavo, valores negativos e números absurdos.
/// =======================================================================
library;

import 'package:farol/core/app_constants.dart';
import 'package:farol/data/models/abastecimento.dart';
import 'package:farol/data/models/gasto.dart';
import 'package:farol/data/models/jornada.dart';
import 'package:farol/data/models/lancamento_diario.dart';
import 'package:farol/domain/entities/resumo_periodo.dart';
import 'package:farol/services/calculations_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  // =====================================================================
  group('Arredondamento (regra comercial, meio centavo sobe)', () {
    test('1,005 arredonda para 1,01 (o erro clássico de ponto flutuante)', () {
      expect(CalculationsService.arredondar(1.005), 1.01);
    });

    test('2,675 arredonda para 2,68', () {
      expect(CalculationsService.arredondar(2.675), 2.68);
    });

    test('negativo se afasta do zero: -1,005 vira -1,01', () {
      expect(CalculationsService.arredondar(-1.005), -1.01);
    });

    test('0,1 + 0,2 vira exatamente 0,30', () {
      expect(CalculationsService.arredondar(0.1 + 0.2), 0.30);
    });

    test('NaN e infinito viram zero em vez de quebrar o app', () {
      expect(CalculationsService.arredondar(double.nan), 0.0);
      expect(CalculationsService.arredondar(double.infinity), 0.0);
      expect(CalculationsService.arredondar(double.negativeInfinity), 0.0);
    });

    test('nunca devolve "-0.0" (ficaria feio na tela)', () {
      expect(CalculationsService.arredondar(-0.0001).toString(), '0.0');
    });

    test('respeita a quantidade de casas pedida', () {
      expect(CalculationsService.arredondar(1 / 3, 4), 0.3333);
      expect(CalculationsService.arredondar(123.456, 2), 123.46);
      expect(CalculationsService.arredondar(123.456, 0), 123.0);
    });
  });

  // =====================================================================
  group('Divisão segura', () {
    test('divisor zero devolve zero, não estoura', () {
      expect(CalculationsService.dividirSeguro(100, 0), 0.0);
    });

    test('divisão normal funciona', () {
      expect(CalculationsService.dividirSeguro(100, 4), 25.0);
    });

    test('dividendo inválido devolve zero', () {
      expect(CalculationsService.dividirSeguro(double.nan, 4), 0.0);
    });
  });

  // =====================================================================
  group('Combustível', () {
    test('240 km em um carro de 12 km/L gasta 20 litros', () {
      expect(CalculationsService.litrosGastos(240, 12), 20.0);
    });

    test('consumo zero não quebra: devolve 0 litros', () {
      expect(CalculationsService.litrosGastos(240, 0), 0.0);
    });

    test('KM zero devolve 0 litros', () {
      expect(CalculationsService.litrosGastos(0, 12), 0.0);
    });

    test('20 litros a R\$ 6,19 custam R\$ 123,80', () {
      expect(CalculationsService.custoCombustivel(20, 6.19), 123.80);
    });

    test('rodagem completa: 240 km a 12 km/L com litro a 6,19', () {
      final custo = CalculationsService.custoCombustivelPorRodagem(
        km: 240,
        kmPorLitro: 12,
        precoLitro: 6.19,
      );
      expect(custo, 123.80);
    });

    test('custo do combustível por KM = preço ÷ consumo', () {
      final v = CalculationsService.custoCombustivelPorKm(
        kmPorLitro: 12,
        precoLitro: 6.19,
      );
      expect(v, 0.5158);
    });

    test('consumo real medido entre dois abastecimentos', () {
      expect(
        CalculationsService.kmPorLitroReal(
          kmRodados: 420,
          litrosAbastecidos: 35,
        ),
        12.0,
      );
    });

    test('consumo real com zero litros não quebra', () {
      expect(
        CalculationsService.kmPorLitroReal(
          kmRodados: 420,
          litrosAbastecidos: 0,
        ),
        0.0,
      );
    });
  });

  // =====================================================================
  group('Descontos no abastecimento', () {
    test('R\$ 200 com 10% e mais R\$ 5 fica R\$ 175', () {
      final v = CalculationsService.aplicarDesconto(
        valor: 200,
        descontoPercentual: 10,
        descontoReais: 5,
      );
      expect(v, 175.0);
    });

    test('desconto maior que o valor nunca deixa negativo', () {
      final v = CalculationsService.aplicarDesconto(
        valor: 100,
        descontoReais: 150,
      );
      expect(v, 0.0);
    });

    test('porcentagem acima de 100 é travada em 100', () {
      final v = CalculationsService.aplicarDesconto(
        valor: 100,
        descontoPercentual: 250,
      );
      expect(v, 0.0);
    });

    test('porcentagem negativa é ignorada (não vira acréscimo)', () {
      final v = CalculationsService.aplicarDesconto(
        valor: 100,
        descontoPercentual: -50,
      );
      expect(v, 100.0);
    });

    test('abastecimento completo: valor final e preço efetivo do litro', () {
      final a = Abastecimento(
        data: DateTime(2026, 9, 1),
        litros: 32.5,
        precoLitro: 6.19,
        descontoPercentual: 8,
      );
      // 32,5 × 6,19 = 201,18  ->  com 8% = 185,09
      expect(CalculationsService.valorBrutoAbastecimento(
        litros: 32.5,
        precoLitro: 6.19,
      ), 201.18);
      expect(CalculationsService.valorFinalAbastecimento(a), 185.09);
      expect(CalculationsService.economiaAbastecimento(a), 16.09);
      expect(CalculationsService.precoEfetivoPorLitro(a), 5.695);
    });

    test('abastecimento com zero litros não divide por zero', () {
      final a = Abastecimento(data: DateTime.now(), litros: 0, precoLitro: 6);
      expect(CalculationsService.precoEfetivoPorLitro(a), 0.0);
    });
  });

  // =====================================================================
  group('Resultado do dia', () {
    // Cenário base usado em vários testes:
    // bruto R$ 347,89 | 240 km | 8,5 h | 23 corridas | combustível R$ 123,80
    const bruto = 347.89;
    const combustivel = 123.80;
    const lucro = 224.09;

    test('lucro bruto = valor bruto − combustível', () {
      expect(
        CalculationsService.lucroBruto(
          valorBruto: bruto,
          custoCombustivel: combustivel,
        ),
        lucro,
      );
    });

    test('lucro líquido desconta também os outros gastos', () {
      expect(
        CalculationsService.lucroLiquido(
          valorBruto: bruto,
          custoCombustivel: combustivel,
          outrosGastos: 40,
        ),
        184.09,
      );
    });

    test('lucro pode ficar negativo em um dia ruim', () {
      expect(
        CalculationsService.lucroBruto(
          valorBruto: 50,
          custoCombustivel: 80,
        ),
        -30.0,
      );
    });

    test('custo por KM', () {
      expect(
        CalculationsService.custoPorKm(custoTotal: combustivel, km: 240),
        0.5158,
      );
    });

    test('custo por KM com 0 km devolve zero', () {
      expect(CalculationsService.custoPorKm(custoTotal: 100, km: 0), 0.0);
    });

    test('lucro por KM', () {
      expect(
        CalculationsService.lucroPorKm(lucro: lucro, km: 240),
        0.9337,
      );
    });

    test('ganho por hora', () {
      expect(
        CalculationsService.ganhoPorHora(lucro: lucro, horas: 8.5),
        26.36,
      );
    });

    test('ganho por hora com 0 horas devolve zero', () {
      expect(CalculationsService.ganhoPorHora(lucro: 200, horas: 0), 0.0);
    });

    test('ticket médio', () {
      expect(
        CalculationsService.ticketMedio(valorBruto: bruto, corridas: 23),
        15.13,
      );
    });

    test('ticket médio com 0 corridas devolve zero', () {
      expect(
        CalculationsService.ticketMedio(valorBruto: 100, corridas: 0),
        0.0,
      );
    });

    test('margem de lucro em porcentagem', () {
      expect(
        CalculationsService.margemLucro(lucro: lucro, valorBruto: bruto),
        64.41,
      );
    });

    test('margem com bruto zero devolve zero', () {
      expect(
        CalculationsService.margemLucro(lucro: 100, valorBruto: 0),
        0.0,
      );
    });
  });

  // =====================================================================
  group('Metas', () {
    test('percentual da meta', () {
      expect(
        CalculationsService.percentualMeta(realizado: 175, meta: 250),
        70.0,
      );
    });

    test('meta zero não divide por zero', () {
      expect(
        CalculationsService.percentualMeta(realizado: 175, meta: 0),
        0.0,
      );
    });

    test('progresso da barra fica travado entre 0 e 1', () {
      expect(
        CalculationsService.progressoMeta(realizado: 500, meta: 250),
        1.0,
      );
      expect(
        CalculationsService.progressoMeta(realizado: -50, meta: 250),
        0.0,
      );
      expect(
        CalculationsService.progressoMeta(realizado: 125, meta: 250),
        0.5,
      );
    });

    test('quanto falta para a meta nunca é negativo', () {
      expect(
        CalculationsService.faltaParaMeta(realizado: 300, meta: 250),
        0.0,
      );
      expect(
        CalculationsService.faltaParaMeta(realizado: 175, meta: 250),
        75.0,
      );
    });

    test('meta atingida', () {
      expect(
        CalculationsService.metaAtingida(realizado: 250, meta: 250),
        isTrue,
      );
      expect(
        CalculationsService.metaAtingida(realizado: 249.99, meta: 250),
        isFalse,
      );
      // Meta zero nunca conta como batida.
      expect(
        CalculationsService.metaAtingida(realizado: 100, meta: 0),
        isFalse,
      );
    });
  });

  // =====================================================================
  group('Tempo de jornada (pausa NÃO conta como trabalho)', () {
    test('jornada de 8h às 18h com 1h de almoço = 9 horas ativas', () {
      final j = Jornada(
        inicio: DateTime(2026, 9, 1, 8),
        fim: DateTime(2026, 9, 1, 18),
        pausas: <Pausa>[
          Pausa(
            inicio: DateTime(2026, 9, 1, 12),
            fim: DateTime(2026, 9, 1, 13),
            motivo: 'Almoço',
          ),
        ],
      );
      expect(CalculationsService.tempoAtivoJornada(j), const Duration(hours: 9));
      expect(
        CalculationsService.tempoPausadoJornada(j),
        const Duration(hours: 1),
      );
    });

    test('várias pausas são somadas', () {
      final j = Jornada(
        inicio: DateTime(2026, 9, 1, 6),
        fim: DateTime(2026, 9, 1, 14),
        pausas: <Pausa>[
          Pausa(
            inicio: DateTime(2026, 9, 1, 8),
            fim: DateTime(2026, 9, 1, 8, 15),
            motivo: 'Café',
          ),
          Pausa(
            inicio: DateTime(2026, 9, 1, 11),
            fim: DateTime(2026, 9, 1, 11, 45),
            motivo: 'Almoço',
          ),
        ],
      );
      // 8 horas totais − 1 hora de pausas = 7 horas
      expect(CalculationsService.tempoAtivoJornada(j), const Duration(hours: 7));
    });

    test('jornada ainda aberta conta até o momento informado', () {
      final j = Jornada(inicio: DateTime(2026, 9, 1, 8));
      final agora = DateTime(2026, 9, 1, 11, 30);
      expect(
        CalculationsService.tempoAtivoJornada(j, agora: agora),
        const Duration(hours: 3, minutes: 30),
      );
    });

    test('pausa ainda aberta é descontada até agora', () {
      final j = Jornada(
        inicio: DateTime(2026, 9, 1, 8),
        pausas: <Pausa>[Pausa(inicio: DateTime(2026, 9, 1, 10))],
      );
      final agora = DateTime(2026, 9, 1, 11);
      // 3 horas de jornada − 1 hora parada = 2 horas
      expect(
        CalculationsService.tempoAtivoJornada(j, agora: agora),
        const Duration(hours: 2),
      );
    });

    test('pausa maior que a jornada nunca deixa o tempo negativo', () {
      final j = Jornada(
        inicio: DateTime(2026, 9, 1, 8),
        fim: DateTime(2026, 9, 1, 9),
        pausas: <Pausa>[
          Pausa(
            inicio: DateTime(2026, 9, 1, 7),
            fim: DateTime(2026, 9, 1, 20),
          ),
        ],
      );
      expect(CalculationsService.tempoAtivoJornada(j), Duration.zero);
    });

    test('duração vira horas decimais: 8h30 = 8,5', () {
      expect(
        CalculationsService.duracaoParaHoras(
          const Duration(hours: 8, minutes: 30),
        ),
        8.5,
      );
    });

    test('soma das horas de várias jornadas no mesmo dia', () {
      final jornadas = <Jornada>[
        Jornada(
          inicio: DateTime(2026, 9, 1, 6),
          fim: DateTime(2026, 9, 1, 10),
        ),
        Jornada(
          inicio: DateTime(2026, 9, 1, 16),
          fim: DateTime(2026, 9, 1, 20, 30),
        ),
      ];
      expect(CalculationsService.horasDeJornadas(jornadas), 8.5);
    });
  });

  // =====================================================================
  group('Vale a pena aceitar a corrida?', () {
    const custoKm = 0.5158; // Onix a 12 km/L com litro a R\$ 6,19

    test('corrida boa: margem acima do alvo -> ACEITAR', () {
      final a = CalculationsService.avaliarCorrida(
        valorOferta: 12,
        kmTotal: 10,
        custoPorKmCombustivel: custoKm,
      );
      expect(a.custoEstimado, 5.16);
      expect(a.lucroEstimado, 6.84);
      expect(a.margem, 57.0);
      expect(a.veredicto, VeredictoCorrida.aceitar);
    });

    test('corrida fraca: dá lucro mas abaixo do alvo -> ATENÇÃO', () {
      final a = CalculationsService.avaliarCorrida(
        valorOferta: 6,
        kmTotal: 10,
        custoPorKmCombustivel: custoKm,
      );
      expect(a.lucroEstimado, 0.84);
      expect(a.margem, 14.0);
      expect(a.veredicto, VeredictoCorrida.atencao);
    });

    test('corrida ruim: prejuízo -> RECUSAR', () {
      final a = CalculationsService.avaliarCorrida(
        valorOferta: 4,
        kmTotal: 10,
        custoPorKmCombustivel: custoKm,
      );
      expect(a.lucroEstimado, -1.16);
      expect(a.veredicto, VeredictoCorrida.recusar);
    });

    test('valor mínimo ideal para bater 30% de margem', () {
      final a = CalculationsService.avaliarCorrida(
        valorOferta: 12,
        kmTotal: 10,
        custoPorKmCombustivel: custoKm,
        margemAlvo: AppConstants.margemLucroAlvoPadrao,
      );
      // 5,16 ÷ (1 − 0,30) = 7,37
      expect(a.valorMinimoIdeal, 7.37);
    });

    test('oferta zero é recusada sem quebrar', () {
      final a = CalculationsService.avaliarCorrida(
        valorOferta: 0,
        kmTotal: 10,
        custoPorKmCombustivel: custoKm,
      );
      expect(a.veredicto, VeredictoCorrida.recusar);
      expect(a.margem, 0.0);
    });

    test('margem alvo de 100% é travada para não dividir por zero', () {
      final a = CalculationsService.avaliarCorrida(
        valorOferta: 12,
        kmTotal: 10,
        custoPorKmCombustivel: custoKm,
        margemAlvo: 100,
      );
      expect(a.valorMinimoIdeal.isFinite, isTrue);
    });
  });

  // =====================================================================
  group('Juros compostos (simulador de patrimônio)', () {
    test('R\$ 1.000 + R\$ 500/mês a 1% ao mês por 12 meses', () {
      final m = CalculationsService.montanteJurosCompostos(
        valorInicial: 1000,
        aporteMensal: 500,
        taxaMensalPercentual: 1,
        meses: 12,
      );
      expect(m, closeTo(7468.08, 0.02));
    });

    test('taxa zero: vira soma simples', () {
      final m = CalculationsService.montanteJurosCompostos(
        valorInicial: 0,
        aporteMensal: 1000,
        taxaMensalPercentual: 0,
        meses: 10,
      );
      expect(m, 10000.0);
    });

    test('sem aporte, só o valor inicial rendendo', () {
      final m = CalculationsService.montanteJurosCompostos(
        valorInicial: 5000,
        aporteMensal: 0,
        taxaMensalPercentual: 1,
        meses: 12,
      );
      expect(m, closeTo(5634.13, 0.02));
    });

    test('zero meses devolve o valor inicial', () {
      final m = CalculationsService.montanteJurosCompostos(
        valorInicial: 5000,
        aporteMensal: 500,
        taxaMensalPercentual: 1,
        meses: 0,
      );
      expect(m, 5000.0);
    });

    test('taxa anual vira mensal pela raiz 12 (não é dividir por 12)', () {
      final mensal = CalculationsService.taxaAnualParaMensal(12);
      expect(mensal, closeTo(0.9489, 0.001));
      // A prova: voltando para o ano tem que dar 12% de novo.
      expect(
        CalculationsService.taxaMensalParaAnual(mensal),
        closeTo(12.0, 0.01),
      );
    });

    test('1% ao mês equivale a 12,6825% ao ano', () {
      expect(
        CalculationsService.taxaMensalParaAnual(1),
        closeTo(12.6825, 0.001),
      );
    });

    test('projeção mês a mês bate com a fórmula fechada', () {
      final projecao = CalculationsService.projecaoPatrimonio(
        valorInicial: 1000,
        aporteMensal: 500,
        taxaMensalPercentual: 1,
        meses: 12,
      );
      // 13 pontos: o mês 0 (partida) + 12 meses
      expect(projecao.length, 13);
      expect(projecao.first.mes, 0);
      expect(projecao.first.saldo, 1000.0);
      expect(projecao.last.saldo, closeTo(7468.08, 0.05));
      // Aportado = 1000 inicial + 12 × 500
      expect(projecao.last.totalAportado, 7000.0);
      // Saldo = aportado + juros
      expect(
        projecao.last.saldo,
        closeTo(
          projecao.last.totalAportado + projecao.last.jurosAcumulados,
          0.05,
        ),
      );
    });

    test('cálculo reverso: quanto guardar por mês para chegar a R\$ 100 mil', () {
      final aporte = CalculationsService.aporteNecessario(
        meta: 100000,
        valorInicial: 0,
        taxaMensalPercentual: 0.8,
        meses: 120,
      );
      expect(aporte, closeTo(499.46, 0.5));

      // A PROVA REAL: guardando esse valor, chega na meta.
      final chegou = CalculationsService.montanteJurosCompostos(
        valorInicial: 0,
        aporteMensal: aporte,
        taxaMensalPercentual: 0.8,
        meses: 120,
      );
      expect(chegou, closeTo(100000, 50));
    });

    test('cálculo reverso com taxa zero', () {
      final aporte = CalculationsService.aporteNecessario(
        meta: 12000,
        valorInicial: 0,
        taxaMensalPercentual: 0,
        meses: 12,
      );
      expect(aporte, 1000.0);
    });

    test('se o valor inicial já passa da meta, aporte necessário é zero', () {
      final aporte = CalculationsService.aporteNecessario(
        meta: 1000,
        valorInicial: 5000,
        taxaMensalPercentual: 1,
        meses: 12,
      );
      expect(aporte, 0.0);
    });

    test('meses para a meta: R\$ 1.000/mês sem juros chega a 10 mil em 10', () {
      expect(
        CalculationsService.mesesParaMeta(
          meta: 10000,
          valorInicial: 0,
          aporteMensal: 1000,
          taxaMensalPercentual: 0,
        ),
        10,
      );
    });

    test('meses para a meta com juros', () {
      expect(
        CalculationsService.mesesParaMeta(
          meta: 100000,
          valorInicial: 0,
          aporteMensal: 500,
          taxaMensalPercentual: 0.8,
        ),
        120,
      );
    });

    test('já tem o valor: zero meses', () {
      expect(
        CalculationsService.mesesParaMeta(
          meta: 1000,
          valorInicial: 1000,
          aporteMensal: 100,
          taxaMensalPercentual: 1,
        ),
        0,
      );
    });

    test('sem aporte e sem juros é impossível: devolve -1', () {
      expect(
        CalculationsService.mesesParaMeta(
          meta: 1000,
          valorInicial: 0,
          aporteMensal: 0,
          taxaMensalPercentual: 0,
        ),
        -1,
      );
    });

    test('meses em texto amigável', () {
      expect(CalculationsService.mesesEmTexto(30), '2 anos e 6 meses');
      expect(CalculationsService.mesesEmTexto(12), '1 ano');
      expect(CalculationsService.mesesEmTexto(1), '1 mês');
      expect(CalculationsService.mesesEmTexto(0), 'Você já tem o valor');
      expect(
        CalculationsService.mesesEmTexto(-1),
        'Não é possível com esses valores',
      );
    });
  });

  // =====================================================================
  group('Custos fixos e variação', () {
    test('rateio: R\$ 900 por mês em 10 dias = R\$ 300', () {
      expect(
        CalculationsService.ratearCustosFixos(
          custoFixoMensal: 900,
          diasDoPeriodo: 10,
        ),
        300.0,
      );
    });

    test('rateio com zero dias devolve zero', () {
      expect(
        CalculationsService.ratearCustosFixos(
          custoFixoMensal: 900,
          diasDoPeriodo: 0,
        ),
        0.0,
      );
    });

    test('variação percentual entre períodos', () {
      expect(
        CalculationsService.variacaoPercentual(atual: 150, anterior: 100),
        50.0,
      );
      expect(
        CalculationsService.variacaoPercentual(atual: 50, anterior: 100),
        -50.0,
      );
    });

    test('período anterior zerado: cresceu do nada = 100%', () {
      expect(
        CalculationsService.variacaoPercentual(atual: 500, anterior: 0),
        100.0,
      );
      expect(
        CalculationsService.variacaoPercentual(atual: 0, anterior: 0),
        0.0,
      );
    });
  });

  // =====================================================================
  group('Resumo de período (o que alimenta telas, Excel e PDF)', () {
    late List<LancamentoDiario> lancamentos;
    late List<Gasto> gastos;

    setUp(() {
      lancamentos = <LancamentoDiario>[
        LancamentoDiario(
          data: DateTime(2026, 9, 1),
          km: 240,
          valorBruto: 347.89,
          horas: 8.5,
          corridas: 23,
          kmPorLitro: 12,
          precoLitro: 6.19,
        ),
        LancamentoDiario(
          data: DateTime(2026, 9, 2),
          km: 180,
          valorBruto: 280.00,
          horas: 7,
          corridas: 19,
          kmPorLitro: 12,
          precoLitro: 6.19,
        ),
      ];
      gastos = <Gasto>[
        Gasto(
          data: DateTime(2026, 9, 1),
          categoria: 'Lavagem',
          valor: 40,
        ),
        Gasto(
          data: DateTime(2026, 9, 2),
          categoria: 'Pedágio',
          valor: 12.50,
        ),
        Gasto(
          data: DateTime(2026, 9, 2),
          categoria: 'Lavagem',
          valor: 20,
        ),
      ];
    });

    test('soma os valores brutos, km, horas e corridas', () {
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: gastos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
      );
      expect(r.valorBruto, 627.89);
      expect(r.km, 420.0);
      expect(r.horas, 15.5);
      expect(r.corridas, 42);
      expect(r.diasTrabalhados, 2);
    });

    test('combustível: 420 km a 12 km/L = 35 L a R\$ 6,19', () {
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: gastos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
      );
      expect(r.litros, 35.0);
      expect(r.custoCombustivel, 216.65);
    });

    test('lucro bruto e lucro líquido', () {
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: gastos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
      );
      // 627,89 − 216,65 = 411,24
      expect(r.lucroBruto, 411.24);
      // gastos: 40 + 12,50 + 20 = 72,50  ->  411,24 − 72,50 = 338,74
      expect(r.outrosGastos, 72.50);
      expect(r.lucroLiquido, 338.74);
    });

    test('agrupa gastos por categoria somando as repetidas', () {
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: gastos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
      );
      expect(r.gastosPorCategoria['Lavagem'], 60.0);
      expect(r.gastosPorCategoria['Pedágio'], 12.50);
      expect(r.gastosPorCategoria.length, 2);
    });

    test('série do gráfico sai em ordem de data', () {
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: gastos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
      );
      final datas = r.lucroPorDia.keys.toList();
      expect(datas.length, 2);
      expect(datas.first.isBefore(datas.last), isTrue);
    });

    test('custos fixos são rateados pelos dias do período', () {
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: gastos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
        custosFixosMensais: 900,
      );
      // 900 ÷ 30 × 2 dias = 60
      expect(r.custosFixosRateados, 60.0);
      expect(r.lucroFinal, 278.74);
    });

    test('período sem nenhum lançamento devolve tudo zerado, sem erro', () {
      final r = CalculationsService.resumir(
        lancamentos: <LancamentoDiario>[],
        gastos: <Gasto>[],
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 30),
      );
      expect(r.vazio, isTrue);
      expect(r.valorBruto, 0.0);
      expect(r.ganhoPorHora, 0.0);
      expect(r.custoPorKm, 0.0);
      expect(r.ticketMedio, 0.0);
      expect(r.margemLucro, 0.0);
      expect(r.diasTrabalhados, 0);
    });

    test('usando o custo REAL do posto em vez da estimativa', () {
      final abastecimentos = <Abastecimento>[
        Abastecimento(
          data: DateTime(2026, 9, 1),
          litros: 40,
          precoLitro: 6.19,
          descontoReais: 10,
        ),
      ];
      final r = CalculationsService.resumir(
        lancamentos: lancamentos,
        gastos: <Gasto>[],
        abastecimentos: abastecimentos,
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 2),
        usarCustoRealAbastecimento: true,
      );
      // 40 × 6,19 = 247,60  −  10 de desconto = 237,60
      expect(r.custoCombustivel, 237.60);
    });

    test('lançamento com KM zero não quebra os indicadores', () {
      final r = CalculationsService.resumir(
        lancamentos: <LancamentoDiario>[
          LancamentoDiario(
            data: DateTime(2026, 9, 1),
            km: 0,
            valorBruto: 100,
            horas: 0,
            corridas: 0,
          ),
        ],
        gastos: <Gasto>[],
        inicio: DateTime(2026, 9, 1),
        fim: DateTime(2026, 9, 1),
      );
      expect(r.custoPorKm, 0.0);
      expect(r.lucroPorKm, 0.0);
      expect(r.ganhoPorHora, 0.0);
      expect(r.ticketMedio, 0.0);
      expect(r.valorBruto, 100.0);
    });
  });

  // =====================================================================
  // VEÍCULO ELÉTRICO
  // =====================================================================
  group('Veículo elétrico', () {
    test('rendimento: 289 km com bateria de 39,4 kWh dá 7,335 km/kWh', () {
      expect(
        CalculationsService.rendimentoEletrico(
          autonomiaKm: 289,
          capacidadeKwh: 39.4,
        ),
        7.335,
      );
    });

    test('rendimento com bateria zerada não estoura: devolve 0', () {
      expect(
        CalculationsService.rendimentoEletrico(
          autonomiaKm: 289,
          capacidadeKwh: 0,
        ),
        0.0,
      );
      expect(
        CalculationsService.rendimentoEletrico(
          autonomiaKm: 0,
          capacidadeKwh: 39.4,
        ),
        0.0,
      );
    });

    test('carga cheia: 39,4 kWh a R\$ 0,90 custa R\$ 35,46', () {
      expect(
        CalculationsService.custoDaCargaCheia(
          capacidadeKwh: 39.4,
          precoKwh: 0.90,
        ),
        35.46,
      );
    });

    test('carga cheia com preço zerado devolve 0', () {
      expect(
        CalculationsService.custoDaCargaCheia(
          capacidadeKwh: 39.4,
          precoKwh: 0,
        ),
        0.0,
      );
    });

    test('cargas necessárias: 400 km com autonomia de 289 km', () {
      expect(
        CalculationsService.cargasNecessarias(km: 400, autonomiaKm: 289),
        1.384,
      );
    });

    test('o elétrico entra nas contas comuns sem fórmula nova', () {
      // O rendimento vira o "km por unidade" de sempre, e o preço do kWh
      // vira o "preço da unidade". A conta do custo é EXATAMENTE a mesma
      // que a de um carro a gasolina.
      final rendimento = CalculationsService.rendimentoEletrico(
        autonomiaKm: 289,
        capacidadeKwh: 39.4,
      );
      final custo = CalculationsService.custoCombustivelPorRodagem(
        km: 289,
        kmPorLitro: rendimento,
        precoLitro: 0.90,
      );
      // Rodar exatamente uma carga tem de custar o preço de uma carga.
      expect((custo - 35.46).abs() < 0.05, isTrue);
    });
  });
}
