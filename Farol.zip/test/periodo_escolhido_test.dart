/// Testes das regras de calendário do painel.
///
/// Aqui não há dinheiro nenhum: o que se confere é se o período que o
/// motorista escolheu vira o intervalo de datas certo. Se estas contas
/// errarem, o relatório inteiro mostra o mês errado.
library;

import 'package:farol/domain/entities/periodo_escolhido.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Dias no mês', () {
    test('meses de 31, 30 e fevereiro', () {
      expect(PeriodoEscolhido.diasNoMes(2026, 1), 31);
      expect(PeriodoEscolhido.diasNoMes(2026, 4), 30);
      expect(PeriodoEscolhido.diasNoMes(2026, 2), 28);
    });

    test('fevereiro em ano bissexto tem 29', () {
      expect(PeriodoEscolhido.diasNoMes(2024, 2), 29);
      expect(PeriodoEscolhido.diasNoMes(2028, 2), 29);
    });
  });

  group('Semanas do mês', () {
    test('setembro de 2026 começa numa terça', () {
      // 01/09/2026 é terça-feira. A primeira semana vai de 1 a 6
      // (domingo), depois entram as semanas cheias.
      final semanas = PeriodoEscolhido.semanasDoMes(2026, 9);

      expect(semanas.first.numero, 1);
      expect(semanas.first.inicio.day, 1);
      expect(semanas.first.fim.day, 6);

      expect(semanas[1].inicio.day, 7);
      expect(semanas[1].fim.day, 13);
    });

    test('a última semana termina no último dia do mês', () {
      for (var mes = 1; mes <= 12; mes++) {
        final semanas = PeriodoEscolhido.semanasDoMes(2026, mes);
        expect(
          semanas.last.fim.day,
          PeriodoEscolhido.diasNoMes(2026, mes),
          reason: 'mês $mes',
        );
        expect(semanas.first.inicio.day, 1, reason: 'mês $mes');
      }
    });

    test('as semanas cobrem o mês inteiro, sem buraco e sem sobra', () {
      final semanas = PeriodoEscolhido.semanasDoMes(2026, 3);
      var esperado = 1;
      for (final s in semanas) {
        expect(s.inicio.day, esperado);
        esperado = s.fim.day + 1;
      }
      expect(esperado - 1, PeriodoEscolhido.diasNoMes(2026, 3));
    });

    test('descobre em que semana uma data cai', () {
      // 10/09/2026 está na segunda semana (07 a 13).
      expect(PeriodoEscolhido.numeroDaSemana(DateTime(2026, 9, 10)), 2);
      expect(PeriodoEscolhido.numeroDaSemana(DateTime(2026, 9, 1)), 1);
    });
  });

  group('Intervalo do período escolhido', () {
    test('dia', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.dia,
        ano: 2026,
        mes: 6,
        dia: 3,
        semana: 1,
      );
      expect(p.inicio, DateTime(2026, 6, 3));
      expect(p.fim, DateTime(2026, 6, 3, 23, 59, 59));
      expect(p.rotulo, '03/06/2026');
    });

    test('mês', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.mes,
        ano: 2025,
        mes: 2,
        dia: 1,
        semana: 1,
      );
      expect(p.inicio, DateTime(2025, 2, 1));
      expect(p.fim, DateTime(2025, 2, 28, 23, 59, 59));
      expect(p.rotulo, 'Fevereiro de 2025');
    });

    test('ano', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.ano,
        ano: 2024,
        mes: 5,
        dia: 9,
        semana: 2,
      );
      expect(p.inicio, DateTime(2024, 1, 1));
      expect(p.fim, DateTime(2024, 12, 31, 23, 59, 59));
      expect(p.rotulo, 'Ano de 2024');
    });

    test('semana devolve o pedaço certo do mês', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.semana,
        ano: 2026,
        mes: 9,
        dia: 1,
        semana: 2,
      );
      expect(p.inicio.day, 7);
      expect(p.fim.day, 13);
    });
  });

  group('Proteções contra data impossível', () {
    test('dia 31 num mês de 30 vira o dia 30', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.dia,
        ano: 2026,
        mes: 4, // abril tem 30
        dia: 31,
        semana: 1,
      );
      expect(p.inicio.day, 30);
      expect(p.fim.day, 30);
    });

    test('trocar de mês ajusta o dia sozinho', () {
      const janeiro = PeriodoEscolhido(
        escopo: EscopoPeriodo.dia,
        ano: 2026,
        mes: 1,
        dia: 31,
        semana: 1,
      );
      final fevereiro = janeiro.copiarCom(mes: 2);
      expect(fevereiro.dia, 28);
    });

    test('semana 5 num mês que só tem 4 não quebra', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.semana,
        ano: 2026,
        mes: 2,
        dia: 1,
        semana: 9,
      );
      // Não pode estourar: cai na última semana existente.
      expect(p.fim.day, PeriodoEscolhido.diasNoMes(2026, 2));
    });
  });

  group('Andar para frente e para trás', () {
    test('mês anterior a janeiro é dezembro do ano passado', () {
      const janeiro = PeriodoEscolhido(
        escopo: EscopoPeriodo.mes,
        ano: 2026,
        mes: 1,
        dia: 1,
        semana: 1,
      );
      final anterior = janeiro.anterior;
      expect(anterior.mes, 12);
      expect(anterior.ano, 2025);
    });

    test('próximo mês depois de dezembro é janeiro do ano seguinte', () {
      const dezembro = PeriodoEscolhido(
        escopo: EscopoPeriodo.mes,
        ano: 2026,
        mes: 12,
        dia: 1,
        semana: 1,
      );
      final proximo = dezembro.proximo;
      expect(proximo.mes, 1);
      expect(proximo.ano, 2027);
    });

    test('dia seguinte ao último do mês cai no mês seguinte', () {
      const ultimo = PeriodoEscolhido(
        escopo: EscopoPeriodo.dia,
        ano: 2026,
        mes: 1,
        dia: 31,
        semana: 5,
      );
      final proximo = ultimo.proximo;
      expect(proximo.mes, 2);
      expect(proximo.dia, 1);
    });

    test('semana anterior à primeira volta para o mês passado', () {
      const primeira = PeriodoEscolhido(
        escopo: EscopoPeriodo.semana,
        ano: 2026,
        mes: 6,
        dia: 1,
        semana: 1,
      );
      final anterior = primeira.anterior;
      expect(anterior.mes, 5);
      expect(
        anterior.semana,
        PeriodoEscolhido.semanasDoMes(2026, 5).length,
      );
    });

    test('ano anda de um em um', () {
      const p = PeriodoEscolhido(
        escopo: EscopoPeriodo.ano,
        ano: 2026,
        mes: 1,
        dia: 1,
        semana: 1,
      );
      expect(p.anterior.ano, 2025);
      expect(p.proximo.ano, 2027);
    });
  });

  test('nomes dos meses em português', () {
    expect(PeriodoEscolhido.nomeMes(6), 'Junho');
    expect(PeriodoEscolhido.nomeMes(9), 'Setembro');
    expect(PeriodoEscolhido.nomeMesCurto(3), 'Mar');
  });
}
