# 🚗 Farol

**Controle financeiro e de jornada para motoristas de aplicativo.**
100% offline — nenhum dado sai do celular.

---

## ⚡ Como gerar o APK (o jeito mais rápido)

1. Instale o Flutter uma única vez:
   https://docs.flutter.dev/get-started/install/windows
2. Dê **dois cliques em `COMPILAR.bat`**.
3. Espere. A primeira vez demora bastante (ele baixa o Android SDK e o Gradle).
4. O APK sai em `build\app\outputs\flutter-apk\app-release.apk`.
5. Passe esse arquivo para o celular e instale.

Tudo o que acontecer fica gravado em **`build_log.txt`**, na mesma pasta.
Se der erro, é esse arquivo que diz o motivo.

> O `COMPILAR.bat` faz sozinho: cria as pastas do Android, aplica as permissões
> de câmera e galeria, baixa as dependências, roda a análise do código e compila.
> Ele **protege o `lib/`** antes de rodar o `flutter create`, então seu código
> nunca é sobrescrito.

### Se preferir digitar os comandos

```bash
flutter create . --project-name farol --org br.com.motorista --platforms=android
# (rode o patch_manifest.ps1 para aplicar as permissões)
flutter pub get
flutter test          # roda os 121 testes dos cálculos e do OCR
flutter build apk --release
```

---

## 🧱 Como o projeto está organizado

```
lib/
├── core/            constantes, rotas, ícones das categorias, navegação
├── data/            modelos Hive + adapters + repositórios
├── domain/          entidades de resultado (ResumoPeriodo, AvaliacaoCorrida)
├── services/        ⭐ CalculationsService, OCR, exportação Excel/PDF, som
├── presentation/    telas, widgets e controllers
├── theme/           os 15 temas, tipografia e o construtor de ThemeData
└── utils/           formatadores pt-BR, validadores, extensões
test/                testes unitários dos cálculos e do parser de OCR
```

### Regras que o código segue

| Regra | Onde está garantida |
|---|---|
| Toda fórmula em UM lugar só | `services/calculations_service.dart` — nenhuma tela faz conta |
| Zero divisão por zero | `dividirSeguro()` e guardas em todos os métodos |
| Zero erro de arredondamento | `arredondar()` corrige o erro de ponto flutuante |
| 100% offline | Hive local; **sem permissão de INTERNET no manifesto** |
| Nada é salvo sem revisão (OCR) | `confirmacao_ocr_screen.dart` é obrigatória |
| pt-BR em tudo | `utils/formatters.dart` |

---

## 🖼️ O OCR do print (a função principal)

Fluxo: **imagem → pré-processamento → ML Kit → parser → confirmação → lançamento**

- `image_preprocessor.dart` gera **3 versões** da imagem (ajustada, cinza com
  contraste, alto contraste). O `OCRService` roda o OCR em todas e **fica com a
  melhor leitura** — é mais lento por alguns décimos de segundo e muito mais
  confiável do que apostar em uma versão só.
- `ocr_parser.dart` é **Dart puro** (sem câmera, sem plugin), por isso é testável.
  Ele acha os números por **palavra-chave + proximidade**: o rótulo pode estar
  na mesma linha, ou até 3 linhas acima do número (a Uber coloca a data no meio).
- **Cuidado que já rendeu um bug:** a palavra "corrida" aparece dentro de
  "distância per**corrida**". Sem comparação por palavra inteira
  (`contemPalavra()`), o app lia *415,8 km* como *415 corridas*. Há teste
  cobrindo exatamente isso.
- Nada é salvo automaticamente. A tela de confirmação mostra a **confiança de
  cada campo** e de qual trecho do texto o número saiu.

Layouts cobertos por teste: Uber semanal, Uber com tudo na mesma linha,
99 diário, e-mail de resumo mensal, foto ruim só com o valor, e o caso em que
um horário de relógio (`19:42`) **não** pode virar horas trabalhadas.

---

## 📊 Exportação

**Excel (2 abas):**
- `Painel` — dashboard com KPIs coloridos e barras feitas com fórmula `REPT`
- `Dados` — tabela completa com fórmulas **reais**

> As fórmulas são gravadas em inglês (`SUM`, `IF`, `SUMIF`, `AVERAGE`) porque é
> assim que o formato `.xlsx` funciona por dentro. O Excel em português mostra
> `SOMA`, `SE`, `SOMASE`, `MÉDIA` automaticamente. Gravar "SOMA" direto daria `#NOME?`.

**PDF:** capa com a marca, KPIs, gráficos desenhados sem imagem, tabelas e rodapé.

---

## ⚠️ Dois pontos que podem precisar de ajuste

**1. Formatação de moeda do Excel.**
Em `export_excel_service.dart`, o método `_fmt()` usa `NumFormat.custom(...)`.
Se a sua versão do pacote `excel` reclamar, **é só esse método que muda** — o
comentário em cima dele lista as alternativas. Os números e as fórmulas
continuam corretos de qualquer jeito.

**2. Fonte.**
O `google_fonts` baixa a Poppins da internet na primeira vez e guarda em cache.
Sem internet, o app usa a fonte do sistema e **nunca quebra**. Para garantir a
Poppins mesmo sem nunca ter internet:

1. Baixe os `.ttf` em https://fonts.google.com/specimen/Poppins
2. Coloque em `assets/fonts/`
3. Adicione no `pubspec.yaml`:
   ```yaml
   fonts:
     - family: Poppins
       fonts:
         - asset: assets/fonts/Poppins-Regular.ttf
         - asset: assets/fonts/Poppins-SemiBold.ttf
           weight: 600
         - asset: assets/fonts/Poppins-Bold.ttf
           weight: 700
   ```
4. Em `lib/theme/app_typography.dart`, troque `fonteEmbutida` para `true`.

---

## 🔊 Som

Funciona **sem nenhum arquivo de áudio** — os toques usam o som nativo do
sistema e a vibração do aparelho. Se quiser um som próprio de comemoração,
coloque `assets/sounds/comemoracao.mp3` e o app passa a usá-lo sozinho.

---

## 🧪 Testes

```bash
flutter test
```

121 casos cobrindo: arredondamento comercial, divisão por zero, combustível,
descontos, lucro, custo/KM, ganho/hora, metas, tempo de jornada com pausas,
avaliação de corrida, juros compostos (incluindo o cálculo reverso, validado
pela volta) e o parser de OCR.

---

## 💾 Cópia de segurança

Os dados vivem só neste celular. **Exportar o Excel de vez em quando é a
cópia de segurança** — se trocar de aparelho ou desinstalar o app, é o que
salva o histórico.
