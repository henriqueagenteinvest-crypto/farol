# 🚗 Farol

**Controle financeiro para motoristas de aplicativo.**
100% offline — nenhum dado sai do celular.

---

## ⚡ Como gerar o APK (o jeito mais rápido)

1. Instale o Flutter uma única vez:
   https://docs.flutter.dev/get-started/install/windows
2. Dê **dois cliques em `COMPILAR.bat`**.
3. Espere. A primeira vez demora bastante (ele baixa o Android SDK e o Gradle).
4. O APK sai em `build\app\outputs\flutter-apk\app-release.apk`.
5. Passe esse arquivo para o celular e instale.

Tudo o que acontecer fica gravado em **`build_log.txt`**, na mesma pasta.
Se der erro, é esse arquivo que diz o motivo.

> O `COMPILAR.bat` faz sozinho: cria as pastas do Android, aplica o manifesto,
> baixa as dependências, roda a análise do código e compila.
> Ele **protege o `lib/`** antes de rodar o `flutter create`, então seu código
> nunca é sobrescrito.

### Se preferir digitar os comandos

```bash
flutter create . --project-name farol --org br.com.motorista --platforms=android
# (rode o patch_manifest.ps1 para aplicar o manifesto)
flutter pub get
flutter test          # roda os testes dos cálculos
flutter build apk --release
```

---

## 🧱 Como o projeto está organizado

```
lib/
├── core/            constantes, rotas, ícones das categorias, navegação
├── data/            modelos Hive + adapters + repositórios
├── domain/          entidades de resultado (ResumoPeriodo, SemanaDeTrabalho)
├── services/        ⭐ CalculationsService, exportação Excel/PDF, som
├── presentation/    telas, widgets e controllers
├── theme/           os 15 temas, tipografia e o construtor de ThemeData
└── utils/           formatadores pt-BR, validadores, extensões
test/                testes unitários dos cálculos
```

### Regras que o código segue

| Regra | Onde está garantida |
|---|---|
| Toda fórmula em UM lugar só | `services/calculations_service.dart` — nenhuma tela faz conta |
| Zero divisão por zero | `dividirSeguro()` e guardas em todos os métodos |
| Zero erro de arredondamento | `arredondar()` corrige o erro de ponto flutuante |
| 100% offline | Hive local; **sem permissão de INTERNET no manifesto** |
| Histórico nunca se perde | `categoriasGastoHistoricas` e campos antigos preservados |
| pt-BR em tudo | `utils/formatters.dart` |

---

## 📅 O painel da semana (a tela principal)

Responde a pergunta que o motorista faz de verdade: **como foi a minha semana,
dia a dia?**

- Os **sete dias**, de segunda a domingo, sempre todos — inclusive os vazios.
- Cada dia mostra **faturado, tempo trabalhado, lucro e corridas**, cada um com
  a sua barrinha. A régua das barras é o **maior valor da própria semana**, então
  bate o olho e já se vê qual dia rendeu mais.
- O **melhor dia ganha o troféu** e uma borda verde. O dia de hoje ganha borda azul.
- **Tocar em qualquer dia abre o lançamento daquele dia — inclusive dias já
  passados.** É por aí que se corrige um erro de digitação de terça-feira na
  sexta. Se o dia tiver mais de um lançamento, o app pergunta qual você quer mexer.
- Setas ‹ › andam entre as semanas; o botão **Hoje** volta para a semana atual.

### Dois modos de leitura (Aparência → Como mostrar os números)

| Modo | Como fica |
|---|---|
| **Indicadores** | cartões, barras, ícones e cores — visual de painel |
| **Texto** | tabela enxuta de nome e valor, sem gráfico nenhum |

A escolha fica **gravada** e vale para a Semana e para o Painel.

---

## 📊 Exportação

**Excel (2 abas):**
- `Painel` — dashboard com KPIs coloridos e barras feitas com fórmula `REPT`
- `Dados` — tabela completa com fórmulas **reais**

> As fórmulas são gravadas em inglês (`SUM`, `IF`, `SUMIF`, `AVERAGE`) porque é
> assim que o formato `.xlsx` funciona por dentro. O Excel em português mostra
> `SOMA`, `SE`, `SOMASE`, `MÉDIA` automaticamente. Gravar "SOMA" direto daria `#NOME?`.

**PDF:** capa com a marca, KPIs, gráficos desenhados sem imagem, tabelas e rodapé.

---

## ⚠️ Dois pontos que podem precisar de ajuste

**1. Formatação de moeda do Excel.**
Em `export_excel_service.dart`, o método `_fmt()` usa `NumFormat.custom(...)`.
Se a sua versão do pacote `excel` reclamar, **é só esse método que muda** — o
comentário em cima dele lista as alternativas. Os números e as fórmulas
continuam corretos de qualquer jeito.

**2. Fonte.**
O `google_fonts` baixa a Poppins da internet na primeira vez e guarda em cache.
Sem internet, o app usa a fonte do sistema e **nunca quebra**. Para garantir a
Poppins mesmo sem nunca ter internet:

1. Baixe os `.ttf` em https://fonts.google.com/specimen/Poppins
2. Coloque em `assets/fonts/`
3. Adicione no `pubspec.yaml`:
   ```yaml
   fonts:
     - family: Poppins
       fonts:
         - asset: assets/fonts/Poppins-Regular.ttf
         - asset: assets/fonts/Poppins-SemiBold.ttf
           weight: 600
         - asset: assets/fonts/Poppins-Bold.ttf
           weight: 700
   ```
4. Em `lib/theme/app_typography.dart`, troque `fonteEmbutida` para `true`.

---

## 🔊 Som

Funciona **sem nenhum arquivo de áudio** — os toques usam o som nativo do
sistema e a vibração do aparelho. Se quiser um som próprio de comemoração,
coloque `assets/sounds/comemoracao.mp3` e o app passa a usá-lo sozinho.

---

## 🧪 Testes

```bash
flutter test
```

Cobrem: arredondamento comercial, divisão por zero, combustível (gasolina,
álcool, GNV e elétrico — a conta é a mesma, só muda a unidade), descontos,
lucro, custo/KM, ganho/hora, metas e recortes de período (dia, semana, mês,
ano, personalizado).

---

## 💾 Cópia de segurança

Os dados vivem só neste celular. **Exportar o Excel de vez em quando é a
cópia de segurança** — se trocar de aparelho ou desinstalar o app, é o que
salva o histórico.
